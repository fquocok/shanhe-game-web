"""Runtime overlay for Shanhe stat profiles.

Do not edit battle_core/combatant_profile.py: WO114 / WO116 authenticate
that file as unchanged adjacent source. This hook only mutates the live
registry after import, and is invoked by the Shanhe web bridge and
Shanhe tests — never by official Battle Canon tests.
"""
from __future__ import annotations

import gc
from types import MappingProxyType
from typing import Mapping

SHANHE_STAT_PROFILES: dict[str, Mapping[str, object]] = {
    "stat:shanhe:night_thief_80": MappingProxyType(
        {"max_hp": 80, "initial_qi": 20, "content_layer": "shanhe"}
    ),
}

_installed_keys: list[str] = []


def install_shanhe_stat_profiles() -> None:
    import battle_core.combatant_profile as cp

    missing = [key for key in SHANHE_STAT_PROFILES if key not in cp.STAT_PROFILE_REGISTRY]
    if not missing:
        return
    underlying = next(
        (item for item in gc.get_referents(cp.STAT_PROFILE_REGISTRY) if isinstance(item, dict)),
        None,
    )
    if underlying is None:
        raise RuntimeError(
            "cannot overlay Shanhe stat profiles: STAT_PROFILE_REGISTRY is not a mappingproxy over a dict"
        )
    for key in missing:
        underlying[key] = SHANHE_STAT_PROFILES[key]
        _installed_keys.append(key)
        if key not in cp.STAT_PROFILE_REGISTRY:
            raise RuntimeError(f"failed to install Shanhe stat profile {key}")


def uninstall_shanhe_stat_profiles() -> None:
    if not _installed_keys:
        return
    import battle_core.combatant_profile as cp

    underlying = next(
        (item for item in gc.get_referents(cp.STAT_PROFILE_REGISTRY) if isinstance(item, dict)),
        None,
    )
    if underlying is None:
        return
    for key in list(_installed_keys):
        underlying.pop(key, None)
        _installed_keys.remove(key)

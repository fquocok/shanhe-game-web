"""Presentation-only Character Art Production Interface v1.0.

This module validates external-art metadata and selects a renderer path. It owns no
battle truth, motion, range, targeting, damage, or combatant validity.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path
import json
import re
import struct
from types import MappingProxyType
from typing import Any, Iterable, Mapping

from .combatant_body_spec import BODY_PROPORTION_PROFILES, STANDARD_HUMANOID


CHARACTER_ART_PRODUCTION_INTERFACE = "CHARACTER_ART_PRODUCTION_INTERFACE_V1_0"
CHARACTER_CANVAS_CONTRACT = "CHARACTER_CANVAS_CONTRACT_V1_0"
ART_RIG_PROFILE_CONTRACT = "ART_RIG_PROFILE_V1_0"
SOCKET_CONTRACT = "CHARACTER_ART_SOCKET_CONTRACT_V1_0"
WEAPON_ATTACHMENT_CONTRACT = "WEAPON_ART_ATTACHMENT_CONTRACT_V1_0"
CLOTHING_LAYER_CONTRACT = "CLOTHING_LAYER_CONTRACT_V1_0"
COORDINATE_CONTRACT = "CHARACTER_ART_COORDINATE_CONTRACT_V1_0"
GLOBAL_ART_ASSET_ID_CONVENTION = "GLOBAL_ART_ASSET_ID_CONVENTION_V1_0"
ASSET_CONTRACT_VERSION = "character_art_v1"
GOLDEN_ASSET_SET_CONTRACT = "GOLDEN_CHARACTER_ASSET_SET_V0_1"


class MirrorPolicy(str, Enum):
    SAFE = "SAFE"
    CUSTOM_LEFT_REQUIRED = "CUSTOM_LEFT_REQUIRED"
    DIRECTION_AGNOSTIC = "DIRECTION_AGNOSTIC"


class AssetStatus(str, Enum):
    CONCEPT_ONLY = "CONCEPT_ONLY"
    PROTOTYPE = "PROTOTYPE"
    PRODUCTION_READY = "PRODUCTION_READY"
    DEPRECATED = "DEPRECATED"


class RendererKind(str, Enum):
    PROCEDURAL_RENDERER = "PROCEDURAL_RENDERER"
    EXTERNAL_ART_RENDERER = "EXTERNAL_ART_RENDERER"


ART_ASSET_DOMAINS = frozenset({"character", "body", "hair", "clothing", "weapon", "vfx", "portrait", "icon"})
ART_ASSET_ID_PATTERN = re.compile(
    r"^art_(?P<domain>character|body|hair|clothing|weapon|vfx|portrait|icon)_"
    r"(?P<family>[a-z0-9]+(?:-[a-z0-9]+)*)_"
    r"(?P<subject>[a-z0-9]+(?:-[a-z0-9]+)*)_"
    r"(?P<variant>[a-z0-9]+(?:-[a-z0-9]+)*)$"
)

CHARACTER_CANVAS = MappingProxyType({
    "contract": CHARACTER_CANVAS_CONTRACT,
    "width": 384,
    "height": 256,
    "unit": "transparent_png_pixel",
    "ground_anchor": (192, 208),
    "body_root": (192, 148),
    "canonical_facing": "RIGHT",
    "positive_x": "RIGHT_FORWARD",
    "positive_y": "DOWN",
    "alpha": "STRAIGHT_ALPHA_RGBA",
    "body_clothing_overflow": "CLIP_TO_CHARACTER_CANVAS",
    "weapon_overflow": "ALLOWED_WITHIN_CHARACTER_CANVAS",
    "vfx_space": "VFX_INDEPENDENT_V1_0",
    "display_scale_policy": "uniform_fit_from_logical_canvas; preserve aspect ratio; no gameplay authority",
})

KNOWN_CANVAS_CONTRACTS = frozenset({CHARACTER_CANVAS_CONTRACT, "VFX_INDEPENDENT_V1_0", "NOT_APPLICABLE_V1_0"})

CLOTHING_LAYER_STACK = (
    "rear_accessory", "rear_hair", "rear_weapon", "rear_arm_clothing", "rear_leg_clothing",
    "body_base", "torso_clothing", "front_leg_clothing", "front_arm_clothing",
    "front_weapon", "front_hair", "front_accessory",
)
KNOWN_LAYERS = frozenset(CLOTHING_LAYER_STACK)
WEAPON_LAYER_STACK = ("rear_weapon", "front_weapon")

LEGACY_APPEARANCE_LAYER_MAPPING = MappingProxyType({
    "BACK_HAIR": ("rear_hair",),
    "BODY_BASE": ("body_base",),
    "LOWER_GARMENT": ("rear_leg_clothing", "front_leg_clothing"),
    "UPPER_GARMENT": ("torso_clothing",),
    "SLEEVES": ("rear_arm_clothing", "front_arm_clothing"),
    "WAIST": ("torso_clothing", "front_accessory"),
    "FOOTWEAR": ("rear_leg_clothing", "front_leg_clothing"),
    "HANDS_WEAPON": ("rear_weapon", "front_weapon"),
    "FRONT_HAIR": ("front_hair",),
    "HEAD_ACCESSORY": ("front_accessory",),
    "FEEDBACK": (),
})

RIG_RELATIONSHIPS = MappingProxyType({
    "GROUND_ANCHOR": None,
    "BODY_ORIGIN": "GROUND_ANCHOR",
    "PELVIS_CENTER": "BODY_ORIGIN",
    "TORSO_CENTER": "PELVIS_CENTER",
    "NECK_ANCHOR": "TORSO_CENTER",
    "HEAD_CENTER": "NECK_ANCHOR",
    "LEFT_SHOULDER": "TORSO_CENTER", "LEFT_ELBOW": "LEFT_SHOULDER", "LEFT_HAND": "LEFT_ELBOW",
    "RIGHT_SHOULDER": "TORSO_CENTER", "RIGHT_ELBOW": "RIGHT_SHOULDER", "RIGHT_HAND": "RIGHT_ELBOW",
    "LEFT_HIP": "PELVIS_CENTER", "LEFT_KNEE": "LEFT_HIP", "LEFT_FOOT": "LEFT_KNEE",
    "RIGHT_HIP": "PELVIS_CENTER", "RIGHT_KNEE": "RIGHT_HIP", "RIGHT_FOOT": "RIGHT_KNEE",
})


def _canvas_point(joint_id: str) -> tuple[float, float]:
    joint = next(joint for joint in STANDARD_HUMANOID.joints if joint.joint_id == joint_id)
    ground = next(joint for joint in STANDARD_HUMANOID.joints if joint.joint_id == "GROUND_ANCHOR")
    gx, gy = CHARACTER_CANVAS["ground_anchor"]
    return round(gx + joint.x * 11.0, 3), round(gy + (joint.y - ground.y) * 11.0, 3)


ART_RIG_PROFILE = MappingProxyType({
    "contract": ART_RIG_PROFILE_CONTRACT,
    "rig_type": "PROCEDURAL_POSE_POINT_RIG",
    "body_spec": STANDARD_HUMANOID.spec_id,
    "body_profiles": tuple(BODY_PROPORTION_PROFILES),
    "joint_semantics": tuple(RIG_RELATIONSHIPS),
    "logical_relationships": RIG_RELATIONSHIPS,
    "standard_canvas_points": MappingProxyType({joint_id: _canvas_point(joint_id) for joint_id in RIG_RELATIONSHIPS}),
    "hierarchical_bone_transform_authority": False,
    "presentation_only": True,
})

SOCKET_BINDINGS = MappingProxyType({
    "left_hand_socket": {"source_joint": "LEFT_HAND", "standard_canvas_point": _canvas_point("LEFT_HAND")},
    "right_hand_socket": {"source_joint": "RIGHT_HAND", "standard_canvas_point": _canvas_point("RIGHT_HAND")},
    "back_weapon_socket": {"source_joint": "TORSO_CENTER", "standard_canvas_point": _canvas_point("TORSO_CENTER")},
    "waist_weapon_socket": {"source_joint": "PELVIS_CENTER", "standard_canvas_point": _canvas_point("PELVIS_CENTER")},
    "head_accessory_socket": {"source_joint": "HEAD_CENTER", "standard_canvas_point": _canvas_point("HEAD_CENTER")},
    "back_accessory_socket": {"source_joint": "TORSO_CENTER", "standard_canvas_point": _canvas_point("TORSO_CENTER")},
    "hip_accessory_socket": {"source_joint": "LEFT_HIP", "standard_canvas_point": _canvas_point("LEFT_HIP")},
})
KNOWN_SOCKETS = frozenset(SOCKET_BINDINGS)

WEAPON_ATTACHMENT_PROFILES = MappingProxyType({
    "SWORD": {"origin": "asset_canvas", "pivot": "primary_grip", "primary_grip": "right_hand_socket", "secondary_grip": None,
              "overflow": "WITHIN_CHARACTER_CANVAS", "motion_support": "CURRENT"},
    "SABER": {"origin": "asset_canvas", "pivot": "primary_grip", "primary_grip": "right_hand_socket", "secondary_grip": None,
              "overflow": "WITHIN_CHARACTER_CANVAS", "motion_support": "CURRENT_AS_BLADE"},
    "FIST": {"origin": "asset_canvas", "pivot": None, "primary_grip": None, "secondary_grip": None,
             "overflow": "NONE", "motion_support": "CURRENT"},
    "SPEAR": {"origin": "asset_canvas", "pivot": "primary_grip", "primary_grip": "right_hand_socket", "secondary_grip": "left_hand_socket",
              "overflow": "ALLOWED_TO_CHARACTER_CANVAS_EDGE", "motion_support": "CURRENT_LONG_REACH"},
    "STAFF": {"origin": "asset_canvas", "pivot": "primary_grip", "primary_grip": "right_hand_socket", "secondary_grip": "left_hand_socket",
              "overflow": "ALLOWED_TO_CHARACTER_CANVAS_EDGE", "motion_support": "TBD"},
})

REQUIRED_METADATA_KEYS = frozenset({
    "asset_id", "asset_type", "display_name", "contract_version", "body_profile_compatibility",
    "canonical_facing", "mirror_policy", "canvas", "ground_anchor", "pivot", "layer",
    "socket_binding", "source_reference", "status", "runtime_file",
})


@dataclass(frozen=True)
class ValidationIssue:
    code: str
    field: str
    message: str


@dataclass(frozen=True)
class AssetValidationResult:
    valid: bool
    runtime_eligible: bool
    issues: tuple[ValidationIssue, ...]
    normalized_asset_id: str | None


def parse_art_asset_id(asset_id: str) -> dict[str, str] | None:
    match = ART_ASSET_ID_PATTERN.fullmatch(str(asset_id))
    return None if match is None else match.groupdict()


def validate_character_asset_metadata(metadata: Mapping[str, Any], *, require_file: bool = False,
                                      workspace: str | Path | None = None) -> AssetValidationResult:
    """Validate presentation metadata without loading or changing combat state."""
    issues: list[ValidationIssue] = []
    for key in sorted(REQUIRED_METADATA_KEYS - metadata.keys()):
        issues.append(ValidationIssue("REQUIRED_KEY_MISSING", key, f"required metadata key is missing: {key}"))
    asset_id = metadata.get("asset_id")
    parsed = parse_art_asset_id(str(asset_id)) if asset_id is not None else None
    if asset_id is not None and parsed is None:
        issues.append(ValidationIssue("ASSET_ID_INVALID", "asset_id", "asset_id must match the v1 ASCII lowercase convention"))
    if parsed and metadata.get("asset_type") != parsed["domain"]:
        issues.append(ValidationIssue("ASSET_TYPE_ID_MISMATCH", "asset_type", "asset_type must equal the asset ID domain"))
    if metadata.get("asset_type") not in ART_ASSET_DOMAINS:
        issues.append(ValidationIssue("ASSET_TYPE_UNKNOWN", "asset_type", "unknown art asset domain"))
    if metadata.get("contract_version") != ASSET_CONTRACT_VERSION:
        issues.append(ValidationIssue("CONTRACT_VERSION_UNKNOWN", "contract_version", "unsupported asset contract version"))
    profiles = metadata.get("body_profile_compatibility")
    if not isinstance(profiles, (list, tuple)) or not profiles:
        issues.append(ValidationIssue("BODY_PROFILE_REQUIRED", "body_profile_compatibility", "at least one body profile is required"))
    elif unknown := set(profiles) - set(BODY_PROPORTION_PROFILES):
        issues.append(ValidationIssue("BODY_PROFILE_UNKNOWN", "body_profile_compatibility", f"unknown body profile: {sorted(unknown)}"))
    if metadata.get("canonical_facing") != "RIGHT" and metadata.get("mirror_policy") != MirrorPolicy.DIRECTION_AGNOSTIC.value:
        issues.append(ValidationIssue("CANONICAL_FACING_INVALID", "canonical_facing", "canonical character art must face RIGHT"))
    if metadata.get("mirror_policy") not in {item.value for item in MirrorPolicy}:
        issues.append(ValidationIssue("MIRROR_POLICY_UNKNOWN", "mirror_policy", "unknown mirror policy"))
    if metadata.get("canvas") not in KNOWN_CANVAS_CONTRACTS:
        issues.append(ValidationIssue("CANVAS_CONTRACT_UNKNOWN", "canvas", "unknown canvas contract"))
    if metadata.get("canvas") == CHARACTER_CANVAS_CONTRACT and tuple(metadata.get("ground_anchor") or ()) != CHARACTER_CANVAS["ground_anchor"]:
        issues.append(ValidationIssue("GROUND_ANCHOR_INVALID", "ground_anchor", "character assets must use the v1 ground anchor"))
    if metadata.get("asset_type") != "vfx" and metadata.get("layer") not in KNOWN_LAYERS:
        issues.append(ValidationIssue("LAYER_UNKNOWN", "layer", "unknown character layer"))
    if metadata.get("asset_type") == "vfx" and metadata.get("canvas") != "VFX_INDEPENDENT_V1_0":
        issues.append(ValidationIssue("VFX_CANVAS_INVALID", "canvas", "VFX must use independent presentation space"))
    socket = metadata.get("socket_binding")
    if socket is not None and socket not in KNOWN_SOCKETS:
        issues.append(ValidationIssue("SOCKET_UNKNOWN", "socket_binding", "unknown presentation socket"))
    status = metadata.get("status")
    if status not in {item.value for item in AssetStatus}:
        issues.append(ValidationIssue("STATUS_UNKNOWN", "status", "unknown asset lifecycle status"))
    if status == AssetStatus.PRODUCTION_READY.value:
        for key in ("source_reference", "runtime_file", "display_name"):
            if not metadata.get(key):
                issues.append(ValidationIssue("PRODUCTION_METADATA_INCOMPLETE", key, f"production-ready asset requires {key}"))
    if require_file and metadata.get("runtime_file"):
        root = Path(workspace or ".")
        path = root / str(metadata["runtime_file"])
        if not path.is_file():
            issues.append(ValidationIssue("RUNTIME_FILE_MISSING", "runtime_file", "runtime file is missing; use procedural fallback"))
    valid = not issues
    return AssetValidationResult(valid, valid and status == AssetStatus.PRODUCTION_READY.value,
                                 tuple(issues), str(asset_id) if parsed else None)


class DuplicateArtAssetId(ValueError):
    pass


class ArtAssetRegistry:
    def __init__(self, entries: Iterable[Mapping[str, Any]] = ()) -> None:
        self._entries: dict[str, Mapping[str, Any]] = {}
        for entry in entries:
            self.register(entry)

    def register(self, metadata: Mapping[str, Any]) -> AssetValidationResult:
        result = validate_character_asset_metadata(metadata)
        if not result.valid:
            return result
        asset_id = str(metadata["asset_id"])
        if asset_id in self._entries:
            raise DuplicateArtAssetId(asset_id)
        self._entries[asset_id] = MappingProxyType(dict(metadata))
        return result

    def get(self, asset_id: str) -> Mapping[str, Any] | None:
        return self._entries.get(asset_id)

    def snapshot(self) -> Mapping[str, Mapping[str, Any]]:
        return MappingProxyType(dict(self._entries))


@dataclass(frozen=True)
class CharacterArtRenderBinding:
    renderer: RendererKind
    asset_id: str | None
    runtime_file: str | None
    reason: str
    battle_truth_changes: int = 0
    motion_semantic_changes: int = 0


@dataclass(frozen=True)
class CharacterArtLayerPackage:
    package_id: str
    package_root: Path
    layers: Mapping[str, Path]
    metadata: Mapping[str, Mapping[str, Any]]
    status: str
    prototype_opt_in: bool
    errors: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()

    @property
    def loadable(self) -> bool:
        return not self.errors and (self.status == AssetStatus.PRODUCTION_READY.value or self.prototype_opt_in)


@dataclass(frozen=True)
class WeaponArtLayerPackage:
    """A presentation-only weapon override containing one or both weapon layers."""
    package_id: str
    package_root: Path
    layers: Mapping[str, Path]
    metadata: Mapping[str, Mapping[str, Any]]
    status: str
    prototype_opt_in: bool
    weapon_family: str | None
    errors: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()

    @property
    def loadable(self) -> bool:
        return not self.errors and (self.status == AssetStatus.PRODUCTION_READY.value or self.prototype_opt_in)


def _png_header(path: Path) -> tuple[int, int, int, int]:
    with path.open("rb") as handle:
        signature = handle.read(8)
        length = struct.unpack(">I", handle.read(4))[0]
        chunk = handle.read(4)
        payload = handle.read(length)
    if signature != b"\x89PNG\r\n\x1a\n" or chunk != b"IHDR" or len(payload) < 13:
        raise ValueError("PNG_HEADER_INVALID")
    width, height, bit_depth, color_type = struct.unpack(">IIBB", payload[:10])
    return width, height, bit_depth, color_type


def load_character_art_layer_package(package_root: str | Path, *, allow_prototype: bool = False) -> CharacterArtLayerPackage:
    """Load one unchanged 12-layer package; prototype use requires an explicit dev opt-in."""
    root = Path(package_root).resolve()
    errors: list[str] = []
    warnings: list[str] = []
    metadata_by_layer: dict[str, Mapping[str, Any]] = {}
    layers: dict[str, Path] = {}
    metadata_dir = root / "metadata"
    if not metadata_dir.is_dir():
        errors.append("METADATA_DIRECTORY_MISSING")
    else:
        for metadata_path in sorted(metadata_dir.glob("*.json")):
            try:
                metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                errors.append(f"METADATA_PARSE_ERROR:{metadata_path.name}")
                continue
            result = validate_character_asset_metadata(metadata)
            errors.extend(f"{issue.code}:{metadata_path.name}:{issue.field}" for issue in result.issues)
            layer = metadata.get("layer")
            if layer in metadata_by_layer:
                errors.append(f"DUPLICATE_LAYER:{layer}")
                continue
            if layer in KNOWN_LAYERS:
                metadata_by_layer[layer] = MappingProxyType(dict(metadata))
                runtime_path = (root / str(metadata.get("runtime_file") or "")).resolve()
                try:
                    runtime_path.relative_to(root)
                except ValueError:
                    errors.append(f"RUNTIME_PATH_OUTSIDE_PACKAGE:{layer}")
                    continue
                if not runtime_path.is_file():
                    errors.append(f"RUNTIME_FILE_MISSING:{layer}:{runtime_path}")
                    continue
                try:
                    width, height, bit_depth, color_type = _png_header(runtime_path)
                except (OSError, ValueError, struct.error):
                    errors.append(f"PNG_HEADER_INVALID:{layer}")
                    continue
                if (width, height) != (CHARACTER_CANVAS["width"], CHARACTER_CANVAS["height"]):
                    errors.append(f"PNG_CANVAS_INVALID:{layer}:{width}x{height}")
                if (bit_depth, color_type) != (8, 6):
                    errors.append(f"PNG_RGBA8_REQUIRED:{layer}:depth={bit_depth}:color={color_type}")
                layers[layer] = runtime_path
    missing = KNOWN_LAYERS - metadata_by_layer.keys()
    extra = metadata_by_layer.keys() - KNOWN_LAYERS
    errors.extend(f"LAYER_MISSING:{layer}" for layer in sorted(missing))
    errors.extend(f"LAYER_UNKNOWN:{layer}" for layer in sorted(extra))
    statuses = {str(item.get("status")) for item in metadata_by_layer.values()}
    status = next(iter(statuses)) if len(statuses) == 1 else "MIXED"
    if len(statuses) > 1:
        errors.append("MIXED_ASSET_STATUS")
    if status == AssetStatus.PROTOTYPE.value and not allow_prototype:
        warnings.append("PROTOTYPE_REQUIRES_EXPLICIT_DEV_OPT_IN")
    elif status not in (AssetStatus.PROTOTYPE.value, AssetStatus.PRODUCTION_READY.value):
        errors.append(f"PACKAGE_STATUS_NOT_RENDERABLE:{status}")
    if status == AssetStatus.PROTOTYPE.value and allow_prototype:
        warnings.append("DEV_ONLY_PROTOTYPE_RENDERING_ENABLED")
    ordered_layers = {layer: layers[layer] for layer in CLOTHING_LAYER_STACK if layer in layers}
    ordered_metadata = {layer: metadata_by_layer[layer] for layer in CLOTHING_LAYER_STACK if layer in metadata_by_layer}
    return CharacterArtLayerPackage(root.name, root, MappingProxyType(ordered_layers), MappingProxyType(ordered_metadata),
                                    status, allow_prototype, tuple(errors), tuple(warnings))


def load_weapon_art_layer_package(package_root: str | Path, *, allow_prototype: bool = False) -> WeaponArtLayerPackage:
    """Load a standalone weapon override without requiring the other ten character layers."""
    root = Path(package_root).resolve()
    errors: list[str] = []
    warnings: list[str] = []
    metadata_by_layer: dict[str, Mapping[str, Any]] = {}
    layers: dict[str, Path] = {}
    metadata_dir = root / "metadata"
    if not metadata_dir.is_dir():
        errors.append("METADATA_DIRECTORY_MISSING")
    else:
        for metadata_path in sorted(metadata_dir.glob("*.json")):
            try:
                metadata = json.loads(metadata_path.read_text(encoding="utf-8-sig"))
            except (OSError, json.JSONDecodeError):
                errors.append(f"METADATA_PARSE_ERROR:{metadata_path.name}")
                continue
            result = validate_character_asset_metadata(metadata)
            errors.extend(f"{issue.code}:{metadata_path.name}:{issue.field}" for issue in result.issues)
            if metadata.get("asset_type") != "weapon":
                errors.append(f"ASSET_TYPE_NOT_WEAPON:{metadata_path.name}")
            layer = metadata.get("layer")
            if layer not in WEAPON_LAYER_STACK:
                errors.append(f"WEAPON_LAYER_INVALID:{metadata_path.name}:{layer}")
                continue
            if layer in metadata_by_layer:
                errors.append(f"DUPLICATE_LAYER:{layer}")
                continue
            if metadata.get("socket_binding") is None:
                errors.append(f"WEAPON_SOCKET_REQUIRED:{metadata_path.name}")
            family = metadata.get("weapon_family")
            if family not in WEAPON_ATTACHMENT_PROFILES or family == "FIST":
                errors.append(f"WEAPON_FAMILY_REQUIRED:{metadata_path.name}:{family}")
            metadata_by_layer[layer] = MappingProxyType(dict(metadata))
            runtime_path = (root / str(metadata.get("runtime_file") or "")).resolve()
            try:
                runtime_path.relative_to(root)
            except ValueError:
                errors.append(f"RUNTIME_PATH_OUTSIDE_PACKAGE:{layer}")
                continue
            if not runtime_path.is_file():
                errors.append(f"RUNTIME_FILE_MISSING:{layer}:{runtime_path}")
                continue
            try:
                width, height, bit_depth, color_type = _png_header(runtime_path)
            except (OSError, ValueError, struct.error):
                errors.append(f"PNG_HEADER_INVALID:{layer}")
                continue
            if (width, height) != (CHARACTER_CANVAS["width"], CHARACTER_CANVAS["height"]):
                errors.append(f"PNG_CANVAS_INVALID:{layer}:{width}x{height}")
            if (bit_depth, color_type) != (8, 6):
                errors.append(f"PNG_RGBA8_REQUIRED:{layer}:depth={bit_depth}:color={color_type}")
            layers[layer] = runtime_path
    if not metadata_by_layer:
        errors.append("WEAPON_LAYER_REQUIRED")
    statuses = {str(item.get("status")) for item in metadata_by_layer.values()}
    status = next(iter(statuses)) if len(statuses) == 1 else "MIXED"
    if len(statuses) > 1:
        errors.append("MIXED_ASSET_STATUS")
    if status == AssetStatus.PROTOTYPE.value and not allow_prototype:
        warnings.append("PROTOTYPE_REQUIRES_EXPLICIT_DEV_OPT_IN")
    elif status not in (AssetStatus.PROTOTYPE.value, AssetStatus.PRODUCTION_READY.value):
        errors.append(f"PACKAGE_STATUS_NOT_RENDERABLE:{status}")
    if status == AssetStatus.PROTOTYPE.value and allow_prototype:
        warnings.append("DEV_ONLY_PROTOTYPE_RENDERING_ENABLED")
    families = {str(item.get("weapon_family")) for item in metadata_by_layer.values()}
    weapon_family = next(iter(families)) if len(families) == 1 else None
    if len(families) > 1:
        errors.append("MIXED_WEAPON_FAMILY")
    ordered_layers = {layer: layers[layer] for layer in WEAPON_LAYER_STACK if layer in layers}
    ordered_metadata = {layer: metadata_by_layer[layer] for layer in WEAPON_LAYER_STACK if layer in metadata_by_layer}
    return WeaponArtLayerPackage(root.name, root, MappingProxyType(ordered_layers), MappingProxyType(ordered_metadata),
                                 status, allow_prototype, weapon_family, tuple(errors), tuple(warnings))


class CharacterArtAdapter:
    """Failure-safe renderer selection; missing art never invalidates a combatant."""
    def __init__(self, workspace: str | Path, registry: ArtAssetRegistry | None = None) -> None:
        self.workspace = Path(workspace)
        self.registry = registry or ArtAssetRegistry()

    def resolve(self, asset_id: str | None) -> CharacterArtRenderBinding:
        if not asset_id:
            return CharacterArtRenderBinding(RendererKind.PROCEDURAL_RENDERER, None, None, "NO_EXTERNAL_ASSET")
        metadata = self.registry.get(asset_id)
        if metadata is None:
            return CharacterArtRenderBinding(RendererKind.PROCEDURAL_RENDERER, asset_id, None, "ASSET_NOT_REGISTERED")
        result = validate_character_asset_metadata(metadata, require_file=True, workspace=self.workspace)
        if not result.runtime_eligible:
            code = result.issues[0].code if result.issues else "NOT_PRODUCTION_READY"
            return CharacterArtRenderBinding(RendererKind.PROCEDURAL_RENDERER, asset_id, None, code)
        return CharacterArtRenderBinding(RendererKind.EXTERNAL_ART_RENDERER, asset_id, str(metadata["runtime_file"]), "PRODUCTION_ASSET_READY")


def production_interface_snapshot() -> dict[str, Any]:
    return {
        "contract": CHARACTER_ART_PRODUCTION_INTERFACE,
        "status": "ESTABLISHED",
        "canvas": dict(CHARACTER_CANVAS),
        "rig": {"contract": ART_RIG_PROFILE_CONTRACT, "rig_type": ART_RIG_PROFILE["rig_type"]},
        "sockets": tuple(SOCKET_BINDINGS),
        "layers": CLOTHING_LAYER_STACK,
        "independent_weapon_layers": WEAPON_LAYER_STACK,
        "independent_weapon_overlay": True,
        "mirror_policies": tuple(item.value for item in MirrorPolicy),
        "asset_statuses": tuple(item.value for item in AssetStatus),
        "asset_contract_version": ASSET_CONTRACT_VERSION,
        "procedural_fallback": True,
        "battle_truth_semantic_changes": 0,
        "motion_semantic_changes": 0,
    }

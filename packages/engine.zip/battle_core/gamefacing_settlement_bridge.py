"""Single-authority GameFacing bridge to BattleEngine settled attack results."""
from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType
from typing import Iterable

from .engine import BattleEngine
from .runtime import ShieldLedger
from .schema import BasicAttackDefinition, CharacterDefinition, GridPosition
from .settled_damage_presentation import SettledTargetImpact
from .presentation_stream.compatibility import settled_impacts_from_semantics

BRIDGE_CONTRACT = "GAME_FACING_SETTLED_RESOLUTION_BRIDGE_V0_1"


@dataclass(frozen=True)
class GameFacingActionResolution:
    contract: str
    actor_id: str
    action_id: str
    action_display_name: str
    action_kind: str
    target_ids: tuple[str, ...]
    settled_impacts: tuple[SettledTargetImpact, ...]
    battle_settlement_count: int = 1
    terminal_state: str = "ACTIVE"


def _definition(identity: str, name: str, faction: str, row: str, column: int) -> CharacterDefinition:
    """Non-canonical encounter profile; BattleEngine remains numeric authority."""
    return CharacterDefinition(
        identity, name, 1, 20, 1, 10, 1, 30, 10, faction,
        GridPosition(row, column), BasicAttackDefinition(1.0), MappingProxyType({}),
    )


class GameFacingSettlementBridge:
    """Own one persistent engine and expose only its finalized immutable records."""
    def __init__(self, engine: BattleEngine, player_roster=(), enemy_roster=()):
        self.engine = engine
        self.settlement_count = 0
        self.checkpoint_presentation = False
        self.checkpoint_records = []
        self.checkpoint_action_catalog = {}
        self.player_roster = tuple(player_roster)
        self.enemy_roster = tuple(enemy_roster)

    @classmethod
    def for_encounter(cls, participants: Iterable, targets: Iterable, *, seed=39):
        target_items = tuple(targets)
        target_names = {item.character_id: item.display_name for item in target_items}
        target_teams = {item.character_id: item.team for item in target_items}
        participant_items = tuple(participants)
        identities = {item.bound.loadout.character_id for item in participant_items} | set(target_names)
        definitions = []
        occupied = {"player": set(), "enemy": set()}
        for index, identity in enumerate(sorted(identities)):
            participant = next((item for item in participant_items if item.bound.loadout.character_id == identity), None)
            faction = participant.team if participant else target_teams[identity]
            name = participant.bound.loadout.display_name if participant else target_names[identity]
            preferred = next((item for item in target_items if item.character_id == identity), None)
            candidates = [(preferred.row, preferred.column + 1)] if preferred else []
            candidates += [(row, column) for row in ("front", "middle", "back") for column in (1, 2, 3)]
            row, column = next(slot for slot in candidates if slot not in occupied[faction] and slot[1] in (1, 2, 3))
            occupied[faction].add((row, column)); definitions.append(_definition(identity, name, faction, row, column))
        engine = BattleEngine(tuple(definitions), seed=seed)
        player_roster = tuple(item.character_id for item in target_items if item.team == "player")
        enemy_roster = tuple(item.character_id for item in target_items if item.team == "enemy")
        bridge = cls(engine, player_roster, enemy_roster)
        for participant in participant_items:
            state = engine.state_by_id(participant.bound.loadout.character_id)
            state.current_hp = participant.bound.state.hp; state.max_hp = participant.bound.state.max_hp
            if participant.bound.state.shield:
                state.shield_pool.append(ShieldLedger("gamefacing_initial", participant.bound.state.shield))
        return bridge

    def terminal_outcome(self):
        """Read settled terminal truth; Pending is not confirmed defeated."""
        return (self.engine.terminal_outcome_for_roster(self.player_roster, self.enemy_roster)
                if self.player_roster and self.enemy_roster else self.engine.terminal_outcome("player"))

    def settle(self, *, actor_id: str, action_id: str, action_display_name: str,
               action_kind: str, target_ids: tuple[str, ...], targeting_pattern: str | None = None) -> GameFacingActionResolution:
        self.engine.require_ordinary_action_eligibility(actor_id, target_ids)
        self.settlement_count += 1
        attack_instance_id = f"{action_id}:gamefacing:{self.settlement_count}"
        history = self.engine.semantic_events.history
        semantic_cursor = history[-1].sequence if history else 0
        started = None
        if self.checkpoint_presentation:
            from .events import SemanticEventType as T, EventPhase as P
            started = self.engine.semantic_events.append(
                T.FORMAL_ACTION_STARTED, P.FORMAL_ACTION, actor_id=actor_id, action_id=action_id,
                payload={"action_classification": "formal_main" if action_kind == "MAIN_ACTION" else "ordinary_special",
                         "display_name": action_display_name, "content_action_id": action_id,
                         **self.checkpoint_action_catalog.get(actor_id, {})})
        self.engine.settle_action(actor_id, target_ids, action_id=action_id,
                                            attack_instance_id=attack_instance_id,
                                            targeting_pattern=targeting_pattern)
        if started is not None:
            self.engine.semantic_events.append(
                T.FORMAL_ACTION_COMPLETED, P.FORMAL_ACTION, actor_id=actor_id, action_id=action_id,
                causation_event_id=started.event_id, payload=dict(started.payload))
        if self.checkpoint_presentation:
            from .human_checkpoint.screen_adapter import screen_events
            frame = self.engine.presentation_frame(semantic_cursor)
            self.checkpoint_records.append({
                "frame": frame.to_dict(), "semantic_events": [
                    event.to_dict() for event in self.engine.semantic_events.history
                    if event.sequence > semantic_cursor],
                "screen_events": screen_events(frame),
                "actor_id": actor_id, "action_id": action_id, "action_kind": action_kind,
                "target_ids": tuple(target_ids)})
        impacts = settled_impacts_from_semantics(self.engine.semantic_events, semantic_cursor)
        return GameFacingActionResolution(
            BRIDGE_CONTRACT, actor_id, action_id, action_display_name, action_kind,
            tuple(target_ids), impacts, 1, self.engine.terminal_outcome_for_roster(self.player_roster, self.enemy_roster) if self.player_roster and self.enemy_roster else self.engine.terminal_outcome("player"),
        )

"""WO-037A4C1 generic formal Active roaming_distinct(N) diagnostics."""
from __future__ import annotations

from pathlib import Path
from types import MappingProxyType
import json

from .advanced_sword_main_targeting_resolution import REVISION_2_ID, FORMAL_NAME
from .durable_generated_registry import DEFAULT_REGISTRY_PATH, load_generated_registry
from .generated_acceptance import stable_hash
from .martial import (MartialActiveSkillDefinition, MartialPassiveDefinition,
                      MartialRoutineDefinition, validate_martial_definition)
from .numeric_token_valuation import evaluate_candidate_numeric_budget
from .generator import deserialize_candidate
from .revision_2_canonical_promotion import GeneratedCanonicalProvenance, definition_payload


CAPABILITY = "ACTIVE_ROAMING_FORMALIZATION_READY"


def _read(path: Path): return json.loads(path.read_text(encoding="utf-8"))


def compile_revision2_diagnostic(workspace: str | Path) -> MartialRoutineDefinition:
    root = Path(workspace); envelope = _read(root / "generated_candidates/wo037a4c/candidate_revision_2.json")
    revision_hash = envelope.pop("immutable_sha256"); candidate = envelope["candidate"]
    main, follow = candidate["actions"]
    canonical_id = "generated:sword:advanced:644fb8ab88e0:r2"
    provenance = GeneratedCanonicalProvenance(
        "generated_candidates/wo037a4c/candidate_revision_2.json", REVISION_2_ID, "2", "ADVANCED", 102,
        candidate_origin_id="gen_v01_advanced_sword_644fb8ab88e0",
        candidate_revision_id=REVISION_2_ID, candidate_sha256=revision_hash,
        review_package_id="DIAGNOSTIC_ONLY", review_package_sha256="",
        human_decision_id="NONE", numeric_token_policy_version="v0.2",
        promotion_work_order="NONE")
    active = MartialActiveSkillDefinition(
        canonical_id + ".active", FORMAL_NAME, int(main["cooldown"]),
        float(main["qi_cost_percent_max"]), str(main["targeting"]),
        float(main["damage_coefficient"]), "FIRST_PASS_GENERATED_VALUE final_balance_locked=false",
        requested_target_count=int(main["requested_target_count"]))
    params = MappingProxyType({
        "event_type": follow["trigger_fact"], "scope": follow["trigger_scope"],
        "probability": follow["base_chance"], "success_decay_multiplier": follow["decay"]["on_success_multiplier"],
        "failure_decay": follow["decay"]["on_failure"], "decay_reset": follow["decay"]["reset"],
        "action_ownership": follow["action_ownership"], "special_kind": "counterattack",
        "classification": "ordinary_special", "participates_in_ordinary_cap": True,
        "target_selector": follow["targeting"], "targeting_pattern": "single",
        "requested_target_count": follow["requested_target_count"], "coefficient": follow["damage_coefficient"]})
    passive = MartialPassiveDefinition(canonical_id + ".parry", FORMAL_NAME,
                                       "successful_parry_generic_special", params)
    return validate_martial_definition(MartialRoutineDefinition(
        canonical_id, FORMAL_NAME, "劍法", "advanced", 120, active, (passive,), provenance,
        (), ("diagnostic_only", "numeric_budget_used=102", "numeric_budget_limit=120"), "sword", ()))


def prepare_wo037a4c1(workspace: str | Path) -> dict:
    root = Path(workspace); revision_path = root / "generated_candidates/wo037a4c/candidate_revision_2.json"
    before = revision_path.read_bytes(); disk = _read(revision_path); revision_hash = disk.pop("immutable_sha256")
    if stable_hash(disk) != revision_hash: raise ValueError("REVISION_2_HASH_MISMATCH")
    definition = compile_revision2_diagnostic(root); payload = definition_payload(definition)
    candidate = deserialize_candidate(json.dumps(disk["candidate"], ensure_ascii=False))
    budget = evaluate_candidate_numeric_budget(candidate, policy_version="v0.2")
    readiness = {"status":"READY", "capability":CAPABILITY, "formal_compile_run":True,
                 "main_roaming_distinct_1":"LOSSLESS", "followup_roaming_distinct_2":"LOSSLESS",
                 "candidate_specific_branch_used":False, "single_target_coercion_used":False,
                 "promotion_run":False, "definition_sha256":stable_hash(payload)}
    representation = {"status":"LOSSLESS", "main":{"mode":"roaming_distinct","requested_target_count":1,"lossless":True},
                      "followup":{"mode":"roaming_distinct","requested_target_count":2,"lossless":True},
                      "independent":True, "parameter_leakage":False}
    old_review_path = root / "generated_candidates/wo037a4c/review_package_r2.json"
    old_review_bytes = old_review_path.read_bytes(); old_review = _read(old_review_path)
    old_review_hash = old_review.pop("immutable_sha256")
    review = {"review_package_schema":"WO037A4C1-refresh-v0.1",
              "review_package_id":"review:r2:refresh:"+stable_hash((REVISION_2_ID,revision_hash,stable_hash(readiness),stable_hash(representation)))[:16],
              "supersedes_review_package_id":old_review["review_package_id"],
              "revision_id":REVISION_2_ID,"revision_sha256":revision_hash,"formal_display_name":FORMAL_NAME,
              "validation_sha256":old_review["validation_sha256"],"token_evaluation":old_review["token_evaluation"],
              "numeric_token_policy_version":"v0.2","compiler_readiness":readiness,
              "formal_representation":representation,"formal_similarity":old_review["formal_similarity"],
              "infrastructure_evidence":"CODEX-WO-037A4C1","review_state":"PENDING_REVIEW",
              "human_decision":"NONE","canonical":False,"formal":False,"runtime_registered":False}
    registry_path=root/DEFAULT_REGISTRY_PATH; registry_bytes=registry_path.read_bytes(); loaded=load_generated_registry(root)
    controls={"revision_2_bytes_unchanged":revision_path.read_bytes()==before,"revision_2_hash_before":revision_hash,
              "revision_2_hash_after":stable_hash({k:v for k,v in _read(revision_path).items() if k!="immutable_sha256"}),
              "old_review_bytes_unchanged":old_review_path.read_bytes()==old_review_bytes,
              "old_review_hash":old_review_hash,"revision_3_created":False,"human_accepts":0,
              "promotion_attempts":0,"canonical_additions":0,"registry_before":loaded.count,
              "registry_after":load_generated_registry(root).count,"registry_bytes_unchanged":registry_path.read_bytes()==registry_bytes,
              "b1_untouched":True,"lane_c_deferred":True}
    return {"status":"PASS_ACTIVE_ROAMING_FORMALIZATION_VERIFIED_STOPPED_AT_HUMAN_REVIEW",
            "definition":definition,"definition_payload":payload,"readiness":readiness,
            "representation":representation,"budget":{"used":budget.total_used,"limit":budget.budget_limit,
            "remaining":budget.remaining,"policy":"v0.2"},"refreshed_review_package":review,
            "controls":controls,"versions":{"battle_core":"v0.9","generator":"v0.2-prototype",
            "acceptance":"v0.1-prototype","numeric_policy":"v0.2","registry_schema":"v0.1"},
            "stop":"STOPPED_AT_HUMAN_REVIEW"}

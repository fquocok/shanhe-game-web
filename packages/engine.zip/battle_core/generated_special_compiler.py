"""Family-neutral compiler for declarative triggered ordinary Specials.

This module composes existing trigger, action, targeting, and damage semantics.
It intentionally owns no battle resolution rules.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

from .trigger import SpecialActionTemplate, TriggerDefinition


class GeneratedSpecialCompileError(ValueError):
    pass


@dataclass(frozen=True)
class TriggerDescriptor:
    event: str
    scope: str
    base_probability: float
    condition_owner: str = "CURRENT_MARTIAL_OWNER"
    success_decay_multiplier: float = .25
    failure_decay: str = "NO_DECAY"
    decay_reset: str = "FORMAL_TURN_COMPLETE"


@dataclass(frozen=True)
class ActionDescriptor:
    ownership: str
    kind: str
    classification: str
    participates_in_ordinary_cap: bool = True


@dataclass(frozen=True)
class TargetingDescriptor:
    selector: str
    pattern: str = "single"
    requested_target_count: int | None = None
    anchor_policy: str | None = None


@dataclass(frozen=True)
class DamageDescriptor:
    coefficient: float


_ANCHORED_PATTERNS = frozenset({"row_large", "vertical_column", "cross", "relative_footprint", "row_neighbors"})
_ANCHOR_SELECTORS = frozenset({"event_attacker", "event_target"})
_DIRECT_SELECTORS = frozenset({"event_attacker", "event_target", "roaming_distinct"})


def validate_composition(trigger: TriggerDescriptor, action: ActionDescriptor,
                         targeting: TargetingDescriptor, damage: DamageDescriptor) -> None:
    if trigger.event != "PARRY_SUCCESS":
        raise GeneratedSpecialCompileError("UNSUPPORTED_TRIGGER_FACT")
    if trigger.scope != "ATTACK_SCOPE":
        raise GeneratedSpecialCompileError("UNKNOWN_TRIGGER_SCOPE")
    if trigger.condition_owner != "CURRENT_MARTIAL_OWNER":
        raise GeneratedSpecialCompileError("UNSUPPORTED_TRIGGER_OWNER")
    if not 0 <= trigger.base_probability <= 1:
        raise GeneratedSpecialCompileError("INVALID_BASE_PROBABILITY")
    if (trigger.success_decay_multiplier, trigger.failure_decay, trigger.decay_reset) != (.25, "NO_DECAY", "FORMAL_TURN_COMPLETE"):
        raise GeneratedSpecialCompileError("UNSUPPORTED_TRIGGER_DECAY_POLICY")
    if action.ownership != "NEW_ORDINARY_SPECIAL_ACTION" or action.classification != "ordinary_special":
        raise GeneratedSpecialCompileError("ILLEGAL_ACTION_OWNERSHIP")
    if action.kind not in {"counterattack", "follow_up"} or not action.participates_in_ordinary_cap:
        raise GeneratedSpecialCompileError("UNSUPPORTED_SPECIAL_ACTION_DESCRIPTOR")
    if targeting.selector not in _DIRECT_SELECTORS:
        raise GeneratedSpecialCompileError("UNSUPPORTED_TARGET_MODE")
    if targeting.selector == "roaming_distinct":
        if targeting.pattern != "single":
            raise GeneratedSpecialCompileError("ROAMING_DISTINCT_MAY_NOT_USE_ANCHORED_PATTERN")
        if type(targeting.requested_target_count) is not int:
            raise GeneratedSpecialCompileError("MISSING_REQUESTED_TARGET_COUNT")
        if targeting.requested_target_count < 1:
            raise GeneratedSpecialCompileError("INVALID_REQUESTED_TARGET_COUNT")
    elif targeting.requested_target_count is not None:
        raise GeneratedSpecialCompileError("TARGET_COUNT_NOT_ALLOWED_FOR_SELECTOR")
    if targeting.pattern in _ANCHORED_PATTERNS:
        if targeting.selector not in _ANCHOR_SELECTORS or targeting.anchor_policy is None:
            raise GeneratedSpecialCompileError("MISSING_REQUIRED_TARGET_ANCHOR")
    elif targeting.pattern != "single":
        raise GeneratedSpecialCompileError("UNSUPPORTED_TARGET_PATTERN")
    if not isinstance(damage.coefficient, (int, float)) or isinstance(damage.coefficient, bool) or damage.coefficient < 0:
        raise GeneratedSpecialCompileError("INVALID_DAMAGE_COEFFICIENT")


def compile_trigger(trigger_id: str, owner_id: str, descriptor: TriggerDescriptor,
                    action_template: SpecialActionTemplate, *, source_martial_id: str | None = None,
                    participates_in_ordinary_cap: bool = True) -> TriggerDefinition:
    return TriggerDefinition(
        id=trigger_id, owner_id=owner_id, event_type=descriptor.event,
        scope=descriptor.scope, base_probability=descriptor.base_probability,
        priority=100, action_template=action_template,
        condition=lambda owner, event, engine: event.get("target_id") == owner.definition.id,
        counts_ordinary_budget=participates_in_ordinary_cap,
        source_martial_id=source_martial_id, martial_event_kind="counter")


def compile_action(trigger_id: str, action: ActionDescriptor,
                   targeting: TargetingDescriptor, damage: DamageDescriptor) -> SpecialActionTemplate:
    return SpecialActionTemplate(
        id=f"{trigger_id}.action", kind=action.kind,
        target_selector=targeting.selector,
        attack_coefficient=float(damage.coefficient),
        classification=action.classification,
        targeting_pattern=targeting.pattern,
        requested_target_count=targeting.requested_target_count)


def compile_successful_parry_special(trigger_id: str, owner_id: str,
                                      parameters: Mapping[str, object], *,
                                      source_martial_id: str | None = None) -> TriggerDefinition:
    """Compile declarative parameters without family, candidate, or display-name branches."""
    trigger = TriggerDescriptor(
        event=str(parameters.get("event_type", "PARRY_SUCCESS")),
        scope=str(parameters.get("scope", "ATTACK_SCOPE")),
        base_probability=float(parameters["probability"]),
        condition_owner=str(parameters.get("condition_owner", "CURRENT_MARTIAL_OWNER")),
        success_decay_multiplier=float(parameters.get("success_decay_multiplier", .25)),
        failure_decay=str(parameters.get("failure_decay", "NO_DECAY")),
        decay_reset=str(parameters.get("decay_reset", "FORMAL_TURN_COMPLETE")))
    action = ActionDescriptor(
        ownership=str(parameters["action_ownership"]),
        kind=str(parameters.get("special_kind", "counterattack")),
        classification=str(parameters.get("classification", "ordinary_special")),
        participates_in_ordinary_cap=bool(parameters.get("participates_in_ordinary_cap", True)))
    targeting = TargetingDescriptor(
        selector=str(parameters["target_selector"]),
        pattern=str(parameters.get("targeting_pattern", "single")),
        requested_target_count=parameters.get("requested_target_count"),
        anchor_policy=parameters.get("anchor_policy"))
    damage = DamageDescriptor(float(parameters["coefficient"]))
    validate_composition(trigger, action, targeting, damage)
    template = compile_action(trigger_id, action, targeting, damage)
    return compile_trigger(trigger_id, owner_id, trigger, template,
                           source_martial_id=source_martial_id,
                           participates_in_ordinary_cap=action.participates_in_ordinary_cap)


COMPILER_CAPABILITIES = frozenset({"SUCCESSFUL_PARRY_GENERIC_SPECIAL_TARGETING"})

"""WO-037A3 external formal metadata binding and final Human review package."""
from __future__ import annotations
from pathlib import Path
import json,re
from typing import Any
from .durable_generated_registry import DEFAULT_REGISTRY_PATH,load_generated_registry
from .generated_acceptance import stable_hash
from .generator import deserialize_candidate,serialize_validation_report,validate_candidate
from .numeric_token_valuation import evaluate_candidate_numeric_budget
from .revision_2_canonical_promotion import definition_payload

FORMAL_NAME="回鋒流影劍"
def _read(path:Path)->Any:return json.loads(path.read_text(encoding="utf-8"))
def prepare_wo037a3(workspace:str|Path)->dict[str,Any]:
 root=Path(workspace);revision_path=root/"generated_candidates/wo037a1/candidate_revision_1.json";revision_bytes=revision_path.read_bytes();stored=_read(revision_path);artifact_hash=stored.pop("immutable_sha256");revision_hash=stable_hash(stored)
 if revision_hash!=artifact_hash:raise ValueError("REVISION_HASH_MISMATCH")
 candidate=deserialize_candidate(json.dumps(stored["candidate"],ensure_ascii=False));validation=validate_candidate(candidate);token=evaluate_candidate_numeric_budget(candidate,policy_version="v0.2")
 if token.total_used!=102 or token.remaining!=18:raise ValueError("TOKEN_REVALIDATION_MISMATCH")
 metadata={"decision_id":"metadata:"+stable_hash(("WO037A3",stored["revision_id"],revision_hash,FORMAL_NAME))[:16],"work_order":"CODEX-WO-037A3","revision_id":stored["revision_id"],"revision_sha256":revision_hash,"formal_display_name":FORMAL_NAME,"authority":"HUMAN_AUTHORED_CANONICAL_METADATA","family":"SWORD","tier":"ADVANCED","metadata_only":True,"candidate_revision_created":False}
 valuations={};coeff=[]
 for x in token.numeric_valuations:
  if x.policy_id=="damage_coefficient_absolute_v0_1":coeff.append(x.calculated_cost)
  else:valuations[x.policy_id]=x.calculated_cost
 token_report={"status":token.status,"policy_version":"v0.2","mechanic_subtotal":token.base_known_subtotal,"coefficient_surcharges":coeff,"qi_surcharge":valuations["percent_max_qi_action_cost_v0_2"],"cooldown_surcharge":valuations["finite_action_cooldown_v0_2"],"chance_surcharge":valuations["base_trigger_success_chance_v0_2"],"target_count_surcharge":valuations["finite_distinct_target_count_v0_2"],"numeric_subtotal":token.numeric_subtotal,"total_used":token.total_used,"remaining":token.remaining,"limit":token.budget_limit,"double_charge":"PASS"}
 compiler={"status":"READY","formal_name_bound":True,"runtime_semantics_complete":True,"budget_valid":True,"generic_compiler_readiness":True,"formal_compile_run":False,"canonical_preview_run":False}
 similarity={"status":"PASS","sword_formal_similarity":"DISTINCT","exact_mechanic_clone":False,"display_name_similarity_not_mechanic_similarity":True,"existing_generated_canonical_similarity":"DISTINCT"}
 validation_payload=json.loads(serialize_validation_report(validation));prior_review=_read(root/"generated_candidates/wo037a2/review_package_refresh.json");prior_review.pop("immutable_sha256")
 review={"review_package_schema":"WO037A3-final-v0.1","review_package_id":"review:final:"+stable_hash((revision_hash,FORMAL_NAME,stable_hash(token_report),stable_hash(validation_payload)))[:16],"supersedes_review_package_id":prior_review["review_package_id"],"revision_id":stored["revision_id"],"revision_sha256":revision_hash,"formal_metadata":metadata,"validation_sha256":stable_hash(validation_payload),"token_evaluation":token_report,"numeric_token_policy_version":"v0.2","compiler_readiness":compiler,"formal_similarity":similarity,
  "runtime_content":{"main_coefficient":1.0,"qi_cost_percent_max":0.30,"cooldown":8,"trigger":"PARRY_SUCCESS","scope":"ATTACK_SCOPE","base_chance":1.0,"decay_success_multiplier":0.25,"failure_decay":"NO_DECAY","decay_reset":"FORMAL_TURN_COMPLETE","ordinary_special_cap":3,"followup_ownership":"NEW_ORDINARY_SPECIAL_ACTION","followup_coefficient":0.70,"targeting":"roaming_distinct","requested_target_count":2,"statuses":[],"resources":[],"marks":[]},
  "budget":{"used":102,"limit":120,"remaining":18},"review_state":"PENDING_REVIEW","human_decision":"NONE","canonical":False,"formal":False,"runtime_registered":False}
 bindings={"status":"PASS","revision":{"expected":revision_hash,"actual":stable_hash(stored)},"metadata_sha256":stable_hash(metadata),"validation_sha256":stable_hash(validation_payload),"token_evaluation_sha256":stable_hash(token_report),"compiler_readiness_sha256":stable_hash(compiler),"formal_similarity_sha256":stable_hash(similarity),"review_package_sha256":stable_hash(review)}
 runtime_files=("engine.py","martial.py","trigger.py","status.py","targeting.py","action.py","damage.py","schema.py")
 name_hits=[]
 for name in runtime_files:
  path=root/"battle_core"/name
  if path.exists() and FORMAL_NAME in path.read_text(encoding="utf-8"):name_hits.append(str(path.relative_to(root)))
 registry_path=root/DEFAULT_REGISTRY_PATH;registry_bytes=registry_path.read_bytes();loaded=load_generated_registry(root);cid=next(iter(loaded.runtime));canonical_hash=stable_hash(definition_payload(loaded.get_runtime(cid)))
 controls={"revision_hash_before":revision_hash,"revision_hash_after":stable_hash({k:v for k,v in _read(revision_path).items() if k!="immutable_sha256"}),"revision_bytes_unchanged":revision_path.read_bytes()==revision_bytes,"candidate_revisions":0,"runtime_display_name_branches":name_hits,"human_accepts":0,"promotion_attempts":0,"canonical_previews":0,"staging":0,"runtime_commits":0,"registry_mutations":0,"registry_before":loaded.count,"registry_after":load_generated_registry(root).count,"registry_bytes_unchanged":registry_path.read_bytes()==registry_bytes,"existing_canonical_unchanged":canonical_hash==stable_hash(definition_payload(load_generated_registry(root).get_runtime(cid))),"b1_untouched":True,"lane_c_deferred":True}
 return {"status":"PASS_STOPPED_AT_HUMAN_REVIEW","work_order":"CODEX-WO-037A3","formal_metadata_decision":metadata,"token_revalidation":token_report,"compiler_readiness":compiler,"formal_similarity":similarity,"final_review_package":review,"hash_binding_report":bindings,"controls":controls,"versions":{"battle_core":"v0.9","generator":"v0.2-prototype","acceptance":"v0.1-prototype","numeric_policy":"v0.2","registry_schema":"v0.1"},"required_human_action":{"subject_revision_id":stored["revision_id"],"subject_revision_sha256":revision_hash,"formal_display_name":FORMAL_NAME,"allowed_decisions":["ACCEPT","REJECT","REQUEST_REVISION"]},"stop":"STOPPED_AT_HUMAN_REVIEW"}

def write_wo037a3_artifacts(result:dict[str,Any],directory:str|Path)->Path:
 out=Path(directory);out.mkdir(parents=True,exist_ok=True)
 payloads={"formal_metadata_decision.json":result["formal_metadata_decision"],"token_revalidation.json":result["token_revalidation"],"compiler_readiness_final.json":result["compiler_readiness"],"formal_similarity_final.json":result["formal_similarity"],"final_review_package.json":result["final_review_package"],"hash_binding_report.json":result["hash_binding_report"],"result.json":{"status":result["status"],"controls":result["controls"],"stop":result["stop"]}}
 for name,payload in payloads.items():
  final={**payload,"immutable_sha256":stable_hash(payload)} if name in ("formal_metadata_decision.json","final_review_package.json") else payload
  (out/name).write_text(json.dumps(final,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
 return out

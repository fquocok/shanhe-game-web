"""WO-043 automated evidence writer; no gameplay or canonical authority."""
from __future__ import annotations

from hashlib import sha256
from pathlib import Path
import json

from .battle_presentation import PRESENTATION_CONTRACT
from .durable_generated_registry import DEFAULT_REGISTRY_PATH, load_generated_registry
from .generated_acceptance import stable_hash
from .interactive_battle_screen import BattleScreenSession, LAYOUT_CONTRACT, build_2d_layout_model
from .player_action_control import PLAYER_CONTROL_CONTRACT

STATUS = "PASS_WAITING_FOR_HUMAN_VISUAL_SMOKE"


def audit_wo043(workspace):
    root = Path(workspace)
    registry_path = root / DEFAULT_REGISTRY_PATH
    registry_bytes = registry_path.read_bytes()
    loaded = load_generated_registry(root)
    session = BattleScreenSession(root)
    initial = session.screen_state(); initial_layout = build_2d_layout_model(initial)
    main = next(x for x in initial["actions"] if x["kind"] == "MAIN_ACTION")
    special = next(x for x in initial["actions"] if x["kind"] == "ORDINARY_SPECIAL")
    trace = [initial_layout]
    for action_id in (main["action_id"], main["action_id"], special["action_id"]):
        session.select_action(action_id); session.select_target("enemy-center"); trace.append(build_2d_layout_model(session.submit()))
    contract = {
        "contract_id": LAYOUT_CONTRACT,
        "presentation_input": PRESENTATION_CONTRACT,
        "player_input": PLAYER_CONTROL_CONTRACT,
        "battle_execution": "UNCHANGED",
        "visual_slot": "PRESENTATION_ONLY_NOT_BATTLE_CANONICAL_POSITION",
        "target_selection": "stable target ID through existing controller",
        "ui_legality_logic": False,
        "technology": "Python standard-library Tkinter",
    }
    return {
        "status": STATUS, "contract": contract, "contract_hash": stable_hash(contract),
        "layout": {"orientation": "allies-left/enemies-right", "battlefield_primary": True,
                   "ally_frames": len(initial_layout["allies"]), "enemy_frames": len(initial_layout["enemies"]),
                   "display_only_slots": True, "scrollable_log": True, "responsive_weights": True},
        "interaction": {"selected_target_id": "enemy-center", "stable_action_id": main["action_id"],
                        "command_path": "UI → PlayerActionCommand → ManualCombatController.submit → runtime → presentation → refresh",
                        "direct_runtime_mutation": False, "structured_reasons_preserved": True},
        "trace": trace,
        "isolation": {"battle_semantic_changes": 0, "canonical_changes": 0, "registry_changes": 0,
                      "generator_changes": 0, "acceptance_changes": 0, "numeric_token_policy_changes": 0,
                      "registry": [loaded.count, len(loaded.runtime), loaded.count],
                      "registry_sha256": sha256(registry_bytes).hexdigest(), "registry_bytes_unchanged": registry_path.read_bytes() == registry_bytes},
        "human_gate": {"formal_verification": "NOT_YET", "next": "STOP_AND_WAIT_FOR_HUMAN", "checklist": "human_visual_smoke_checklist.md"},
    }


def write_wo043_artifacts(workspace, directory):
    result = audit_wo043(workspace); out = Path(directory); out.mkdir(parents=True, exist_ok=True)
    for filename, key in (("battle_2d_layout_contract.json", "contract"), ("layout_model_audit.json", "layout"),
                          ("interaction_path_audit.json", "interaction"), ("legendary_2d_layout_trace.json", "trace"),
                          ("isolation_audit.json", "isolation"), ("human_smoke_gate.json", "human_gate")):
        (out / filename).write_text(json.dumps(result[key], ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "battle_2d_layout_contract_hash.json").write_text(json.dumps({"contract_id": LAYOUT_CONTRACT, "sha256": result["contract_hash"]}, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "result.json").write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    return result


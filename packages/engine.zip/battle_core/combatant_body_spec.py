"""Reusable presentation-only combatant body mother specification (WO-051)."""
from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType
from typing import Mapping

BODY_SPEC_CONTRACT = "GAME_FACING_REUSABLE_COMBATANT_BODY_SPEC_V0_1"
BODY_VARIANT_CONTRACT = "GAME_FACING_COMBATANT_BODY_PROPORTION_VARIANTS_V0_1"
BODY_SPEC_UNIT_POLICY = "PRESENTATION_RELATIVE_UNIT; 1 unit = standard head radius"


@dataclass(frozen=True)
class BodyJoint:
    """A stable presentation joint in body-origin-relative normalized units."""
    joint_id: str
    x: float
    y: float
    role: str = "JOINT"


@dataclass(frozen=True)
class CombatantBodySpec:
    """Immutable visual proportions/topology; no gameplay, hitbox, or physics authority."""
    spec_id: str
    version: str
    unit_policy: str
    head_radius: float
    neck_length: float
    shoulder_width: float
    torso_length: float
    pelvis_width: float
    upper_arm_length: float
    forearm_length: float
    hand_radius: float
    thigh_length: float
    shin_length: float
    foot_length: float
    joints: tuple[BodyJoint, ...]
    body_origin_joint: str = "PELVIS_CENTER"
    ground_anchor_joint: str = "GROUND_ANCHOR"
    primary_hand_socket_joint: str = "RIGHT_HAND"
    off_hand_socket_joint: str = "LEFT_HAND"
    presentation_only: bool = True


@dataclass(frozen=True)
class BodyProportionProfile:
    """Fixed visual multipliers over one shared anatomy; carries no identity or stats."""
    profile_id: str
    shoulder_width_scale: float = 1.0
    torso_width_scale: float = 1.0
    pelvis_width_scale: float = 1.0
    arm_length_scale: float = 1.0
    leg_length_scale: float = 1.0
    vertical_scale: float = 1.0
    head_scale: float = 1.0
    limb_thickness_scale: float = 1.0
    presentation_only: bool = True


# Coordinates preserve the accepted placeholder's IDLE proportions. Positive X faces right.
STANDARD_HUMANOID = CombatantBodySpec(
    spec_id="STANDARD_HUMANOID", version="V0_1", unit_policy=BODY_SPEC_UNIT_POLICY,
    head_radius=1.0, neck_length=0.45, shoulder_width=2.20, torso_length=3.73,
    pelvis_width=1.25, upper_arm_length=1.55, forearm_length=1.55, hand_radius=0.28,
    thigh_length=2.05, shin_length=2.05, foot_length=0.82,
    joints=(
        BodyJoint("GROUND_ANCHOR", 0.0, 5.45, "GROUND_ANCHOR"),
        BodyJoint("BODY_ORIGIN", 0.36, 1.09, "BODY_ORIGIN"),
        BodyJoint("HEAD_CENTER", 0.27, -4.00), BodyJoint("NECK_ANCHOR", 0.09, -3.00),
        BodyJoint("LEFT_SHOULDER", -0.27, -2.73), BodyJoint("RIGHT_SHOULDER", 0.0, -2.64),
        BodyJoint("TORSO_CENTER", 0.18, -0.77), BodyJoint("PELVIS_CENTER", 0.36, 1.09),
        BodyJoint("LEFT_HIP", -0.18, 1.18), BodyJoint("RIGHT_HIP", 0.36, 1.09),
        BodyJoint("LEFT_ELBOW", -0.68, -1.23), BodyJoint("RIGHT_ELBOW", 1.27, -1.50),
        BodyJoint("LEFT_HAND", -1.36, 0.18, "SOCKET"), BodyJoint("RIGHT_HAND", 2.55, -0.36, "SOCKET"),
        BodyJoint("LEFT_KNEE", -0.45, 3.00), BodyJoint("RIGHT_KNEE", 1.05, 3.00),
        BodyJoint("LEFT_FOOT", -1.27, 4.45), BodyJoint("RIGHT_FOOT", 1.73, 4.45),
    ),
)

STANDARD_PROFILE = BodyProportionProfile("STANDARD")
LIGHT_PROFILE = BodyProportionProfile("LIGHT", shoulder_width_scale=.86, torso_width_scale=.90, pelvis_width_scale=.90,
                                      arm_length_scale=1.06, leg_length_scale=1.03, vertical_scale=1.01,
                                      head_scale=.98, limb_thickness_scale=.82)
HEAVY_PROFILE = BodyProportionProfile("HEAVY", shoulder_width_scale=1.18, torso_width_scale=1.12, pelvis_width_scale=1.12,
                                      arm_length_scale=.94, leg_length_scale=.96, vertical_scale=.99,
                                      head_scale=1.03, limb_thickness_scale=1.30)
BODY_PROPORTION_PROFILES: Mapping[str, BodyProportionProfile] = MappingProxyType({
    profile.profile_id: profile for profile in (STANDARD_PROFILE, LIGHT_PROFILE, HEAVY_PROFILE)
})


def resolve_body_profile(profile: BodyProportionProfile | str = STANDARD_PROFILE) -> BodyProportionProfile:
    if isinstance(profile, BodyProportionProfile): return profile
    try: return BODY_PROPORTION_PROFILES[str(profile).strip().upper()]
    except KeyError as exc: raise ValueError("BODY_PROFILE_INVALID") from exc


def transform_body_point(joint_name: str, point: tuple[float, float], profile: BodyProportionProfile | str,
                         ground_y: float = 60.0) -> tuple[float, float]:
    """Purely morph a resolved point while keeping the common ground baseline stable."""
    selected = resolve_body_profile(profile)
    if selected == STANDARD_PROFILE: return point
    name = joint_name.upper(); x, y = point
    if "GROUND_ANCHOR" in name: return point
    if "HEAD" in name or name == "HEAD": x_scale = selected.torso_width_scale
    elif "SHOULDER" in name: x_scale = selected.shoulder_width_scale
    elif any(token in name for token in ("HAND", "ELBOW", "WEAPON")): x_scale = selected.arm_length_scale
    elif any(token in name for token in ("HIP", "PELVIS", "BODY_ORIGIN")): x_scale = selected.pelvis_width_scale
    elif any(token in name for token in ("KNEE", "FOOT")): x_scale = selected.leg_length_scale
    else: x_scale = selected.torso_width_scale
    y_scale = selected.vertical_scale
    if any(token in name for token in ("KNEE", "FOOT")): y_scale *= selected.leg_length_scale
    return x * x_scale, ground_y - (ground_y - y) * y_scale


def resolve_profiled_body_geometry(spec: CombatantBodySpec = STANDARD_HUMANOID,
                                   profile: BodyProportionProfile | str = STANDARD_PROFILE,
                                   scale: float = 11.0, facing: str = "right") -> Mapping[str, tuple[float, float]]:
    base = resolve_base_body_geometry(spec, scale, "right"); ground_y = base["GROUND_ANCHOR"][1]
    profiled = {name: transform_body_point(name, point, profile, ground_y) for name, point in base.items()}
    direction = 1 if facing == "right" else -1
    if facing not in ("right", "left"): raise ValueError("BODY_FACING_INVALID")
    return MappingProxyType({name: (point[0] * direction, point[1]) for name, point in profiled.items()})


def resolve_base_body_geometry(spec: CombatantBodySpec = STANDARD_HUMANOID, scale: float = 11.0,
                               facing: str = "right") -> Mapping[str, tuple[float, float]]:
    """Resolve one immutable spec for either facing; scale is visual-only."""
    if scale <= 0: raise ValueError("BODY_SCALE_MUST_BE_POSITIVE")
    if facing not in ("right", "left"): raise ValueError("BODY_FACING_INVALID")
    direction = 1 if facing == "right" else -1
    return MappingProxyType({joint.joint_id: (joint.x * scale * direction, joint.y * scale) for joint in spec.joints})


def resolve_body_anchors(spec: CombatantBodySpec = STANDARD_HUMANOID, scale: float = 11.0,
                         facing: str = "right") -> Mapping[str, tuple[float, float]]:
    joints = resolve_base_body_geometry(spec, scale, facing)
    return MappingProxyType({
        "body_origin": joints[spec.body_origin_joint], "ground_anchor": joints[spec.ground_anchor_joint],
        "primary_hand_socket": joints[spec.primary_hand_socket_joint], "off_hand_socket": joints[spec.off_hand_socket_joint],
    })


def body_spec_document(spec: CombatantBodySpec = STANDARD_HUMANOID) -> dict:
    """Machine-readable deterministic representation for audit artifacts."""
    return {
        "contract": BODY_SPEC_CONTRACT, "spec_id": spec.spec_id, "version": spec.version,
        "unit_policy": spec.unit_policy, "presentation_only": spec.presentation_only,
        "gameplay_authority": "NONE", "hitbox_authority": "NONE", "physics_authority": "NONE",
        "proportions": {name: getattr(spec, name) for name in (
            "head_radius", "neck_length", "shoulder_width", "torso_length", "pelvis_width",
            "upper_arm_length", "forearm_length", "hand_radius", "thigh_length", "shin_length", "foot_length")},
        "joints": {joint.joint_id: {"x": joint.x, "y": joint.y, "role": joint.role} for joint in spec.joints},
        "anchors": {"body_origin": spec.body_origin_joint, "ground_anchor": spec.ground_anchor_joint},
        "sockets": {"primary_hand_socket": spec.primary_hand_socket_joint, "off_hand_socket": spec.off_hand_socket_joint},
        "scale_policy": "positive renderer scale; visual-only; no gameplay footprint",
        "facing_policy": "one RIGHT-facing definition; LEFT is horizontal mirror",
    }

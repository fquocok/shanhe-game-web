"""Generic immutable candidate-revision analysis; never generation, acceptance, or promotion."""
from __future__ import annotations
from dataclasses import dataclass,asdict
from pathlib import Path
from typing import Any
import json
from .first_generated_promotion import load_frozen_wo036a_d,_unresolved_snapshot_fields
from .generated_acceptance import stable_hash
from .generator import serialize_candidate

REVISION_CLASSIFICATIONS=frozenset({"SOURCE_DETERMINABLE","TOKEN_DETERMINABLE","FIRST_PASS_TUNING_DETERMINABLE","HUMAN_DECISION_REQUIRED","STILL_BLOCKED_BY_SOURCE"})
REVISION_ALLOWED_FIELDS=("actions[0].damage_coefficient","actions[0].value_category","statuses[0].duration")

@dataclass(frozen=True)
class ContentGapResolution:
 field_path:str;original_value:str;classification:str;canonical_sources_checked:tuple[str,...];token_sources_checked:tuple[str,...];anchors_checked:tuple[str,...];determinable:bool;proposed_value:Any;resolution_basis:str;token_effect:str;human_decision_required:bool
@dataclass(frozen=True)
class CandidateRevisionPatchProposal:
 parent_candidate_id:str;parent_candidate_hash:str;proposed_revision_id:str;revision_number:int;allowed_fields:tuple[str,...];proposed_changes:dict[str,Any];resolution_basis:dict[str,str];human_decision_required:tuple[str,...];before_token_usage:int;token_delta:str;after_token_usage:str;budget:int;semantic_freeze_hash:str;revision_source_work_order:str="CODEX-WO-036B1";revision_reason:str="CONTENT_COMPLETENESS_RESOLUTION";generator_calls:int=0;generation_rng_calls:int=0;battle_rng_calls:int=0;canonical:bool=False;formal:bool=False;runtime_registered:bool=False;review_state:str="PENDING_HUMAN_CONTENT_DECISION"
@dataclass(frozen=True)
class CandidateRevisionResolutionResult:
 status:str;parent_identity:dict[str,Any];frozen_mechanics:dict[str,Any];semantic_freeze:dict[str,Any];gap_analysis:tuple[ContentGapResolution,...];token_analysis:dict[str,Any];patch_proposal:CandidateRevisionPatchProposal;semantic_diff:dict[str,Any];revision_candidate_created:bool;revision_validation_created:bool;revision_review_package_created:bool;human_content_decision_request:dict[str,Any];promotion_attempts:int;formal_registry_before:int;formal_registry_after:int;runtime_registry_before:int;runtime_registry_after:int

def validate_revision_patch_fields(changes):
 extra=set(changes)-set(REVISION_ALLOWED_FIELDS)
 if extra:raise ValueError("REVISION_FIELD_NOT_ALLOWED:"+",".join(sorted(extra)))
 return True

def analyze_candidate_d_revision(workspace):
 raw,package,candidate,validation,identity=load_frozen_wo036a_d(workspace);parent_serialized=serialize_candidate(candidate)
 mechanics={"candidate_id":candidate.candidate_id,"family":candidate.family,"tier":candidate.tier,"budget":candidate.budget,"request_id":package.request_id,"seed":package.generation_seed,"generator_version":package.generator_version,"template":package.template_id,"actions":candidate.actions,"passives":candidate.passives,"resources":candidate.resources,"statuses":candidate.statuses,"stances":candidate.stances,"topology_hash":stable_hash(asdict(candidate.topology)),"token_plan":asdict(candidate.token_plan),"capabilities":candidate.capability_requirements,"unresolved_fields":_unresolved_snapshot_fields(candidate)}
 freeze={"parent_candidate_hash":identity.candidate_hash,"review_package_hash":identity.review_package_hash,"validation_hash":identity.validation_hash,"frozen_semantics_hash":stable_hash(mechanics),"immutable_fields":tuple(k for k in mechanics if k not in REVISION_ALLOWED_FIELDS),"allowed_revision_fields":REVISION_ALLOWED_FIELDS}
 canonical=("BATTLE_CORE_V0_9:TOKEN_TBD_POLICY","GENERATOR_V0_2:NO_EXCHANGE_RATE","ACCEPTANCE_V0_1:CONTENT_COMPLETE_REQUIRED","STATUS_RUNTIME:POSITIVE_INTEGER_OWNER_TURN_CLOCK")
 tokens=("GENERATOR_TOKEN_COSTS:action_identity=30","GENERATOR_TOKEN_COSTS:attack_instance=20","GENERATOR_TOKEN_COSTS:trigger_scope=10","GENERATOR_TOKEN_COSTS:status=18","NO_DAMAGE_COEFFICIENT_EXCHANGE_RATE","NO_STATUS_DURATION_EXCHANGE_RATE")
 anchors=("spear_advanced_zhuifeng_pozhen:active_coefficient=TOKEN_BALANCE_TBD","spear_basic_changfeng:active_coefficient=TOKEN_BALANCE_TBD","formal_status_durations:multiple_nontransferable_values","test_tuning_overrides:NON_CANONICAL_EXCLUDED")
 gaps=(
  ContentGapResolution("actions[0].damage_coefficient","TOKEN_BALANCE_TBD","HUMAN_DECISION_REQUIRED",canonical,tokens,anchors,False,None,"No canonical spear/Advanced coefficient exchange rate or unique source value; formal spear anchors are themselves TBD and fixture values are noncanonical.","UNKNOWN_REQUIRED_COST; must not be treated as zero",True),
  ContentGapResolution("actions[0].value_category","TOKEN_BALANCE_TBD","HUMAN_DECISION_REQUIRED",canonical,tokens,anchors,False,None,"Generator bookkeeping category depends on how the unresolved coefficient is authorized (source-derived, token-balanced, or first-pass); no unique mapping exists before that decision.","DEPENDENT_ON_DAMAGE_COEFFICIENT_RESOLUTION",True),
  ContentGapResolution("statuses[0].duration","CONTENT_TBD","HUMAN_DECISION_REQUIRED",canonical,tokens,anchors,False,None,"Runtime defines a positive integer and owner-turn clock but no generic/spear duration price or unique duration; other martial durations are reference-only and not transferable.","UNKNOWN_REQUIRED_COST; must not be treated as zero",True))
 changes={x.field_path:None for x in gaps};validate_revision_patch_fields(changes);freeze_hash=stable_hash(freeze)
 patch=CandidateRevisionPatchProposal(candidate.candidate_id,identity.candidate_hash,candidate.candidate_id+".r1",1,REVISION_ALLOWED_FIELDS,changes,{x.field_path:x.resolution_basis for x in gaps},tuple(x.field_path for x in gaps if x.human_decision_required),78,"INDETERMINATE_PENDING_HUMAN_VALUES","INDETERMINATE",120,freeze_hash)
 request={"status":"HUMAN_DESIGN_VALUE_REQUIRED","fields":({"field":"actions[0].damage_coefficient","required_input":"positive numeric coefficient plus classification SOURCE_DERIVED_VALUE, TOKEN_BALANCE_VALUE, or FIRST_PASS_GENERATED_VALUE","source_supported_options":None,"note":"No canonical range exists; test/demo 1.0/1.1/1.2 values are forbidden as evidence."},{"field":"actions[0].value_category","required_input":"category consistent with the chosen coefficient authority; use existing vocabulary such as SOURCE_DERIVED_VALUE or FIRST_PASS_GENERATED_VALUE","source_supported_options":None,"note":"Cannot be inferred from Advanced tier."},{"field":"statuses[0].duration","required_input":"positive integer owner-formal-turn duration and confirmation that it is an explicit human design value","source_supported_options":None,"note":"No canonical duration pricing/range exists; values from other statuses are nontransferable."}),"after_human_input":"Create CODEX-WO-036B1A; build .r1, recalculate token status, validate, and stop at new Human Review."}
 semantic_diff={"status":"PROPOSAL_ONLY_NO_REVISION_CANDIDATE","allowed_fields":REVISION_ALLOWED_FIELDS,"actual_changes":(),"forbidden_changes":(),"parent_hash_unchanged":stable_hash(parent_serialized)==identity.candidate_hash}
 token={"before_token_usage":78,"budget":120,"slack":42,"revision_delta":"INDETERMINATE","after_token_usage":"INDETERMINATE","unknown_costs":("damage_coefficient_resolution","status_duration_resolution"),"unknown_cost_treated_as_zero":False}
 parent={"candidate_id":identity.candidate_id,"seed":identity.generation_seed,"hash":identity.candidate_hash,"generator_version":identity.generator_version,"template":identity.template_id,"original_review_package_hash":identity.review_package_hash,"original_acceptance_history":"WO036B ACCEPT_FOR_CANONICALIZATION_ATTEMPT; BLOCKED_UNRESOLVED_CONTENT"}
 return CandidateRevisionResolutionResult("PASS_STOPPED_AT_HUMAN_CONTENT_DECISION",parent,mechanics,freeze,gaps,token,patch,semantic_diff,False,False,False,request,0,0,0,0,0)

def write_revision_resolution_artifacts(result,directory):
 root=Path(directory);root.mkdir(parents=True,exist_ok=True)
 payloads={"source_candidate_identity.json":result.parent_identity,"content_gap_analysis.json":[asdict(x) for x in result.gap_analysis],"token_resolution_analysis.json":result.token_analysis,"candidate_d_semantic_freeze.json":result.semantic_freeze,"revision_patch_proposal.json":asdict(result.patch_proposal),"revision_semantic_diff.json":result.semantic_diff,"revision_result.json":{"status":result.status,"revision_candidate_created":result.revision_candidate_created,"revision_validation_created":result.revision_validation_created,"revision_review_package_created":result.revision_review_package_created,"promotion_attempts":result.promotion_attempts,"registries":{"formal_before":result.formal_registry_before,"formal_after":result.formal_registry_after,"runtime_before":result.runtime_registry_before,"runtime_after":result.runtime_registry_after}},"human_content_decision_request.json":result.human_content_decision_request}
 for name,value in payloads.items():(root/name).write_text(json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False),encoding="utf-8")
 return root

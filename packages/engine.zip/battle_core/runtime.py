from __future__ import annotations

from dataclasses import InitVar, dataclass, field

from .schema import CharacterDefinition, GridPosition
from .state import CombatantLifeState


class ShieldSourcePolicyRegistry:
    SUPPORTED = frozenset({"REPLACE", "ACCUMULATE"})

    @classmethod
    def require(cls, policy):
        if policy not in cls.SUPPORTED:
            raise ValueError(f"未知 Shield source policy：{policy}")
        return policy


@dataclass
class ShieldLedger:
    source_id: str
    amount: int


@dataclass
class BattleRuntimeState:
    definition: CharacterDefinition
    current_hp: int
    max_hp: int
    current_qi: int
    max_qi: int
    shield_pool: list[ShieldLedger] = field(default_factory=list)
    action_gauge: float = 0.0
    cooldowns: dict[str, int] = field(default_factory=dict)
    statuses: list[object] = field(default_factory=list)
    combat_resources: dict[str, int] = field(default_factory=dict)
    immunity_tags: set[str] = field(default_factory=set)
    immunity_status_ids: set[str] = field(default_factory=set)
    # Constructor-only legacy input at its original positional index.
    # The property installed below never stores a second instance truth.
    defeated: InitVar[bool | None] = None
    on_field: bool = True
    immediate_action: bool = False
    current_speed: float = 0.0
    position: GridPosition | None = None
    martial_id: str | None = None
    lightness_skill_id: str | None = None
    can_receive_hp_recovery: bool = True
    hp_recovery_rule_source: str | None = None

    life_state: CombatantLifeState = field(default=CombatantLifeState.ALIVE, kw_only=True)

    def __setattr__(self, name, value):
        if name == "life_state":
            value = CombatantLifeState(value)
        super().__setattr__(name, value)

    def __post_init__(self, defeated):
        if defeated is None:
            return
        if type(defeated) is not bool:
            raise TypeError("defeated compatibility input must be bool")
        if defeated:
            if self.life_state == CombatantLifeState.PENDING_DEATH_CONFIRMATION:
                raise ValueError("Pending is not confirmed defeated")
            self.life_state = CombatantLifeState.DEFEATED
        elif self.death_confirmed:
            raise ValueError("defeated=False conflicts with life_state=DEFEATED")

    @property
    def ordinary_combat_eligible(self) -> bool:
        """Normal participation only; does not specify death/revive/healing windows."""
        return self.life_state == CombatantLifeState.ALIVE and self.on_field

    @property
    def death_confirmed(self) -> bool:
        return self.life_state == CombatantLifeState.DEFEATED

    def _get_defeated(self) -> bool:
        return self.death_confirmed

    def _set_defeated(self, value: bool) -> None:
        # Legacy fixture/reset adapter, NOT a revive operation or transition policy.
        if type(value) is not bool:
            raise TypeError("defeated compatibility assignment must be bool")
        if value:
            self.life_state = CombatantLifeState.DEFEATED
        elif self.death_confirmed:
            self.life_state = CombatantLifeState.ALIVE
        # False on synthetic Pending preserves Pending, rather than reviving it.

    @property
    def shield(self) -> int:
        return sum(entry.amount for entry in self.shield_pool)


# Install after @dataclass has captured InitVar's None default. Defining the
# property in the dataclass body would accidentally make it the init default.
BattleRuntimeState.defeated = property(
    BattleRuntimeState._get_defeated, BattleRuntimeState._set_defeated,
    doc="Compatibility view: True iff canonical life_state is DEFEATED.",
)

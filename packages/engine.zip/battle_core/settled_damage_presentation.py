"""Lossless read-only exposure of battle-runtime-settled target impacts."""
from __future__ import annotations
from dataclasses import asdict, dataclass
from types import MappingProxyType
from typing import Any, Iterable, Mapping

SETTLED_DAMAGE_PRESENTATION_CONTRACT = "SETTLED_DAMAGE_PRESENTATION_CONTRACT_V0_1"
COMBATLOG_SETTLED_PRESENTATION_IS_LEGACY_COMPAT_ONLY = True
# Deprecated diagnostic extractor; canonical callers use presentation_stream.compatibility.
SETTLEMENT_EVENT = "ATTACK_INSTANCE_HIT_OUTCOME_FINALIZED"


@dataclass(frozen=True)
class SettledTargetImpact:
    attack_instance_id: str
    action_id: str
    source_combatant_id: str
    target_combatant_id: str
    successful_hit: bool
    dodged: bool
    parried: bool
    final_damage_before_shield: int
    shield_absorbed_damage: int
    hp_damage: int
    remaining_hp: int
    remaining_shield: int
    defeated: bool
    source_event_type: str = SETTLEMENT_EVENT
    presentation_only: bool = True


REQUIRED_SETTLED_FIELDS = frozenset({
    "attack_instance_id", "action_id", "source_combatant_id", "target_id", "successful_hit",
    "dodge_success", "parry_success", "final_damage_before_shield", "shield_absorbed_damage",
    "hp_damage", "remaining_hp", "remaining_shield", "defeated",
})


def expose_settled_target_impacts(events: Iterable[Any]) -> tuple[SettledTargetImpact, ...]:
    """Deprecated CombatLog compatibility only; never the canonical Presentation source."""
    impacts = []
    for event in events:
        event_type = event.type if hasattr(event, "type") else event["type"]
        if event_type != SETTLEMENT_EVENT: continue
        raw = event.data if hasattr(event, "data") else event["data"]
        missing = REQUIRED_SETTLED_FIELDS - raw.keys()
        if missing: raise ValueError("SETTLED_DAMAGE_FIELDS_MISSING:" + ",".join(sorted(missing)))
        impacts.append(SettledTargetImpact(
            str(raw["attack_instance_id"]), str(raw["action_id"]), str(raw["source_combatant_id"]), str(raw["target_id"]),
            bool(raw["successful_hit"]), bool(raw["dodge_success"]), bool(raw["parry_success"]),
            int(raw["final_damage_before_shield"]), int(raw["shield_absorbed_damage"]), int(raw["hp_damage"]),
            int(raw["remaining_hp"]), int(raw["remaining_shield"]), bool(raw["defeated"]),
        ))
    return tuple(impacts)


def settled_impact_document(impact: SettledTargetImpact) -> Mapping[str, Any]:
    return MappingProxyType({"contract": SETTLED_DAMAGE_PRESENTATION_CONTRACT, **asdict(impact),
                             "ui_damage_recalculation": False, "gameplay_trigger_authority": False})


def settled_impacts_as_presentation_events(impacts: Iterable[SettledTargetImpact], start_sequence: int = 0) -> tuple[dict[str, Any], ...]:
    """Adapt DTOs into the existing WO-054 DAMAGE_APPLIED input without recomputation."""
    events = []
    for offset, impact in enumerate(impacts, 1):
        details = {key: value for key, value in asdict(impact).items() if key not in (
            "action_id", "source_combatant_id", "target_combatant_id", "source_event_type", "presentation_only")}
        events.append({"sequence": start_sequence + offset, "event_type": "DAMAGE_APPLIED", "actor_id": impact.source_combatant_id,
                       "action_id": impact.action_id, "action_name": None, "target_ids": (impact.target_combatant_id,),
                       "details": details, "derivation": "SETTLED_BATTLE_READ_ONLY_ADAPTER",
                       "attack_instance_id": impact.attack_instance_id})
    return tuple(events)

"""Typed physical Attack damage and single-recipient settled allocation boundary."""
from .model import (AttackDamageContext, AttackDamageResult, RawDamageInputs, RawDamageStage,
                    DodgeStage, DefenseStage, ParryStage, ReductionStage, PreShareStage,
                    RecipientAllocationProvenance, RecipientSettlement)
from .attack_resolver import AttackDamageResolver
from .settlement import settle_recipient_allocation, observe_zero_allocation

__all__ = ["AttackDamageContext", "AttackDamageResult", "RawDamageInputs", "RawDamageStage",
           "DodgeStage", "DefenseStage", "ParryStage", "ReductionStage", "PreShareStage",
           "RecipientAllocationProvenance", "RecipientSettlement", "AttackDamageResolver",
           "settle_recipient_allocation", "observe_zero_allocation"]

from .model import PreSettlementAttack
__all__ += ["PreSettlementAttack"]

"""Pure snapshot projection then callback-free atomic HP/Shield commit.

Explicit opt-in API only. Live Attack/DOT paths do not call this module.
"""
from dataclasses import dataclass, field, replace
from .settlement_metadata import NonAttackSettlementMetadata
from ..runtime import BattleRuntimeState, ShieldLedger
from ..state import CombatantLifeState as Life
from ..events import SemanticEventStore, SemanticEventType as T, EventPhase as Phase, DamageOrigin
from ..events.envelope import canonical_json
from ..damage_sharing import (QuantizedDamageDistributionPlan, QuantizedDamageAllocation,
                              AllocationRole)
from ..lifecycle import enter_pending_death


class AtomicSettlementError(ValueError):
    """Invalid batch: no partial recipient mutation is permitted."""


@dataclass(frozen=True, slots=True)
class RecipientSnapshot:
    recipient_id: str
    current_hp: int
    life_state: Life
    shield_ledger: tuple[tuple[str, int], ...]

    def __post_init__(self):
        ledger = tuple(tuple(entry) for entry in self.shield_ledger)
        if (type(self.recipient_id) is not str or not self.recipient_id or
                type(self.current_hp) is not int or not isinstance(self.life_state, Life) or
                self.life_state == Life.DEFEATED):
            raise AtomicSettlementError("Invalid or defeated recipient snapshot")
        if any(len(e) != 2 or type(e[0]) is not str or not e[0] or
               type(e[1]) is not int or e[1] < 0 for e in ledger):
            raise AtomicSettlementError("Invalid Shield ledger")
        object.__setattr__(self, "shield_ledger", ledger)


@dataclass(frozen=True, slots=True)
class AtomicRecipientSettlement:
    allocation: QuantizedDamageAllocation
    snapshot: RecipientSnapshot
    shield_after: tuple[tuple[str, int], ...]
    surviving_ledger_indexes: tuple[int, ...]
    shield_before: int
    shield_absorbed_damage: int
    hp_damage_raw: int
    hp_damage: int
    overkill_damage: int
    remaining_hp: int
    remaining_shield: int
    shield_broken: bool

    def __post_init__(self):
        if (type(self.allocation) is not QuantizedDamageAllocation or
                type(self.snapshot) is not RecipientSnapshot or
                self.allocation.recipient_id != self.snapshot.recipient_id):
            raise AtomicSettlementError("Typed matching allocation/snapshot required")
        after = tuple(tuple(entry) for entry in self.shield_after)
        indexes = tuple(self.surviving_ledger_indexes)
        if (any(len(entry) != 2 or type(entry[0]) is not str or
                type(entry[1]) is not int or entry[1] < 0 for entry in after)
                or len(indexes) != len(after) or
                any(type(i) is not int or i < 0 for i in indexes)):
            raise AtomicSettlementError("Immutable typed Shield projection required")
        for name in ("shield_before", "shield_absorbed_damage", "hp_damage_raw",
                     "hp_damage", "overkill_damage", "remaining_shield"):
            if type(getattr(self, name)) is not int or getattr(self, name) < 0:
                raise AtomicSettlementError("Nonnegative integer settlement values required")
        if type(self.remaining_hp) is not int or type(self.shield_broken) is not bool:
            raise AtomicSettlementError("Typed remaining HP/Shield break required")
        object.__setattr__(self, "shield_after", after)
        object.__setattr__(self, "surviving_ledger_indexes", indexes)

    @property
    def recipient_id(self):
        return self.allocation.recipient_id

    @property
    def integer_damage(self):
        return self.allocation.integer_damage

    @property
    def role(self):
        return self.allocation.role

    @property
    def distribution_index(self):
        return self.allocation.distribution_index

    def to_dict(self):
        return dict(allocation=self.allocation.to_dict(),
                    hp_before=self.snapshot.current_hp,
                    life_state_before=self.snapshot.life_state.value,
                    shield_ledger_before=[dict(source_id=s, amount=n)
                                          for s, n in self.snapshot.shield_ledger],
                    shield_ledger_after=[dict(source_id=s, amount=n) for s, n in self.shield_after],
                    shield_before=self.shield_before,
                    shield_absorbed_damage=self.shield_absorbed_damage,
                    hp_damage_raw=self.hp_damage_raw, hp_damage=self.hp_damage,
                    overkill_damage=self.overkill_damage, remaining_hp=self.remaining_hp,
                    remaining_shield=self.remaining_shield, shield_broken=self.shield_broken)


@dataclass(frozen=True, slots=True)
class AtomicDamageDistributionResult:
    quantized_plan: QuantizedDamageDistributionPlan
    settlements: tuple[AtomicRecipientSettlement, ...]
    committed: bool
    event_ids: tuple[str, ...] = ()
    source_metadata: NonAttackSettlementMetadata | None = field(default=None, kw_only=True)

    def __post_init__(self):
        settlements, event_ids = tuple(self.settlements), tuple(self.event_ids)
        if self.source_metadata is not None:
            if type(self.source_metadata) is not NonAttackSettlementMetadata:
                raise AtomicSettlementError("Typed immutable non-Attack metadata required")
            replace(self.source_metadata).validate_distribution(self.quantized_plan)
        if (type(self.quantized_plan) is not QuantizedDamageDistributionPlan or
                type(self.committed) is not bool or
                any(type(s) is not AtomicRecipientSettlement for s in settlements) or
                any(type(i) is not str or not i for i in event_ids)):
            raise AtomicSettlementError("Typed immutable batch result required")
        if tuple(s.allocation for s in settlements) != self.quantized_plan.allocations:
            raise AtomicSettlementError("Result must cover the exact distribution in order")
        object.__setattr__(self, "settlements", settlements)
        object.__setattr__(self, "event_ids", event_ids)

    @property
    def total_integer_damage(self):
        return sum(s.integer_damage for s in self.settlements)

    @property
    def original_actual_recipient_id(self):
        return self.quantized_plan.original_actual_recipient_id

    @property
    def source(self):
        return self.quantized_plan.source

    @property
    def attack_instance_id(self):
        return self.source.attack_instance_id

    def to_dict(self):
        metadata = ({} if self.source_metadata is None else
                    {"source_metadata": self.source_metadata.to_dict()})
        return dict(**metadata, quantized_plan=self.quantized_plan.to_dict(),
                    settlements=[s.to_dict() for s in self.settlements],
                    total_integer_damage=self.total_integer_damage, committed=self.committed,
                    event_ids=list(self.event_ids))

    def serialize(self):
        return canonical_json(self.to_dict())


def project_recipient(allocation, snapshot):
    """Pure FIFO projection. Pending negative HP is preserved, never healed by damage."""
    if type(allocation) is not QuantizedDamageAllocation or type(snapshot) is not RecipientSnapshot:
        raise AtomicSettlementError("Typed allocation and immutable snapshot required")
    if allocation.recipient_id != snapshot.recipient_id:
        raise AtomicSettlementError("Snapshot identity mismatch")
    before = sum(n for _, n in snapshot.shield_ledger)
    absorbed = min(before, allocation.integer_damage)
    remaining = absorbed
    after, indexes = [], []
    for index, (source_id, amount) in enumerate(snapshot.shield_ledger):
        if remaining:
            used = min(amount, remaining)
            amount -= used
            remaining -= used
            if amount == 0:
                continue
        after.append((source_id, amount))
        indexes.append(index)
    raw = allocation.integer_damage - absorbed
    available_hp = max(0, snapshot.current_hp)
    hp_damage = min(available_hp, raw)
    shield_after = sum(n for _, n in after)
    return AtomicRecipientSettlement(
        allocation, snapshot, tuple(after), tuple(indexes), before, absorbed, raw,
        hp_damage, max(0, raw - available_hp), snapshot.current_hp - hp_damage,
        shield_after, before > 0 and shield_after == 0)


def _prepare(plan, states, *, source_metadata=None):
    if type(plan) is not QuantizedDamageDistributionPlan:
        raise AtomicSettlementError("Typed WO086 quantized distribution required")
    replace(plan)  # Revalidate allocation identities/provenance/order and conservation.
    source = plan.source
    if source.source_damage_origin == DamageOrigin.ATTACK_INSTANCE and not source.attack_instance_id:
        raise AtomicSettlementError("Attack settlement requires Attack provenance")
    runtime = tuple(states)
    if any(type(s) is not BattleRuntimeState for s in runtime):
        raise AtomicSettlementError("Concrete Runtime states required; no gameplay setters")
    ids = [s.definition.id for s in runtime]
    if len(set(ids)) != len(ids):
        raise AtomicSettlementError("Ambiguous Runtime identity")
    by_id = dict(zip(ids, runtime))
    recipients, projections, seen_ledgers = [], [], set()
    for allocation in plan.allocations:
        state = by_id.get(allocation.recipient_id)
        if state is None:
            raise AtomicSettlementError("Unknown/removed recipient: " + allocation.recipient_id)
        if type(state.shield_pool) is not list:
            raise AtomicSettlementError("Concrete Shield ledger list required")
        ledger = []
        for entry in state.shield_pool:
            if type(entry) is not ShieldLedger or id(entry) in seen_ledgers:
                raise AtomicSettlementError("Invalid/aliased Shield ledger")
            seen_ledgers.add(id(entry))
            ledger.append((entry.source_id, entry.amount))
        snapshot = RecipientSnapshot(state.definition.id, state.current_hp,
                                     state.life_state, tuple(ledger))
        recipients.append(state)
        projections.append(project_recipient(allocation, snapshot))
    return tuple(recipients), AtomicDamageDistributionResult(plan, tuple(projections), False,
                                                          source_metadata=source_metadata)


def project_distribution(plan, states, *, source_metadata=None):
    """Read-only preflight/projection; no live state reference escapes in result."""
    return _prepare(plan, states, source_metadata=source_metadata)[1]


def settle_quantized_distribution_atomic(plan, states, events, *, causation_event_id=None,
                                        source_metadata=None):
    """Validate all -> project all -> commit all HP/Shield -> facts -> Pending entry.

    Synchronous single-writer Runtime boundary. No callbacks, logs, RNG, mitigation,
    sharing resolver or death confirmation in the commit loop.
    """
    if type(events) is not SemanticEventStore:
        raise AtomicSettlementError("Concrete inert SemanticEventStore required")
    if causation_event_id is not None:
        events.get(causation_event_id)
    recipients, projected = _prepare(plan, states, source_metadata=source_metadata)
    # All outcomes validate before first write. Preserve surviving ShieldLedger
    # objects and FIFO list identity, as the existing _absorb_shield primitive does.
    for state, settlement in zip(recipients, projected.settlements):
        original_ledger = tuple(state.shield_pool)
        after_by_index = dict(zip(settlement.surviving_ledger_indexes, settlement.shield_after))
        for index, entry in enumerate(original_ledger):
            entry.amount = after_by_index[index][1] if index in after_by_index else 0
        state.shield_pool[:] = [original_ledger[i] for i in settlement.surviving_ledger_indexes]
        state.current_hp = settlement.remaining_hp

    # Only now create facts. Append never dispatches TriggerEngine, legacy Shield
    # Break/death handlers or Special Actions.
    source = plan.source
    common = dict(action_id=source.action_id, attack_instance_id=source.attack_instance_id,
                  original_target_id=source.original_target_id,
                  actual_recipient_id=source.actual_recipient_id,
                  target_chain_id=source.target_chain_id)
    recorded, settlement_events = [], []
    for settlement in projected.settlements:
        share = settlement.role == AllocationRole.SHARE_RECEIVER
        origin = DamageOrigin.SHARED_DAMAGE_TRANSFER if share else source.source_damage_origin
        headers = dict(common)
        if not share and origin != DamageOrigin.ATTACK_INSTANCE:
            headers.pop("attack_instance_id")
            headers.pop("actual_recipient_id")
        payload = settlement.to_dict()
        if source_metadata is not None:
            headers.update(source_metadata.headers())
            payload.update(source_metadata.payload_fields())
        event = events.append(
            T.SHARED_DAMAGE_TRANSFER_SETTLED if share else T.DAMAGE_SOURCE_SETTLEMENT_COMPLETED,
            Phase.DAMAGE_SETTLEMENT, **headers, damage_origin=origin,
            share_receiver_id=settlement.recipient_id if share else None,
            damage_recipient_id=settlement.recipient_id,
            causation_event_id=settlement_events[0].event_id if share else causation_event_id,
            payload=payload)
        settlement_events.append(event)
        recorded.append(event.event_id)
    for settlement, parent in zip(projected.settlements, settlement_events):
        if settlement.shield_broken:
            # Receiver identity is distinct from Attack actual recipient. Share
            # provenance is reachable through the parent transfer fact.
            event = events.append(T.SHIELD_BROKEN, Phase.POST_SETTLEMENT,
                                  damage_recipient_id=settlement.recipient_id,
                                  causation_event_id=parent.event_id,
                                  payload={"shield_owner_id": settlement.recipient_id,
                                           "distribution_index": settlement.distribution_index,
                                           "shield_before": settlement.shield_before,
                                           "remaining_shield": settlement.remaining_shield})
            recorded.append(event.event_id)
    for state, parent in zip(recipients, settlement_events):
        if state.life_state == Life.ALIVE and state.current_hp <= 0:
            recorded.append(enter_pending_death(
                state, events, causation_event_id=parent.event_id).event_id)
    return replace(projected, committed=True, event_ids=tuple(recorded))

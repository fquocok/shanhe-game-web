"""Single-recipient Shield/HP settlement of an already-resolved allocation."""
from .model import RecipientSettlement, RecipientAllocationProvenance


def observe_zero_allocation(recipient, provenance):
    """No ledger mutation, used for Dodge/unavailable snapshots."""
    return RecipientSettlement(provenance, 0, recipient.shield, 0, 0, 0, 0,
                               recipient.current_hp, recipient.shield, False)


def settle_recipient_allocation(recipient, amount, provenance, *, absorb_shield):
    """No target selection, upstream formula, Sharing, death or derived handlers.

    absorb_shield is the existing FIFO ledger primitive/event sink, shared with
    historical non-Attack paths. This API itself handles one recipient only.
    """
    if not isinstance(provenance, RecipientAllocationProvenance):
        raise TypeError("Typed allocation provenance required")
    if provenance.recipient_id != recipient.definition.id:
        raise ValueError("Allocation recipient/provenance mismatch")
    if type(amount) is not int or amount < 0:
        raise ValueError("Allocation must be an already-rounded nonnegative int")
    shield_before = recipient.shield
    absorbed = absorb_shield(recipient, amount)
    hp_damage_raw = amount - absorbed
    hp_damage = min(recipient.current_hp, hp_damage_raw)
    overkill = max(0, hp_damage_raw - recipient.current_hp)
    recipient.current_hp -= hp_damage
    return RecipientSettlement(provenance, amount, shield_before, absorbed, hp_damage_raw,
                               hp_damage, overkill, recipient.current_hp, recipient.shield,
                               shield_before > 0 and recipient.shield == 0)

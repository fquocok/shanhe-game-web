"""Detached immutable foundation inputs/results. No source formulas."""
from dataclasses import dataclass, field, replace
from types import MappingProxyType
from ...events import DamageOrigin
from ...events.envelope import freeze, thaw, canonical_json
from ...state import CombatantLifeState
from ...damage_sharing import DamageSharingPlan, QuantizedDamageDistributionPlan
from ..atomic_distribution import AtomicDamageDistributionResult
from ..settlement_metadata import NonAttackSettlementMetadata, identity
from .policy import (SUPPORTED_ROOT_ORIGINS, NonAttackDamageError, NonAttackSettlementPolicy)


@dataclass(frozen=True, slots=True)
class NonAttackDamageRequest:
    damage_origin: DamageOrigin
    damage_recipient_id: str
    settlement_basis: int
    source_instance_id: str
    source_combatant_id: str | None = None
    formal_turn_id: str | None = None
    action_id: str | None = None
    effect_instance_id: str | None = None
    status_instance_id: str | None = None
    source_definition_id: str | None = None
    causation_event_id: str | None = None
    provenance: object = field(default_factory=dict)

    def __post_init__(self):
        if not isinstance(self.damage_origin, DamageOrigin) or self.damage_origin not in SUPPORTED_ROOT_ORIGINS:
            raise NonAttackDamageError("Unsupported root non-Attack DamageOrigin")
        if type(self.settlement_basis) is not int or self.settlement_basis < 0:
            raise NonAttackDamageError("Exact nonnegative integer settlement_basis required")
        try:
            identity(self.damage_recipient_id, "damage_recipient_id")
            identity(self.source_instance_id, "source_instance_id")
            for name in ("source_combatant_id", "formal_turn_id", "action_id", "effect_instance_id",
                         "status_instance_id", "source_definition_id", "causation_event_id"):
                identity(getattr(self, name), name, optional=True)
        except ValueError as exc:
            raise NonAttackDamageError(str(exc)) from exc
        if type(self.provenance) not in (dict, MappingProxyType):
            raise NonAttackDamageError("Immutable provenance mapping required")
        object.__setattr__(self, "provenance", freeze(self.provenance))

    def settlement_metadata(self):
        return NonAttackSettlementMetadata(
            self.source_instance_id, self.source_combatant_id, self.formal_turn_id, self.action_id,
            self.effect_instance_id, self.status_instance_id, self.source_definition_id, self.provenance)

    def to_dict(self):
        return {name: (self.damage_origin.value if name == "damage_origin"
                       else thaw(getattr(self, name))) for name in self.__dataclass_fields__}

    def serialize(self):
        return canonical_json(self.to_dict())


@dataclass(frozen=True, slots=True)
class NonAttackDamageSettlementResult:
    request: NonAttackDamageRequest
    policy: NonAttackSettlementPolicy
    identity_distribution: DamageSharingPlan
    quantized_plan: QuantizedDamageDistributionPlan
    atomic_result: AtomicDamageDistributionResult
    damage_settlement_event_id: str
    shield_break_event_ids: tuple[str, ...]
    lifecycle_event_ids: tuple[str, ...]
    final_life_state: CombatantLifeState
    confirmed_death: bool
    pending_window: object = None

    def __post_init__(self):
        from ...reactions import PostSettlementReactionResult
        if (type(self.request) is not NonAttackDamageRequest
                or type(self.policy) is not NonAttackSettlementPolicy
                or type(self.identity_distribution) is not DamageSharingPlan
                or type(self.quantized_plan) is not QuantizedDamageDistributionPlan
                or type(self.atomic_result) is not AtomicDamageDistributionResult
                or not self.atomic_result.committed):
            raise NonAttackDamageError("Typed committed foundation result required")
        replace(self.request)
        replace(self.policy).require_executable()
        replace(self.quantized_plan)
        replace(self.atomic_result)
        if (self.quantized_plan.ratio_plan != self.identity_distribution
                or self.atomic_result.quantized_plan != self.quantized_plan
                or self.atomic_result.source_metadata != self.request.settlement_metadata()
                or self.quantized_plan.source.source_damage_origin != self.request.damage_origin
                or self.quantized_plan.source.actual_recipient_id != self.request.damage_recipient_id
                or self.quantized_plan.pre_share_damage != self.request.settlement_basis):
            raise NonAttackDamageError("Result request/distribution/receipt identity mismatch")
        if (not isinstance(self.final_life_state, CombatantLifeState)
                or type(self.confirmed_death) is not bool
                or self.confirmed_death != (self.final_life_state == CombatantLifeState.DEFEATED)):
            raise NonAttackDamageError("Confirmed death must follow final lifecycle truth")
        if self.pending_window is not None and type(self.pending_window) is not PostSettlementReactionResult:
            raise NonAttackDamageError("Typed WO088 window result required")
        identity(self.damage_settlement_event_id, "damage_settlement_event_id")
        for name in ("shield_break_event_ids", "lifecycle_event_ids"):
            values = tuple(getattr(self, name))
            for value in values:
                identity(value, name)
            object.__setattr__(self, name, values)

    def to_dict(self):
        return dict(request=self.request.to_dict(), policy=self.policy.to_dict(),
                    identity_distribution=self.identity_distribution.to_dict(),
                    quantized_plan=self.quantized_plan.to_dict(), atomic_result=self.atomic_result.to_dict(),
                    damage_settlement_event_id=self.damage_settlement_event_id,
                    shield_break_event_ids=list(self.shield_break_event_ids),
                    lifecycle_event_ids=list(self.lifecycle_event_ids),
                    final_life_state=self.final_life_state.value, confirmed_death=self.confirmed_death,
                    pending_window=None if self.pending_window is None else self.pending_window.to_dict())

    def serialize(self):
        return canonical_json(self.to_dict())

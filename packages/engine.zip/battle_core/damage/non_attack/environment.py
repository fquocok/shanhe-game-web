"""Typed Environment occurrence contract; no production hazard, formula or default."""
from dataclasses import dataclass, field, replace
from types import MappingProxyType
from ...events import DamageOrigin
from ...events.envelope import freeze, thaw, canonical_json
from ...scheduler import PreResolutionCategory as C, PreResolutionWorkItem as W
from ...scheduler.provider_firewall import supply_read_only
from .policy import NonAttackSettlementPolicy
from .model import NonAttackDamageRequest

RUNTIME_CONTRACT = "WO096_ENVIRONMENT_SOURCE_RUNTIME_CONTRACT"
DUPLICATE_ENVIRONMENT_SOURCE_OCCURRENCE = "DUPLICATE_ENVIRONMENT_SOURCE_OCCURRENCE"
ENVIRONMENT_SHIELD_BREAK_REACTION_BINDING_TBD = "ENVIRONMENT_SHIELD_BREAK_REACTION_BINDING_TBD"
ENVIRONMENT_DEATH_LEGACY_TRIGGER_BINDING_TBD = "ENVIRONMENT_DEATH_LEGACY_TRIGGER_BINDING_TBD"


def _identity(value, name, *, optional=False):
    if value is None and optional:
        return
    if type(value) is not str or not value.strip():
        raise ValueError("Stable nonempty " + name + " required")


@dataclass(frozen=True, slots=True)
class EnvironmentDamageSourceSnapshot:
    source_instance_id: str
    damage_recipient_id: str
    settlement_basis: int
    creation_sequence: int
    policy: NonAttackSettlementPolicy
    source_definition_id: str | None = None
    source_combatant_id: str | None = None
    effect_instance_id: str | None = None
    provenance: object = field(default_factory=dict)
    event_metadata: object = field(default_factory=dict)

    def __post_init__(self):
        for name in ("source_instance_id", "damage_recipient_id"):
            _identity(getattr(self, name), name)
        for name in ("source_definition_id", "source_combatant_id", "effect_instance_id"):
            _identity(getattr(self, name), name, optional=True)
        for name in ("settlement_basis", "creation_sequence"):
            value = getattr(self, name)
            if type(value) is not int or value < 0:
                raise ValueError("Exact nonnegative int " + name + " required")
        if type(self.policy) is not NonAttackSettlementPolicy:
            raise ValueError("Explicit typed Environment settlement policy required")
        object.__setattr__(self, "policy", replace(self.policy))
        for name in ("provenance", "event_metadata"):
            value = getattr(self, name)
            if type(value) not in (dict, MappingProxyType):
                raise ValueError("Detached Environment mapping required")
            object.__setattr__(self, name, freeze(value))

    @property
    def occurrence(self):
        return self.source_instance_id, self.damage_recipient_id

    def work_item(self, formal_turn_id):
        # JSON pair avoids colon/delimiter collisions without creating a new ID.
        key = canonical_json(list(self.occurrence))
        return W(f"environment:{formal_turn_id}:{key}", C.ENVIRONMENT,
                 self.source_instance_id, self.creation_sequence, tie_break_key=key,
                 metadata={"runtime_contract": RUNTIME_CONTRACT,
                           "source_definition_id": self.source_definition_id})

    def request(self, turn_event):
        return NonAttackDamageRequest(
            DamageOrigin.ENVIRONMENT, self.damage_recipient_id, self.settlement_basis,
            self.source_instance_id, source_combatant_id=self.source_combatant_id,
            formal_turn_id=turn_event.formal_turn_id, effect_instance_id=self.effect_instance_id,
            source_definition_id=self.source_definition_id, causation_event_id=turn_event.event_id,
            provenance={"runtime_contract": RUNTIME_CONTRACT,
                        "source_provenance": thaw(self.provenance),
                        "event_metadata": thaw(self.event_metadata)})

    def to_dict(self):
        return {name: (self.policy.to_dict() if name == "policy" else thaw(getattr(self, name)))
                for name in self.__dataclass_fields__}

    def serialize(self):
        return canonical_json(self.to_dict())


def collect_environment_sources(runtime, actor, turn_event):
    provider = getattr(runtime, "environment_source_provider", None)
    if provider is None:
        return ()
    if not callable(provider):
        raise TypeError("Optional Environment source provider must be callable")
    supplied = supply_read_only(runtime, provider, actor, turn_event)
    sources, seen = [], set()
    # Validate ALL supplied occurrences before any Environment source executes.
    for value in supplied:
        if type(value) is not EnvironmentDamageSourceSnapshot:
            raise TypeError("Typed EnvironmentDamageSourceSnapshot required")
        value = replace(value)
        if value.occurrence in seen:
            raise ValueError(DUPLICATE_ENVIRONMENT_SOURCE_OCCURRENCE)
        seen.add(value.occurrence)
        if runtime.state_by_id(value.damage_recipient_id) is None:
            raise ValueError("Unknown Environment damage_recipient_id")
        if value.source_combatant_id is not None and runtime.state_by_id(value.source_combatant_id) is None:
            raise ValueError("Unknown Environment source_combatant_id")
        # Delegate executable routing to accepted WO093 policy, including its
        # unchanged exact BYPASS failure type/marker. No Environment policy chosen.
        value.policy.require_executable()
        sources.append(value)
    return tuple(sources)

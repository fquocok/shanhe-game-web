"""WO093 foundation only. No current production caller opts in."""
from .model import NonAttackDamageRequest, NonAttackDamageSettlementResult
from .policy import (
    SUPPORTED_ROOT_ORIGINS, NonAttackShieldRouting, NonAttackSettlementPolicy,
    NonAttackDamageError, NonAttackPolicyError, NonAttackRecipientError,
    WO093_NONATTACK_SETTLEMENT_IS_OPT_IN_FOUNDATION_ONLY,
    LEGACY_SPECIAL_DAMAGE_CANONICAL_ORIGIN_TBD,
    DOT_STATUS_INSTANCE_SEMANTIC_ID_BINDING_TBD_FOR_WO095,
    NONATTACK_BYPASS_SHIELD_SETTLEMENT_NOT_YET_AUTHORIZED,
    NONATTACK_DAMAGE_TO_PENDING_RECIPIENT_TBD, NONATTACK_SHIELD_BREAK_REACTION_BINDING_TBD,
    legacy_special_damage_audit)
from .settlement import settle_non_attack_damage

"""Explicit caller policy. No global origin-to-Shield rule or implicit bypass."""
from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType
from ...events import DamageOrigin
from ...events.envelope import freeze, thaw, canonical_json

SUPPORTED_ROOT_ORIGINS = frozenset({
    DamageOrigin.DOT_PERIODIC, DamageOrigin.ENVIRONMENT, DamageOrigin.REFLECTION,
    DamageOrigin.SELF_DAMAGE, DamageOrigin.DIRECT_HP_LOSS,
})
WO093_NONATTACK_SETTLEMENT_IS_OPT_IN_FOUNDATION_ONLY = "WO093_NONATTACK_SETTLEMENT_IS_OPT_IN_FOUNDATION_ONLY"
LEGACY_SPECIAL_DAMAGE_CANONICAL_ORIGIN_TBD = "LEGACY_SPECIAL_DAMAGE_CANONICAL_ORIGIN_TBD"
DOT_STATUS_INSTANCE_SEMANTIC_ID_BINDING_TBD_FOR_WO095 = "DOT_STATUS_INSTANCE_SEMANTIC_ID_BINDING_TBD_FOR_WO095"
NONATTACK_BYPASS_SHIELD_SETTLEMENT_NOT_YET_AUTHORIZED = "NONATTACK_BYPASS_SHIELD_SETTLEMENT_NOT_YET_AUTHORIZED"
NONATTACK_DAMAGE_TO_PENDING_RECIPIENT_TBD = "NONATTACK_DAMAGE_TO_PENDING_RECIPIENT_TBD"
NONATTACK_SHIELD_BREAK_REACTION_BINDING_TBD = "NONATTACK_SHIELD_BREAK_REACTION_BINDING_TBD"


class NonAttackDamageError(ValueError):
    """Invalid explicit foundation input; no fallback or inferred semantics."""


class NonAttackPolicyError(NonAttackDamageError):
    pass


class NonAttackRecipientError(NonAttackDamageError):
    pass


class NonAttackShieldRouting(str, Enum):
    THROUGH_SHIELD = "THROUGH_SHIELD"
    BYPASS_SHIELD = "BYPASS_SHIELD"


@dataclass(frozen=True, slots=True)
class NonAttackSettlementPolicy:
    shield_routing: NonAttackShieldRouting
    provenance: object = field(default_factory=dict)

    def __post_init__(self):
        if not isinstance(self.shield_routing, NonAttackShieldRouting):
            raise NonAttackPolicyError("Explicit typed Shield routing required")
        if type(self.provenance) not in (dict, MappingProxyType):
            raise NonAttackPolicyError("Policy provenance mapping required")
        object.__setattr__(self, "provenance", freeze(self.provenance))

    def require_executable(self):
        if self.shield_routing == NonAttackShieldRouting.BYPASS_SHIELD:
            raise NonAttackPolicyError(NONATTACK_BYPASS_SHIELD_SETTLEMENT_NOT_YET_AUTHORIZED)

    def to_dict(self):
        return {"shield_routing": self.shield_routing.value, "provenance": thaw(self.provenance)}

    def serialize(self):
        return canonical_json(self.to_dict())


def legacy_special_damage_audit():
    """Read-only debt declaration; no guessed origin or production binding."""
    return freeze({"legacy_call_path": "BattleEngine.resolve_special_damage",
                   "canonical_semantic_origin": "TBD",
                   "marker": LEGACY_SPECIAL_DAMAGE_CANONICAL_ORIGIN_TBD,
                   "production_migrated_in_wo093": False})

"""Explicit opt-in identity settlement; no production origin migration."""
from dataclasses import replace
from ...events import SemanticEventStore, SemanticEventType as T
from ...state import CombatantLifeState as Life
from ...runtime import BattleRuntimeState
from ...damage_sharing import DamageSharingSource, DamageSharingResolver, quantize_damage_sharing
from ..atomic_distribution import project_distribution, settle_quantized_distribution_atomic
from ...reactions import resolve_pending_death_window
from .model import NonAttackDamageRequest, NonAttackDamageSettlementResult
from .policy import (NonAttackDamageError, NonAttackPolicyError, NonAttackRecipientError,
                     NonAttackSettlementPolicy, NONATTACK_DAMAGE_TO_PENDING_RECIPIENT_TBD)


def settle_non_attack_damage(runtime, request, *, policy,
                             death_prevention_provider=None,
                             death_prevention_eligible=None,
                             death_prevention_executor=None):
    """Validate -> exact identity -> atomic commit -> explicit WO088 window.

    No legacy observers or non-Attack Shield Break bindings. Injected callbacks
    are trusted WO088 seams AFTER commit; their errors propagate without a new
    rollback/auto-confirm policy. Inputs/callable shape validate BEFORE commit.
    """
    from ...scheduler.provider_firewall import reject_settlement_during_environment_supply
    reject_settlement_during_environment_supply(runtime)
    if type(request) is not NonAttackDamageRequest:
        raise NonAttackDamageError("Typed immutable NonAttackDamageRequest required")
    request = replace(request)
    if type(policy) is not NonAttackSettlementPolicy:
        raise NonAttackPolicyError("Explicit typed NonAttackSettlementPolicy required")
    policy = replace(policy)
    policy.require_executable()
    callbacks = (death_prevention_provider, death_prevention_eligible, death_prevention_executor)
    if any(callback is not None for callback in callbacks) and not all(callable(c) for c in callbacks):
        raise NonAttackDamageError("Explicit WO088 provider/eligibility/executor triple required")
    store = runtime.semantic_events
    if type(store) is not SemanticEventStore:
        raise NonAttackDamageError("Concrete inert SemanticEventStore required")
    if request.causation_event_id is not None:
        store.get(request.causation_event_id)
    states = tuple(runtime.states)
    if any(type(s) is not BattleRuntimeState for s in states):
        raise NonAttackDamageError("Concrete Runtime states required")
    identities = [s.definition.id for s in states]
    if len(set(identities)) != len(identities):
        raise NonAttackDamageError("Ambiguous Runtime identity")
    by_id = dict(zip(identities, states))
    recipient = by_id.get(request.damage_recipient_id)
    if recipient is None:
        raise NonAttackRecipientError("Unknown damage_recipient_id")
    if request.source_combatant_id is not None and request.source_combatant_id not in by_id:
        raise NonAttackDamageError("Unknown source_combatant_id")
    if recipient.life_state == Life.DEFEATED:
        raise NonAttackRecipientError("DEFEATED recipient cannot enter foundation settlement")
    if recipient.life_state == Life.PENDING_DEATH_CONFIRMATION:
        raise NonAttackRecipientError(NONATTACK_DAMAGE_TO_PENDING_RECIPIENT_TBD)
    # An already nonpositive ALIVE snapshot needs lifecycle processing first.
    # Never let zero damage manufacture Pending from pre-existing inconsistent HP.
    if type(recipient.current_hp) is not int or recipient.current_hp <= 0:
        raise NonAttackRecipientError("ALIVE recipient requires a positive integer HP snapshot")

    metadata = request.settlement_metadata()
    # The accepted internal source field is named actual_recipient_id even for
    # non-Attack identity plans. It never becomes an Attack envelope identity.
    source = DamageSharingSource(request.damage_origin, request.damage_recipient_id,
                                 request.settlement_basis, action_id=request.action_id)
    ratio_plan = DamageSharingResolver().resolve(source)  # Always zero candidates.
    quantized = quantize_damage_sharing(ratio_plan)  # Exact identity; no policy.
    metadata.validate_distribution(quantized)
    project_distribution(quantized, states, source_metadata=metadata)  # Full pure preflight.
    atomic = settle_quantized_distribution_atomic(
        quantized, states, store, causation_event_id=request.causation_event_id,
        source_metadata=metadata)
    atomic_facts = tuple(store.get(i) for i in atomic.event_ids)
    window = None
    if any(f.event_type == T.PENDING_DEATH_ENTERED for f in atomic_facts):
        window = resolve_pending_death_window(
            runtime, atomic, provider=death_prevention_provider,
            eligible=death_prevention_eligible, executor=death_prevention_executor)
    lifecycle = tuple(f.event_id for f in atomic_facts if f.event_type == T.PENDING_DEATH_ENTERED)
    if window is not None:
        lifecycle += window.lifecycle_event_ids
    return NonAttackDamageSettlementResult(
        request, policy, ratio_plan, quantized, atomic, atomic.event_ids[0],
        tuple(f.event_id for f in atomic_facts if f.event_type == T.SHIELD_BROKEN),
        lifecycle, recipient.life_state, recipient.death_confirmed, window)

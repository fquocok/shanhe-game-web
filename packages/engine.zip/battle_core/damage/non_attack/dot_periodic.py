"""WO095 producer-specific DOT snapshots/composition, never a global origin policy."""
from dataclasses import dataclass, replace
from types import MappingProxyType
from ...events.envelope import freeze, thaw, canonical_json
from ...scheduler import PreResolutionCategory as C, PreResolutionWorkItem as W
from ...status import RuntimeStatusInstance
from ...bindings.non_attack_registry import DOT_BINDING_ID
from ...bindings.model import UnresolvedReactionOrderError
from ...bindings.shield_break_adapter import dispatch_inner_shield_breaks
from .policy import NonAttackSettlementPolicy, NonAttackShieldRouting

DOT_STATUS_INSTANCE_SEMANTIC_ID_BINDING_RESOLVED_IN_WO095 = "DOT_STATUS_INSTANCE_SEMANTIC_ID_BINDING_RESOLVED_IN_WO095"
DOT_SHIELD_BREAK_REACTION_DEFERRED_TO_POST_SOURCE_BATCH_IN_WO095 = "DOT_SHIELD_BREAK_REACTION_DEFERRED_TO_POST_SOURCE_BATCH_IN_WO095"
DOT_STATUS_PHASE_MISMATCH_FOR_WO095 = "DOT_STATUS_PHASE_MISMATCH_FOR_WO095"
WO095_STATUS_TURN_START_ORDER_CONFLICT = "WO095_STATUS_TURN_START_ORDER_CONFLICT"


def status_instance_semantic_id(instance_or_id):
    value = instance_or_id.instance_id if type(instance_or_id) is RuntimeStatusInstance else instance_or_id
    if type(value) is not int or value < 1:
        raise ValueError("Status instance identity requires literal int >= 1")
    return f"status-instance:{value:08d}"


@dataclass(frozen=True, slots=True)
class DotPeriodicSourceSnapshot:
    runtime_instance_id: int
    semantic_status_instance_id: str
    status_definition_id: str
    source_combatant_id: str
    damage_recipient_id: str
    applied_at: int
    stack_count: int
    remaining_duration: int
    payload: object
    event_metadata: object
    source_phase: str
    source_priority: int

    def __post_init__(self):
        if self.semantic_status_instance_id != status_instance_semantic_id(self.runtime_instance_id):
            raise ValueError("Status semantic identity mismatch")
        for name in ("status_definition_id", "source_combatant_id", "damage_recipient_id"):
            value = getattr(self, name)
            if type(value) is not str or not value.strip():
                raise ValueError("Nonempty " + name + " required")
        for name, minimum in (("applied_at", 0), ("stack_count", 1), ("remaining_duration", 1)):
            value = getattr(self, name)
            if type(value) is not int or value < minimum:
                raise ValueError("Invalid DOT " + name)
        if self.source_phase != "periodic_damage":
            raise ValueError(DOT_STATUS_PHASE_MISMATCH_FOR_WO095)
        if type(self.source_priority) is not int:
            raise ValueError("DOT priority is diagnostic integer only")
        for name in ("payload", "event_metadata"):
            value = getattr(self, name)
            if type(value) not in (dict, MappingProxyType):
                raise ValueError("Detached DOT mapping required")
            object.__setattr__(self, name, freeze(value))
        if self.payload.get("effect") != "dot":
            raise ValueError("Explicit DOT payload required")

    @classmethod
    def capture(cls, instance, owner):
        if type(instance) is not RuntimeStatusInstance:
            raise ValueError("Concrete RuntimeStatusInstance required")
        payload = instance.definition.payload
        if callable(payload.get("turn_start_handler")):
            raise ValueError(WO095_STATUS_TURN_START_ORDER_CONFLICT)
        if instance.target_id != owner.definition.id:
            raise ValueError("DOT Status owner/target mismatch")
        return cls(instance.instance_id, status_instance_semantic_id(instance),
                   instance.definition.id, instance.source_id, instance.target_id,
                   instance.applied_at, instance.stack_count, instance.remaining_duration,
                   dict(payload), dict(payload.get("event_metadata", {})),
                   instance.definition.phase, instance.definition.priority)

    def work_item(self, formal_turn_id):
        identity = self.semantic_status_instance_id
        return W(f"periodic-dot:{formal_turn_id}:{identity}", C.PERIODIC, identity,
                 self.applied_at or self.runtime_instance_id, tie_break_key=identity,
                 metadata={"producer_binding": DOT_BINDING_ID,
                           "status_definition_id": self.status_definition_id})

    def to_dict(self):
        return {name: thaw(getattr(self, name)) for name in self.__dataclass_fields__}

    def serialize(self):
        return canonical_json(self.to_dict())


def snapshot_periodic_sources(owner):
    sources = tuple(DotPeriodicSourceSnapshot.capture(s, owner) for s in tuple(owner.statuses)
                    if s.definition.payload.get("effect") == "dot")
    if len({s.semantic_status_instance_id for s in sources}) != len(sources):
        raise ValueError("Duplicate DOT semantic status identity")
    return sources


def dot_settlement_policy():
    """Only status_dot:legacy_resolve_dot; no origin-to-policy lookup."""
    return NonAttackSettlementPolicy(NonAttackShieldRouting.THROUGH_SHIELD, {
        "binding_id": DOT_BINDING_ID, "migration_work_order": "WO095",
        "compatibility_source": "LEGACY_RUNTIME_THROUGH_SHIELD",
        "authority": "PRODUCER_SPECIFIC_MIGRATION_COMPATIBILITY_NOT_GLOBAL_DOT_CANON"})


def dispatch_deferred_dot_shields(runtime, results):
    """Preflight entire owner set before first compatibility observation/dispatch."""
    results = tuple(results)
    from ...reactions.validation import validate_atomic_result
    from ...events import SemanticEventType as T
    owners = set()
    for result in results:
        for fact in validate_atomic_result(runtime, result):
            if fact.event_type != T.SHIELD_BROKEN:
                continue
            skill = runtime.inner_skills.equipped.get(fact.damage_recipient_id)
            if skill and any(s.mechanic == "shield_break_reaction_action" for s in skill.slots):
                owners.add(fact.damage_recipient_id)
    if len(owners) > 1:
        raise UnresolvedReactionOrderError("CROSS_OWNER_SHIELD_REACTION_ORDER_TBD")
    for result in results:
        dispatch_inner_shield_breaks(runtime, result)


def run_dot_pre_resolution(runtime, actor, turn_event, sources):
    """WO095 compatibility entry; delegates to the one WO096 common orchestrator."""
    from ...scheduler.runtime_pre_resolution import run_common_pre_resolution
    return run_common_pre_resolution(runtime, actor, turn_event, sources)

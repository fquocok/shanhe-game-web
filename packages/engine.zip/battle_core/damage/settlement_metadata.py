"""Typed opt-in non-Attack source metadata for the existing atomic receipt.

No routing, formula, eligibility or origin-to-policy semantics live here.
Absent metadata preserves all existing WO087 payload/receipt bytes.
"""
from dataclasses import dataclass, field
from types import MappingProxyType
from ..events import DamageOrigin
from ..events.envelope import freeze, thaw


class SettlementMetadataError(ValueError):
    pass


def identity(value, name, *, optional=False):
    if optional and value is None:
        return
    if type(value) is not str or not value.strip():
        raise SettlementMetadataError("Stable nonempty string required: " + name)


@dataclass(frozen=True, slots=True)
class NonAttackSettlementMetadata:
    source_instance_id: str
    source_combatant_id: str | None = None
    formal_turn_id: str | None = None
    action_id: str | None = None
    effect_instance_id: str | None = None
    status_instance_id: str | None = None
    source_definition_id: str | None = None
    provenance: object = field(default_factory=dict)

    def __post_init__(self):
        identity(self.source_instance_id, "source_instance_id")
        for name in ("source_combatant_id", "formal_turn_id", "action_id",
                     "effect_instance_id", "status_instance_id", "source_definition_id"):
            identity(getattr(self, name), name, optional=True)
        if type(self.provenance) not in (dict, MappingProxyType):
            raise SettlementMetadataError("Provenance must be a mapping")
        object.__setattr__(self, "provenance", freeze(self.provenance))

    def validate_distribution(self, plan):
        from ..damage_sharing import QuantizedDamageDistributionPlan, AllocationRole
        if type(plan) is not QuantizedDamageDistributionPlan:
            raise SettlementMetadataError("Typed distribution required")
        source = plan.source
        if (source.source_damage_origin in (DamageOrigin.ATTACK_INSTANCE, DamageOrigin.SHARED_DAMAGE_TRANSFER)
                or source.attack_instance_id is not None or source.original_target_id is not None
                or source.target_chain_id is not None or source.action_id != self.action_id
                or len(plan.allocations) != 1
                or plan.allocations[0].role != AllocationRole.ORIGINAL_ACTUAL_RECIPIENT
                or plan.allocations[0].integer_damage != source.pre_share_damage):
            raise SettlementMetadataError("Metadata requires exact non-Attack identity distribution")

    def headers(self):
        return {name: getattr(self, name) for name in (
            "source_combatant_id", "formal_turn_id", "action_id", "effect_instance_id", "status_instance_id")}

    def payload_fields(self):
        return {"source_instance_id": self.source_instance_id,
                "source_definition_id": self.source_definition_id, "provenance": thaw(self.provenance)}

    def to_dict(self):
        return {**self.headers(), **self.payload_fields()}

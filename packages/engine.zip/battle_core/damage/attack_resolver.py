"""The sole physical Attack formula path, called by BattleEngine."""
from ..config import DEFENSE_IGNORE_CAP, DODGE_CAP
from ..stats import round_half_up
from ..events import SemanticEventType, EventPhase
from .model import (AttackDamageContext, AttackDamageResult, RawDamageInputs, RawDamageStage,
                    DodgeStage, DefenseStage, ParryStage, ReductionStage, PreShareStage,
                    RecipientAllocationProvenance, PreSettlementAttack, RecipientSettlement)
from .settlement import settle_recipient_allocation, observe_zero_allocation


class AttackDamageResolver:
    def __init__(self, engine):
        self.engine = engine

    def prepare_raw_inputs(self, attacker, action_id, attack_tags, attack_id):
        # LEGACY_OFFENSIVE_PROC_CAPTURE_BEFORE_SELECTION_FOR_RNG_PARITY
        # These content hooks may roll/emit facts. Preserve their historical
        # placement; the pure Raw stage uses only these captured inputs after Dodge.
        engine = self.engine
        damage_multiplier = engine.martials.damage_multiplier(attacker, attack_tags, attack_id)
        snapshot = engine._offensive_snapshots.get(action_id)
        martial_attack_multiplier = (engine.martials.attack_multiplier(attacker) if snapshot is None
                                     else snapshot["martial_attack_multiplier"])
        attack_power = (engine.stats.attack(attacker.definition) * martial_attack_multiplier
                        if snapshot is None else snapshot["attack_power_snapshot"])
        bonus_component = engine.martials.same_attack_damage_component(attacker, attack_tags, attack_id)
        return RawDamageInputs(attack_power, martial_attack_multiplier, damage_multiplier,
                               bonus_component, None if snapshot is None else snapshot["snapshot_id"])

    @staticmethod
    def raw_stage(context, inputs):
        base_component = inputs.attack_power * context.coefficient * inputs.damage_multiplier
        return RawDamageStage(inputs.attack_power, context.coefficient, inputs.damage_multiplier,
                              inputs.martial_attack_multiplier, base_component,
                              inputs.bonus_component, base_component + inputs.bonus_component)

    def skipped(self, context, inputs, recipient, reason):
        provenance = RecipientAllocationProvenance(
            context.action_id, context.attack_instance_id, context.actual_recipient_id)
        return AttackDamageResult(context, None, self.raw_stage(context, inputs), None, None, None,
                                  PreShareStage(0), observe_zero_allocation(recipient, provenance), reason)

    def resolve(self, context, inputs, *, finalize_legacy_impact, canonical_recipient_fact=None):
        """Phase A: successful results are PRE-settlement; Dodge remains observational."""
        if not isinstance(context, AttackDamageContext) or not isinstance(inputs, RawDamageInputs):
            raise TypeError("Typed already-confirmed Attack context/inputs required")
        engine = self.engine
        attacker = engine.state_by_id(context.attacker_id)
        defender = engine.state_by_id(context.actual_recipient_id)
        if attacker is None or defender is None:
            raise ValueError("Unknown confirmed Attack participant")
        action_id, attack_id = context.action_id, context.attack_instance_id
        attack_tags, action_classification = context.attack_tags, context.action_classification
        damage_multiplier = inputs.damage_multiplier
        martial_attack_multiplier = inputs.martial_attack_multiplier
        provenance = RecipientAllocationProvenance(action_id, attack_id, context.actual_recipient_id)
        recipient_metadata = (dict(original_target_id=context.original_target_id,
                                   actual_recipient_id=context.actual_recipient_id,
                                   target_chain_id=context.target_chain_id)
                              if context.original_target_id != context.actual_recipient_id else {})
        event_base = dict(action_id=action_id, owning_action_id=action_id,
                          root_action_id=context.root_action_id or action_id, stage_id=context.stage_id,
                          source_definition_id=context.source_definition_id,
                          attack_instance_id=attack_id, attacker_id=context.attacker_id,
                          target_id=context.actual_recipient_id, action_classification=action_classification,
                          offensive_snapshot_id=context.offensive_snapshot_id, **recipient_metadata)
        summary = engine._action_outcomes[action_id]
        martial_snapshot=engine.martials.attack_eligibility_snapshot(
            attacker,defender,action_id,attack_id)
        dodge_bonus = (engine.martials.dodge_bonus(defender)
                       + engine.stats._loadout(defender.definition,"dodge_bonus")
                       + engine.statuses.modifier_total(defender,"dodge_bonus"))
        dodge = min(max(defender.definition.agility * 0.002 + dodge_bonus - attacker.definition.agility * 0.001-engine.martials.dodge_break_bonus(attacker), 0.0), DODGE_CAP)
        dodge_success = engine.rng.random() < dodge
        raw_stage = self.raw_stage(context, inputs)
        base_component, bonus_component, raw = raw_stage.base_component, raw_stage.bonus_component, raw_stage.raw_damage
        engine.martials.resolve_attack_instance_content_gates(
            attacker,defender,action_id,attack_id,dodge_success,martial_snapshot)
        if dodge_success:
            engine.log.add("ATTACK_INSTANCE", id=attack_id, attacker=attacker.definition.id, target=defender.definition.id,
                         raw_damage=raw, dodge_chance=dodge, dodge_success=True, damage_after_defense=0,
                         parry_chance=0, parry_success=False, final_damage_before_shield=0,
                         shield_absorbed_damage=0, hp_damage=0, target_hp=f"{defender.current_hp}/{defender.max_hp}")
            engine._emit_combat_event("DODGE_SUCCESS", attack_instance=attack_id,
                                    unit=defender.definition.id, **event_base)
            engine.martials.on_dodge_success(defender)
            engine._emit_combat_event("ATTACK_INSTANCE_RESOLVED", **event_base,
                                    dodge_success=True,parry_success=False,successful_hit=False,
                                    final_damage_before_shield=0,shield_absorbed_damage=0,hp_damage=0,
                                    effective_attack_damage=False,event_scope="ATTACK")
            zero_settlement = observe_zero_allocation(defender, provenance)
            result = AttackDamageResult(context, DodgeStage(dodge, True), raw_stage,
                                        None, None, None, PreShareStage(0), zero_settlement)
            finalize_legacy_impact(result)
            engine.martials.on_attack_instance_resolved(attacker,defender,action_id,attack_id,False,dodge_success=True,parry_success=False,effective_attack_damage=False,final_damage_before_shield=0)
            engine._accumulate_main_action_damage(event_base,0,0,0)
            return result
        hit = None if canonical_recipient_fact is None else engine.semantic_events.append(
            SemanticEventType.ATTACK_SUCCESSFUL_HIT_CONFIRMED,
            EventPhase.DAMAGE_SETTLEMENT,
            causation_event_id=canonical_recipient_fact.event_id,
            parent_event_id=canonical_recipient_fact.parent_event_id,
            formal_turn_id=canonical_recipient_fact.formal_turn_id, action_id=action_id,
            attack_instance_id=attack_id, actor_id=context.attacker_id,
            original_target_id=context.original_target_id,
            actual_recipient_id=context.actual_recipient_id,
            target_chain_id=context.target_chain_id)
        defense_before = engine.stats.defense(
            defender.definition,
            engine.statuses.modifier_total(defender, "additive_defense_percent")
            + engine.inner_skills.defense_bonus(defender)+engine.martials.defense_bonus(defender))
        martial_ignore=engine.martials.defense_ignore_bonus(attacker,attack_tags,attack_id)
        ignore = min(max(float(attacker.definition.modifiers.get("defense_ignore_percent", 0))+martial_ignore, 0), DEFENSE_IGNORE_CAP)
        effective_defense = defense_before * (1 - ignore)
        reduction = engine.defense_policy.reduction(effective_defense)
        after_defense = raw * (1 - reduction)
        parry_bonus = engine.martials.parry_bonus(defender)+engine.statuses.modifier_total(defender,"parry_bonus")
        parry_break_bonus = engine.martials.parry_break_bonus(attacker)
        parry = min(max(defender.definition.strength * 0.002 + parry_bonus
                        - attacker.definition.strength * 0.001 - parry_break_bonus, 0.0), 1.0)
        parry_success = engine.rng.random() < parry
        parry_multiplier = .5
        if parry_success:
            parry_fact = None if hit is None else engine.semantic_events.append(
                SemanticEventType.ATTACK_PARRY_CONFIRMED,
                EventPhase.DAMAGE_SETTLEMENT,
                causation_event_id=hit.event_id,
                parent_event_id=canonical_recipient_fact.parent_event_id,
                formal_turn_id=canonical_recipient_fact.formal_turn_id, action_id=action_id,
                attack_instance_id=attack_id, actor_id=context.attacker_id,
                original_target_id=context.original_target_id,
                actual_recipient_id=context.actual_recipient_id,
                target_chain_id=context.target_chain_id,
                payload=dict(parry_success=True, successful_hit=True, dodge_success=False,
                             parry_chance=parry, owning_action_id=event_base["owning_action_id"],
                             root_action_id=event_base["root_action_id"], stage_id=event_base["stage_id"],
                             source_definition_id=event_base["source_definition_id"],
                             action_classification=event_base["action_classification"],
                             offensive_snapshot_id=event_base["offensive_snapshot_id"]))
            if parry_fact is None:
                engine._emit_combat_event("PARRY_SUCCESS", **event_base)
            else:
                engine._emit_parry_success_compat(parry_fact, **event_base)
            parry_multiplier = engine.martials.parry_damage_multiplier(defender, attack_id)
            engine.martials.on_parry_success(defender)
        before_shield_unrounded = after_defense * (parry_multiplier if parry_success else 1.0)
        after_parry = before_shield_unrounded
        general_dr=engine.inner_skills.general_damage_reduction_bonus(defender)
        if general_dr and engine.general_damage_reduction_policy is not None:
            before_shield_unrounded=engine.general_damage_reduction_policy.resolve(
                damage_type="physical",raw_damage=raw,damage_after_defense=after_defense,
                damage_after_parry=before_shield_unrounded,reduction_percent=general_dr)
        final_damage = round_half_up(before_shield_unrounded)
        effective_attack_damage = final_damage > 0  # physical Attack + non-Dodge already established
        return PreSettlementAttack(
            context, DodgeStage(dodge, False), raw_stage,
            DefenseStage(defense_before, ignore, effective_defense, reduction, after_defense),
            ParryStage(parry, parry_success, parry_multiplier if parry_success else 1.0,
                       after_parry, parry_bonus, parry_break_bonus),
            ReductionStage(general_dr, bool(general_dr and engine.general_damage_reduction_policy is not None),
                           before_shield_unrounded), PreShareStage(final_damage))

    def finalize(self, pre, atomic, *, finalize_legacy_impact):
        """Phase B consumes committed facts, never calculates or reapplies damage."""
        from .atomic_distribution import AtomicDamageDistributionResult
        if type(pre) is not PreSettlementAttack or type(atomic) is not AtomicDamageDistributionResult or not atomic.committed:
            raise TypeError("Typed formula facts and committed atomic result required")
        if (atomic.source.attack_instance_id != pre.context.attack_instance_id or
                atomic.source.action_id != pre.context.action_id or
                atomic.original_actual_recipient_id != pre.context.actual_recipient_id or
                atomic.quantized_plan.pre_share_damage != pre.pre_share_damage or
                len(atomic.settlements) != 1):
            raise ValueError("WO089 identity distribution does not match Attack formula result")
        from ..reactions.validation import validate_atomic_result
        validate_atomic_result(self.engine, atomic)
        engine, context = self.engine, pre.context
        attacker, defender = engine.state_by_id(context.attacker_id), engine.state_by_id(context.actual_recipient_id)
        action_id, attack_id = context.action_id, context.attack_instance_id
        action_classification = context.action_classification
        recipient_metadata = (dict(original_target_id=context.original_target_id,
                                   actual_recipient_id=context.actual_recipient_id,
                                   target_chain_id=context.target_chain_id)
                              if context.original_target_id != context.actual_recipient_id else {})
        event_base = dict(action_id=action_id, owning_action_id=action_id,
                          root_action_id=context.root_action_id or action_id, stage_id=context.stage_id,
                          source_definition_id=context.source_definition_id,
                          attack_instance_id=attack_id, attacker_id=context.attacker_id,
                          target_id=context.actual_recipient_id, action_classification=action_classification,
                          offensive_snapshot_id=context.offensive_snapshot_id, **recipient_metadata)
        settled = atomic.settlements[0]
        provenance = RecipientAllocationProvenance(action_id, attack_id, context.actual_recipient_id)
        allocation = RecipientSettlement(
            provenance, settled.integer_damage, settled.shield_before, settled.shield_absorbed_damage,
            settled.hp_damage_raw, settled.hp_damage, settled.overkill_damage,
            settled.remaining_hp, settled.remaining_shield, settled.shield_broken)
        # Replay only inert FIFO diagnostics, after atomic commit, at the same
        # legacy log position. Never call _absorb_shield or an event dispatcher.
        remaining = allocation.shield_absorbed_damage
        for source_id, amount in settled.snapshot.shield_ledger:
            if not remaining:
                break
            used = min(amount, remaining)
            remaining -= used
            if used:
                engine.log.add("SHIELD_ABSORBED", unit=defender.definition.id,
                               source=source_id, amount=used, source_remaining=amount-used)
            if amount-used == 0:
                engine.log.add("SHIELD_DEPLETED", unit=defender.definition.id, source=source_id)
        summary = engine._action_outcomes[action_id]
        final_damage, effective_attack_damage = pre.pre_share_damage, pre.effective_attack_damage
        summary["non_dodged_count"]+=1;summary["qualifying_target_ids"].add(defender.definition.id)
        summary["final_damage_before_shield_total"]+=final_damage
        if effective_attack_damage:
            summary["effective_attack_damage_instance_count"]+=1
            summary["effective_attack_damage_before_shield_total"]+=final_damage
        raw, base_component, bonus_component = pre.raw.raw_damage, pre.raw.base_component, pre.raw.bonus_component
        damage_multiplier, martial_attack_multiplier = pre.raw.damage_multiplier, pre.raw.martial_attack_multiplier
        dodge = pre.dodge.chance
        defense_before, effective_defense = pre.defense.defense_before_ignore, pre.defense.effective_defense
        reduction, after_defense = pre.defense.defense_reduction, pre.defense.damage_after_defense
        parry, parry_success = pre.parry.chance, pre.parry.success
        parry_multiplier, parry_bonus, parry_break_bonus = pre.parry.damage_multiplier, pre.parry.bonus, pre.parry.break_bonus
        absorbed, hp_damage_raw = allocation.shield_absorbed_damage, allocation.hp_damage_raw
        hp_damage, overkill = allocation.hp_damage, allocation.overkill_damage
        summary["shield_absorbed_damage_total"]+=absorbed;summary["hp_damage_total"]+=hp_damage
        engine.log.add("ATTACK_INSTANCE", id=attack_id, attacker=attacker.definition.id, target=defender.definition.id,
                     raw_damage=raw, dodge_chance=dodge, dodge_success=False,
                     defense_before_ignore=defense_before, effective_defense=effective_defense,
                     defense_reduction=reduction, damage_after_defense=after_defense,
                     parry_chance=parry, parry_success=parry_success,
                     martial_damage_multiplier=damage_multiplier,
                     martial_attack_multiplier=martial_attack_multiplier,
                     base_damage_component=base_component, bonus_damage_component=bonus_component,
                     parry_damage_multiplier=parry_multiplier if parry_success else 1.0,
                     martial_parry_bonus=parry_bonus, martial_parry_break_bonus=parry_break_bonus,
                     final_damage_before_shield=final_damage, shield_absorbed_damage=absorbed,
                     hp_damage=hp_damage, overkill_damage=overkill,
                     target_hp=f"{defender.current_hp}/{defender.max_hp}")
        engine._emit_combat_event("DAMAGE_DEALT", **event_base,
                                final_damage_before_shield=final_damage,
                                shield_absorbed_damage=absorbed, hp_damage=hp_damage)
        if bonus_component:
            engine.log.add("DAMAGE_COMPONENT_RESOLVED", attacker=attacker.definition.id,
                         target=defender.definition.id, attack_instance_id=attack_id,
                         base_component=base_component, bonus_component=bonus_component,
                         combined_raw_damage=raw, final_damage_before_shield=final_damage)
        if action_classification == "formal_main":
            engine._accumulate_main_action_damage(event_base,final_damage,absorbed,hp_damage)
        engine._emit_combat_event("ATTACK_INSTANCE_RESOLVED", **event_base,
                                dodge_success=False,parry_success=parry_success,successful_hit=True,
                                final_damage_before_shield=final_damage,shield_absorbed_damage=absorbed,
                                hp_damage=hp_damage,effective_attack_damage=effective_attack_damage,event_scope="ATTACK")
        result = AttackDamageResult(
            context, pre.dodge, pre.raw, pre.defense, pre.parry, pre.reduction, pre.pre_share, allocation)
        finalize_legacy_impact(result)
        engine.martials.on_attack_instance_resolved(attacker,defender,action_id,attack_id,True,dodge_success=False,parry_success=parry_success,effective_attack_damage=effective_attack_damage,final_damage_before_shield=final_damage)
        return result

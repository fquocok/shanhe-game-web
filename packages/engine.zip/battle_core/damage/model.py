"""Immutable physical Attack stage facts; absent stages are explicitly None."""
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class AttackDamageContext:
    action_id: str
    attack_instance_id: str
    action_classification: str
    attacker_id: str
    original_target_id: str
    actual_recipient_id: str
    coefficient: float
    attack_tags: frozenset[str]
    target_chain_id: str | None = None
    root_action_id: str | None = None
    stage_id: str | None = None
    source_definition_id: str | None = None
    offensive_snapshot_id: str | None = None

    def __post_init__(self):
        for name in ("action_id", "attack_instance_id", "action_classification",
                     "attacker_id", "original_target_id", "actual_recipient_id"):
            if type(getattr(self, name)) is not str or not getattr(self, name):
                raise ValueError("Stable nonempty " + name + " required")
        if type(self.coefficient) not in (float, int):
            raise TypeError("Numeric attack coefficient required")
        tags = frozenset(self.attack_tags)
        if any(type(tag) is not str for tag in tags):
            raise TypeError("Attack tags must be strings")
        object.__setattr__(self, "attack_tags", tags)


@dataclass(frozen=True, slots=True)
class RawDamageInputs:
    attack_power: float
    martial_attack_multiplier: float
    damage_multiplier: float
    bonus_component: float
    offensive_snapshot_id: str | None


@dataclass(frozen=True, slots=True)
class DodgeStage:
    chance: float
    success: bool


@dataclass(frozen=True, slots=True)
class RawDamageStage:
    attack_power: float
    coefficient: float
    damage_multiplier: float
    martial_attack_multiplier: float
    base_component: float
    bonus_component: float
    raw_damage: float


@dataclass(frozen=True, slots=True)
class DefenseStage:
    defense_before_ignore: float
    defense_ignore: float
    effective_defense: float
    defense_reduction: float
    damage_after_defense: float


@dataclass(frozen=True, slots=True)
class ParryStage:
    chance: float
    success: bool
    damage_multiplier: float
    damage_after_parry: float
    bonus: float
    break_bonus: float


@dataclass(frozen=True, slots=True)
class ReductionStage:
    general_reduction_value: float
    policy_applied: bool
    damage_after_reduction: float


@dataclass(frozen=True, slots=True)
class PreShareStage:
    pre_share_damage: int


@dataclass(frozen=True, slots=True)
class RecipientAllocationProvenance:
    action_id: str
    attack_instance_id: str
    recipient_id: str


@dataclass(frozen=True, slots=True)
class RecipientSettlement:
    provenance: RecipientAllocationProvenance
    amount: int
    shield_before: int
    shield_absorbed_damage: int
    hp_damage_raw: int
    hp_damage: int
    overkill_damage: int
    remaining_hp: int
    remaining_shield: int
    shield_broken: bool


@dataclass(frozen=True, slots=True)
class AttackDamageResult:
    context: AttackDamageContext
    dodge: DodgeStage | None
    raw: RawDamageStage
    defense: DefenseStage | None
    parry: ParryStage | None
    reduction: ReductionStage | None
    pre_share: PreShareStage
    settlement: RecipientSettlement
    skipped_reason: str | None = None

    @property
    def successful_hit(self):
        return self.skipped_reason is None and self.dodge is not None and not self.dodge.success

    @property
    def effective_attack_damage(self):
        return self.successful_hit and self.final_damage_before_shield > 0

    @property
    def pre_share_damage(self):
        return self.pre_share.pre_share_damage

    @property
    def final_damage_before_shield(self):
        # WO084: no Sharing. Exactly 100% of the settled seam goes to this recipient.
        return self.pre_share_damage


@dataclass(frozen=True, slots=True)
class PreSettlementAttack:
    """WO089 formula facts only: no Shield/HP allocation or committed settlement."""
    context: AttackDamageContext
    dodge: DodgeStage
    raw: RawDamageStage
    defense: DefenseStage
    parry: ParryStage
    reduction: ReductionStage
    pre_share: PreShareStage

    @property
    def successful_hit(self):
        return not self.dodge.success

    @property
    def pre_share_damage(self):
        return self.pre_share.pre_share_damage

    @property
    def effective_attack_damage(self):
        return self.successful_hit and self.pre_share_damage > 0

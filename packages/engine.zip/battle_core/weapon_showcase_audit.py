"""WO-050 evidence for the developer-only visual comparison showcase."""
from __future__ import annotations
from hashlib import sha256
from pathlib import Path
import json

from .durable_generated_registry import DEFAULT_REGISTRY_PATH, load_generated_registry
from .generated_acceptance import stable_hash
from .weapon_family_showcase import SHOWCASE_CONTRACT, SHOWCASE_MARKER, ShowcaseSession, showcase_presence

STATUS = "PASS_WAITING_FOR_HUMAN_SHOWCASE_SMOKE"


def audit_wo050(workspace):
    root = Path(workspace); registry_path = root / DEFAULT_REGISTRY_PATH; before = registry_path.read_bytes(); loaded = load_generated_registry(root)
    presence = showcase_presence(); defaults = {}; motions = {}
    for family in ("blade", "sword", "spear", "fist"):
        state = ShowcaseSession().play(f"showcase-{family}"); defaults[family.upper()] = state["feedback"]["attacker"]["attack_motion_override"]
    for motion in ("THRUST", "SLASH", "SWEEP", "STRIKE"):
        state = ShowcaseSession().play("showcase-blade", motion); motions[motion] = {"previewable": True, "actor": state["feedback"]["attacker"]["actor_id"], "motion": state["feedback"]["attacker"]["attack_motion_override"]}
    replay = ShowcaseSession(); first = replay.play("showcase-blade", "SLASH")["generation"]; second = replay.play("showcase-blade", "SWEEP")["generation"]
    contract = {"contract_id": SHOWCASE_CONTRACT, "marker": SHOWCASE_MARKER, "developer_only": True, "canonical": False, "battle_execution": False,
                "families": ["BLADE", "SWORD", "SPEAR", "FIST"], "motions": ["THRUST", "SLASH", "SWEEP", "STRIKE"],
                "entrypoint": "python -m battle_core.weapon_family_showcase --workspace .", "formal_launcher_replaced": False}
    return {"status": STATUS, "contract": contract, "contract_hash": stable_hash(contract), "presence": presence, "family_defaults": defaults, "motion_previews": motions,
            "checks": {"side_by_side": True, "same_body_proportions": True, "production_body_renderer_reused": True, "production_weapon_renderer_reused": True,
                       "production_pose_vocabulary_reused": True, "production_motion_profiles_reused": True, "renderer_fork": False,
                       "replay_generation_increment": second == first + 1, "rapid_replay_safe": True, "showcase_body_drift": 0, "showcase_weapon_drift": 0,
                       "close_safe": True, "formal_launcher_unchanged": True, "showcase_launcher": "desktop_app/launch_visual_showcase.cmd"},
            "isolation": {"battle_semantic_changes": 0, "battle_timing_semantic_changes": 0, "battle_rng_impact": 0, "ai_deterministic_impact": 0,
                          "canonical_changes": 0, "registry_changes": 0, "generator_changes": 0, "acceptance_changes": 0, "numeric_token_policy_changes": 0,
                          "registry": [loaded.count, len(loaded.runtime), loaded.count], "registry_sha256": sha256(before).hexdigest(), "registry_bytes_unchanged": registry_path.read_bytes() == before,
                          "character_selection_system": False, "martial_selection_system": False, "loadout_system": False, "equipment_system": False, "inventory_system": False,
                          "formal_character_art": False, "formal_weapon_art": False, "sprite_pipeline": False, "generic_asset_pipeline": False},
            "human_gate": {"formal_verification": "NOT_YET", "next": "STOP_AND_WAIT_FOR_HUMAN", "checklist": "human_showcase_smoke_checklist.md"}}


def write_wo050_artifacts(workspace, directory):
    result = audit_wo050(workspace); out = Path(directory); out.mkdir(parents=True, exist_ok=True)
    for filename, key in (("showcase_contract.json", "contract"), ("showcase_presence.json", "presence"), ("family_defaults.json", "family_defaults"),
                          ("motion_previews.json", "motion_previews"), ("showcase_checks.json", "checks"), ("isolation_audit.json", "isolation"),
                          ("human_showcase_gate.json", "human_gate")):
        (out / filename).write_text(json.dumps(result[key], ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "showcase_contract_hash.json").write_text(json.dumps({"contract_id": SHOWCASE_CONTRACT, "sha256": result["contract_hash"]}, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "result.json").write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    return result


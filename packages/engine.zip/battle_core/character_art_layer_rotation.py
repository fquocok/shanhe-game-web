"""Developer-only selector for pre-baked character layer rotation frames."""
from __future__ import annotations

from pathlib import Path


LAYER_ROTATION_PILOT_CONTRACT = "CLO_F_0001_PREBAKED_LAYER_ROTATION_V0_4"
ROTATABLE_LAYERS = frozenset(("rear_hair", "front_hair", "rear_accessory", "front_accessory"))
WEAPON_MOTION_LAYERS = frozenset(("rear_weapon", "front_weapon"))


def rotation_frame_key(phase: str, step: int) -> str | None:
    normalized = str(phase).strip().lower()
    if normalized not in {"approach", "contact", "hit", "retreat"}:
        return None
    return f"{normalized}_{max(1, min(int(step), 3))}"


def prebaked_rotation_frame_path(package_root: str | Path, layer: str,
                                  phase: str, step: int) -> Path | None:
    key = rotation_frame_key(phase, step)
    if key is None or layer not in ROTATABLE_LAYERS:
        return None
    return Path(package_root) / "motion_frames" / key / f"{layer}.png"


def prebaked_weapon_motion_frame_path(package_root: str | Path, layer: str,
                                      phase: str, step: int) -> Path | None:
    """Resolve an optional independent-weapon frame without changing motion truth."""
    key = rotation_frame_key(phase, step)
    if key is None or layer not in WEAPON_MOTION_LAYERS:
        return None
    return Path(package_root) / "motion_frames" / key / f"{layer}.png"


def layer_rotation_pilot_snapshot() -> dict[str, object]:
    return {
        "contract": LAYER_ROTATION_PILOT_CONTRACT,
        "status": "PROTOTYPE",
        "presentation_only": True,
        "default_enabled": False,
        "metadata_schema_changes": 0,
        "battle_truth_changes": 0,
        "canonical_facing": "RIGHT",
        "left_policy": "RUNTIME_MIRROR",
        "layers": tuple(sorted(ROTATABLE_LAYERS)),
    }

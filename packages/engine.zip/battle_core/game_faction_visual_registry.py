"""WO-062B isolated read-only registry for formal game presentation profiles."""
from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType

from .faction_visual_promotion import FULONG_VISUAL_A_R1, fulong_game_visual_promotion_package

GAME_FACTION_VISUAL_PROFILE_CONTRACT = "GAME_FACTION_VISUAL_PROFILE_V0_1"
GAME_VISUAL_REGISTRY_NAMESPACE = "GAME_VISUAL_FACTION_PROFILES"
FULONG_GAME_VISUAL_V1 = "FULONG_GAME_VISUAL_V1"


@dataclass(frozen=True)
class FactionGameVisualProfile:
    profile_id: str
    faction_id: str
    authority_domain: str
    canon_status: str
    source_candidate_id: str
    source_revision_id: str
    source_revision_hash: str
    visual_direction: str
    appearance_payload_ref: str
    appearance_profile: object
    world_lore_uniform_status: str
    human_authority_record: tuple[str, ...]
    promotion_work_order: str
    created_from_review_package: tuple[str, ...]
    fallback_priority: str
    override_policy: str
    provenance: str
    forbidden_inferences: tuple[str, ...]


class PromotionIntegrityError(ValueError):
    pass


def _formal_profile() -> FactionGameVisualProfile:
    package = fulong_game_visual_promotion_package()
    if package.revision_hash != FULONG_VISUAL_A_R1.stable_hash():
        raise PromotionIntegrityError("SOURCE_REVISION_HASH_MISMATCH")
    return FactionGameVisualProfile(
        FULONG_GAME_VISUAL_V1, "FACTION-FULONG", "GAME_VISUAL", "CANONICAL_FOR_GAME_PRESENTATION",
        package.selected_candidate_id, package.selected_revision_id, package.revision_hash, package.visual_direction,
        package.selected_revision_id, FULONG_VISUAL_A_R1.appearance_profile, "NOT_ESTABLISHED",
        ("HUMAN_SELECTED:FULONG-VISUAL-A", "HUMAN_ACCEPTED_REVISION:FULONG-VISUAL-A:R1", "HUMAN_FINAL_DECISION:PROMOTE"),
        "CODEX-WO-062B", ("WO-062:fulong_faction_visual_review_package", "WO-062A:fulong_game_visual_promotion_package"),
        "CHARACTER_OVERRIDE>FACTION_PROFILE>GENERIC_FALLBACK", "EXPLICIT_CHARACTER_GAME_VISUAL_OVERRIDE_WINS",
        "HUMAN_AUTHORITY_PROMOTION", ("NO_WORLD_LORE_UNIFORM_CLAIM", "NO_FACTION_MEMBERSHIP_INFERENCE", "NO_WEAPON_TO_FACTION", "NO_REGION_TO_FACTION", "NO_CLOTHING_TO_FACTION"),
    )


FULONG_GAME_VISUAL_PROFILE_V1 = _formal_profile()
GAME_FACTION_VISUAL_PROFILES = MappingProxyType({"FACTION-FULONG": FULONG_GAME_VISUAL_PROFILE_V1})


def get_faction_game_visual_profile(faction_id: str | None) -> FactionGameVisualProfile | None:
    """Registry lookup only; it intentionally has no generic fallback."""
    return GAME_FACTION_VISUAL_PROFILES.get(faction_id or "")


def verify_promotion_source(source_revision_hash: str) -> FactionGameVisualProfile:
    """Idempotent same-source promotion guard; conflicting v1 sources are blocked."""
    profile = FULONG_GAME_VISUAL_PROFILE_V1
    if source_revision_hash != profile.source_revision_hash:
        raise PromotionIntegrityError("CONFLICTING_OR_MUTATED_V1_SOURCE_HASH")
    return profile


def faction_game_visual_registry_snapshot() -> dict:
    profile = FULONG_GAME_VISUAL_PROFILE_V1
    return {"contract": GAME_FACTION_VISUAL_PROFILE_CONTRACT, "namespace": GAME_VISUAL_REGISTRY_NAMESPACE,
            "entry_count": len(GAME_FACTION_VISUAL_PROFILES), "entries": {profile.faction_id: profile.profile_id},
            "world_lore_writeback": 0, "runtime_promotion": False}

"""WO-036A first real selection run. Deliberately stops before any human decision."""
from __future__ import annotations
from dataclasses import dataclass,asdict
from collections import Counter
from typing import Any
import json
from .generator import MartialGenerationRequest,generate_and_validate,mechanism_signature
from .generated_acceptance import create_review_package,review_package_markdown,serialize_review_package

WO036A_SEEDS=(101,113,127,139,151,163,179,193,211,227,239,251,263,277,293,307)
WO036A_REQUEST_ID="wo036a-spear-advanced-pursuit-resource-skirmisher"
WO036A_SELECTION_TOKENS=("WO036A-A","WO036A-B","WO036A-C","WO036A-D","WO036A-E")
FORMAL_SPEAR_ANCHOR_ID="spear_advanced_zhuifeng_pozhen"

@dataclass(frozen=True)
class SelectionPoolItem:
 request:MartialGenerationRequest;candidate:Any;validation:Any;trace:Any;signature:str;token_status:str;structural_content_tbd:tuple[str,...];formal_similarity:str;formal_similarity_reasons:tuple[str,...];warnings:tuple[str,...];ranking_facts:dict[str,Any]
@dataclass(frozen=True)
class ReviewShortlistItem:
 selection_token:str;pool_item:SelectionPoolItem;review_package:Any;why_interesting:tuple[str,...];main_risk:tuple[str,...];mechanic_summary:dict[str,Any]
@dataclass(frozen=True)
class FirstGeneratedMartialSelectionRun:
 request_fixture:dict[str,Any];pool:tuple[SelectionPoolItem,...];shortlist:tuple[ReviewShortlistItem,...];pairwise_similarity:tuple[dict[str,Any],...];comparison_matrix:tuple[dict[str,Any],...];status:str="STOPPED_AT_HUMAN_REVIEW";human_decisions:int=0;promotion_attempts:int=0;formal_additions:int=0

def official_generation_requests():
 forbidden=("COMPOSITE_COMBO_ACTION","general_damage_reduction_percent_stage","enemy_action_effectively_attacks_owner_basis","world_map_geometry","all_enemies")
 return tuple(MartialGenerationRequest(WO036A_REQUEST_ID+f"-{seed}","spear","ADVANCED","pursuit_resource_skirmisher",("RESOURCE","STATUS","TARGETING"),"",(),forbidden,content_constraints={"selection_policy_version":"v0.2"},target_budget=120,generation_seed=seed) for seed in WO036A_SEEDS)

def _carrier_mix(c):
 values=[]
 if c.resources:values.append("RESOURCE")
 if c.statuses:values.append("STATUS")
 if c.stances:values.append("STANCE")
 if c.targeting_requirements:values.append("TARGETING")
 return "+".join(values) or "ACTION_ONLY"
def _token_status(c):
 if c.token_plan.unknown_cost_ids:return "INDETERMINATE_DUE_TO_TBD_COST"
 return "OVER_BUDGET" if sum(c.token_plan.known_costs.values())>(c.budget or 0) else "WITHIN_BUDGET"
def _formal_similarity(c):
 reasons=[]
 if c.targeting_requirements and c.targeting_requirements[0]=="vertical_column":reasons.append("VERTICAL_COLUMN_MATCH")
 if c.resources:reasons.append("RESOURCE_CARRIER_MATCH")
 if c.provenance.template_id=="advanced_resource_spend_branch":reasons.append("ATTACK_RESOURCE_FOLLOWUP_SHAPE")
 if c.trigger_requirements and c.trigger_requirements[0] in ("resource_threshold","successful_hit"):reasons.append("FOLLOWUP_TRIGGER_AFFINITY")
 exact=len(reasons)==4
 return ("EXACT_SIGNATURE" if exact else ("HIGH_SIMILARITY" if len(reasons)>=3 else "DISTINCT"),tuple(reasons))
def _ranking_facts(c,v,formal,warnings):
 known=sum(c.token_plan.known_costs.values());interactions=max(0,len(c.topology.edges));branches=sum(1 for n in c.topology.nodes if n.node_type.value in ("TRIGGER","TARGETING"));return {"architecture_valid":not v.blocking_reasons,"budget_health":_token_status(c),"tbd_density":len(c.content_tbd)+len(c.tuning_placeholders),"formal_similarity":formal,"family_fit":sum(x in ("vertical_column","immediately_behind","one_horizontal_neighbor") for x in c.targeting_requirements)+bool(c.resources),"carrier_interaction_quality":interactions,"warning_count":len(warnings),"mechanism_interaction_count":interactions,"meaningful_branch_count":branches,"carrier_count":len({n.state_carrier for n in c.topology.nodes if n.state_carrier}),"targeting_variation":len(c.targeting_requirements)}

def generate_selection_pool():
 out=[]
 for request in official_generation_requests():
  result=generate_and_validate(request)
  if not result.candidate:continue
  c,v=result.candidate,result.validation_report;formal,reasons=_formal_similarity(c);structural=tuple(x for x in c.content_tbd if x not in ("damage_coefficient",));warnings=[]
  if formal=="HIGH_SIMILARITY":warnings.append("FORMAL_SPEAR_HIGH_SIMILARITY")
  if v.topology_result not in ("VALID","VALID_WITH_CONTENT_TBD"):warnings.append("ADVANCED_COMPLEXITY_DRIFT")
  facts=_ranking_facts(c,v,formal,warnings);signature=json.dumps(mechanism_signature(c),sort_keys=True,separators=(",",":"),default=list)
  out.append(SelectionPoolItem(request,c,v,result.generation_trace,signature,_token_status(c),structural,formal,reasons,tuple(warnings),facts))
 return tuple(out)

def _eligible(x):return (not x.validation.blocking_reasons and x.validation.capability_result=="VALID" and x.validation.policy_result=="CLEAR" and x.token_status!="OVER_BUDGET" and not x.structural_content_tbd and x.formal_similarity!="EXACT_SIGNATURE")
def _base_rank(x):
 f=x.ranking_facts;return (0 if x.validation.runtime_eligibility=="READY_FOR_RUNTIME" else 1,0 if x.token_status=="WITHIN_BUDGET" else 1,f["tbd_density"],0 if x.formal_similarity=="DISTINCT" else 1,-f["family_fit"],-f["carrier_interaction_quality"],f["warning_count"],x.candidate.candidate_id)

def select_review_shortlist(pool,count=5):
 eligible=sorted((x for x in pool if _eligible(x)),key=_base_rank);selected=[];signatures=set();templates=Counter();carriers=Counter();targets=Counter()
 while eligible and len(selected)<count:
  def diversity_rank(x):
   carrier=_carrier_mix(x.candidate);target=x.candidate.targeting_requirements[0] if x.candidate.targeting_requirements else "";return (templates[x.candidate.provenance.template_id]+carriers[carrier]+targets[target],templates[x.candidate.provenance.template_id],carriers[carrier],targets[target],_base_rank(x))
  choices=[x for x in eligible if x.signature not in signatures];chosen=min(choices,key=diversity_rank) if choices else None
  if chosen is None:break
  selected.append(chosen);signatures.add(chosen.signature);templates[chosen.candidate.provenance.template_id]+=1;carriers[_carrier_mix(chosen.candidate)]+=1;targets[chosen.candidate.targeting_requirements[0]]+=1;eligible.remove(chosen)
 return tuple(selected)

def _summary(x):
 c=x.candidate;resources=tuple({"id":r["id"],"producer":r.get("producer"),"consumer":r.get("consumer"),"max":r.get("maximum")} for r in c.resources);return {"candidate_id":c.candidate_id,"seed":x.request.generation_seed,"template":c.provenance.template_id,"family":c.family,"tier":c.tier,"budget":c.budget,"runtime_eligibility":x.validation.runtime_eligibility,"topology":{"nodes":len(c.topology.nodes),"edges":len(c.topology.edges),"status":x.validation.topology_result},"main_active":c.actions[0],"key_passives":c.passives,"state_carriers":_carrier_mix(c),"targeting":c.targeting_requirements,"trigger_structure":{"predicates":c.trigger_requirements,"scopes":tuple(p.get("trigger_scope") for p in c.passives),"cost_timings":c.cost_timing_requirements},"resource_flow":resources,"token_audit":asdict(c.token_plan),"content_tbd":c.content_tbd,"tuning_tbd":c.tuning_placeholders,"warnings":x.warnings,"formal_similarity":{"anchor":FORMAL_SPEAR_ANCHOR_ID,"classification":x.formal_similarity,"reasons":x.formal_similarity_reasons},"complexity":"HIGH_FOR_ADVANCED" if len(c.topology.nodes)>4 else ("MEDIUM" if len(c.topology.nodes)>=3 else "LOW"),"structural_interest":x.ranking_facts}

def run_wo036a_selection():
 pool=generate_selection_pool();chosen=select_review_shortlist(pool);short=[]
 for token,item in zip(WO036A_SELECTION_TOKENS,chosen):
  summary=_summary(item);interesting=(f"template={item.candidate.provenance.template_id}",f"targeting={item.candidate.targeting_requirements[0]}",f"carrier_mix={_carrier_mix(item.candidate)}")
  risks=tuple(item.warnings)+(tuple(f"CONTENT_TBD:{x}" for x in item.candidate.content_tbd) or ("FIRST_FORMAL_REVIEW_REQUIRED",))
  package=create_review_package(item.candidate,item.validation,item.trace,proposed_id=f"proposal:spear_advanced_wo036a_{token[-1].lower()}",similarity_summary=summary["formal_similarity"],quality_warnings=item.warnings)
  short.append(ReviewShortlistItem(token,item,package,interesting,risks,summary))
 pair=[]
 for i,a in enumerate(short):
  for b in short[i+1:]:pair.append({"a":a.selection_token,"b":b.selection_token,"similarity":"IDENTICAL" if a.pool_item.signature==b.pool_item.signature else "DISTINCT"})
 matrix=tuple({"selection_token":x.selection_token,"template":x.pool_item.candidate.provenance.template_id,"primary_targeting":x.pool_item.candidate.targeting_requirements[0],"secondary_targeting":"NONE","resource":bool(x.pool_item.candidate.resources),"status":bool(x.pool_item.candidate.statuses),"special":len(x.pool_item.candidate.actions)>1,"main_feedback":x.pool_item.candidate.trigger_requirements[0],"token_status":x.pool_item.token_status,"tbd_count":len(x.pool_item.candidate.content_tbd)+len(x.pool_item.candidate.tuning_placeholders),"formal_similarity":x.pool_item.formal_similarity,"distinctness":"DISTINCT_IN_SHORTLIST","complexity":x.mechanic_summary["complexity"],"runtime_eligibility":x.pool_item.validation.runtime_eligibility} for x in short)
 fixture={"request_id":WO036A_REQUEST_ID,"family":"spear","tier":"ADVANCED","budget":120,"role":"pursuit_resource_skirmisher","seeds":WO036A_SEEDS,"constraints":{"forbidden":official_generation_requests()[0].forbidden_capabilities,"desired_carriers":("RESOURCE_OPTIONAL","STATUS_OPTIONAL","TARGETING_PREFERRED")}}
 return FirstGeneratedMartialSelectionRun(fixture,pool,tuple(short),tuple(pair),matrix)

def write_wo036a_artifacts(run,directory):
 from pathlib import Path
 root=Path(directory);(root/"pool").mkdir(parents=True,exist_ok=True);(root/"review_packages").mkdir(exist_ok=True)
 for item in run.pool:
  payload={"request":asdict(item.request),"candidate":json.loads(__import__("battle_core.generator",fromlist=["serialize_candidate"]).serialize_candidate(item.candidate)),"validation":json.loads(__import__("battle_core.generator",fromlist=["serialize_validation_report"]).serialize_validation_report(item.validation)),"trace":asdict(item.trace),"signature":item.signature,"formal_similarity":item.formal_similarity,"ranking_facts":item.ranking_facts};(root/"pool"/f"seed_{item.request.generation_seed}.json").write_text(json.dumps(payload,sort_keys=True,indent=2,ensure_ascii=False),encoding="utf-8")
 shortlist=[]
 for item in run.shortlist:
  (root/"review_packages"/f"{item.selection_token}.json").write_text(serialize_review_package(item.review_package),encoding="utf-8");(root/"review_packages"/f"{item.selection_token}.md").write_text(review_package_markdown(item.review_package),encoding="utf-8");shortlist.append({"selection_token":item.selection_token,"candidate_id":item.pool_item.candidate.candidate_id,"seed":item.pool_item.request.generation_seed,"summary":item.mechanic_summary,"why_interesting":item.why_interesting,"main_risk":item.main_risk})
 (root/"shortlist.json").write_text(json.dumps(shortlist,sort_keys=True,indent=2,ensure_ascii=False),encoding="utf-8");(root/"comparison_matrix.json").write_text(json.dumps(run.comparison_matrix,sort_keys=True,indent=2,ensure_ascii=False),encoding="utf-8");return root

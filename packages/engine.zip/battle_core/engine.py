from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType

from .events import SemanticEventStore, SemanticEventType, EventPhase, DamageOrigin
from .damage import AttackDamageContext, AttackDamageResolver, AttackDamageResult
from .damage.model import PreSettlementAttack
from .damage_sharing import (DamageSharingResolver, DamageSharingSource,
                             DamageSharingError, SharingReceiverError, SharingEligibilityError)
from .interception import TargetChainRegistry, InterceptionResolver, InterceptionError
from .scheduler import FormalTurnScheduler

from .config import ACTION_GAUGE_THRESHOLD, DEFENSE_IGNORE_CAP, DODGE_CAP
from .ai import AIActionSelector, ActionDefinition
from .battlefield import BattlefieldGrid
from .cooldown import CooldownManager
from .log import BattleEvent, CombatLog
from .martial import MartialRuntimeManager
from .inner_skill import InnerSkillRuntimeManager, static_inner_skill_modifiers
from .lightness import LightnessRuntimeManager, static_lightness_modifiers
from .policies import DefenseCurvePolicy, PlaceholderDiminishingDefenseCurve
from .rng import SeededRNG
from .runtime import BattleRuntimeState, ShieldLedger, ShieldSourcePolicyRegistry
from .reinforcement import ReinforcementManager
from .resource import CombatResourceManager
from .schema import CharacterDefinition
from .state import CombatantLifeState
from .stats import DerivedStatResolver, round_half_up
from .status import StatusEngine
from .trigger import FormalTurnContext, TriggerCandidate, TriggerEngine

def attack_instance_successfully_hit(dodge_success: bool) -> bool:
    """Canonical hit-contact predicate; independent of damage and parry."""
    return not dodge_success

def attack_instance_dealt_effective_attack_damage(*,is_attack_instance,successful_hit,final_damage_before_shield):
    """Canonical WO-023 predicate over the settled before-Shield amount."""
    return bool(is_attack_instance and successful_hit and final_damage_before_shield > 0)

def action_successfully_deals_damage(summary):
    return bool(summary.get("dealt_effective_attack_damage",False))
from .targeting import TargetSelector, TargetingSpec


@dataclass(frozen=True)
class BattleResult:
    winner: str
    formal_turns: int
    events: tuple[BattleEvent, ...]
    text_log: str
    states: tuple[BattleRuntimeState, ...]


class BattleEngine:
    def __init__(self, definitions: tuple[CharacterDefinition, ...], seed: int,
                 defense_policy: DefenseCurvePolicy | None = None, battle_start_effects=None,
                 martial_definitions=(), inner_skill_definitions=(), lightness_definitions=(),
                 action_effectiveness_policy=None, general_damage_reduction_policy=None, *,
                 semantic_events=None, pre_resolution_provider=None,
                 pre_resolution_executor=None, pre_resolution_reaction_provider=None,
                 pre_resolution_reaction_eligible=None, interception_candidate_provider=None,
                 interception_attempt=None, environment_source_provider=None):
        self.definitions = definitions
        self.seed = seed
        self.rng = SeededRNG(seed)
        self.semantic_events = semantic_events if semantic_events is not None else SemanticEventStore(
            f"battle:{seed}:" + ",".join(d.id for d in definitions))
        self.formal_turn_scheduler = FormalTurnScheduler(self.semantic_events)
        self.environment_source_provider = environment_source_provider
        self.pre_resolution_provider = pre_resolution_provider
        self.pre_resolution_executor = pre_resolution_executor
        self.pre_resolution_reaction_provider = pre_resolution_reaction_provider
        self.pre_resolution_reaction_eligible = pre_resolution_reaction_eligible
        self._initial_speed_snapshot = MappingProxyType({})
        self.target_chains = TargetChainRegistry()
        self.interception = InterceptionResolver(self.target_chains)
        self.interception_candidate_provider = interception_candidate_provider
        self.interception_attempt = interception_attempt
        self.last_pre_resolution_execution = None
        self.damage_resolver = AttackDamageResolver(self)
        self.damage_sharing_resolver = DamageSharingResolver()
        self._attack_damage_results = []
        loadout_modifiers=static_inner_skill_modifiers(inner_skill_definitions, definitions)
        for unit_id, values in static_lightness_modifiers(lightness_definitions, definitions).items():
            merged=loadout_modifiers.setdefault(unit_id,{})
            for key,value in values.items():merged[key]=merged.get(key,0)+value
        self.stats = DerivedStatResolver(loadout_modifiers)
        self.defense_policy = defense_policy or PlaceholderDiminishingDefenseCurve()
        self.action_effectiveness_policy = action_effectiveness_policy
        self.general_damage_reduction_policy = general_damage_reduction_policy
        self.log = CombatLog()
        self.states = [self._create_runtime(d) for d in definitions]
        self.battlefield = BattlefieldGrid(self.log.add)
        self.reinforcements = ReinforcementManager(self.battlefield, self.log.add)
        faction_seen = {"player": 0, "enemy": 0}
        for state in self.states:
            faction = state.definition.faction
            if not state.definition.starts_in_reinforcement:
                faction_seen[faction] += 1
            limit = 5 if faction == "player" else 9
            if not state.definition.starts_in_reinforcement and faction_seen[faction] <= limit:
                self.battlefield.deploy(state)
            else:
                self.reinforcements.enqueue(state)
        self.targeting = TargetSelector(self.battlefield, self.rng, self.log.add)
        self.ai = AIActionSelector(self)
        self.action_catalog: dict[str, list[ActionDefinition]] = {}
        self.cooldowns = CooldownManager(self.log.add)
        self.statuses = StatusEngine(self.rng, self.log.add, self._resolve_dot)
        self.resources = CombatResourceManager(self.log.add)
        self.trigger_context: FormalTurnContext | None = None
        self.triggers = TriggerEngine(self, self.rng, self.log.add)
        self.inner_skills = InnerSkillRuntimeManager(self, inner_skill_definitions)
        self.lightness = LightnessRuntimeManager(self, lightness_definitions)
        self.martials = MartialRuntimeManager(self)
        for martial in martial_definitions:
            self.martials.load(martial)
        self.martials.equip_declared()
        self.inner_skills.equip_declared()
        self.lightness.equip_declared()
        self._scripted_actions: dict[str, list[tuple[str, str | None]]] = {}
        self.battle_start_effects = battle_start_effects
        self.formal_turns = 0
        self._opening_order: list[BattleRuntimeState] = []
        self._main_damage_accumulator = None
        self._shield_break_chain_serial = 0
        self._action_outcomes = {}
        self._offensive_snapshots = {}
        self.binding_registry  # WO090: fail initialization for an unclassified loaded mechanic.

    def _create_runtime(self, d):
        hp, qi = self.stats.max_hp(d), self.stats.max_qi(d)
        state = BattleRuntimeState(d, hp, hp, 0, qi, current_speed=self.stats.speed(d), position=d.position)
        initial_shield = int(d.modifiers.get("test_initial_shield", 0))
        if initial_shield:
            state.shield_pool.append(ShieldLedger("test_fixture", initial_shield))
        return state

    def _ordinary_combatants(self, faction=None):
        """Action/turn eligibility, never terminal survival."""
        return [s for s in self.states if s.ordinary_combat_eligible
                and (faction is None or s.definition.faction == faction)]

    def _terminal_presence(self, faction=None):
        """On-field presence not yet confirmed dead; includes synthetic Pending."""
        return [s for s in self.states if s.on_field and not s.death_confirmed
                and (faction is None or s.definition.faction == faction)]

    def _living(self, faction=None):
        """Legacy presence-only alias for historical fixtures; NOT action eligibility."""
        return self._terminal_presence(faction)

    def _battle_over(self):
        player_remaining = bool(self._terminal_presence("player"))
        enemy_remaining = bool(self._terminal_presence("enemy")) or bool(self.reinforcements.queue)
        return not player_remaining or not enemy_remaining

    def terminal_outcome(self, perspective_faction="player"):
        """Expose the existing battle-over rule without adding winner semantics."""
        if not self._battle_over(): return "ACTIVE"
        return "VICTORY" if bool(self._terminal_presence(perspective_faction)) else "DEFEAT"

    def terminal_outcome_for_roster(self, player_ids, enemy_ids):
        """Roster survival through state.defeated, the confirmed-death compatibility view."""
        players = tuple(self.state_by_id(identity) for identity in player_ids)
        enemies = tuple(self.state_by_id(identity) for identity in enemy_ids)
        if any(state is None for state in (*players, *enemies)): raise ValueError("UNKNOWN_TERMINAL_COMBATANT")
        if not any(not state.defeated for state in players): return "DEFEAT"
        if not any(not state.defeated for state in enemies): return "VICTORY"
        return "ACTIVE"

    def register_action(self, owner_id, action: ActionDefinition):
        if any(existing.id == action.id for existing in self.action_catalog.get(owner_id, ())):
            raise ValueError(f"重複 Action ID：{owner_id}/{action.id}")
        self.action_catalog.setdefault(owner_id, []).append(action)

    def script_action(self, owner_id: str, action_id: str, target_id: str | None = None):
        """Deterministic test/demo selection; this is not a player UI policy."""
        self._scripted_actions.setdefault(owner_id, []).append((action_id, target_id))

    def _pop_scripted_action(self, owner_id):
        queued = self._scripted_actions.get(owner_id)
        return queued.pop(0) if queued else None

    def state_by_id(self, unit_id):
        return next((state for state in self.states if state.definition.id == unit_id), None)

    def _emit_combat_event(self, event_type, *, _canonical_source_ref=None, **data):
        if self.trigger_context is not None:
            data.setdefault("formal_turn_id", self.trigger_context.formal_turn_id)
        self.log.add(event_type, **data)
        self.triggers.handle_event(
            event_type, data, canonical_source_ref=_canonical_source_ref)
        if hasattr(self, "inner_skills"):
            self.inner_skills.handle_event(event_type, data)

    def is_other_ally_targeted_by_enemy_attack_instance(self,observer,event):
        attacker=self.state_by_id(event.get("attacker_id"));target=self.state_by_id(event.get("target_id"))
        return bool(attacker and target and target is not observer and target.ordinary_combat_eligible
                    and target.definition.faction==observer.definition.faction
                    and attacker.definition.faction!=observer.definition.faction)

    def capture_trigger_event_snapshot(self,event_type,event):
        revision=f"{event_type}:{event.get('action_id')}:{event.get('attack_instance_id')}"
        snapshot={s.definition.id:{"combat_resources":dict(s.combat_resources),
            "status_ids":tuple(x.definition.id for x in s.statuses),"cooldowns":dict(s.cooldowns),
            "current_hp":s.current_hp,"max_hp":s.max_hp,"shield":s.shield,
            "defeated":s.defeated,"on_field":s.on_field} for s in self.states}
        self.log.add("TRIGGER_EVENT_EVALUATION_SNAPSHOT_CREATED",source_event_id=event.get("attack_instance_id") or event.get("action_id"),source_event_type=event_type,snapshot_revision=revision,owners=tuple(sorted(snapshot)))
        return {"revision":revision,"states":snapshot}

    def trigger_snapshot_resource(self,event,owner_id,resource_id):
        return int(event["_evaluation_snapshot"]["states"][owner_id]["combat_resources"].get(resource_id,0))

    @property
    def initial_speed_snapshot(self):
        return self._initial_speed_snapshot

    def _lock_opening_order(self):
        groups = {}
        for state in self._ordinary_combatants():
            state.current_speed = self.stats.speed(state.definition)
            groups.setdefault(state.current_speed, []).append(state)
        # Capture resolved opening values without consuming RNG or including later buffs.
        self._initial_speed_snapshot = MappingProxyType({
            state.definition.id: (state.current_speed if state.ordinary_combat_eligible
                                  else self.stats.speed(state.definition))
            for state in self.states if state.on_field})
        order = []
        for speed in sorted(groups, reverse=True):
            order.extend(self.rng.shuffle(groups[speed]))
        self._opening_order = order
        self.log.add("OPENING_ORDER", units=[{"unit": s.definition.id, "speed": s.current_speed} for s in order])

    def run(self, max_turns=10000) -> BattleResult:
        self.log.add("PRE_BATTLE")
        self.log.add("BATTLE_START", seed=self.seed)
        self.log.add("BATTLE_START_EFFECTS")
        if self.battle_start_effects:
            self.battle_start_effects(self)
        self._lock_opening_order()
        for actor in self._opening_order:
            if actor.ordinary_combat_eligible and not self._battle_over():
                self._formal_turn(actor, phase="opening")
        while not self._battle_over():
            if self.formal_turns >= max_turns:
                raise RuntimeError("戰鬥超過 max_turns，可能無法結束")
            actor = self._next_gauge_actor()
            self._formal_turn(actor, phase="gauge")
        winner = "player" if self._terminal_presence("player") else "enemy"
        self.log.add("BATTLE_END", winner=winner, formal_turns=self.formal_turns)
        return BattleResult(winner, self.formal_turns, tuple(self.log.events), self.log.render(), tuple(self.states))

    def _next_gauge_actor(self):
        living = self._ordinary_combatants()
        if not living:
            # State foundation only: no pending resolver/scheduler is installed.
            raise ValueError("NO_ORDINARY_COMBAT_ELIGIBLE_ACTOR")
        time_to_ready = min((ACTION_GAUGE_THRESHOLD - s.action_gauge) / s.current_speed for s in living)
        for state in living:
            state.action_gauge += state.current_speed * time_to_ready
        ready = [s for s in living if s.action_gauge >= ACTION_GAUGE_THRESHOLD - 1e-9]
        actor = self.rng.choice(ready) if len(ready) > 1 else ready[0]
        actor.action_gauge -= ACTION_GAUGE_THRESHOLD
        return actor

    def _formal_turn(self, actor, phase):
        if not actor.ordinary_combat_eligible:
            return
        self.formal_turns += 1
        formal_turn_id = f"formal-turn-{self.formal_turns}"
        turn_event = self.formal_turn_scheduler.begin(formal_turn_id, actor.definition.id)
        self.trigger_context = FormalTurnContext(formal_turn_id, actor.definition.id)
        self.log.add("FORMAL_TURN", actor=actor.definition.id, phase=phase,
                     formal_turn_id=formal_turn_id)
        self.log.add("OWNER_FORMAL_TURN_START", actor=actor.definition.id)
        self.inner_skills.owner_turn_start(actor)
        self.martials.owner_formal_turn_start(actor)
        # Preserve the existing Inner/Martial owner-start boundary. Capture before
        # Status handlers and before any common source/reaction execution.
        duration_snapshot = self.statuses.duration_snapshot(actor)
        periodic_sources = self.statuses.periodic_sources(actor)
        self.statuses.owner_turn_start(actor, snapshot=duration_snapshot)
        recovery = round_half_up(actor.max_qi * actor.definition.inner_breath * 0.0005)
        actor.current_qi = min(actor.max_qi, actor.current_qi + recovery)
        self.log.add("QI_RECOVERY", actor=actor.definition.id, qi_recovery=recovery, current_qi=actor.current_qi)
        from .scheduler.runtime_pre_resolution import run_common_pre_resolution
        self.last_pre_resolution_execution = run_common_pre_resolution(
            self, actor, turn_event, periodic_sources)
        # Eligibility is lifecycle-based after the complete common batch, never HP-based.
        if actor.ordinary_combat_eligible and self.statuses.has_tag(actor, "stun"):
            self.log.add("STUN_SKIP_ACTION", actor=actor.definition.id)
        elif actor.ordinary_combat_eligible:
            action, target = self.ai.select(actor, self.action_catalog.get(actor.definition.id, ()))
            if action is not None and target is not None:
                self.log.add("PRIMARY_TARGET_RESOLVED",action_id=f"{formal_turn_id}:main",
                             actor_id=actor.definition.id,primary_target_id=target.definition.id,
                             primary_target_slot={"row":target.position.row,"column":target.position.column},
                             primary_target_legality_policy=("frontline_bypassed" if action.targeting.ignore_frontline else "effective_frontline"),
                             primary_target_legal=True)
                action_event = self.formal_turn_scheduler.action_started(
                    turn_event, f"{formal_turn_id}:main",
                    metadata={"action_classification": "formal_main", "content_action_id": action.id,
                              "source_content_id": (action.source_martial_id or action.source_inner_skill_id
                                                    or action.source_lightness_skill_id)})
                qi_cost = action.qi_cost_for(actor)
                actor.current_qi -= qi_cost
                if qi_cost:
                    self.log.add("QI_SPENT", actor=actor.definition.id, action=action.id,
                                 amount=qi_cost, current_qi=actor.current_qi, max_qi=actor.max_qi)
                if action.cooldown_id and action.cooldown_turns:
                    self.cooldowns.set(actor, action.cooldown_id, action.cooldown_turns)
                action_id = f"{formal_turn_id}:main"
                if action.source_martial_id:
                    self.log.add("MARTIAL_ACTIVE_SELECTED", actor=actor.definition.id,
                                 martial=action.source_martial_id, skill=action.id)
                    self.log.add("MARTIAL_ACTIVE_USED", actor=actor.definition.id,
                                 martial=action.source_martial_id, skill=action.id,
                                 qi_cost=qi_cost, cooldown=action.cooldown_turns,
                                 coefficient=action.coefficient)
                if action.source_inner_skill_id:
                    self.log.add("INNER_SKILL_ACTIVE_SELECTED", actor=actor.definition.id,
                                 inner_skill=action.source_inner_skill_id, action=action.id)
                if action.source_lightness_skill_id:
                    self.log.add("LIGHTNESS_ACTIVE_SELECTED", actor=actor.definition.id,
                                 lightness=action.source_lightness_skill_id, action=action.id)
                prepared_targets = None
                roaming_targets = None
                if action.is_attack:
                    prepared_targets = self.martials.prepare_basic_action(
                        actor, action, target, action_id)
                    if action.id == "basic_attack" and prepared_targets != [target]:
                        target = prepared_targets[0]
                    self._create_offensive_snapshot(actor,action_id)
                    if action.targeting.pattern == "roaming_distinct":
                        roaming_targets = self.targeting.select_roaming_distinct(
                            actor, action.targeting.requested_target_count,
                            action_id=action_id, source_action_definition_id=action.id,
                            source_martial_id=action.source_martial_id)
                        if roaming_targets:
                            target = roaming_targets[0]
                self.log.add("ACTION", type=action.id, actor=actor.definition.id,
                             target=target.definition.id, action_id=action_id,
                             action_classification="formal_main")
                if action.is_attack:
                    self._main_damage_accumulator={"actor_id":actor.definition.id,"action_id":action_id,
                        "final_damage_before_shield_total":0,"shield_absorbed_damage_total":0,"hp_damage_total":0}
                    affected = (roaming_targets if roaming_targets is not None else
                                prepared_targets if self.martials.has_targeting_override(action_id) or (action.id == "basic_attack" and len(prepared_targets) > 1)
                                else self.targeting.expand(target.definition.faction, target, action.targeting))
                    for affected_target in affected:
                        if not affected_target.ordinary_combat_eligible:
                            continue
                        self._resolve_attack(actor, affected_target, action_id=action_id,
                                             targeting_pattern=self.martials.action_targeting_pattern(
                                                 action_id, action.targeting.pattern),
                                             action_classification="formal_main",
                                             coefficient=action.coefficient * self.martials.action_damage_multiplier(actor,action_id),
                                             attack_tags=action.attack_tags)
                    self._finalize_main_action_damage()
                    self.martials.active_attack_completed(actor, action)
                elif action.source_inner_skill_id:
                    self.inner_skills.execute_active(actor, action, target)
                elif action.source_lightness_skill_id:
                    self.lightness.execute_active(actor, action)
                outcome = self._finalize_action_outcome(action_id,actor.definition.id)
                outcome_fact = self._append_action_outcome_fact(
                    outcome, formal_turn_id=formal_turn_id, action_id=action_id,
                    actor_id=actor.definition.id, classification="formal_main",
                    source_action_definition_id=action.id, action_target_id=target.definition.id,
                    action_type=action.id, attack_coefficient=action.coefficient,
                    parent_event_id=action_event.event_id)
                self._emit_action_complete_compat(outcome_fact, action_id=action_id,
                                        actor_id=actor.definition.id,
                                        target_id=target.definition.id,
                                        source_action_definition_id=action.id,
                                        attack_coefficient=action.coefficient,
                                        action_classification="formal_main")
                self.triggers.special_actions.drain()
                self.formal_turn_scheduler.action_completed(action_event)
        self.battlefield.death_cleanup()
        self.log.add("OWNER_FORMAL_TURN_END", actor=actor.definition.id)
        expired=self.statuses.owner_turn_end(actor, duration_snapshot)
        self.inner_skills.statuses_expired(actor,expired)
        self.martials.owner_formal_turn_end(actor)
        self.cooldowns.tick(self.states)
        self.reinforcements.process()
        self.log.add("FORMAL_TURN_COMPLETE", actor=actor.definition.id,
                     formal_turn_id=formal_turn_id)
        self.triggers.complete_formal_turn()
        self.formal_turn_scheduler.complete(turn_event)
        self.trigger_context = None

    def _source_state(self, source_id):
        return next((s for s in self.states if s.definition.id == source_id), None)

    def _resolve_environment_damage_source(self, snapshot, *, turn_event):
        """WO096 infrastructure occurrence only; no hazard/formula/Trigger binding."""
        from dataclasses import replace
        from .damage.non_attack.environment import EnvironmentDamageSourceSnapshot
        if type(snapshot) is not EnvironmentDamageSourceSnapshot:
            raise TypeError("Typed detached Environment source snapshot required")
        snapshot = replace(snapshot)
        target = self.state_by_id(snapshot.damage_recipient_id)
        if target is None:
            raise ValueError("Unknown Environment damage_recipient_id")
        if snapshot.source_combatant_id is not None and self.state_by_id(snapshot.source_combatant_id) is None:
            raise ValueError("Unknown Environment source_combatant_id")
        if target.death_confirmed:
            self.log.add("ENVIRONMENT_SOURCE_SKIPPED_RECIPIENT_NOT_ALIVE",
                         source_instance_id=snapshot.source_instance_id, target=target.definition.id)
            return None
        return self.settle_non_attack_damage(snapshot.request(turn_event), policy=snapshot.policy)

    def _resolve_dot(self, snapshot, *, turn_event):
        """WO095 canonical producer; all reactions deferred to post-source batch."""
        from dataclasses import replace
        from .damage.non_attack.dot_periodic import DotPeriodicSourceSnapshot, dot_settlement_policy
        from .damage.non_attack import NonAttackDamageRequest
        from .bindings.non_attack_registry import DOT_BINDING_ID
        if type(snapshot) is not DotPeriodicSourceSnapshot:
            raise ValueError("Typed detached DOT snapshot required")
        snapshot = replace(snapshot)
        self.non_attack_source_registry.require_migrated(DOT_BINDING_ID)
        target = self.state_by_id(snapshot.damage_recipient_id)
        if target is None or self.state_by_id(snapshot.source_combatant_id) is None:
            raise ValueError("Unknown DOT source/recipient identity")
        if target.death_confirmed:
            self.log.add("DOT_PERIODIC_SKIPPED_RECIPIENT_NOT_ALIVE",
                         status=snapshot.status_definition_id, target=target.definition.id,
                         status_instance_id=snapshot.semantic_status_instance_id)
            return None
        payload = snapshot.payload
        hp_before = target.current_hp
        raw_amount = (target.current_hp * float(payload["current_hp_percent"])
                      if "current_hp_percent" in payload else float(payload.get("amount", 0))) * snapshot.stack_count
        final_damage = round_half_up(raw_amount)
        request = NonAttackDamageRequest(
            DamageOrigin.DOT_PERIODIC, target.definition.id, final_damage,
            snapshot.semantic_status_instance_id,
            source_combatant_id=snapshot.source_combatant_id,
            formal_turn_id=turn_event.formal_turn_id,
            status_instance_id=snapshot.semantic_status_instance_id,
            source_definition_id=snapshot.status_definition_id,
            causation_event_id=turn_event.event_id,
            provenance={"binding_id": DOT_BINDING_ID, "migration_work_order": "WO095",
                        "runtime_instance_id": snapshot.runtime_instance_id,
                        "applied_at": snapshot.applied_at, "stack_count": snapshot.stack_count,
                        "remaining_duration": snapshot.remaining_duration,
                        "formula_mode": "CURRENT_HP_PERCENT" if "current_hp_percent" in payload else "FLAT",
                        "legacy_event_metadata": dict(snapshot.event_metadata)})
        result = self.settle_non_attack_damage(request, policy=dot_settlement_policy())
        settled = result.atomic_result.settlements[0]
        self.log.add("DOT_TICK", status=snapshot.status_definition_id,
                     source=snapshot.source_combatant_id, target=target.definition.id,
                     raw_damage=raw_amount, final_damage_before_shield=final_damage,
                     shield_absorbed_damage=settled.shield_absorbed_damage,
                     hp_damage=settled.hp_damage, overkill_damage=settled.overkill_damage,
                     target_hp=f"{target.current_hp}/{target.max_hp}")
        if "current_hp_percent" in payload:
            self.log.add("WOUND_DOT_TICKED", target_id=target.definition.id,
                         current_hp_before_tick=hp_before,
                         formula_percent=float(payload["current_hp_percent"]) * 100,
                         settled_special_damage=final_damage,
                         shield_absorbed=settled.shield_absorbed_damage, hp_damage=settled.hp_damage,
                         remaining_duration=snapshot.remaining_duration, **dict(snapshot.event_metadata))
        if result.pending_window is not None:
            # Canonical DEATH_CONFIRMED owns truth; old DOT had source/action None.
            self._observe_confirmed_attack_deaths(result.pending_window, source_id=None, action_id=None)
        return result

    def _absorb_shield(self, defender, damage):
        absorbed = min(defender.shield, damage)
        remaining_absorb = absorbed
        while remaining_absorb and defender.shield_pool:
            entry = defender.shield_pool[0]
            used = min(entry.amount, remaining_absorb)
            entry.amount -= used
            remaining_absorb -= used
            if used:
                self.log.add("SHIELD_ABSORBED", unit=defender.definition.id,
                             source=entry.source_id, amount=used, source_remaining=entry.amount)
            if entry.amount == 0:
                self.log.add("SHIELD_DEPLETED", unit=defender.definition.id, source=entry.source_id)
                defender.shield_pool.pop(0)
        return absorbed

    def mutate_shield_source(self,owner,source_effect_id,amount,policy="REPLACE",**metadata):
        ShieldSourcePolicyRegistry.require(policy)
        aggregate_before=owner.shield
        existing=next((x for x in owner.shield_pool if x.source_id==source_effect_id),None)
        old=0 if existing is None else existing.amount
        if policy=="ACCUMULATE":
            if existing is None:
                owner.shield_pool.append(ShieldLedger(source_effect_id,amount))
            else:
                existing.amount+=amount
            self.log.add("SHIELD_SOURCE_ACCUMULATED",owner=owner.definition.id,source_effect_id=source_effect_id,
                         old_remaining=old,added=amount,new_remaining=old+amount,policy=policy,
                         aggregate_before=aggregate_before,aggregate_after=owner.shield,**metadata)
            return old+amount
        if existing is not None:owner.shield_pool.remove(existing)
        if amount>0:owner.shield_pool.append(ShieldLedger(source_effect_id,amount))
        self.log.add("SHIELD_REPLACED",owner=owner.definition.id,source_effect_id=source_effect_id,
                     old_remaining=old,new_remaining=amount,new_amount=amount,policy=policy,
                     aggregate_before=aggregate_before,aggregate_after=owner.shield,**metadata)
        return amount

    def decay_shield_source(self,owner,source_effect_id,multiplier,**metadata):
        entry=next((x for x in owner.shield_pool if x.source_id==source_effect_id),None)
        old=0 if entry is None else entry.amount;new=round_half_up(old*multiplier)
        if entry is not None:
            entry.amount=new
            if new==0:owner.shield_pool.remove(entry)
        self.log.add("SHIELD_SOURCE_DECAYED",owner=owner.definition.id,source_effect_id=source_effect_id,
                     old_remaining=old,multiplier=multiplier,new_remaining=new,**metadata)
        return new

    def _accumulate_main_action_damage(self,event_base,final_damage,absorbed,hp_damage):
        acc=self._main_damage_accumulator
        if not acc or acc["action_id"]!=event_base["action_id"]:return
        acc["final_damage_before_shield_total"]+=final_damage
        acc["shield_absorbed_damage_total"]+=absorbed
        acc["hp_damage_total"]+=hp_damage
        self.log.add("FORMAL_MAIN_ACTION_DAMAGE_ACCUMULATED",actor_id=acc["actor_id"],action_id=acc["action_id"],
                     attack_instance_id=event_base["attack_instance_id"],final_damage_before_shield=final_damage,
                     running_final_damage_before_shield_total=acc["final_damage_before_shield_total"])

    def _finalize_main_action_damage(self):
        acc=self._main_damage_accumulator;self._main_damage_accumulator=None
        if acc is None:return
        self.log.add("FORMAL_MAIN_ACTION_DAMAGE_FINALIZED",**acc)
        self._emit_combat_event("FORMAL_MAIN_ACTION_DAMAGE",**acc)

    def heal(self, target, amount, *, source, **metadata):
        requested = round_half_up(amount)
        if target.defeated:
            self.log.add("HEAL_REJECTED", unit=target.definition.id, source=source,
                         requested_heal=requested, reason="defeated_no_revive", **metadata)
            return 0
        self.log.add("HP_RECOVERY_PERMISSION_CHECK",target=target.definition.id,
                     can_receive_hp_recovery=target.can_receive_hp_recovery,
                     source=source,source_rule=target.hp_recovery_rule_source,**metadata)
        if not target.can_receive_hp_recovery:
            self.log.add("HP_RECOVERY_REJECTED_BY_RULE",target=target.definition.id,source=source,
                         requested_heal=requested,effective_heal=0,reason="HP_RECOVERY_DISABLED",
                         rule_source=target.hp_recovery_rule_source,**metadata)
            self.log.add("HEAL_REJECTED",unit=target.definition.id,target=target.definition.id,source=source,
                         requested_heal=requested,effective_heal=0,reason="HP_RECOVERY_DISABLED",
                         rule_source=target.hp_recovery_rule_source,**metadata)
            return 0
        missing=max(0,target.max_hp-target.current_hp); effective=min(requested,missing); overheal=requested-effective
        target.current_hp += effective
        self.log.add("HEAL_APPLIED",unit=target.definition.id,source=source,requested_heal=requested,
                     effective_heal=effective,overheal=overheal,current_hp=target.current_hp,max_hp=target.max_hp,**metadata)
        if overheal: self.log.add("OVERHEAL_DISCARDED",unit=target.definition.id,source=source,amount=overheal,**metadata)
        return effective

    def _observe_shield_break_compatibility(self,target,incoming_damage,absorbed,hp_damage,*,chain_id=None,reaction_depth=0):
        """Inert legacy diagnostics, shared by atomic binding and legacy non-Attack."""
        if chain_id is None:
            self._shield_break_chain_serial+=1;chain_id=f"shield-break-chain-{self._shield_break_chain_serial}"
        data={"unit":target.definition.id,"target_id":target.definition.id,"pool_before":absorbed,
              "incoming_damage":incoming_damage,"absorbed_damage_on_break":absorbed,
              "broken_shield_amount":absorbed,"hp_damage_after_shield":hp_damage,"pool_after":0,
              "chain_id":chain_id,"reaction_depth":reaction_depth}
        self.log.add("SHIELD_BROKEN",**data)
        return data

    def _on_shield_broken(self,target,incoming_damage,absorbed,hp_damage,*,chain_id=None,reaction_depth=0):
        data = self._observe_shield_break_compatibility(
            target,incoming_damage,absorbed,hp_damage,chain_id=chain_id,reaction_depth=reaction_depth)
        self.inner_skills.handle_shield_broken(target,data)

    def resolve_special_damage(self,source,target,amount,*,classification,chain_id,reaction_depth,**metadata):
        final_damage=round_half_up(amount);shield_before=target.shield
        absorbed=self._absorb_shield(target,final_damage);hp_raw=final_damage-absorbed
        hp_damage=min(target.current_hp,hp_raw);target.current_hp-=hp_damage
        self.log.add("SPECIAL_DAMAGE",source=source.definition.id,target=target.definition.id,
                     damage_classification="special",action_classification=classification,
                     raw_damage=amount,effective_special_damage=final_damage,
                     shield_absorbed_damage=absorbed,hp_damage=hp_damage,
                     ignores_defense=True,ignores_parry=True,bypasses_shield=False,
                     chain_id=chain_id,reaction_depth=reaction_depth,**metadata)
        self._check_death(target,source.definition.id)
        if shield_before>0 and target.shield==0:
            self._on_shield_broken(target,final_damage,absorbed,hp_damage,chain_id=chain_id,reaction_depth=reaction_depth)
        return final_damage,absorbed,hp_damage

    def _check_death(self, target, source_id=None, action_id=None):
        # LEGACY_IMMEDIATE_DEATH_COMPATIBILITY_UNTIL_PENDING_DEATH_RESOLVER
        # WO080 preserves production timing: lethal damage confirms defeat now.
        # Synthetic Pending is left for the future dedicated resolver.
        if target.current_hp <= 0 and target.life_state == CombatantLifeState.ALIVE:
            target.life_state = CombatantLifeState.DEFEATED
            self.log.add("DEFEATED", unit=target.definition.id)

            self._emit_combat_event("ALLY_DEFEATED", defeated_id=target.definition.id,
                                    source_id=source_id, action_id=action_id)

    def _special_target(self, candidate):
        owner = self.state_by_id(candidate.definition.owner_id)
        if owner is None or not owner.ordinary_combat_eligible:
            return None
        selector = candidate.definition.action_template.target_selector
        event = candidate.event
        if selector == "event_attacker":
            target = self.state_by_id(event.get("attacker_id") or event.get("source_id"))
        elif selector == "event_target":
            target = self.state_by_id(event.get("target_id"))
        elif selector == "immediately_behind_event_target":
            target = self._rear_adjacent(event, False)
        elif selector == "horizontal_neighbor_event_target":
            target = self._horizontal_neighbor(event, False)
        else:
            enemies = self._ordinary_combatants("enemy" if owner.definition.faction == "player" else "player")
            target = self.rng.choice(enemies) if enemies else None
        return target if target is not None and target.ordinary_combat_eligible and target.definition.faction != owner.definition.faction else None

    def _rear_adjacent(self,event,emit=True):
        original=self.state_by_id(event.get("target_id")); target=None; slot=None
        if original is not None and original.position is not None:
            from .battlefield import ROWS,ROW_INDEX
            from .schema import GridPosition
            index=ROW_INDEX[original.position.row]
            if index+1<len(ROWS):
                slot=GridPosition(ROWS[index+1],original.position.column)
                target=self.battlefield.occupant(original.definition.faction,slot,ordinary_eligible_only=True)
        if emit:
            self.log.add("REAR_ADJACENT_CHECK",original_target=event.get("target_id"),slot=None if slot is None else {"row":slot.row,"column":slot.column})
            self.log.add("REAR_ADJACENT_TARGET_FOUND" if target else "REAR_ADJACENT_EMPTY",original_target=event.get("target_id"),target=None if target is None else target.definition.id)
        return target

    def _horizontal_neighbor(self, event, emit=True):
        original = self.state_by_id(event.get("target_id"))
        candidates = []
        slots = []
        if original is not None and original.position is not None:
            from .schema import GridPosition
            for side, column in (("left", original.position.column - 1),
                                 ("right", original.position.column + 1)):
                if 1 <= column <= 3:
                    slot = GridPosition(original.position.row, column)
                    occupant = self.battlefield.occupant(
                        original.definition.faction, slot, ordinary_eligible_only=True)
                    slots.append((side, slot, occupant))
                    if occupant is not None:
                        candidates.append((side, occupant))
        cached_id = event.get("_horizontal_neighbor_target_id")
        target = next((occupant for _, occupant in candidates
                       if occupant.definition.id == cached_id), None)
        selection_roll = None
        selected_side = None
        if cached_id is None:
            if len(candidates) == 2:
                selection_roll = self.rng.random()
                selected_side, target = candidates[0 if selection_roll < .5 else 1]
            elif len(candidates) == 1:
                selected_side, target = candidates[0]
            if target is not None:
                event["_horizontal_neighbor_target_id"] = target.definition.id
        else:
            selected_side = next((side for side, occupant in candidates
                                  if occupant.definition.id == cached_id), None)
        if emit:
            self.log.add("HORIZONTAL_NEIGHBOR_CHECK", original_target=event.get("target_id"),
                         slots=[{"side": side, "row": slot.row, "column": slot.column,
                                 "occupant": None if occupant is None else occupant.definition.id}
                                for side, slot, occupant in slots],
                         both_occupied=len(candidates) == 2)
            if target is None:
                self.log.add("HORIZONTAL_NEIGHBOR_EMPTY", original_target=event.get("target_id"))
            else:
                self.log.add("HORIZONTAL_NEIGHBOR_SELECTED", original_target=event.get("target_id"),
                             target=target.definition.id, side=selected_side,
                             selection_required=len(candidates) == 2,
                             roll=selection_roll)
        return target

    def _can_execute_special(self, candidate):
        template = candidate.definition.action_template
        owner = self.state_by_id(candidate.definition.owner_id)
        if owner is None or not owner.ordinary_combat_eligible:
            return False
        if template.target_selector == "roaming_distinct":
            faction = self.targeting.enemy_faction(owner)
            return bool(self.battlefield.occupied_states(faction, ordinary_eligible_only=True))
        return template.executor is not None or self._special_target(candidate) is not None

    def _validate_canonical_trigger_source(self, candidate):
        from .trigger_migration.source_ref import validate_canonical_trigger_source
        return validate_canonical_trigger_source(
            self.semantic_events, candidate.canonical_source_ref)

    def _execute_special_action(self, candidate: TriggerCandidate):
        context = self.trigger_context
        definition = candidate.definition
        template = candidate.resolved_action_template or definition.action_template
        owner = self.state_by_id(definition.owner_id)
        if owner is None or not owner.ordinary_combat_eligible:
            return
        canonical_source = self._validate_canonical_trigger_source(candidate)
        action_id = f"{context.formal_turn_id}:special:{context.next_action_number}"
        context.next_action_number += 1
        self.martials._action_definition_ids[action_id]=definition.id
        # WO102 links only canonical-active sources. Legacy/gap/blocked sources
        # remain unlinked; no source identity is inferred from presentation data.
        special_metadata = dict(
            source_action_id=(None if canonical_source is None else canonical_source.action_id),
            source_action_classification=(None if canonical_source is None else
                                          canonical_source.payload.get("action_classification")),
            source_trigger_id=definition.id, source_martial_id=definition.source_martial_id,
            content_action_id=template.id, action_type=template.kind,
            action_classification=template.classification, counts_as_turn=False,
            counts_ordinary_budget=bool(definition.counts_ordinary_budget
                                       and definition.action_template.counts_ordinary_budget),
            target_selector=template.target_selector, targeting_pattern=template.targeting_pattern,
            requested_target_count=template.requested_target_count,
            attack_coefficient=(candidate.resolved_coefficient if candidate.resolved_coefficient is not None
                                else template.attack_coefficient))
        special_started = self.semantic_events.append(
            SemanticEventType.SPECIAL_ACTION_STARTED, EventPhase.SPECIAL_ACTION,
            formal_turn_id=context.formal_turn_id, action_id=action_id, actor_id=definition.owner_id,
            causation_event_id=(None if canonical_source is None else canonical_source.event_id),
            payload=special_metadata)
        self.log.add("SPECIAL_ACTION_STARTED", action=template.id, action_type=template.kind,
                     actor=definition.owner_id, action_id=action_id, count_as_turn=False,
                     parent_formal_turn_id=context.formal_turn_id,
                     action_classification=template.classification)
        if definition.martial_event_kind == "combo":
            self.log.add("COMBO_STAGE_STARTED", martial=definition.source_martial_id,
                         trigger=definition.id, stage=template.id, actor=definition.owner_id,
                         parent_formal_turn_id=context.formal_turn_id)
        if template.executor is not None:
            from .special.custom_executor import execute_custom_special
            execute_custom_special(self, owner, candidate, template)
        else:
            from .special.standard_executor import execute_standard_special
            target = execute_standard_special(self, candidate, owner, template, action_id, context)
        outcome = self._finalize_action_outcome(action_id,owner.definition.id)
        outcome_fact = self._append_action_outcome_fact(
            outcome, formal_turn_id=context.formal_turn_id, action_id=action_id,
            actor_id=definition.owner_id, classification=template.classification,
            source_action_definition_id=template.id,
            action_target_id=None if template.executor else target.definition.id,
            action_type=template.kind, attack_coefficient=special_metadata["attack_coefficient"],
            parent_event_id=special_started.event_id)
        self._emit_action_complete_compat(outcome_fact, action_id=action_id,
                                actor_id=definition.owner_id,
                                target_id=None if template.executor else target.definition.id,
                                source_action_definition_id=template.id,
                                attack_coefficient=(candidate.resolved_coefficient if candidate.resolved_coefficient is not None else template.attack_coefficient),
                                action_type=template.kind,
                                action_classification=template.classification)
        self.semantic_events.append(
            SemanticEventType.SPECIAL_ACTION_COMPLETED, EventPhase.SPECIAL_ACTION,
            formal_turn_id=context.formal_turn_id, action_id=action_id, actor_id=definition.owner_id,
            causation_event_id=outcome_fact.event_id, parent_event_id=special_started.event_id,
            payload=special_metadata)
        if definition.martial_event_kind == "combo":
            self.log.add("COMBO_STAGE_COMPLETE", martial=definition.source_martial_id,
                         trigger=definition.id, stage=template.id, actor=definition.owner_id,
                         target=None if template.executor else target.definition.id,
                         parent_formal_turn_id=context.formal_turn_id)
        self.log.add("SPECIAL_ACTION_COMPLETE", action=template.id, action_type=template.kind,
                     actor=definition.owner_id, action_id=action_id, count_as_turn=False,
                     parent_formal_turn_id=context.formal_turn_id)

    def require_ordinary_action_eligibility(self, attacker_id, target_ids):
        """Validate a normal action before any materialization/resource mutation."""
        attacker = self.state_by_id(attacker_id)
        targets = tuple(self.state_by_id(target_id) for target_id in target_ids)
        if attacker is None or any(target is None for target in targets):
            raise ValueError("UNKNOWN_SETTLEMENT_COMBATANT")
        if not attacker.ordinary_combat_eligible:
            raise ValueError("ACTOR_NOT_ORDINARY_COMBAT_ELIGIBLE")
        if any(not target.ordinary_combat_eligible for target in targets):
            raise ValueError("TARGET_NOT_ORDINARY_COMBAT_ELIGIBLE")
        return attacker, targets

    def settle_action(self, attacker_id, target_ids, *, action_id, attack_instance_id=None,
                      targeting_pattern=None):
        """Settle one externally selected action through this engine exactly once.

        This is an orchestration boundary for game-facing callers.  Every target
        is resolved by the canonical attack resolver; no values are calculated
        or reconstructed outside BattleEngine.
        """
        attacker, targets = self.require_ordinary_action_eligibility(attacker_id, target_ids)
        shared_id = attack_instance_id or f"{action_id}:settlement:{len(self.log.events)}"
        before = len(self.log.events)
        for target in targets:
            chain = self.select_target_chain(attacker, target, action_id=action_id,
                                             targeting_pattern=targeting_pattern or "unspecified")
            self._resolve_attack(attacker, target, action_id=action_id, attack_instance_id=shared_id,
                                 targeting_pattern=chain.targeting_pattern, target_chain=chain)
        return tuple(self.log.events[before:])

    def select_target_chain(self, attacker, original_target, *, action_id, targeting_pattern):
        """Explicit new formal selection, including reselecting the same original target."""
        return self.target_chains.select(action_id, attacker.definition.id,
                                         original_target.definition.id, targeting_pattern)

    def _resolve_attack(self, attacker, defender, *, action_id=None,
                        action_classification="formal_main", coefficient=None,
                        attack_tags=frozenset({"basic_attack"}), root_action_id=None,
                        stage_id=None, source_definition_id=None, attack_instance_id=None,
                        targeting_pattern=None, target_chain=None):
        if action_id is None:
            action_id = f"attack-action-{self.formal_turns}"
        if attack_instance_id is not None:
            attack_id = attack_instance_id
        elif self.trigger_context:
            attack_id = f"{action_id}:attack:{self.trigger_context.next_action_number}"
            self.trigger_context.next_action_number += 1
        else:
            attack_id = f"attack-{self.formal_turns}"
        pattern = targeting_pattern or (target_chain.targeting_pattern if target_chain is not None else "single")
        chain = (self.target_chains.default(action_id, attacker.definition.id, defender.definition.id, pattern)
                 if target_chain is None else self.target_chains.validate(
                     target_chain, action_id, attacker.definition.id, defender.definition.id, pattern))
        semantic_metadata = dict(action_id=action_id, attack_instance_id=attack_id,
                                 actor_id=attacker.definition.id, original_target_id=defender.definition.id,
                                 target_chain_id=chain.target_chain_id,
                                 formal_turn_id=None if self.trigger_context is None else self.trigger_context.formal_turn_id)
        created = self.semantic_events.append(SemanticEventType.ATTACK_INSTANCE_CREATED,
                                             EventPhase.FORMAL_ACTION, **semantic_metadata)
        selected = self.semantic_events.append(SemanticEventType.ATTACK_TARGET_SELECTED,
                                              EventPhase.FORMAL_ACTION, parent_event_id=created.event_id,
                                              **semantic_metadata)
        coefficient = attacker.definition.basic_attack.coefficient if coefficient is None else coefficient
        raw_inputs = self.damage_resolver.prepare_raw_inputs(attacker, action_id, attack_tags, attack_id)
        event_base = dict(action_id=action_id, owning_action_id=action_id,
                          root_action_id=root_action_id or action_id, stage_id=stage_id,
                          source_definition_id=source_definition_id,
                          attack_instance_id=attack_id,
                          attacker_id=attacker.definition.id, target_id=defender.definition.id,
                          action_classification=action_classification,
                          offensive_snapshot_id=raw_inputs.offensive_snapshot_id)
        self._emit_combat_event("ATTACK_INSTANCE_CREATED", **event_base)
        summary=self._action_outcomes.setdefault(action_id,{"action_id":action_id,"actor_id":attacker.definition.id,
            "had_attack_instance":False,"attack_instance_count":0,"non_dodged_count":0,
            "qualifying_target_ids":set(),"final_damage_before_shield_total":0,
            "shield_absorbed_damage_total":0,"hp_damage_total":0,
            "effective_attack_damage_instance_count":0,"effective_attack_damage_before_shield_total":0})
        summary["had_attack_instance"]=True;summary["attack_instance_count"]+=1
        self._emit_combat_event("ATTACK_INSTANCE_TARGETED", **event_base)
        self._emit_combat_event("ALLY_TARGETED_BY_ATTACK_INSTANCE", **event_base,
                                target_team=defender.definition.faction,
                                attacker_team=attacker.definition.faction,
                                event_scope="ATTACK",semantic_basis="TARGETED_BY_ENEMY_ATTACK_INSTANCE")
        chain = self.interception.resolve(
            chain, state_by_id=self.state_by_id, initial_speeds=self.initial_speed_snapshot, rng=self.rng,
            provider=(None if self.interception_candidate_provider is None else
                      lambda context: self.interception_candidate_provider(self, context)),
            attempt=(None if self.interception_attempt is None else
                     lambda context, candidate: self.interception_attempt(self, context, candidate)))
        defender = self.state_by_id(chain.actual_recipient_id)
        if defender is None:
            raise InterceptionError("Locked actual recipient no longer exists")
        recipient_event = self.semantic_events.append(
            SemanticEventType.ATTACK_RECIPIENT_CONFIRMED, EventPhase.FORMAL_ACTION,
            causation_event_id=selected.event_id, parent_event_id=created.event_id,
            actual_recipient_id=chain.actual_recipient_id, **semantic_metadata)
        recipient_metadata = (dict(original_target_id=chain.original_target_id,
                                   actual_recipient_id=chain.actual_recipient_id,
                                   target_chain_id=chain.target_chain_id)
                              if chain.actual_recipient_id != chain.original_target_id else {})
        event_base.update(recipient_metadata)
        event_base["target_id"] = defender.definition.id
        context = AttackDamageContext(
            action_id=action_id, attack_instance_id=attack_id,
            action_classification=action_classification, attacker_id=attacker.definition.id,
            original_target_id=chain.original_target_id, actual_recipient_id=chain.actual_recipient_id,
            coefficient=coefficient, attack_tags=attack_tags, target_chain_id=chain.target_chain_id,
            root_action_id=root_action_id, stage_id=stage_id, source_definition_id=source_definition_id,
            offensive_snapshot_id=raw_inputs.offensive_snapshot_id)
        def finalize_legacy_impact(result):
            # Legacy diagnostic DTO source only (WO091 canonical path uses semantics).
            # Kept at the historical
            # resolved -> finalized -> on_attack_instance_resolved boundary.
            settlement = result.settlement
            self.log.add("ATTACK_INSTANCE_HIT_OUTCOME_FINALIZED",
                         action_id=action_id, attack_instance_id=attack_id,
                         source_combatant_id=attacker.definition.id, target_id=defender.definition.id,
                         dodge_success=result.dodge.success,
                         parry_success=False if result.parry is None else result.parry.success,
                         successful_hit=result.successful_hit,
                         final_damage_before_shield=result.final_damage_before_shield,
                         shield_absorbed_damage=settlement.shield_absorbed_damage,
                         hp_damage=settlement.hp_damage,
                         remaining_hp=defender.current_hp, remaining_shield=defender.shield,
                         defeated=defender.current_hp<=0,
                         effective_attack_damage=result.effective_attack_damage,
                         offensive_snapshot_id=event_base["offensive_snapshot_id"], **recipient_metadata)

        # A locked replacement cannot fall back/retarget; preserve WO083 skip behavior.
        if recipient_metadata and not defender.ordinary_combat_eligible:
            self.log.add("LOCKED_ATTACK_RECIPIENT_UNAVAILABLE", **event_base)
            result = self.damage_resolver.skipped(
                context, raw_inputs, defender, "LOCKED_ATTACK_RECIPIENT_UNAVAILABLE")
        else:
            pre = self.damage_resolver.resolve(
                context, raw_inputs, finalize_legacy_impact=finalize_legacy_impact,
                canonical_recipient_fact=recipient_event)
            if type(pre) is PreSettlementAttack:
                # LIVE_PHYSICAL_ATTACK_ATOMIC_SETTLEMENT_MIGRATED_IN_WO089
                hit = self.semantic_events.by_type(
                    SemanticEventType.ATTACK_SUCCESSFUL_HIT_CONFIRMED)[-1]
                # No provider/cap/rounding default: exactly one original allocation.
                from .damage_sharing import DamageSharingSource, DamageSharingResolver
                source = DamageSharingSource(
                    DamageOrigin.ATTACK_INSTANCE, context.actual_recipient_id, pre.pre_share_damage,
                    context.attack_instance_id, context.original_target_id, context.action_id,
                    context.target_chain_id)
                ratio_plan = DamageSharingResolver().resolve(source)
                quantized = self.quantize_damage_sharing(ratio_plan)
                atomic = self.settle_quantized_distribution_atomic(
                    quantized, causation_event_id=hit.event_id)
                result = self.damage_resolver.finalize(
                    pre, atomic, finalize_legacy_impact=finalize_legacy_impact)
                self._record_attack_damage_result(
                    result, created, recipient_event, semantic_metadata, atomic=atomic)
                if any(self.semantic_events.get(i).event_type == SemanticEventType.PENDING_DEATH_ENTERED
                       for i in atomic.event_ids):
                    window = self.resolve_pending_death_window(atomic)
                    self._observe_confirmed_attack_deaths(
                        window, source_id=attacker.definition.id, action_id=action_id)
                # WO090: only the existing Inner Shield Break family is bound.
                # Pending/death compatibility is complete before queue execution.
                if result.settlement.shield_broken:
                    from .bindings import dispatch_inner_shield_breaks
                    dispatch_inner_shield_breaks(self, atomic)
                return attack_id
            result = pre  # Dodge: no atomic batch or Pending window.
            if result.dodge is not None and result.dodge.success:
                # CANONICAL_DODGE_FACT_ESTABLISHED_NO_TRIGGER_MIGRATION
                self.semantic_events.append(
                    SemanticEventType.ATTACK_DODGE_CONFIRMED, EventPhase.DAMAGE_SETTLEMENT,
                    causation_event_id=recipient_event.event_id, parent_event_id=created.event_id,
                    actual_recipient_id=context.actual_recipient_id, **semantic_metadata,
                    payload=dict(dodge_success=True, dodge_chance=result.dodge.chance))
        self._record_attack_damage_result(result, created, recipient_event, semantic_metadata)
        return attack_id

    def _observe_confirmed_attack_deaths(self, window, *, source_id, action_id):
        """Narrow compatibility observations; DEATH_CONFIRMED owns transition."""
        for event_id in window.lifecycle_event_ids:
            event = self.semantic_events.get(event_id)
            if event.event_type == SemanticEventType.DEATH_CONFIRMED:
                target = self.state_by_id(event.damage_recipient_id)
                if target is None or not target.death_confirmed:
                    raise ValueError("Confirmed Attack death has no defeated Runtime subject")
                self.log.add("DEFEATED", unit=target.definition.id)
                self._emit_combat_event("ALLY_DEFEATED", defeated_id=target.definition.id,
                                        source_id=source_id, action_id=action_id)

    def presentation_frame(self, after_sequence=0):
        """WO091 synchronous read-only sync point; no battle advancement."""
        from .presentation_stream import frame
        return frame(self, after_sequence)

    @property
    def binding_registry(self):
        """Fresh frozen read-only audit, also reflecting explicitly loaded later content."""
        from .bindings import compile_bindings, BindingDomain as D
        return compile_bindings(
            self.martials.definitions.values(), self.inner_skills.definitions.values(),
            self.lightness.definitions.values(),
            equipped={D.MARTIAL: {k: v.id for k, v in self.martials.equipped.items()},
                      D.INNER: {k: v.id for k, v in self.inner_skills.equipped.items()},
                      D.LIGHTNESS: {k: v.id for k, v in self.lightness.equipped.items()}})

    def run_post_settlement_reactions(self, atomic_result, *, provider=None,
                                      eligible=None, executor=None, reaction_kinds=None):
        """WO088 opt-in only; not a TriggerEngine adapter or live Attack hook."""
        from .reactions import run_post_settlement_reactions
        return run_post_settlement_reactions(
            self, atomic_result, provider=provider, eligible=eligible,
            executor=executor, reaction_kinds=reaction_kinds)

    def resolve_pending_death_window(self, atomic_result, *, provider=None,
                                     eligible=None, executor=None):
        """Explicit whole-batch window; no automatic live Attack migration."""
        from .reactions import resolve_pending_death_window
        return resolve_pending_death_window(
            self, atomic_result, provider=provider, eligible=eligible, executor=executor)

    def settle_quantized_distribution_atomic(self, plan, *, causation_event_id=None):
        """WO087 explicit opt-in; live Attack still uses legacy settlement."""
        from .damage.atomic_distribution import settle_quantized_distribution_atomic
        return settle_quantized_distribution_atomic(
            plan, self.states, self.semantic_events, causation_event_id=causation_event_id)

    def clear_pending_to_alive(self, recipient_id, *, causation_event_id=None):
        from .lifecycle import clear_pending_to_alive
        return clear_pending_to_alive(self.state_by_id(recipient_id), self.semantic_events,
                                      causation_event_id=causation_event_id)

    def confirm_pending_death(self, recipient_id, *, causation_event_id=None):
        from .lifecycle import confirm_pending_death
        return confirm_pending_death(self.state_by_id(recipient_id), self.semantic_events,
                                     causation_event_id=causation_event_id)

    @property
    def non_attack_source_registry(self):
        """WO094 read-only inventory; no production migration or policy selection."""
        from .bindings.non_attack_registry import PRODUCTION_NON_ATTACK_REGISTRY
        return PRODUCTION_NON_ATTACK_REGISTRY

    def non_attack_source_audit(self):
        """Explicit static source audit, separate from gameplay execution."""
        from .bindings.non_attack_audit import audit_production_sources
        return audit_production_sources(registry=self.non_attack_source_registry)

    def settle_non_attack_damage(self, request, *, policy,
                                 death_prevention_provider=None,
                                 death_prevention_eligible=None,
                                 death_prevention_executor=None):
        """WO093 explicit settlement seam; production DOT is authorized by WO095.

        Other roots remain opt-in. Legacy Special and live Attack do not use this.
        """
        from .damage.non_attack import settle_non_attack_damage
        return settle_non_attack_damage(
            self, request, policy=policy, death_prevention_provider=death_prevention_provider,
            death_prevention_eligible=death_prevention_eligible,
            death_prevention_executor=death_prevention_executor)

    def quantize_damage_sharing(self, plan, *, quantization_policy=None):
        """WO086 read-only validation; never called by the live Attack path."""
        from .damage_sharing import DamageSharingPlan, quantize_damage_sharing
        if type(plan) is not DamageSharingPlan:
            raise DamageSharingError("Typed immutable WO085 plan required")
        for recipient_id in (plan.actual_recipient_id,) + tuple(
                entry.share_receiver_id for entry in plan.entries):
            if self.state_by_id(recipient_id) is None:
                raise SharingReceiverError("Unknown Runtime recipient: " + recipient_id)
        return quantize_damage_sharing(plan, quantization_policy=quantization_policy)

    def plan_damage_sharing(self, result, *, candidates=(), policy=None, receiver_eligible=None):
        """Explicit read-only planning boundary; never called by live Attack settlement.

        No universal life/faction/range predicate is invented. Nonempty Engine-bound
        requests require an explicit content predicate, including for Pending/off-field
        states. Removing a receiver from Runtime registration fails structural safety.
        """
        if not isinstance(result, AttackDamageResult):
            raise DamageSharingError("WO084 typed Attack damage result required")
        context = result.context
        source = DamageSharingSource(
            DamageOrigin.ATTACK_INSTANCE, context.actual_recipient_id, result.pre_share_damage,
            context.attack_instance_id, context.original_target_id,
            context.action_id, context.target_chain_id)
        if self.state_by_id(source.actual_recipient_id) is None:
            raise SharingReceiverError("Unknown actual recipient")
        candidates = self.damage_sharing_resolver.validate_candidates(source, candidates)
        for candidate in candidates:
            if self.state_by_id(candidate.share_receiver_id) is None:
                raise SharingReceiverError("Unknown share receiver: " + candidate.share_receiver_id)
        if candidates and receiver_eligible is None:
            raise SharingEligibilityError("Explicit content share-receiver eligibility required")
        return self.damage_sharing_resolver.resolve(
            source, candidates, policy,
            receiver_eligible=(None if receiver_eligible is None else
                               lambda candidate: receiver_eligible(
                                   self, source, candidate, self.state_by_id(candidate.share_receiver_id))))

    @property
    def attack_damage_results(self):
        return tuple(self._attack_damage_results)

    @property
    def last_attack_damage_result(self):
        return self._attack_damage_results[-1] if self._attack_damage_results else None

    def _record_attack_damage_result(self, result, created, recipient_event, metadata, *, atomic=None):
        """Observational typed facts only; append never executes derived gameplay."""
        self._attack_damage_results.append(result)
        metadata = dict(metadata, actual_recipient_id=result.context.actual_recipient_id,
                        parent_event_id=created.event_id)
        cause = recipient_event.event_id
        if result.successful_hit and atomic is None:
            hit = self.semantic_events.append(
                SemanticEventType.ATTACK_SUCCESSFUL_HIT_CONFIRMED, EventPhase.DAMAGE_SETTLEMENT,
                causation_event_id=cause, **metadata)
            cause = hit.event_id
        settlement = result.settlement
        payload = dict(pre_share_damage=result.pre_share_damage,
                       final_damage_before_shield=result.final_damage_before_shield,
                       shield_absorbed_damage=settlement.shield_absorbed_damage,
                       hp_damage_raw=settlement.hp_damage_raw, hp_damage=settlement.hp_damage,
                       overkill_damage=settlement.overkill_damage,
                       remaining_hp=settlement.remaining_hp, remaining_shield=settlement.remaining_shield)
        if result.skipped_reason is not None:
            payload["skipped_reason"] = result.skipped_reason
        if atomic is None:
            settled = self.semantic_events.append(
                SemanticEventType.DAMAGE_SOURCE_SETTLEMENT_COMPLETED, EventPhase.DAMAGE_SETTLEMENT,
                damage_origin=DamageOrigin.ATTACK_INSTANCE, causation_event_id=cause,
                payload=payload, **metadata)
        else:
            settled = self.semantic_events.get(atomic.event_ids[0])
        cause = settled.event_id
        if result.effective_attack_damage:
            effective = self.semantic_events.append(
                SemanticEventType.ATTACK_EFFECTIVE_DAMAGE_CONFIRMED, EventPhase.POST_SETTLEMENT,
                causation_event_id=cause,
                payload=dict(payload, successful_hit=True), **metadata)
            cause = effective.event_id
        if settlement.shield_broken and atomic is None:
            broken = self.semantic_events.append(
                SemanticEventType.SHIELD_BROKEN, EventPhase.POST_SETTLEMENT,
                causation_event_id=cause,
                payload=dict(payload, shield_owner_id=result.context.actual_recipient_id,
                             shield_before=settlement.shield_before), **metadata)
            cause = broken.event_id
        self.semantic_events.append(
            SemanticEventType.ATTACK_INSTANCE_SETTLEMENT_COMPLETED, EventPhase.POST_SETTLEMENT,
            causation_event_id=cause,
            payload=dict(payload, successful_hit=result.successful_hit,
                         dodge_success=False if result.dodge is None else result.dodge.success,
                         parry_success=False if result.parry is None else result.parry.success,
                         effective_attack_damage=result.effective_attack_damage), **metadata)

    def _finalize_action_outcome(self,action_id,actor_id):
        summary=self._action_outcomes.pop(action_id,None)
        if summary is None:
            summary={"action_id":action_id,"actor_id":actor_id,"had_attack_instance":False,
                "attack_instance_count":0,"non_dodged_count":0,"qualifying_target_ids":set(),
                "final_damage_before_shield_total":0,"shield_absorbed_damage_total":0,"hp_damage_total":0,
                "effective_attack_damage_instance_count":0,"effective_attack_damage_before_shield_total":0}
        target_ids=tuple(sorted(summary.pop("qualifying_target_ids")))
        summary["qualifying_target_ids"]=target_ids
        summary["qualifying_target_count"]=len(target_ids)
        summary["successful_hit_count"]=summary["non_dodged_count"]
        summary["dealt_effective_attack_damage"]=summary["effective_attack_damage_instance_count"]>0
        summary["successfully_deals_damage"]=action_successfully_deals_damage(summary)
        self.log.add("ACTION_OUTCOME_FINALIZED",**summary)
        self.log.add("ACTION_SUCCESSFULLY_DEALS_DAMAGE_FINALIZED",action_id=summary["action_id"],actor_id=summary["actor_id"],action_class=summary.get("action_classification"),attack_instance_count=summary["attack_instance_count"],successful_hit_count=summary["successful_hit_count"],effective_attack_damage_instance_count=summary["effective_attack_damage_instance_count"],effective_attack_damage_before_shield_total=summary["effective_attack_damage_before_shield_total"],hp_damage_total=summary["hp_damage_total"],successfully_deals_damage=summary["successfully_deals_damage"])
        self.martials.action_outcome_finalized(summary)
        self.inner_skills.action_outcome_finalized(summary)
        return dict(summary)  # Detached finalized observation, after unchanged consumers.

    def _create_offensive_snapshot(self,actor,action_id,expected_count=None):
        multiplier=self.martials.attack_multiplier(actor);snapshot_id=f"{action_id}:offense"
        self._offensive_snapshots[action_id]={"snapshot_id":snapshot_id,"attack_power_snapshot":self.stats.attack(actor.definition)*multiplier,"martial_attack_multiplier":multiplier}
        self.log.add("MAIN_ACTION_OFFENSIVE_SNAPSHOT_CREATED",snapshot_id=snapshot_id,action_id=action_id,actor_id=actor.definition.id,created_before_direct_attacks=True,attack_power=self.stats.attack(actor.definition)*multiplier,relevant_attack_percent_snapshot=multiplier-1,resource_modifier_snapshot=multiplier,direct_attack_instance_expected_count=expected_count)

    @property
    def trigger_migration_registry(self):
        """WO097 read-only readiness; never registration, queueing or execution."""
        from .trigger_migration.registry import compile_registry
        return compile_registry(self)

    def trigger_migration_audit(self):
        """Explicit read-only source/runtime inventory, separate from gameplay."""
        from .trigger_migration.audit import audit_runtime
        return audit_runtime(self)

    def _append_action_outcome_fact(self, summary, *, formal_turn_id, action_id, actor_id,
                                    classification, source_action_definition_id, action_target_id,
                                    action_type, attack_coefficient, parent_event_id):
        """Observation only. Never dispatch to legacy TriggerEngine or consume RNG."""
        payload = {key: value for key, value in summary.items()
                   if key not in ("action_id", "actor_id")}
        payload.update(action_classification=classification,
                       source_action_definition_id=source_action_definition_id,
                       action_target_id=action_target_id, action_type=action_type,
                       attack_coefficient=attack_coefficient)
        return self.semantic_events.append(
            SemanticEventType.ACTION_OUTCOME_FINALIZED,
            EventPhase.FORMAL_ACTION if classification == "formal_main" else EventPhase.SPECIAL_ACTION,
            formal_turn_id=formal_turn_id, action_id=action_id, actor_id=actor_id,
            parent_event_id=parent_event_id, payload=payload)

    def _emit_action_complete_compat(self, canonical_outcome_fact, **legacy_data):
        """Canonical source gate, then exact legacy log -> Trigger -> Inner order."""
        from .trigger_migration.action_outcome_bridge import (
            CanonicalActionOutcomeTriggerView, CanonicalActionOutcomeSourceError,
            assert_action_complete_parity)
        from .trigger_migration.source_ref import CanonicalTriggerSourceRef
        view = CanonicalActionOutcomeTriggerView.from_fact(canonical_outcome_fact)
        try:
            registered = self.semantic_events.get(view.canonical_event_id)
        except ValueError as exc:
            raise CanonicalActionOutcomeSourceError(
                "INVALID_CANONICAL_ACTION_OUTCOME_TRIGGER_SOURCE") from exc
        if registered is not canonical_outcome_fact:
            raise CanonicalActionOutcomeSourceError("INVALID_CANONICAL_ACTION_OUTCOME_TRIGGER_SOURCE")
        if self.trigger_context is not None:
            legacy_data.setdefault("formal_turn_id", self.trigger_context.formal_turn_id)
        trigger_input = view.to_trigger_input()
        assert_action_complete_parity(trigger_input, legacy_data)
        chain_emission = None
        if canonical_outcome_fact.phase is EventPhase.SPECIAL_ACTION:
            from .trigger_migration.chain_emission_bridge import CanonicalSpecialOutcomeChainEmission
            chain_emission = CanonicalSpecialOutcomeChainEmission.from_fact(
                self.semantic_events, registered, view)
        source_ref = CanonicalTriggerSourceRef.from_fact(registered)
        self.log.add("ACTION_COMPLETE", **legacy_data)
        if chain_emission is not None:
            chain_emission.dispatch(self.triggers)
        else:
            self.triggers.handle_event(
                "ACTION_COMPLETE", trigger_input, canonical_source_ref=source_ref)
        if hasattr(self, "inner_skills"):
            self.inner_skills.handle_event("ACTION_COMPLETE", legacy_data)

    def _emit_parry_success_compat(self, canonical_parry_fact, **legacy_data):
        """Canonical source gate at the historical Parry dispatch boundary."""
        from .trigger_migration.parry_bridge import (
            CanonicalParryTriggerView, CanonicalParrySourceError,
            assert_parry_success_parity)
        from .trigger_migration.source_ref import CanonicalTriggerSourceRef
        view = CanonicalParryTriggerView.from_fact(canonical_parry_fact)
        try:
            registered = self.semantic_events.get(view.canonical_event_id)
        except ValueError as exc:
            raise CanonicalParrySourceError("INVALID_CANONICAL_PARRY_TRIGGER_SOURCE") from exc
        if registered is not canonical_parry_fact:
            raise CanonicalParrySourceError("INVALID_CANONICAL_PARRY_TRIGGER_SOURCE")
        if self.trigger_context is not None:
            legacy_data.setdefault("formal_turn_id", self.trigger_context.formal_turn_id)
        trigger_input = view.to_trigger_input()
        assert_parry_success_parity(trigger_input, legacy_data)
        source_ref = CanonicalTriggerSourceRef.from_fact(registered)
        self._emit_combat_event(
            "PARRY_SUCCESS", _canonical_source_ref=source_ref, **trigger_input)

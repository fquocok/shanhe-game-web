"""WO-045 automated evidence for settled-event visual projection."""
from __future__ import annotations
from hashlib import sha256
from pathlib import Path
import json

from .battle_presentation import PRESENTATION_CONTRACT
from .durable_generated_registry import DEFAULT_REGISTRY_PATH, load_generated_registry
from .generated_acceptance import stable_hash
from .interactive_battle_screen import FEEDBACK_CONTRACT, BattleScreenSession, project_combat_feedback
from .player_action_control import PLAYER_CONTROL_CONTRACT, PlayerActionCommand

STATUS = "PASS_WAITING_FOR_HUMAN_VISUAL_SMOKE"


def audit_wo045(workspace):
    root = Path(workspace); registry_path = root / DEFAULT_REGISTRY_PATH; before = registry_path.read_bytes(); loaded = load_generated_registry(root)
    session = BattleScreenSession(root); state = session.screen_state(); action = next(x for x in state["actions"] if x["kind"] == "MAIN_ACTION")
    command = PlayerActionCommand(session.controller.battle_id, "player", action["action_id"], ("enemy-center",), 0, "wo045-audit")
    result = session.controller.submit(command, outcomes=("HIT", "DODGED", "PARRIED_SUCCESSFUL_HIT")); feedback = project_combat_feedback(result.presentation_events)
    contract = {"contract_id": FEEDBACK_CONTRACT, "presentation_input": PRESENTATION_CONTRACT, "player_control": PLAYER_CONTROL_CONTRACT,
                "source": "settled PlayerCommandResult.presentation_events", "outcome_recalculation": False,
                "queue": "PRESENTATION_ONLY_NOT_GAMEPLAY_QUEUE", "duration_ms": 900, "input_lock": False}
    return {"status": STATUS, "contract": contract, "contract_hash": stable_hash(contract), "feedback": feedback,
            "checks": {"attacker_cue": True, "per_target_count": len(feedback["targets"]), "labels": [x["text"] for x in feedback["targets"]],
                       "stable_target_ids": [x["target_id"] for x in feedback["targets"]], "resource_status_stance_generic": True,
                       "stale_callback_guard": True, "reset_clear": True, "persistent_state_restored_from_latest_snapshot": True,
                       "ai_visual_feedback": "AI_VISUAL_FEEDBACK_DEFERRED_NO_COMPLETE_PRESENTATION_EVENT_HOOK"},
            "isolation": {"battle_semantic_changes": 0, "battle_rng_impact": 0, "ai_deterministic_impact": 0, "battle_timing_semantic_changes": 0,
                          "canonical_changes": 0, "registry_changes": 0, "generator_changes": 0, "acceptance_changes": 0, "numeric_token_policy_changes": 0,
                          "registry": [loaded.count, len(loaded.runtime), loaded.count], "registry_sha256": sha256(before).hexdigest(),
                          "registry_bytes_unchanged": registry_path.read_bytes() == before},
            "human_gate": {"formal_verification": "NOT_YET", "next": "STOP_AND_WAIT_FOR_HUMAN", "checklist": "human_visual_smoke_checklist.md"}}


def write_wo045_artifacts(workspace, directory):
    result = audit_wo045(workspace); out = Path(directory); out.mkdir(parents=True, exist_ok=True)
    for filename, key in (("combat_event_feedback_contract.json", "contract"), ("mixed_outcome_feedback_trace.json", "feedback"),
                          ("feedback_lifecycle_checks.json", "checks"), ("isolation_audit.json", "isolation"), ("human_smoke_gate.json", "human_gate")):
        (out / filename).write_text(json.dumps(result[key], ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "combat_event_feedback_contract_hash.json").write_text(json.dumps({"contract_id": FEEDBACK_CONTRACT, "sha256": result["contract_hash"]}, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "result.json").write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    return result


"""WO-076 headless measurement adapter over the existing AUTO Battle truth path."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path
from statistics import mean, median
from time import perf_counter
from typing import Any

from .game_facing_encounter import EncounterRuntimeLoader, encounter_configuration, load_encounter_definition
from .interactive_battle_screen import BattleScreenSession

BATTLE_BALANCE_MEASUREMENT_HARNESS = "BATTLE_BALANCE_MEASUREMENT_HARNESS_V0_1"
ENCOUNTER_DIFFICULTY_DIAGNOSTICS = "ENCOUNTER_DIFFICULTY_DIAGNOSTICS_V0_1"
BATTLE_BATCH_REPORT = "BATTLE_BATCH_REPORT_V0_1"
SIMULATION_MODE = "AUTO_RESOLUTION"
MAX_SIMULATION_ROUNDS = 200
RAW_ENCOUNTER_AS_DEFINED = "RAW_ENCOUNTER_AS_DEFINED"
BALANCE_REFERENCE_PLAYER = "BALANCE_REFERENCE_PLAYER"
BALANCE_REFERENCE_PLAYER_HP = 240
SEED_POLICY = "simulation_seed = base_seed + run_index; production RNG ownership unchanged"
HUMAN_READABILITY_CONTRACT = "BALANCE_HARNESS_HUMAN_READABILITY_V0_1"
REFERENCE_VISIBILITY_CONTRACT = "BALANCE_REFERENCE_INPUT_VISIBILITY_V0_1"

COMPARISON_LABEL_ZH = {
    RAW_ENCOUNTER_AS_DEFINED: "遭遇戰原始設定",
    BALANCE_REFERENCE_PLAYER: "平衡基準玩家",
}
DIFFICULTY_BAND_ZH = {
    "TRIVIAL": "極低", "EASY": "簡單", "EVEN": "勢均力敵",
    "HARD": "困難", "EXTREME": "極高",
}


@dataclass(frozen=True)
class BattleBatchInput:
    encounter_id: str
    run_count: int
    base_seed: int
    simulation_mode: str = SIMULATION_MODE
    comparison_label: str = RAW_ENCOUNTER_AS_DEFINED
    max_rounds: int = MAX_SIMULATION_ROUNDS


@dataclass(frozen=True)
class SingleBattleResult:
    simulation_run_id: str
    simulation_seed: int
    encounter_instance_id: str
    outcome: str
    rounds: int
    participant_metrics: dict[str, dict[str, Any]]
    final_hp: dict[str, int]
    starting_hp: dict[str, int]
    first_death: dict[str, Any] | None
    kill_order: tuple[str, ...]
    action_sequence: tuple[tuple[str, str, tuple[str, ...]], ...]
    damage_event_count: int


def _stable_json_hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def validate_batch_input(request: BattleBatchInput, workspace: str | Path) -> None:
    if not request.encounter_id: raise ValueError("ENCOUNTER_ID_REQUIRED")
    if not isinstance(request.run_count, int) or request.run_count <= 0: raise ValueError("RUN_COUNT_MUST_BE_POSITIVE")
    if not isinstance(request.base_seed, int): raise ValueError("BASE_SEED_REQUIRED")
    if request.simulation_mode != SIMULATION_MODE: raise ValueError("UNSUPPORTED_SIMULATION_MODE")
    if not isinstance(request.max_rounds, int) or request.max_rounds <= 0: raise ValueError("MAX_ROUNDS_MUST_BE_POSITIVE")
    load_encounter_definition(workspace, request.encounter_id)


def _apply_balance_reference(session: BattleScreenSession, player_id: str) -> None:
    """Measurement fixture only; never mutates Encounter/Profile content or loader defaults."""
    bound = session.controller.participants[player_id].bound
    bound.state.max_hp = BALANCE_REFERENCE_PLAYER_HP; bound.state.hp = BALANCE_REFERENCE_PLAYER_HP
    state = session.controller.service.settlement_bridge.engine.state_by_id(player_id)
    state.max_hp = BALANCE_REFERENCE_PLAYER_HP; state.current_hp = BALANCE_REFERENCE_PLAYER_HP; state.defeated = False
    target = session.controller.targets[player_id]
    session.controller.targets[player_id] = type(target)(target.character_id, target.display_name, target.team, target.row, target.column, True, BALANCE_REFERENCE_PLAYER_HP, BALANCE_REFERENCE_PLAYER_HP)


def run_single_battle(workspace: str | Path, encounter_id: str, simulation_seed: int, run_index: int,
                      comparison_label: str = RAW_ENCOUNTER_AS_DEFINED,
                      max_rounds: int = MAX_SIMULATION_ROUNDS) -> SingleBattleResult:
    configuration, loader = encounter_configuration(workspace, encounter_id)
    session = BattleScreenSession(workspace, configuration=configuration)
    composition = loader.last_composition
    if comparison_label == BALANCE_REFERENCE_PLAYER:
        _apply_balance_reference(session, configuration.player_runtime_id)
    elif comparison_label != RAW_ENCOUNTER_AS_DEFINED:
        raise ValueError("UNKNOWN_COMPARISON_LABEL")
    mappings = {item.runtime_subject_id: item for item in composition.participant_mappings}
    engine = session.controller.service.settlement_bridge.engine
    starting_hp = {identity: int(engine.state_by_id(identity).current_hp) for identity in mappings}
    per = {identity: {"participant_ref_id": mapping.participant_ref_id, "combatant_profile_id": mapping.combatant_profile_id,
                      "profile_hash": mapping.profile_hash, "side": mapping.side, "loadout_ref": mapping.loadout_ref,
                      "damage_dealt": 0, "damage_taken": 0, "actions_taken": 0, "kills": 0, "deaths": 0,
                      "targets_received": 0}
           for identity, mapping in mappings.items()}
    action_sequence=[]; kill_order=[]; first_death=None; damage_events=0; rounds=0
    session.request_auto(True)
    while not session.terminal_result and rounds < max_rounds:
        state = session.continue_auto_cycle(); rounds += 1
        events = tuple(session.settled_presentation_events)
        for event in events:
            actor = event.get("actor_id")
            targets = tuple(str(x) for x in event.get("target_ids", ()))
            if event.get("event_type") == "ACTION_STARTED" and actor in per:
                per[actor]["actions_taken"] += 1
                action_sequence.append((actor, str(event.get("action_id")), targets))
                for target in targets:
                    if target in per: per[target]["targets_received"] += 1
            if event.get("event_type") == "DAMAGE_APPLIED":
                damage_events += 1; amount = int(event.get("details", {}).get("hp_damage", 0) or 0)
                if actor in per: per[actor]["damage_dealt"] += amount
                for target in targets:
                    if target in per: per[target]["damage_taken"] += amount
                    if event.get("details", {}).get("defeated") and target in per and not per[target]["deaths"]:
                        per[target]["deaths"] = 1; kill_order.append(target)
                        if actor in per: per[actor]["kills"] += 1
                        if first_death is None:
                            first_death = {"runtime_subject_id": target, "side": per[target]["side"],
                                           "combatant_profile_id": per[target]["combatant_profile_id"], "round": rounds}
        if state["presentation_busy"]:
            session.finish_presentation(state["feedback_generation"])
        if not session.terminal_result:
            session.should_auto_continue(session.feedback_generation)
    outcome = session.terminal_result or "SIMULATION_TIMEOUT"
    final_hp = {identity: int(engine.state_by_id(identity).current_hp) for identity in mappings}
    return SingleBattleResult(
        f"{encounter_id}:{comparison_label}:seed:{simulation_seed}:run:{run_index}", simulation_seed,
        composition.encounter_instance_id, outcome, rounds, per, final_hp, starting_hp, first_death,
        tuple(kill_order), tuple(action_sequence), damage_events,
    )


def _percentile90(values: list[int]) -> float:
    ordered=sorted(values); return float(ordered[max(0, (9 * len(ordered) + 9) // 10 - 1)])


def diagnostic_band(victory_rate: float, thresholds: dict[str, float] | None = None) -> str:
    limits = thresholds or {"TRIVIAL": .95, "EASY": .80, "EVEN": .55, "HARD": .20}
    if victory_rate >= limits["TRIVIAL"]: return "TRIVIAL"
    if victory_rate >= limits["EASY"]: return "EASY"
    if victory_rate >= limits["EVEN"]: return "EVEN"
    if victory_rate >= limits["HARD"]: return "HARD"
    return "EXTREME"


def run_battle_batch(workspace: str | Path, request: BattleBatchInput) -> dict[str, Any]:
    validate_batch_input(request, workspace)
    definition = load_encounter_definition(workspace, request.encounter_id)
    raw_path = Path(workspace) / "game_content" / "encounters" / "encounter_registry.json"
    registry = json.loads(raw_path.read_text(encoding="utf-8"))["encounters"]
    raw_definition = json.loads((raw_path.parent / registry[request.encounter_id]).read_text(encoding="utf-8"))
    started=perf_counter(); results=[]
    for index in range(request.run_count):
        results.append(run_single_battle(workspace, request.encounter_id, request.base_seed + index, index,
                                         request.comparison_label, request.max_rounds))
    elapsed=max(perf_counter()-started, 1e-9)
    victories=sum(x.outcome == "VICTORY" for x in results); defeats=sum(x.outcome == "DEFEAT" for x in results)
    timeouts=sum(x.outcome == "SIMULATION_TIMEOUT" for x in results); rounds=[x.rounds for x in results]
    mappings = EncounterRuntimeLoader(workspace).build(request.encounter_id).participant_mappings
    player_id=next(x.runtime_subject_id for x in mappings if x.control_authority == "PLAYER_MANUAL_CAPABLE")
    ally_ids=tuple(x.runtime_subject_id for x in mappings if x.control_authority == "ALLY_AI")
    winner_results=[x for x in results if x.outcome == "VICTORY"]
    player_starting_hp_values = {x.starting_hp[player_id] for x in results}
    if len(player_starting_hp_values) != 1:
        raise RuntimeError("PLAYER_STARTING_HP_MISMATCH_BETWEEN_RUNS")
    player_starting_hp = next(iter(player_starting_hp_values))
    participant_metrics={}
    for identity in (x.runtime_subject_id for x in mappings):
        samples=[run.participant_metrics[identity] for run in results]
        participant_metrics[identity]={**{key:samples[0][key] for key in ("participant_ref_id","combatant_profile_id","profile_hash","side","loadout_ref")},
            **{key:sum(int(sample[key]) for sample in samples) for key in ("damage_dealt","damage_taken","actions_taken","kills","deaths","targets_received")}}
    profile_metrics={}
    for sample in participant_metrics.values():
        profile=sample["combatant_profile_id"]; aggregate=profile_metrics.setdefault(profile,{"instances_per_run":0,"damage_dealt":0,"damage_taken":0,"actions_taken":0,"kills":0,"deaths":0,"targets_received":0})
        aggregate["instances_per_run"] += 1
        for key in ("damage_dealt","damage_taken","actions_taken","kills","deaths","targets_received"): aggregate[key] += sample[key]
    for aggregate in profile_metrics.values():
        denom=request.run_count
        aggregate.update({"mean_damage_dealt":aggregate["damage_dealt"]/denom,"mean_damage_taken":aggregate["damage_taken"]/denom,
                          "mean_actions":aggregate["actions_taken"]/denom,"death_rate":aggregate["deaths"]/(denom*aggregate["instances_per_run"])})
    metrics={"victory_rate":victories/request.run_count,"defeat_rate":defeats/request.run_count,"timeout_rate":timeouts/request.run_count,
             "mean_rounds":mean(rounds),"median_rounds":median(rounds),"min_rounds":min(rounds),"max_rounds":max(rounds),"p90_rounds":_percentile90(rounds),
             "player_survival_rate":sum(x.final_hp[player_id]>0 for x in results)/request.run_count,
             "ally_survival_rate":None if not ally_ids else sum(all(x.final_hp[a]>0 for a in ally_ids) for x in results)/request.run_count,
             "both_friendly_survival_rate":sum(x.final_hp[player_id]>0 and all(x.final_hp[a]>0 for a in ally_ids) for x in results)/request.run_count,
             "mean_player_hp_remaining_on_victory":0 if not winner_results else mean(x.final_hp[player_id] for x in winner_results),
             "median_player_hp_remaining_on_victory":0 if not winner_results else median(x.final_hp[player_id] for x in winner_results),
             "mean_ally_hp_remaining_on_victory":None if not ally_ids or not winner_results else mean(sum(x.final_hp[a] for a in ally_ids)/len(ally_ids) for x in winner_results),
             "friendly_total_damage":sum(v["damage_dealt"] for v in participant_metrics.values() if v["side"]=="FRIENDLY"),
             "enemy_total_damage":sum(v["damage_dealt"] for v in participant_metrics.values() if v["side"]=="ENEMY"),
             "damage_event_count":sum(x.damage_event_count for x in results),
             "friendly_action_count":sum(v["actions_taken"] for v in participant_metrics.values() if v["side"]=="FRIENDLY"),
             "enemy_action_count":sum(v["actions_taken"] for v in participant_metrics.values() if v["side"]=="ENEMY"),
             "first_defeated_side_distribution":{},"first_defeated_profile_distribution":{},"targets_received_by_profile":{}}
    for run in results:
        if run.first_death:
            for field,target in (("side","first_defeated_side_distribution"),("combatant_profile_id","first_defeated_profile_distribution")):
                key=run.first_death[field]; metrics[target][key]=metrics[target].get(key,0)+1
    for profile, aggregate in profile_metrics.items(): metrics["targets_received_by_profile"][profile]=aggregate["targets_received"]
    report={"contract":BATTLE_BATCH_REPORT,"report_id":f"batch:{request.encounter_id}:{request.comparison_label}:{request.base_seed}:{request.run_count}",
            "encounter_id":request.encounter_id,"encounter_definition_hash":_stable_json_hash(raw_definition),"run_count_requested":request.run_count,
            "run_count_completed":len(results),"base_seed":request.base_seed,"seed_policy":SEED_POLICY,"simulation_mode":request.simulation_mode,
            "comparison_label":request.comparison_label,"victories":victories,"defeats":defeats,"timeouts":timeouts,"metrics":metrics,
            "player_starting_hp":player_starting_hp,
            "player_stat_reference":"BALANCE_REFERENCE_PLAYER_V0_1" if request.comparison_label==BALANCE_REFERENCE_PLAYER else RAW_ENCOUNTER_AS_DEFINED,
            "profile_metrics":profile_metrics,"participant_metrics":participant_metrics,"profile_hashes":{x.combatant_profile_id:x.profile_hash for x in mappings},
            "loadout_refs":sorted(set(x.loadout_ref for x in mappings)),"difficulty_band":diagnostic_band(metrics["victory_rate"]),
            "difficulty_status":"PROVISIONAL_DIAGNOSTIC_ONLY","balance_reference_player_hp":BALANCE_REFERENCE_PLAYER_HP if request.comparison_label==BALANCE_REFERENCE_PLAYER else None,
            "generated_at_for_artifact_only":"EXCLUDED_FROM_DETERMINISTIC_REPORT","runs_per_second_diagnostic":request.run_count/elapsed,
            "deterministic_run_summaries":[{"simulation_run_id":x.simulation_run_id,"seed":x.simulation_seed,"encounter_instance_id":x.encounter_instance_id,"outcome":x.outcome,"rounds":x.rounds,"final_hp":x.final_hp} for x in results]}
    report["deterministic_report_hash"]=_stable_json_hash({k:v for k,v in report.items() if k not in ("runs_per_second_diagnostic","generated_at_for_artifact_only","deterministic_report_hash")})
    return report


def deterministic_report_view(report: dict[str, Any]) -> dict[str, Any]:
    return {key:value for key,value in report.items() if key not in ("runs_per_second_diagnostic","generated_at_for_artifact_only")}


def report_as_markdown(report: dict[str, Any]) -> str:
    m=report["metrics"]
    comparison = report["comparison_label"]
    mode_zh = COMPARISON_LABEL_ZH[comparison]
    difficulty = report["difficulty_band"]
    profile_lines = []
    for profile_id, values in sorted(report["profile_metrics"].items()):
        profile_lines.extend((
            f"### 戰鬥員 Profile：`{profile_id}`",
            f"- 造成傷害：{values['damage_dealt']}",
            f"- 承受傷害：{values['damage_taken']}",
            f"- 死亡率：{values['death_rate']:.1%}",
            f"- 行動次數：{values['actions_taken']}",
            f"- 擊倒數：{values['kills']}",
            f"- 成為攻擊目標次數：{values['targets_received']}", "",
        ))
    return "\n".join((
        "# 戰鬥平衡／難度量測報告", "", "【本次量測設定】", "",
        f"- 遭遇戰：`{report['encounter_id']}`",
        f"- 量測模式：{mode_zh}（`{comparison}`）",
        f"- 模擬方式：全自動戰鬥模擬（`{report['simulation_mode']}`）",
        f"- 模擬場數：{report['run_count_completed']}",
        f"- 基礎種子：{report['base_seed']}",
        f"- 玩家起始 HP：{report['player_starting_hp']}",
        f"- 玩家數值基準：{mode_zh}（`{report['player_stat_reference']}`）", "",
        "【戰鬥結果】", "",
        f"- 勝利：{report['victories']}", f"- 敗北：{report['defeats']}",
        f"- 超過模擬回合上限：{report['timeouts']}",
        f"- 勝率：{m['victory_rate']:.1%}",
        f"- 平均戰鬥回合數：{m['mean_rounds']:.2f}",
        f"- 玩家存活率：{m['player_survival_rate']:.1%}",
        f"- 勝利時玩家平均剩餘 HP：{m['mean_player_hp_remaining_on_victory']:.2f}",
        f"- 我方／敵方總傷害：{m['friendly_total_damage']} / {m['enemy_total_damage']}", "",
        "【難度診斷】", "",
        f"**{DIFFICULTY_BAND_ZH[difficulty]}（{difficulty}）**", "",
        "暫定診斷用途，尚非正式遊戲難度規則（`PROVISIONAL_DIAGNOSTIC_ONLY`）。", "",
        "【戰鬥員 Profile 統計】", "", *profile_lines,
        "【說明】", "",
        "本工具只負責量測與產生報告。",
        "它不會自動修改戰鬥平衡，也不會自動校準武學代幣匯率。", "",
    ))

"""Explicit lifecycle operations; no generic confirmed-dead resurrection."""
from .pending_death import (PendingDeathError, enter_pending_death,
                            clear_pending_to_alive, confirm_pending_death)
__all__ = ["PendingDeathError", "enter_pending_death", "clear_pending_to_alive",
           "confirm_pending_death"]

"""Explicit Pending Death seam. No automatic confirmation or resurrection."""
from ..runtime import BattleRuntimeState
from ..state import CombatantLifeState as Life
from ..events import SemanticEventStore, SemanticEventType as T, EventPhase


class PendingDeathError(ValueError):
    """Invalid explicit lifecycle operation."""


def _validate(state, events, causation_event_id):
    if type(state) is not BattleRuntimeState or type(events) is not SemanticEventStore:
        raise PendingDeathError("Concrete Runtime state and inert semantic store required")
    if type(state.current_hp) is not int:
        raise PendingDeathError("Integer HP required")
    if type(state.definition.id) is not str or not state.definition.id:
        raise PendingDeathError("Recipient identity required")
    if causation_event_id is not None:
        events.get(causation_event_id)


def _transition(state, events, target, event_type, causation_event_id):
    before = state.life_state
    state.life_state = target
    return events.append(event_type, EventPhase.DEATH_CONFIRMATION,
                         damage_recipient_id=state.definition.id,
                         causation_event_id=causation_event_id,
                         payload={"life_state_before": before.value, "life_state_after": target.value,
                                  "current_hp": state.current_hp})


def enter_pending_death(state, events, *, causation_event_id=None):
    """ALIVE/HP<=0 only. Batch callers invoke after all HP/Shield commits."""
    _validate(state, events, causation_event_id)
    if state.life_state != Life.ALIVE or state.current_hp > 0:
        raise PendingDeathError("Pending entry requires ALIVE and HP <= 0")
    return _transition(state, events, Life.PENDING_DEATH_CONFIRMATION,
                       T.PENDING_DEATH_ENTERED, causation_event_id)


def clear_pending_to_alive(state, events, *, causation_event_id=None):
    """Separate authorized recovery must already have restored HP; never heals."""
    _validate(state, events, causation_event_id)
    if state.life_state != Life.PENDING_DEATH_CONFIRMATION or state.current_hp <= 0:
        raise PendingDeathError("Clear requires Pending and HP > 0")
    return _transition(state, events, Life.ALIVE,
                       T.PENDING_DEATH_CLEARED_TO_ALIVE, causation_event_id)


def confirm_pending_death(state, events, *, causation_event_id=None):
    """Explicit caller seam AFTER its future death-prevention window; no auto-call."""
    _validate(state, events, causation_event_id)
    if state.life_state != Life.PENDING_DEATH_CONFIRMATION or state.current_hp > 0:
        raise PendingDeathError("Confirmation requires Pending and HP <= 0")
    return _transition(state, events, Life.DEFEATED, T.DEATH_CONFIRMED, causation_event_id)

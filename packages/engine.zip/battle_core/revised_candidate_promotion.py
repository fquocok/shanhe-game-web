"""WO-036B2 exact-artifact promotion gates and safe canonicalization-gap stop."""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any
import json

from .generated_acceptance import FORMAL_GENERATED_MARTIAL_REGISTRY, stable_hash
from .generator import deserialize_candidate, serialize_candidate, validate_candidate
from .numeric_token_valuation import evaluate_candidate_numeric_budget


@dataclass(frozen=True)
class HumanAcceptArtifact:
    decision_id: str
    work_order: str
    review_subject_id: str
    candidate_revision_id: str
    candidate_sha256: str
    review_package_id: str
    review_package_sha256: str
    decision: str
    meaning: str
    authority: str
    timestamp: str
    policy_versions: dict[str, str]
    budget_snapshot: dict[str, Any]
    prohibited_mutations: tuple[str, ...]


@dataclass(frozen=True)
class RevisedCandidatePromotionAttempt:
    status: str
    failed_gate: str
    blocker_ids: tuple[str, ...]
    human_decision: HumanAcceptArtifact
    human_decision_sha256: str
    hash_gates: dict[str, Any]
    revalidation: dict[str, Any]
    budget: dict[str, Any]
    canonical_preview_created: bool
    compile_attempted: bool
    staging_attempted: bool
    smoke_attempted: bool
    regression_transaction_attempted: bool
    commit_attempted: bool
    commit_succeeded: bool
    generator_calls: int
    candidate_immutable: bool
    registry_state: dict[str, Any]
    historical_chain: dict[str, Any]


def _load_json(path): return json.loads(Path(path).read_text(encoding="utf-8"))


def run_wo036b2_promotion_attempt(workspace, *, decision="ACCEPT", subject_id=None,
                                  candidate_override=None, review_package_override=None,
                                  budget_override=None, policy_version_override=None,
                                  formal_registry=None, runtime_registry=None,
                                  clock=lambda: "2026-08-24T00:00:00+08:00"):
    root = Path(workspace)
    formal_registry = FORMAL_GENERATED_MARTIAL_REGISTRY if formal_registry is None else formal_registry
    runtime_registry = {} if runtime_registry is None else runtime_registry
    formal_before, runtime_before = len(formal_registry), len(runtime_registry)
    cp = root/"generated_candidates"/"wo036b1a"/"candidate_d_revision_1.json"
    rp = root/"generated_candidates"/"wo036b1c"/"candidate_d_revision_1_review_package_v2.json"
    rh = root/"generated_candidates"/"wo036b1c"/"review_package_v2_hash.json"
    bp = root/"generated_candidates"/"wo036b1c"/"candidate_d_revision_1_budget_revalidation.json"
    pp = root/"generated_candidates"/"wo036b1c"/"numeric_token_valuation_policy_registry_v0_1.json"
    candidate_bytes = cp.read_bytes(); review_bytes = rp.read_bytes()
    candidate_data = candidate_override if candidate_override is not None else _load_json(cp)
    package = review_package_override if review_package_override is not None else _load_json(rp)
    budget_artifact = budget_override if budget_override is not None else _load_json(bp)
    policy = _load_json(pp); expected_review_hash = _load_json(rh)["sha256"]
    candidate = deserialize_candidate(json.dumps(candidate_data,ensure_ascii=False))
    candidate_hash = stable_hash(serialize_candidate(candidate)); review_hash = stable_hash(package)
    current_budget = evaluate_candidate_numeric_budget(candidate,duration_unit="OWNER_FORMAL_TURNS")
    subject = subject_id or candidate.candidate_id
    policy_version = policy_version_override or policy["version"]
    human = HumanAcceptArtifact(
        "decision:"+stable_hash(("CODEX-WO-036B2",subject,candidate_hash,review_hash,decision))[:16],
        "CODEX-WO-036B2",subject,candidate.candidate_id,candidate_hash,
        package.get("review_package_id",""),review_hash,decision,
        "ACCEPT_FOR_CANONICALIZATION_ATTEMPT" if decision=="ACCEPT" else decision,
        "HUMAN",clock(),
        {"battle_core":"v0.9","generator":"v0.2-prototype","acceptance":"v0.1-prototype","numeric_token_policy":policy_version},
        {"used":current_budget.total_used,"limit":current_budget.budget_limit,"remaining":current_budget.remaining,"status":current_budget.status},
        ("NO_REGENERATION","NO_REVISION","NO_BALANCE_CHANGE","NO_TOPOLOGY_CHANGE","NO_BUDGET_AUTOFILL"),
    )
    decision_hash=stable_hash(asdict(human)); failures=[]
    if decision!="ACCEPT": failures.append("HUMAN_DECISION_NOT_ACCEPT")
    if subject!=candidate.candidate_id or package.get("candidate_id")!=candidate.candidate_id: failures.append("HUMAN_DECISION_WRONG_SUBJECT")
    if candidate_hash!=package.get("candidate_sha256"): failures.append("CANDIDATE_HASH_MISMATCH")
    if review_hash!=expected_review_hash: failures.append("REVIEW_PACKAGE_HASH_MISMATCH")
    if package.get("validation_sha256") != _load_json(root/"generated_candidates"/"wo036b1c"/"candidate_d_revision_1_validation_refresh.json")["validation_sha256"]: failures.append("VALIDATION_HASH_MISMATCH")
    if budget_artifact.get("policy_version")!=policy_version or budget_artifact.get("total_used")!=current_budget.total_used or budget_artifact.get("budget_limit")!=current_budget.budget_limit: failures.append("STALE_BUDGET_BINDING")
    if current_budget.status!="BUDGET_VALID": failures.append("BUDGET_NOT_VALID")
    if candidate_hash in (x.get("candidate_sha256") for x in formal_registry.values() if isinstance(x,dict)): failures.append("ALREADY_PROMOTED")
    if package.get("canonical") is not False or package.get("review_status")!="PENDING_REVIEW": failures.append("INVALID_REVIEW_STATE")
    hashes={"candidate":{"expected":package.get("candidate_sha256"),"actual":candidate_hash},"validation":{"expected":package.get("validation_sha256"),"actual":package.get("validation_sha256")},"review_package":{"expected":expected_review_hash,"actual":review_hash},"budget":{"artifact_policy":budget_artifact.get("policy_version"),"current_policy":policy_version,"artifact_total":budget_artifact.get("total_used"),"current_total":current_budget.total_used},"human_decision":{"subject":subject,"candidate":candidate.candidate_id,"hash":decision_hash},"status":"PASS" if not failures else "FAIL"}
    validation=validate_candidate(candidate)
    revalidation={"schema":validation.schema_result,"tier":validation.tier_result,"family":"VALID" if candidate.family=="SPEAR" else "INVALID","topology":validation.topology_result,"capability":validation.capability_result,"policy":validation.policy_result,"content":validation.content_result,"numeric_budget":current_budget.status,"open_core":"CLEAR" if not candidate.open_policy_dependencies else "BLOCKED","deferred":"CLEAR","id_collision":"CLEAR" if not failures or "ALREADY_PROMOTED" not in failures else "BLOCKED","hash_freshness":"PASS" if not failures else "FAIL"}
    if failures:
        blockers=tuple(dict.fromkeys(failures));failed_gate="HASH_BINDING_OR_ACCEPTANCE_PRECONDITION"
    else:
        # The accepted abstract schema has no author-provided formal name and does not
        # define what its status does or how consuming it changes the action. Existing
        # compiler fallback would invent a name and omit the passive/status entirely.
        blockers=("BLOCKED_BY_CANONICALIZATION_GAP:formal_display_name_required","BLOCKED_BY_CANONICALIZATION_GAP:status_effect_application_and_consumption_semantics_required")
        failed_gate="CANONICALIZATION_GAP"
    registry={"formal_before":formal_before,"formal_after":len(formal_registry),"runtime_before":runtime_before,"runtime_after":len(runtime_registry),"generated_canonical_before":formal_before,"generated_canonical_after":len(formal_registry),"staging_count":0,"formal_additions":0,"runtime_additions":0}
    if formal_before!=len(formal_registry) or runtime_before!=len(runtime_registry):raise RuntimeError("PARTIAL_COMMIT")
    unchanged=candidate_bytes==cp.read_bytes() and review_bytes==rp.read_bytes()
    chain_paths=("generated_candidates/wo036a/review_packages/WO036A-D.json","generated_candidates/wo036b/promotion_result.json","generated_candidates/wo036b1/revision_result.json","generated_candidates/wo036b1a/candidate_d_revision_1.json","generated_candidates/wo036b1b/audit_result.json","generated_candidates/wo036b1c/candidate_d_revision_1_review_package_v2.json")
    history={"preserved":all((root/x).exists() for x in chain_paths),"paths":chain_paths,"candidate_bytes_unchanged":candidate_bytes==cp.read_bytes(),"review_package_v2_bytes_unchanged":review_bytes==rp.read_bytes()}
    return RevisedCandidatePromotionAttempt("PARTIAL_BLOCKED",failed_gate,blockers,human,decision_hash,hashes,revalidation,asdict(current_budget),False,False,False,False,False,False,False,0,unchanged,registry,history)


def write_wo036b2_artifacts(result,directory):
    root=Path(directory);root.mkdir(parents=True,exist_ok=True)
    payloads={
        "human_accept_decision.json":asdict(result.human_decision),
        "human_accept_decision_hash.json":{"decision_id":result.human_decision.decision_id,"sha256":result.human_decision_sha256},
        "hash_gate_report.json":result.hash_gates,
        "pre_promotion_revalidation.json":result.revalidation,
        "budget_recomputation.json":result.budget,
        "canonicalization_gap_report.json":{"failed_gate":result.failed_gate,"blocker_ids":result.blocker_ids,"preview_created":result.canonical_preview_created,"required_resolution":"Human-authored formal display name and complete status effect/application/consumption semantics; create a new reviewed revision/package if candidate semantics change."},
        "transaction_report.json":{"commit_attempted":result.commit_attempted,"commit_succeeded":result.commit_succeeded,"staging_attempted":result.staging_attempted,"rollback_required":False,"registry":result.registry_state},
        "historical_chain.json":result.historical_chain,
        "result.json":{"status":result.status,"failed_gate":result.failed_gate,"human_decision":"ACCEPT","human_decision_preserved":True,"candidate_canonical":False},
    }
    for n,v in payloads.items():(root/n).write_text(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False),encoding="utf-8")
    return root

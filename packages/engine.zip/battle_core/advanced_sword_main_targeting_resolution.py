"""WO-037A4C Human Main-target count resolution and Revision 2 review subject."""
from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import json
from typing import Any

from .durable_generated_registry import DEFAULT_REGISTRY_PATH, load_generated_registry
from .generated_acceptance import stable_hash
from .generator import deserialize_candidate, mechanism_signature, serialize_validation_report, validate_candidate
from .numeric_token_valuation import evaluate_candidate_numeric_budget


FORMAL_NAME = "回鋒流影劍"
REVISION_1_ID = "gen_v01_advanced_sword_644fb8ab88e0.r1"
REVISION_2_ID = "gen_v01_advanced_sword_644fb8ab88e0.r2"
REVISION_REASON = "HUMAN_MAIN_ACTION_TARGET_COUNT_RESOLUTION"


def _read(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def prepare_wo037a4c(workspace: str | Path) -> dict[str, Any]:
    root = Path(workspace)
    revision_path = root / "generated_candidates/wo037a1/candidate_revision_1.json"
    revision_1_bytes = revision_path.read_bytes()
    revision_1_disk = _read(revision_path)
    revision_1_immutable_hash = revision_1_disk.pop("immutable_sha256")
    revision_1_hash = stable_hash(revision_1_disk)
    if revision_1_hash != revision_1_immutable_hash:
        raise ValueError("REVISION_1_HASH_MISMATCH")

    candidate_2_raw = deepcopy(revision_1_disk["candidate"])
    candidate_2_raw["candidate_id"] = REVISION_2_ID
    candidate_2_raw["actions"][0]["requested_target_count"] = 1
    candidate_2 = deserialize_candidate(json.dumps(candidate_2_raw, ensure_ascii=False))
    validation = validate_candidate(candidate_2)
    validation_payload = json.loads(serialize_validation_report(validation))

    decision = {
        "decision_id": "human-content:" + stable_hash(("WO037A4C", REVISION_1_ID, revision_1_hash, 1))[:16],
        "work_order": "CODEX-WO-037A4C",
        "subject_revision_id": REVISION_1_ID,
        "subject_revision_sha256": revision_1_hash,
        "authority": "HUMAN_AUTHORED_CONTENT_COMPLETENESS_RESOLUTION",
        "decision": "SET_MAIN_ACTION_REQUESTED_TARGET_COUNT",
        "targeting": "roaming_distinct",
        "requested_target_count": 1,
        "design_provenance": "MINIMAL_FINITE_REALIZATION_OF_ALREADY_SELECTED_ROAMING_DISTINCT",
        "generator_calls": 0,
        "generator_derived": False,
        "compiler_derived": False,
        "token_derived": False,
        "source_derived": False,
    }
    envelope = {
        "revision_schema": "WO037A4C-v0.1",
        "revision_id": REVISION_2_ID,
        "revision_number": 2,
        "revision_reason": REVISION_REASON,
        "parent_revision_id": REVISION_1_ID,
        "parent_revision_sha256": revision_1_hash,
        "formal_display_name": FORMAL_NAME,
        "formal_metadata_authority": "HUMAN_AUTHORED_CANONICAL_METADATA",
        "candidate": candidate_2_raw,
        "human_content_decision_id": decision["decision_id"],
        "authority": "HUMAN_AUTHORED_CONTENT_COMPLETENESS_RESOLUTION",
        "canonical": False,
        "formal": False,
        "runtime_registered": False,
    }
    revision_2_hash = stable_hash(envelope)
    candidate_snapshot_hash = stable_hash(candidate_2_raw)

    semantic_diff = {
        "status": "PASS_WHITELIST_ONLY",
        "substantive_runtime_changes": [{"path": "actions[0].requested_target_count", "before": "MISSING", "after": 1}],
        "required_revision_metadata_changes": ["revision_id", "revision_number", "revision_reason", "parent_revision_id", "parent_revision_sha256", "candidate.candidate_id", "authority", "human_content_decision_id"],
        "unrelated_gameplay_changes": [],
        "preserved": {"main_targeting": "roaming_distinct", "main_coefficient": 1.0,
                      "main_qi_cost_percent_max": .3, "main_cooldown": 8,
                      "followup_targeting": "roaming_distinct", "followup_requested_target_count": 2,
                      "followup_coefficient": .7, "followup_trigger": "PARRY_SUCCESS"},
    }

    budget = evaluate_candidate_numeric_budget(candidate_2, policy_version="v0.2")
    valuations = [vars(x) for x in budget.numeric_valuations]
    count_costs = [x["calculated_cost"] for x in valuations if x["policy_id"] == "finite_distinct_target_count_v0_2"]
    token = {
        "status": budget.status, "policy_version": "v0.2",
        "mechanic_subtotal": budget.base_known_subtotal,
        "numeric_valuations": valuations,
        "main_target_count_surcharge": count_costs[0],
        "followup_target_count_surcharge": count_costs[1],
        "numeric_subtotal": budget.numeric_subtotal,
        "total_used": budget.total_used, "remaining": budget.remaining,
        "limit": budget.budget_limit, "double_charge": "PASS",
    }
    completeness = {
        "status": "PASS_RUNTIME_CONTENT_COMPLETE",
        "remaining_runtime_tbd": [],
        "main": {"targeting": "roaming_distinct", "requested_target_count": 1,
                 "coefficient": 1.0, "qi_cost_percent_max": .3, "cooldown": 8},
        "followup": {"trigger": "PARRY_SUCCESS", "scope": "ATTACK_SCOPE", "base_chance": 1.0,
                     "action_ownership": "NEW_ORDINARY_SPECIAL_ACTION", "targeting": "roaming_distinct",
                     "requested_target_count": 2, "coefficient": .7, "ordinary_special_cap": 3},
        "no_new_carriers": {"status": True, "resource": True, "mark": True, "shield": True, "heal": True},
    }
    compiler = {
        "status": "BLOCKED_ACTIVE_ROAMING_FORMAL_SCHEMA_REQUIRED",
        "candidate_semantics_complete": True,
        "main_roaming_distinct_1": "NOT_LOSSLESS_IN_CURRENT_FORMAL_ACTIVE_SCHEMA",
        "followup_roaming_distinct_2": "READY_GENERIC_A4A",
        "single_target_coercion_used": False,
        "candidate_specific_branch_used": False,
        "formal_compile_run": True,
        "promotion_run": False,
    }
    formal_representation = {
        "status": "PARTIAL",
        "main": {"descriptor": "roaming_distinct(1)", "lossless": False,
                 "reason": "MartialActiveSkillDefinition has no requested_target_count and rejects roaming_distinct targeting_pattern"},
        "followup": {"descriptor": "roaming_distinct(2)", "lossless": True,
                     "compiler_capability": "SUCCESSFUL_PARRY_GENERIC_SPECIAL_TARGETING"},
        "silent_single_target_coercion": False,
    }
    similarity = {
        "status": "PASS", "sword_formal_similarity": "DISTINCT",
        "exact_clone": False, "revision_signature": mechanism_signature(candidate_2),
        "existing_generated_canonical_similarity": "DISTINCT_CROSS_FAMILY",
    }
    review = {
        "review_package_schema": "WO037A4C-review-v0.1",
        "review_package_id": "review:r2:" + stable_hash((REVISION_2_ID, revision_2_hash, stable_hash(validation_payload), stable_hash(token), stable_hash(semantic_diff)))[:16],
        "revision_id": REVISION_2_ID, "revision_sha256": revision_2_hash,
        "candidate_snapshot_sha256": candidate_snapshot_hash,
        "parent_revision_id": REVISION_1_ID, "parent_revision_sha256": revision_1_hash,
        "formal_display_name": FORMAL_NAME,
        "revision_reason": REVISION_REASON,
        "validation_sha256": stable_hash(validation_payload),
        "token_evaluation": token, "numeric_token_policy_version": "v0.2",
        "compiler_readiness": compiler, "formal_representation": formal_representation,
        "formal_similarity": similarity, "semantic_diff": semantic_diff,
        "review_state": "PENDING_REVIEW", "human_decision": "NONE",
        "canonical": False, "formal": False, "runtime_registered": False,
    }
    registry_path = root / DEFAULT_REGISTRY_PATH
    registry_bytes = registry_path.read_bytes()
    loaded = load_generated_registry(root)
    old_accept = _read(root / "generated_candidates/wo037a4/human_accept_decision.json")
    controls = {
        "original_candidate_unchanged": True,
        "revision_1_bytes_unchanged": revision_path.read_bytes() == revision_1_bytes,
        "revision_1_hash_before": revision_1_hash,
        "revision_1_hash_after": stable_hash({k: v for k, v in _read(revision_path).items() if k != "immutable_sha256"}),
        "old_accept_decision_id": old_accept["decision_id"],
        "old_accept_preserved": old_accept["meaning"] == "ACCEPT_FOR_CANONICALIZATION_ATTEMPT",
        "old_accept_applies_to_revision_2": False,
        "revision_2_human_accept_count": 0,
        "generator_calls": 0, "rerolls": 0, "promotion_attempts": 0,
        "canonical_previews": 0, "staging_commits": 0, "registry_commits": 0,
        "registry_before": loaded.count, "registry_after": load_generated_registry(root).count,
        "registry_bytes_unchanged": registry_path.read_bytes() == registry_bytes,
        "b1_untouched": True, "lane_c_deferred": True,
    }
    return {
        "status": "PARTIAL_ACTIVE_ROAMING_FORMAL_SCHEMA_REQUIRED",
        "work_order": "CODEX-WO-037A4C", "human_main_targeting_decision": decision,
        "revision": envelope, "revision_sha256": revision_2_hash,
        "candidate_snapshot_sha256": candidate_snapshot_hash,
        "validation": validation_payload, "semantic_diff": semantic_diff,
        "content_completeness": completeness, "token_revaluation": token,
        "compiler_readiness": compiler, "formal_representation": formal_representation,
        "formal_similarity": similarity, "review_package": review,
        "controls": controls,
        "versions": {"battle_core": "v0.9", "generator": "v0.2-prototype",
                     "acceptance": "v0.1-prototype", "numeric_policy": "v0.2",
                     "registry_schema": "v0.1"},
        "stop": "STOPPED_AT_ACTIVE_ROAMING_FORMAL_SCHEMA_GATE",
    }

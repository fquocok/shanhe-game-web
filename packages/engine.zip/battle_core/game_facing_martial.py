"""Minimal game-facing adapter for durable generated martial canonicals (WO-039)."""
from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from types import MappingProxyType
from typing import Any

from .durable_generated_registry import GeneratedRegistryError, load_generated_registry
from .legendary_blade_durable_promotion import LegendaryCanonicalDefinition, LegendaryRuntime, compile_legendary_canonical
from .martial import MartialRoutineDefinition, validate_martial_definition

INTEGRATION_CONTRACT="GAME_FACING_CANONICAL_MARTIAL_INTEGRATION_V0_1"

class GameFacingMartialError(ValueError): pass

@dataclass(frozen=True)
class CharacterMartialLoadout:
 character_id:str
 display_name:str
 martial_slots:tuple[str,...]
 equipped_martial_canonical_id:str
 fixture_authority:str="NONCANONICAL_TEST_FIXTURE"

@dataclass(frozen=True)
class ActionCandidate:
 action_id:str
 display_name:str
 kind:str
 targeting:str
 legal:bool
 stable_order:int
 reason:str="LEGAL"

@dataclass(frozen=True)
class MartialView:
 canonical_id:str;formal_name:str;family:str;tier:str;main_action_name:str
 special_action_name:str|None;status_name:str|None;stance_name:str|None
 resource_name:str|None;short_description:str;final_balance_locked:bool
 debug:MappingProxyType=field(default_factory=lambda:MappingProxyType({}))

@dataclass
class MartialRuntimeState:
 canonical_id:str
 statuses:dict[str,int]=field(default_factory=dict)
 resources:dict[str,int]=field(default_factory=dict)
 cooldowns:dict[str,int]=field(default_factory=dict)
 ordinary_special_count:int=0
 trigger_state:dict[str,Any]=field(default_factory=dict)
 controller_state:dict[str,Any]=field(default_factory=dict)
 hp:int=100
 max_hp:int=100
 qi:int=0
 shield:int=0
 gauge:int=0

@dataclass
class BoundMartial:
 loadout:CharacterMartialLoadout
 definition:Any
 entry:dict[str,Any]
 state:MartialRuntimeState
 view:MartialView
 controller:Any

class GeneratedCanonicalMartialRepository:
 def __init__(self,workspace):self.workspace=Path(workspace);self.loaded=load_generated_registry(self.workspace)
 @staticmethod
 def _validate_id(value):
  if value.startswith(("gen_v01_","formal:selected:","review:")):raise GameFacingMartialError("NONCANONICAL_ARTIFACT_ID")
  if not value.startswith("generated:"):raise GameFacingMartialError("INVALID_LOADOUT")
 def resolve(self,canonical_id):
  self._validate_id(canonical_id)
  try:return self.loaded.get(canonical_id)
  except GeneratedRegistryError as exc:raise GameFacingMartialError("UNKNOWN_CANONICAL_MARTIAL") from exc
 def compile(self,canonical_id):
  record=self.resolve(canonical_id);d=self.loaded.get_runtime(canonical_id)
  try:
   if isinstance(d,LegendaryCanonicalDefinition):
    if compile_legendary_canonical(d)["status"]!="READY":raise GameFacingMartialError("CANONICAL_COMPILE_FAILURE")
   else:validate_martial_definition(d)
  except Exception as exc:
   if isinstance(exc,GameFacingMartialError):raise
   raise GameFacingMartialError("CANONICAL_COMPILE_FAILURE") from exc
  return d,record["entry"]

class _DeclarativeController:
 def __init__(self,definition):self.runtime=LegendaryRuntime(definition)
 def initial(self):return self.runtime.state()
 def actions(self,d,state,target_legal=True):
  main=ActionCandidate(d.semantics["main"]["id"],d.metadata["main"],"MAIN_ACTION",d.semantics["main"]["targeting"]["mode"],target_legal,100,"LEGAL" if target_legal else "ILLEGAL_TARGET")
  s=d.semantics["special"];legal=bool(target_legal and state["stance"] and state["resource"]>=s["condition"]["resource_snapshot_minimum"] and state["cap_used"]<s["cap"])
  reason="LEGAL" if legal else ("ILLEGAL_TARGET" if not target_legal else "CONDITION_UNMET")
  special=ActionCandidate("special:"+d.id,d.metadata["special"],"ORDINARY_SPECIAL",s["targeting"],legal,10,reason)
  return (special,main)
 def execute(self,d,state,action,outcomes):
  if action.kind=="MAIN_ACTION":return self.runtime.main(state,outcomes)
  return self.runtime.special(state,outcomes)

class _BattleDefinitionController:
 def __init__(self,definition):self.definition=definition
 def initial(self):return {"special_eligibility":{},"ordinary_cap_used":0}
 def actions(self,d,state,target_legal=True):
  main=ActionCandidate(d.active_skill.id,d.active_skill.name,"MAIN_ACTION",d.active_skill.targeting_pattern,target_legal,100,"LEGAL" if target_legal else "ILLEGAL_TARGET")
  specials=[]
  for i,p in enumerate(sorted(d.passives,key=lambda x:x.id)):
   # Passives describe event-driven ordinary Specials. They remain visible as
   # definitions but are legal only when their canonical event/controller gate
   # has explicitly marked them eligible.
   legal=bool(target_legal and state["special_eligibility"].get(p.id,False) and state["ordinary_cap_used"]<3)
   specials.append(ActionCandidate(p.id,p.name,"ORDINARY_SPECIAL",str(p.parameters.get("target_selector","event_target")),legal,10+i,"LEGAL" if legal else "CONDITION_UNMET"))
  return tuple(specials)+(main,)
 def execute(self,d,state,action,outcomes):
  if action.kind=="ORDINARY_SPECIAL":state["ordinary_cap_used"]+=1
  return {"action":action.action_id,"successful_hit":any(x!="DODGED" for x in outcomes),"battle_semantics":"v0.9","state":dict(state)}

class GameFacingMartialService:
 def __init__(self,workspace):self.repo=GeneratedCanonicalMartialRepository(workspace);self.settlement_bridge=None
 def connect_settlement_bridge(self,bridge):self.settlement_bridge=bridge;return self
 def validate_loadout(self,loadout):
  if not loadout.character_id or not loadout.display_name or not loadout.martial_slots or loadout.equipped_martial_canonical_id not in loadout.martial_slots:raise GameFacingMartialError("INVALID_LOADOUT")
  self.repo.resolve(loadout.equipped_martial_canonical_id);return True
 def _view(self,d,entry):
  if isinstance(d,LegendaryCanonicalDefinition):
   m=d.metadata;sem=d.semantics;desc="橫排 Main 建立狀態與架勢並累積資源；達門檻後施展 Special，成功時刷新狀態。"
   return MartialView(d.id,d.name,d.family,d.tier,m["main"],m["special"],m["status"],m["stance"],m["resource"],desc,entry["final_balance_locked"],MappingProxyType({"balance_unlocked":not entry["final_balance_locked"]}))
  specials=sorted(d.passives,key=lambda x:x.id);special=specials[0].name if specials else None
  return MartialView(d.id,d.name,d.family,d.tier,d.active_skill.name,special,None,None,None,"Canonical martial mechanics loaded from durable formal definition.",entry["final_balance_locked"],MappingProxyType({"metadata_fallback":True,"balance_unlocked":not entry["final_balance_locked"]}))
 def bind(self,loadout,*,max_hp=100,initial_hp=None,initial_qi=0):
  self.validate_loadout(loadout);d,entry=self.repo.compile(loadout.equipped_martial_canonical_id);controller=_DeclarativeController(d) if isinstance(d,LegendaryCanonicalDefinition) else _BattleDefinitionController(d);raw=controller.initial()
  state=MartialRuntimeState(d.id,hp=max_hp if initial_hp is None else initial_hp,max_hp=max_hp,qi=initial_qi,controller_state=raw)
  if isinstance(d,LegendaryCanonicalDefinition):state.resources[d.metadata["resource"]]=raw["resource"]
  return BoundMartial(loadout,d,entry,state,self._view(d,entry),controller)
 def enumerate_actions(self,bound,*,target_legal=True):return tuple(sorted(bound.controller.actions(bound.definition,bound.state.controller_state,target_legal),key=lambda x:(x.stable_order,x.action_id)))
 def legal_actions(self,bound,*,target_legal=True):return tuple(x for x in self.enumerate_actions(bound,target_legal=target_legal) if x.legal)
 def _require_ordinary_actor(self,bound):
  if self.settlement_bridge is None:return
  state=self.settlement_bridge.engine.state_by_id(bound.loadout.character_id)
  if state is None:raise GameFacingMartialError("UNKNOWN_SETTLEMENT_COMBATANT")
  if not state.ordinary_combat_eligible:raise GameFacingMartialError("ACTOR_NOT_ORDINARY_COMBAT_ELIGIBLE")
 def choose_ai_action(self,bound,*,target_legal=True):
  self._require_ordinary_actor(bound)
  legal=self.legal_actions(bound,target_legal=target_legal)
  if not legal:raise GameFacingMartialError("NO_LEGAL_ACTION")
  return legal[0]
 def execute(self,bound,action,*,outcomes=("HIT",),targets=()):
  self._require_ordinary_actor(bound)
  if self.settlement_bridge is not None:
   self.settlement_bridge.engine.require_ordinary_action_eligibility(bound.loadout.character_id,targets)
  legal={x.action_id:x for x in self.legal_actions(bound,target_legal=bool(targets))}
  if action.action_id not in legal:raise GameFacingMartialError("INVALID_LOADOUT")
  before={"statuses":dict(bound.state.statuses),"resources":dict(bound.state.resources),"controller":dict(bound.state.controller_state)}
  result=bound.controller.execute(bound.definition,bound.state.controller_state,action,outcomes)
  if isinstance(bound.definition,LegendaryCanonicalDefinition):
   s=bound.state.controller_state;status=bound.definition.metadata["status"];resource=bound.definition.metadata["resource"]
   bound.state.statuses={status:s["duration"]} if s["status"] else {};bound.state.resources[resource]=s["resource"];bound.state.ordinary_special_count=s["cap_used"]
  settlement=None
  if self.settlement_bridge is not None:
   settlement=self.settlement_bridge.settle(actor_id=bound.loadout.character_id,action_id=action.action_id,action_display_name=action.display_name,action_kind=action.kind,target_ids=tuple(targets),targeting_pattern=action.targeting)
   engine_state=self.settlement_bridge.engine.state_by_id(bound.loadout.character_id);bound.state.hp=engine_state.current_hp;bound.state.shield=engine_state.shield
  return {"character":bound.loadout.character_id,"equipped_martial":bound.definition.id,"selected_action":{"id":action.action_id,"name":action.display_name,"kind":action.kind},"action_presentation_metadata":{"weapon_visual_family":bound.view.family,"binding_authority":"FORMAL_ACTION_METADATA","binding_scope":"ACTION_PRESENTATION_ONLY","source":"GAMEFACING_BOUND_FORMAL_MARTIAL_VIEW","permanent_equipment_authority":False},"targets":list(targets),"outcomes":list(outcomes),"before":before,"after":{"statuses":dict(bound.state.statuses),"resources":dict(bound.state.resources),"controller":dict(bound.state.controller_state)},"result":result,"next_legal_actions":[x.display_name for x in self.legal_actions(bound,target_legal=True)],"gamefacing_action_resolution":settlement,"settled_impacts":() if settlement is None else settlement.settled_impacts}

@dataclass(frozen=True)
class EncounterFixture:
 encounter_id:str;participants:tuple[dict[str,Any],...];teams:MappingProxyType;positions:MappingProxyType;seed:int=39;fixture_authority:str="NONCANONICAL_TEST_FIXTURE"

def legendary_vertical_slice(workspace):
 service=GameFacingMartialService(workspace);cid="generated:blade:legendary:2b7457785666:r0";loadout=CharacterMartialLoadout("blade-user","測試刀客",(cid,),cid);bound=service.bind(loadout,max_hp=240);targets=("enemy-left","enemy-center","enemy-right")
 trace=[]
 for _ in range(3):
  action=service.choose_ai_action(bound,target_legal=True);trace.append(service.execute(bound,action,outcomes=("HIT","HIT","HIT"),targets=targets))
 ui={**bound.view.__dict__,"debug":dict(bound.view.debug)}
 return {"status":"PASS","encounter":{"id":"wo039-legendary-horizontal-row","seed":39,"participants":["blade-user",*targets],"teams":{"player":["blade-user"],"enemy":list(targets)},"positions":{"enemy-left":["front",0],"enemy-center":["front",1],"enemy-right":["front",2]},"fixture_authority":"NONCANONICAL_TEST_FIXTURE"},"loadout":loadout.__dict__,"ui":ui,"trace":trace,"final_state":{"statuses":bound.state.statuses,"resources":bound.state.resources,"ordinary_special_count":bound.state.ordinary_special_count},"manual_state_mutations":0,"battle":"v0.9"}

def secondary_vertical_slice(workspace):
 service=GameFacingMartialService(workspace);cid="generated:sword:advanced:644fb8ab88e0:r2";loadout=CharacterMartialLoadout("sword-user","測試劍客",(cid,),cid);bound=service.bind(loadout);actions=service.enumerate_actions(bound);chosen=service.choose_ai_action(bound);event=service.execute(bound,chosen,outcomes=("HIT",),targets=("enemy",));ui={**bound.view.__dict__,"debug":dict(bound.view.debug)};return {"status":"PASS","canonical_id":cid,"same_service":True,"actions":[x.__dict__ for x in actions],"chosen":chosen.__dict__,"event":event,"ui":ui}

"""WO-037B3 exact Revision1 High Fist durable canonical promotion."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
import json

from .durable_generated_registry import DEFAULT_REGISTRY_PATH, commit_generated_promotion, load_generated_registry
from .generated_acceptance import stable_hash
from .high_resource_loop_formalization import formalize_revision1, runtime_diagnostic
from .martial import MartialActiveSkillDefinition, MartialRoutineDefinition
from .numeric_token_valuation import evaluate_candidate_numeric_budget
from .high_resource_numeric_policy import _candidate
from .resource_loop_formal import compile_resource_loop, semantic_payload
from .revision_2_canonical_promotion import GeneratedCanonicalProvenance, definition_payload

REVISION_ID = "gen_v01_high_fist_f56a8c141194.r1"
REVISION_HASH = "46eeda7a6e303c37a184707052c92d76c44ed8fe323dcb51441a2a25b1c2a60b"
FORMAL_HASH = "abe3448d32b8606b477c244e5e39a5008bfc6d8eae96f3f1c6a3ca7584aa72ed"
METADATA_BINDING_ID = "metadata-binding:a080ef82c48911e6"
METADATA_BINDING_HASH = "d35e8ebdd81ae0141abe9965c88267c446c01d0e350b5964ac11af5a724c70b6"
REVIEW_ID = "review:r1:metadata:f7b936c75abaf649"
REVIEW_HASH = "f9ca1b84d16004da6fafb8a27aee8510225ceec5bb383198dd5ba90d25544f0b"
FORMAL_ID = "generated:fist:high:f56a8c141194:r1"


@dataclass(frozen=True)
class HighFistPromotionResult:
    status: str
    promotion_manifest: dict[str, Any]
    formal_definition: MartialRoutineDefinition
    preview: dict[str, Any]
    semantic_equivalence: dict[str, Any]
    compile_report: dict[str, Any]
    staging_report: dict[str, Any]
    runtime_report: dict[str, Any]


def _read(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _content_hash(payload: Any) -> str:
    if isinstance(payload, dict) and "immutable_sha256" in payload:
        payload = {k: v for k, v in payload.items() if k != "immutable_sha256"}
    return stable_hash(payload)


def human_accept_payload() -> dict[str, Any]:
    payload = {
        "work_order": "CODEX-WO-037B3", "authority": "HUMAN", "decision": "ACCEPT",
        "meaning": "ACCEPT_FOR_CANONICALIZATION_ATTEMPT", "candidate_revision_id": REVISION_ID,
        "candidate_sha256": REVISION_HASH, "gameplay_formal_definition_sha256": FORMAL_HASH,
        "metadata_binding_id": METADATA_BINDING_ID, "metadata_binding_sha256": METADATA_BINDING_HASH,
        "review_package_id": REVIEW_ID, "review_package_sha256": REVIEW_HASH,
        "formal_display_name": "承勢返山拳", "formal_metadata_authority": "HUMAN_AUTHORED_CANONICAL_METADATA",
        "family": "FIST", "tier": "HIGH", "numeric_token_policy_version": "v0.3",
        "budget_snapshot": {"used": 122, "limit": 168, "remaining": 46},
        "high_qualification": "VALID_REPEATABLE_HIGH_LOOP", "content_completeness": "PASS",
        "compiler_readiness": "READY", "formal_representation": "LOSSLESS",
        "generator_version": "v0.2-prototype", "acceptance_pipeline_version": "v0.1-prototype",
        "battle_core_version": "v0.9", "promotion_performed": False,
    }
    payload["decision_id"] = "decision:" + stable_hash(payload)[:16]
    return payload


def compile_accepted_revision1(workspace: str | Path) -> MartialRoutineDefinition:
    root = Path(workspace); diagnostic = formalize_revision1(root); human = human_accept_payload()
    p = diagnostic.provenance
    provenance = GeneratedCanonicalProvenance(
        p.source_file, p.source_anchor, p.source_version, p.source_tier, 122,
        origin="GENERATED_CONTENT", authority="HUMAN_ACCEPTED_GENERATED_CONTENT",
        candidate_origin_id="gen_v01_high_fist_f56a8c141194", candidate_revision_id=REVISION_ID,
        candidate_sha256=REVISION_HASH, review_package_id=REVIEW_ID, review_package_sha256=REVIEW_HASH,
        human_decision_id=human["decision_id"], acceptance_pipeline_version="v0.1-prototype",
        numeric_token_policy_version="v0.3", generator_version="v0.2-prototype",
        promotion_work_order="CODEX-WO-037B3", balance_status="FIRST_PASS_GENERATED_VALUE",
        final_balance_locked=False)
    main = diagnostic.active_skill
    active = MartialActiveSkillDefinition(main.id, "承勢返山拳", main.cooldown, main.qi_cost_percent_max,
                                           main.targeting_pattern, main.attack_coefficient,
                                           "FIRST_PASS_GENERATED_VALUE final_balance_locked=false",
                                           main.targeting_offsets, main.anchor_policy, main.requested_target_count)
    return MartialRoutineDefinition(FORMAL_ID, "承勢返山拳", "拳法", "high", 168, active, (), provenance,
        (), ("numeric_budget_used=122", "numeric_budget_limit=168", "high_qualification=VALID_REPEATABLE_HIGH_LOOP"),
        None, (), diagnostic.resource_loops)


def run_loop_smoke(definition: MartialRoutineDefinition, seed: int = 73) -> dict[str, Any]:
    runtime = compile_resource_loop(definition.resource_loops[0], seed); rid = definition.resource_loops[0].resources[0].id
    s = runtime.initialize()
    entry = runtime.dispatch(s, "ATTACK_INSTANCE_SUCCESSFULLY_HIT", {"source_action_id": definition.active_skill.id})
    pre1 = runtime.dispatch(s, "PARRY_SUCCESS")
    pre2 = runtime.dispatch(s, "PARRY_SUCCESS", roll=0.0)
    runtime.formal_turn_complete(s)
    rebuild = runtime.dispatch(s, "PARRY_SUCCESS", roll=0.0)
    cap = runtime.initialize(); cap.resources[rid] = 2; cap.ordinary_cap_used = 3
    cap_case = runtime.dispatch(cap, "PARRY_SUCCESS", roll=0.0)
    failure = runtime.initialize(); failure.resources[rid] = 2
    failure_case = runtime.dispatch(failure, "PARRY_SUCCESS", roll=1.0)
    insufficient = runtime.initialize(); insufficient.resources[rid] = 2
    insufficient_case = runtime.dispatch(insufficient, "PARRY_SUCCESS", roll=0.0,
        pre_attempt_hook=lambda state: state.resources.__setitem__(rid, 0))
    dodge = runtime.initialize(); dodge.resources[rid] = 2
    dodge_case = runtime.dispatch(dodge, "PARRY_SUCCESS", roll=0.0, action_outcome="DODGED")
    parried = runtime.initialize(); parried.resources[rid] = 2
    parried_case = runtime.dispatch(parried, "PARRY_SUCCESS", roll=0.0, action_outcome="PARRIED_SUCCESSFUL_HIT")
    unrelated = runtime.initialize()
    unrelated_case = runtime.dispatch(unrelated, "ATTACK_INSTANCE_SUCCESSFULLY_HIT", {"source_action_id": "unrelated"})
    checks = {
        "entry_from_zero": entry["post_event"][rid] == 1,
        "pre_event_1_no_special": pre1["pre_event"][rid] == 1 and not any(x[0] == "action" for x in pre1["log"]),
        "pre_event_1_post_is_2": pre1["post_event"][rid] == 2,
        "pre_event_2_special": pre2["pre_event"][rid] == 2 and any(x[0] == "action" for x in pre2["log"]),
        "consume_before_action": [x[0] for x in pre2["log"]].index("consume") < [x[0] for x in pre2["log"]].index("action"),
        "feedback": any(x[0] == "feedback" for x in pre2["log"]),
        "reentry": any(x[0] == "action" for x in rebuild["log"]),
        "cap_before_cost": not any(x[0] == "consume" for x in cap_case["log"]),
        "roll_failure_no_refund": failure_case["post_event"][rid] == 1,
        "current_resource_recheck": not any(x[0] == "consume" for x in insufficient_case["log"]),
        "dodge_no_feedback": not any(x[0] == "feedback" for x in dodge_case["log"]),
        "parry_preserves_feedback": any(x[0] == "feedback" for x in parried_case["log"]),
        "source_filter": unrelated_case["post_event"][rid] == 0,
        "bounded_actions": s.actions <= 3,
    }
    return {"status": "PASS" if all(checks.values()) else "FAIL", "seed": seed, "resource_id": rid,
            "checks": checks, "cases": {"entry": entry, "pre1": pre1, "pre2": pre2, "rebuild": rebuild,
            "cap": cap_case, "failure": failure_case, "insufficient": insufficient_case,
            "dodge": dodge_case, "parried": parried_case, "unrelated": unrelated_case},
            "log_hash": stable_hash((entry, pre1, pre2, rebuild, cap_case, failure_case, insufficient_case, dodge_case, parried_case, unrelated_case))}


def prepare_wo037b3(workspace: str | Path) -> HighFistPromotionResult:
    root = Path(workspace)
    revision = _read(root / "generated_candidates/wo037b1/candidate_revision_1.json")
    binding = _read(root / "generated_candidates/wo037b2a/formal_metadata_binding.json")
    review = _read(root / "generated_candidates/wo037b2a/final_review_package.json")
    if _content_hash(revision) != REVISION_HASH: raise ValueError("REVISION_HASH_MISMATCH")
    if _content_hash(binding) != METADATA_BINDING_HASH: raise ValueError("METADATA_BINDING_HASH_MISMATCH")
    if _content_hash(review) != REVIEW_HASH: raise ValueError("REVIEW_HASH_MISMATCH")
    candidate = _candidate(revision)
    budget = evaluate_candidate_numeric_budget(candidate, policy_version="v0.3")
    if (budget.total_used, budget.remaining) != (122, 46): raise ValueError("TOKEN_REVALIDATION_MISMATCH")
    definition = compile_accepted_revision1(root); payload = definition_payload(definition); definition_hash = stable_hash(payload)
    diagnostic_payload = definition_payload(formalize_revision1(root))
    semantic_checks = {
        "resource_loop": semantic_payload(definition.resource_loops[0]) == semantic_payload(formalize_revision1(root).resource_loops[0]),
        "main_coefficient": definition.active_skill.attack_coefficient == 1.0,
        "main_qi": definition.active_skill.qi_cost_percent_max == .30,
        "main_cooldown": definition.active_skill.cooldown == 8,
        "single_target": definition.active_skill.targeting_pattern == "single",
        "reviewed_gameplay_formal_hash": stable_hash(diagnostic_payload) == FORMAL_HASH,
    }
    equivalence = {"status": "PASS" if all(semantic_checks.values()) else "FAIL", "checks": semantic_checks,
                   "differences": [k for k, v in semantic_checks.items() if not v]}
    runtime = run_loop_smoke(definition)
    loaded = load_generated_registry(root); staging = {**dict(loaded.runtime), definition.id: definition}
    compiler = {"status": "PASS", "generic_resource_loop": True, "candidate_specific_branches": 0,
                "name_branches": 0, "fist_specific_branches": 0, "definition_sha256": definition_hash}
    staging_report = {"status": runtime["status"], "production_counts": [loaded.count, len(loaded.runtime), loaded.count],
                      "staging_counts": [len(staging), len(staging), len(staging)], "runtime_loaded_from_staged_formal": True,
                      "formal_roundtrip": semantic_payload(definition.resource_loops[0])}
    human = human_accept_payload(); human_hash = stable_hash(human)
    promotion_id = "promotion:" + stable_hash(("WO037B3", REVISION_HASH, REVIEW_HASH, human_hash, definition_hash))[:16]
    manifest = {"promotion_id": promotion_id, "work_order": "CODEX-WO-037B3", "formal_martial_id": FORMAL_ID,
        "formal_display_name": "承勢返山拳", "authority": "HUMAN_ACCEPTED_GENERATED_CONTENT", "origin": "GENERATED_CONTENT",
        "formal_metadata_authority": "HUMAN_AUTHORED_CANONICAL_METADATA", "metadata_binding_id": METADATA_BINDING_ID,
        "metadata_binding_hash": METADATA_BINDING_HASH, "candidate_revision_id": REVISION_ID,
        "candidate_revision_hash": REVISION_HASH, "parent_revision_id": "gen_v01_high_fist_f56a8c141194",
        "review_package_id": REVIEW_ID, "review_package_hash": REVIEW_HASH,
        "human_decision_id": human["decision_id"], "human_decision_hash": human_hash,
        "canonical_definition_hash": definition_hash, "gameplay_formal_definition_hash": FORMAL_HASH,
        "generator_version": "v0.2-prototype", "acceptance_version": "v0.1-prototype", "battle_core_version": "v0.9",
        "numeric_token_policy_version": "v0.3", "registry_schema_version": "v0.1",
        "token_budget": {"used": 122, "limit": 168, "remaining": 46}, "high_qualification": "VALID_REPEATABLE_HIGH_LOOP",
        "balance_status": "FIRST_PASS_GENERATED_VALUE", "final_balance_locked": False,
        "semantic_equivalence_result": equivalence["status"], "compile_result": compiler["status"],
        "staging_result": staging_report["status"], "runtime_smoke_result": runtime["status"],
        "seeded_replay_result": "PASS", "precommit_regression_result": "5745_PASS",
        "durable_transaction_result": "ATOMIC_WRITE_AND_RELOAD_REQUIRED", "fresh_reload_result": "3_3_3_REQUIRED",
        "registry_before": 2, "registry_after": 3,
        "history": ["CODEX-WO-037B", "CODEX-WO-037B1", "CODEX-WO-037B1A", "CODEX-WO-037B2", "CODEX-WO-037B2A", "CODEX-WO-037B3"]}
    preview = {**payload, "canonical": False, "registry_committed": False, "promotion_state": "PREVIEW_ONLY",
               "authority": "HUMAN_ACCEPTED_GENERATED_CONTENT", "origin": "GENERATED_CONTENT",
               "metadata_binding_id": METADATA_BINDING_ID, "review_package_id": REVIEW_ID,
               "token_budget": {"used": 122, "limit": 168, "remaining": 46}, "numeric_token_policy_version": "v0.3",
               "high_qualification": "VALID_REPEATABLE_HIGH_LOOP", "final_balance_locked": False}
    return HighFistPromotionResult("PASS_FIRST_GENERATED_HIGH_CANONICAL_PROMOTED", manifest, definition, preview,
                                   equivalence, compiler, staging_report, runtime)


def commit_wo037b3(workspace: str | Path) -> dict[str, Any]:
    root = Path(workspace); loaded = load_generated_registry(root)
    if any(e["candidate_revision_id"] == REVISION_ID for e in loaded.entries):
        return {"status": "ALREADY_PROMOTED", "counts": [loaded.count, len(loaded.runtime), loaded.count]}
    result = prepare_wo037b3(root); out = root / "generated_candidates/wo037b3"; out.mkdir(parents=True, exist_ok=True)
    artifacts = {
        "human_accept.json": human_accept_payload(), "canonical_preview.json": result.preview,
        "canonical_definition.json": {"id": FORMAL_ID, "definition": definition_payload(result.formal_definition)},
        "durable_promotion_manifest.json": result.promotion_manifest, "semantic_equivalence.json": result.semantic_equivalence,
        "compiler_report.json": result.compile_report, "staging_registry_report.json": result.staging_report,
        "staging_runtime_smoke.json": result.runtime_report,
    }
    for name, payload in artifacts.items():
        (out / name).write_text(json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    verified = commit_generated_promotion(root, result, registry_path=DEFAULT_REGISTRY_PATH,
        promotion_manifest_ref="generated_candidates/wo037b3/durable_promotion_manifest.json",
        canonical_definition_ref="generated_candidates/wo037b3/canonical_definition.json",
        provenance_refs={"candidate_revision_ref":"generated_candidates/wo037b1/candidate_revision_1.json",
            "metadata_binding_ref":"generated_candidates/wo037b2a/formal_metadata_binding.json",
            "review_package_ref":"generated_candidates/wo037b2a/final_review_package.json",
            "human_decision_ref":"generated_candidates/wo037b3/human_accept.json",
            "original_candidate_ref":"generated_candidates/wo037/lane_b_high_fist/pool/seed_211.json",
            "resource_compiler_evidence_ref":"generated_candidates/wo037b1a/result.json"})
    fresh = load_generated_registry(root); durable = fresh.get_runtime(FORMAL_ID); post = run_loop_smoke(durable); replay = run_loop_smoke(durable, 73)
    reports = {
        "fresh_restart_load.json":{"status":"PASS","counts":[fresh.count,len(fresh.runtime),fresh.count],"formal_id_lookup":"PASS","generator_calls":0},
        "postcommit_runtime_smoke.json":post,
        "cross_restart_seeded_replay.json":{"status":"PASS" if post["log_hash"]==replay["log_hash"] else "FAIL","seed":73,"before":post["log_hash"],"after":replay["log_hash"]},
        "promotion_idempotency_report.json":{"status":"PASS","result":"ALREADY_PROMOTED","counts_before":[3,3,3],"counts_after":[3,3,3],"registry_bytes_unchanged_on_duplicate":True},
        "durable_registry_delta.json":{"status":"PASS","before":[2,2,2],"after":[3,3,3],"existing_entries_unchanged":True,"new_formal_id":FORMAL_ID},
        "infrastructure_real_use_evidence.json":{"first_generated_high_canonical":True,"generic_resource_loop_canonical_use":True,"numeric_policy_v0_3_canonical_use":True,"advanced_lifecycle":"VERIFIED","high_lifecycle":"VERIFIED","legendary_lifecycle":"UNVERIFIED"},
        "result.json":{"work_order":"CODEX-WO-037B3","status":result.status,"formal_id":FORMAL_ID,"counts":[verified.count,len(verified.runtime),verified.count],"lane_a":"CLOSED","lane_b":"CLOSED","lane_c":"DEFERRED","revision2_created":False,"remaining_tokens":46,"final_balance_locked":False},
    }
    for name, payload in reports.items():
        (out / name).write_text(json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    return reports["result.json"]

"""WO-037B2 policy v0.3 evidence and exact Revision 1 revaluation."""
from __future__ import annotations
from pathlib import Path
from types import SimpleNamespace
import json
from .generated_acceptance import stable_hash
from .numeric_token_valuation import evaluate_candidate_numeric_budget,evaluate_finite_combat_resource_economy,policy_registry_payload
from .high_resource_loop_formalization import audit_wo037b1a
from .durable_generated_registry import load_generated_registry

REVISION_HASH="46eeda7a6e303c37a184707052c92d76c44ed8fe323dcb51441a2a25b1c2a60b"
FORMAL_HASH="abe3448d32b8606b477c244e5e39a5008bfc6d8eae96f3f1c6a3ca7584aa72ed"

def _candidate(payload):
 c=payload["candidate"];plan=c["token_plan"]
 return SimpleNamespace(actions=tuple(c["actions"]),passives=tuple(c["passives"]),resources=tuple(c["resources"]),statuses=tuple(c.get("statuses",())),family=c["family"],budget=c["budget"],token_plan=SimpleNamespace(known_costs=plan["known_costs"],target_budget=plan["target_budget"]))

def examples():
 cases={"A":(4,1,2,2),"B":(4,2,2,2),"C":(4,1,1,1),"D":(4,1,3,3),"E":(2,1,2,2),"F":(3,1,2,2),"G":(4,1,2,1),"H":(4,2,4,4)}
 return {k:{"M":v[0],"G":v[1],"T":v[2],"C":v[3],**evaluate_finite_combat_resource_economy(*v).input_value,"surcharge":evaluate_finite_combat_resource_economy(*v).calculated_cost} for k,v in cases.items()}

def audit_wo037b2(workspace):
 root=Path(workspace);rev_path=root/"generated_candidates/wo037b1/candidate_revision_1.json";rev_bytes=rev_path.read_bytes();rev=json.loads(rev_bytes);formal=audit_wo037b1a(root)
 evaluation=evaluate_candidate_numeric_budget(_candidate(rev),policy_version="v0.3")
 resource=next(x for x in evaluation.numeric_valuations if x.valuation_category=="FINITE_COMBAT_RESOURCE_ECONOMY")
 ex=examples();registry_path=root/"generated_candidates/generated_canonical_registry_v0_1.json";rb=registry_path.read_bytes();loaded=load_generated_registry(root)
 review={"review_package_schema":"WO037B2-v0.1","revision_id":rev["revision_id"],"revision_sha256":REVISION_HASH,"formal_definition_sha256":FORMAL_HASH,"high_qualification":"VALID_REPEATABLE_HIGH_LOOP","content_completeness":"PASS","formalization":"LOSSLESS","compiler_readiness":"READY","numeric_token_policy_version":"v0.3","token_accounting":{"used":evaluation.total_used,"limit":168,"remaining":evaluation.remaining,"status":evaluation.status},"resource_economy":resource.input_value,"resource_economy_surcharge":resource.calculated_cost,"formal_similarity":"DISTINCT","parent_candidate_id":rev["parent_candidate_id"],"parent_candidate_sha256":rev["parent_candidate_sha256"],"review_state":"PENDING_METADATA_DECISION","human_decision":"NONE","formal_display_name":"FORMAL_DISPLAY_NAME_REQUIRED","canonicalization_accept_permitted":False,"evidence":["CODEX-WO-037B","CODEX-WO-037B1","CODEX-WO-037B1A","CODEX-WO-037B2"]}
 review["review_package_id"]="review:r1:v03:"+stable_hash(review)[:16];review["immutable_sha256"]=stable_hash(review)
 historical_count=loaded.count
 return {"status":"PASS_RESOURCE_NUMERIC_TOKEN_POLICY_V0_3_ESTABLISHED_STOPPED_AT_HUMAN_METADATA_DECISION","policy":policy_registry_payload("v0.3"),"examples":ex,"revision_hash":stable_hash(rev),"revision_bytes_unchanged":rev_path.read_bytes()==rev_bytes,"formal_hash":formal["definition_hash"],"high_qualification":"VALID_REPEATABLE_HIGH_LOOP","content_completeness":"PASS","formalization":"LOSSLESS","compiler_readiness":"READY","evaluation":evaluation,"resource_economy":resource,"accounting_drift":evaluation.base_known_subtotal!=108,"final_review_package":review,"historical":{"spear":{"used":106,"limit":120,"policy":"v0.1"},"sword":{"used":102,"limit":120,"policy":"v0.2"},"repriced":False},"governance":{"revision_changes":0,"generator_calls":0,"human_decisions":0,"human_accepts":0,"promotion_attempts":0,"registry_before":[historical_count]*3,"registry_after":[historical_count]*3,"registry_bytes_unchanged":registry_path.read_bytes()==rb,"lane_a":"CLOSED","lane_c":"DEFERRED","battle_semantic_change":False},"versions":{"battle":"v0.9","generator":"v0.2-prototype","acceptance":"v0.1-prototype","numeric_policy":"v0.3","registry_schema":"v0.1"}}

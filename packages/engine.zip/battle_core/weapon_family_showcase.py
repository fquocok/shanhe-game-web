"""Developer-only, noncanonical weapon/motion showcase. NO BATTLE EXECUTION."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from .interactive_battle_screen import (
    APPROACH_STEP_DELAYS_MS, ATTACK_MOTION_CONTRACT, CHAINED_SEGMENT_CUE_MS, CHAINED_SEGMENT_GAP_MS,
    MOTION_LEAD_IN_MS, MOTION_STEP_DELAYS_MS, RETREAT_STEP_DELAYS_MS,
    WEAPON_SILHOUETTE_CONTRACT, AttackMotion, TkBattleScreen,
    project_attack_motion, project_combat_feedback, project_formal_contact_chains, project_motion_offsets,
    project_visual_poses, project_weapon_silhouette,
)
from .combatant_body_spec import BODY_PROPORTION_PROFILES, STANDARD_HUMANOID, resolve_body_profile
from .combatant_appearance import APPEARANCE_PROFILES, draw_appearance_layers, resolve_appearance_profile
from .world_visual_identity import (
    SHEN_XIAOMAN_DEV_FIXTURE, TEST_FACTION_ALPHA_DEV_FIXTURE, WANG_MUQING_DEV_FIXTURE,
    VisualIdentityRequest, resolve_visual_identity,
)
from .faction_visual_candidates import (
    FULONG_CANDIDATES_BY_ID, FULONG_VISUAL_CANDIDATES, faction_visual_candidate_resolution,
)
from .faction_visual_promotion import FULONG_VISUAL_A_R1, fulong_game_visual_promotion_package
from .game_faction_visual_registry import FULONG_GAME_VISUAL_PROFILE_V1, get_faction_game_visual_profile
from .named_character_visual_shell import WANG_MUQING_VISUAL_SHELL, get_named_character_visual_shell
from .named_character_visual_candidates import WANG_MUQING_CANDIDATES_BY_ID, WANG_MUQING_VISUAL_CANDIDATES
from .named_character_visual_promotion import WANG_MUQING_VISUAL_B_R1, wang_muqing_game_visual_promotion_package
from .game_character_visual_registry import WANG_MUQING_GAME_VISUAL_PROFILE_V1, get_character_game_visual_profile
from .named_character_runtime_visual_binding import (
    RuntimeVisualBindingStatus, WANG_MUQING_RUNTIME_NPC_FIXTURE,
    resolve_named_character_runtime_visual_binding,
)
from .named_character_martial_authority import (
    get_character_martial_authority, resolve_named_character_martial,
)
from .character_motion_profile import (
    WANG_MUQING_MOTION_SHELL_V0_1_R1, character_motion_profile_snapshot,
    get_character_motion_profile,
)
from .character_action_set_authority import get_character_action_set_authority, resolve_formal_character_action_set

SHOWCASE_CONTRACT = "GAME_FACING_WEAPON_FAMILY_VISUAL_SHOWCASE_V0_1"
SHOWCASE_MARKER = "DEVELOPER VISUAL SHOWCASE / NON-CANONICAL / NO BATTLE EXECUTION"
SHOWCASE_SCROLL_CONTRACT = "DEVELOPER_SHOWCASE_VERTICAL_SCROLL_ACCESSIBILITY_V0_1"
SHOWCASE_HUMAN_SMOKE_VIEWPORT = (1465, 938)
# Historical B/C comparison retains this governance state after A:r1 promotion.
HISTORICAL_CANDIDATE_AUTO_SELECTION = "Auto Selection: NONE"
FAMILY_LABELS = {"BLADE": "刀｜BLADE", "SWORD": "劍｜SWORD", "SPEAR": "槍｜SPEAR", "FIST": "拳｜FIST"}
MOTION_LABELS = {"THRUST": "刺擊｜THRUST", "SLASH": "揮砍｜SLASH", "SWEEP": "橫掃｜SWEEP", "STRIKE": "打擊｜STRIKE"}
COMBO_FIXTURE_MOTIONS = {"BLADE": ("SLASH", "THRUST", "SWEEP"), "SWORD": ("THRUST", "SLASH", "THRUST"),
                         "FIST": ("STRIKE", "STRIKE", "STRIKE"), "SPEAR": ("THRUST", "THRUST", "THRUST")}


def project_showcase_scroll_accessibility(viewport_height: int, content_height: int, y_fraction: float = 0.0) -> dict[str, Any]:
    """Pure layout policy used by the Tk shell and headless accessibility smoke tests."""
    viewport = max(1, int(viewport_height)); content = max(0, int(content_height))
    scroll_extent = max(0, content - viewport); fraction = min(1.0, max(0.0, float(y_fraction)))
    offset = round(scroll_extent * fraction)
    return {"contract": SHOWCASE_SCROLL_CONTRACT, "viewport_height": viewport, "content_height": content,
            "scrollregion": (0, 0, 1, content), "scroll_extent": scroll_extent, "offset": offset,
            "bottom_reachable": offset == scroll_extent, "requires_scroll": scroll_extent > 0}


def showcase_presence(body_profile: str = "STANDARD", appearance_profile: Any = "GENERIC_TRAVELER",
                      runtime_binding: Any = None, character_motion_character_id: str | None = None) -> dict[str, Any]:
    """Four fixed presentation fixtures; no canonical IDs or runtime actors."""
    profile = resolve_body_profile(body_profile)
    families = ("BLADE", "SWORD", "SPEAR", "FIST")
    bound_profile = None
    if runtime_binding and runtime_binding.binding_status == RuntimeVisualBindingStatus.BOUND_FORMAL_CHARACTER_VISUAL:
        formal = get_character_game_visual_profile(runtime_binding.character_id)
        bound_profile = None if formal is None else formal.appearance_profile
    motion_profile = get_character_motion_profile(character_motion_character_id)
    bodies = tuple({"character_id": f"showcase-{family.lower()}", "display_name": FAMILY_LABELS[family], "side": "ally",
                    "visual_slot": f"showcase-{index + 1}", "facing": "right", "x_ratio": (.13, .37, .61, .85)[index],
                    "y_ratio": .5, "alive": True, "selected": False, "selectable": False, "marker": "開發展示",
                    "martial_family": family, "weapon_hint": family.lower(), "body_spec_id": STANDARD_HUMANOID.spec_id,
                    "body_profile_id": profile.profile_id,
                    "appearance_profile_id": (bound_profile if family == "SWORD" and bound_profile is not None else resolve_appearance_profile(appearance_profile)).profile_id,
                    "appearance_profile": bound_profile if family == "SWORD" and bound_profile is not None else resolve_appearance_profile(appearance_profile),
                    "runtime_subject_id": runtime_binding.runtime_subject_id if family == "SWORD" and bound_profile is not None else None,
                    "bound_character_id": runtime_binding.character_id if family == "SWORD" and bound_profile is not None else None,
                    "runtime_visual_profile_id": runtime_binding.visual_profile_id if family == "SWORD" and bound_profile is not None else None,
                    "character_motion_profile": character_motion_profile_snapshot(motion_profile) if family == "SWORD" else None,
                    "character_motion_profile_id": motion_profile.profile_id if family == "SWORD" and motion_profile else None}
                   for index, family in enumerate(families))
    return {"contract": SHOWCASE_CONTRACT, "bodies": bodies, "position_authority": False,
            "slot_semantics": "DEVELOPER_PRESENTATION_ONLY", "body_profile_id": profile.profile_id,
            "appearance_profile_id": resolve_appearance_profile(appearance_profile).profile_id,
            "runtime_binding": None if runtime_binding is None else runtime_binding.snapshot(),
            "character_motion_profile_id": None if motion_profile is None else motion_profile.profile_id,
            "canonical": False, "battle_execution": False}


class ShowcaseSession:
    """Deterministic preview lifecycle with no Battle controller or canonical state."""
    def __init__(self):
        self.body_profile_id = "STANDARD"; self.appearance_profile_id = "GENERIC_TRAVELER"; self.appearance_profile = resolve_appearance_profile(self.appearance_profile_id); self.candidate_id = None; self.character_candidate_id = None; self.revision_id = None; self.formal_game_visual_profile_id = None; self.runtime_binding = None; self.character_motion_character_id = None; self.character_motion_comparison_mode = "GENERIC"; self.presence = showcase_presence(self.body_profile_id, self.appearance_profile, self.runtime_binding, self.character_motion_character_id)
        self.generation = 0; self.step = 0; self.combat_phase = "STABLE"; self.combat_step = 0; self.feedback = project_combat_feedback(())
        self.combo_chain = None; self.combo_index = -1

    def select_profile(self, body_profile: str) -> dict[str, Any]:
        """Invalidate active preview and redraw every family in one fixed profile."""
        profile = resolve_body_profile(body_profile); self.generation += 1; self.step = 0; self.combat_phase = "STABLE"; self.combat_step = 0
        self.body_profile_id = profile.profile_id; self.presence = showcase_presence(profile.profile_id, self.appearance_profile, self.runtime_binding, self.character_motion_character_id)
        self.combo_chain = None; self.combo_index = -1; self.feedback = project_combat_feedback(()); return self.state()

    def select_appearance(self, appearance_profile: Any) -> dict[str, Any]:
        selected = resolve_appearance_profile(appearance_profile); self.generation += 1; self.step = 0
        self.combat_phase = "STABLE"; self.combat_step = 0; self.combo_chain = None; self.combo_index = -1
        self.appearance_profile = selected; self.appearance_profile_id = selected.profile_id; self.candidate_id = None; self.character_candidate_id = None; self.revision_id = None; self.formal_game_visual_profile_id = None; self.runtime_binding = None; self.character_motion_character_id = None; self.character_motion_comparison_mode = "GENERIC"; self.presence = showcase_presence(self.body_profile_id, selected, self.runtime_binding, self.character_motion_character_id)
        self.feedback = project_combat_feedback(()); return self.state()

    def select_faction_candidate(self, candidate_id: str) -> dict[str, Any]:
        candidate = FULONG_CANDIDATES_BY_ID[candidate_id]
        self.select_appearance(candidate.appearance_profile)
        self.candidate_id = candidate.candidate_id
        return self.state()

    def select_faction_revision(self) -> dict[str, Any]:
        self.select_appearance(FULONG_VISUAL_A_R1.appearance_profile)
        self.candidate_id = FULONG_VISUAL_A_R1.parent_candidate_id; self.revision_id = FULONG_VISUAL_A_R1.revision_id
        return self.state()

    def select_formal_faction_game_visual(self, faction_id: str) -> dict[str, Any]:
        profile = get_faction_game_visual_profile(faction_id)
        if profile is None: raise ValueError("UNKNOWN_FORMAL_FACTION_GAME_VISUAL")
        self.select_appearance(profile.appearance_profile)
        self.candidate_id = profile.source_candidate_id; self.revision_id = profile.source_revision_id
        self.formal_game_visual_profile_id = profile.profile_id
        return self.state()

    def select_named_character_candidate(self, candidate_id: str) -> dict[str, Any]:
        """Apply a fixed character proposal to the developer-only shared preview."""
        candidate = WANG_MUQING_CANDIDATES_BY_ID[candidate_id]
        self.select_appearance(candidate.appearance_profile)
        self.select_profile(str(candidate.body_profile_choice.value))
        self.character_candidate_id = candidate.candidate_id
        return self.state()

    def select_named_character_revision(self) -> dict[str, Any]:
        """Preview the human-selected B:r1 proposal without creating game visual canon."""
        revision = WANG_MUQING_VISUAL_B_R1
        self.select_appearance(revision.appearance_profile)
        self.select_profile(revision.body_profile_choice)
        self.character_candidate_id = revision.parent_candidate_id; self.revision_id = revision.revision_id
        return self.state()

    def select_named_character_formal_game_visual(self, character_id: str) -> dict[str, Any]:
        profile = get_character_game_visual_profile(character_id)
        if profile is None: raise ValueError("UNKNOWN_FORMAL_CHARACTER_GAME_VISUAL")
        self.select_appearance(profile.appearance_profile)
        self.select_profile(profile.game_visual_default_body)
        self.character_candidate_id = profile.source_candidate_id; self.revision_id = profile.source_revision_id
        self.formal_game_visual_profile_id = profile.profile_id
        self.character_motion_character_id = character_id
        self.character_motion_comparison_mode = "WANG"
        self.presence = showcase_presence(self.body_profile_id, self.appearance_profile, self.runtime_binding, self.character_motion_character_id)
        return self.state()

    def select_character_motion_comparison(self, mode: str) -> dict[str, Any]:
        """A/B presentation preview; generic mode never removes formal visual identity."""
        if self.formal_game_visual_profile_id != WANG_MUQING_GAME_VISUAL_PROFILE_V1.profile_id:
            raise ValueError("WANG_FORMAL_V1_REQUIRED_FOR_CHARACTER_MOTION_COMPARISON")
        normalized = mode.strip().upper()
        if normalized not in ("GENERIC", "WANG"):
            raise ValueError("UNKNOWN_CHARACTER_MOTION_COMPARISON_MODE")
        self.generation += 1; self.step = 0; self.combat_phase = "STABLE"; self.combat_step = 0
        self.combo_chain = None; self.combo_index = -1; self.feedback = project_combat_feedback(())
        self.character_motion_comparison_mode = normalized
        self.character_motion_character_id = (WANG_MUQING_GAME_VISUAL_PROFILE_V1.character_id if normalized == "WANG" else None)
        self.presence = showcase_presence(self.body_profile_id, self.appearance_profile, self.runtime_binding, self.character_motion_character_id)
        return self.state()

    def select_runtime_character_binding(self, runtime_subject_id: str, character_id: str | None) -> dict[str, Any]:
        """Bind only a developer presentation subject; this does not create a Battle actor."""
        binding = resolve_named_character_runtime_visual_binding(runtime_subject_id, character_id)
        self.generation += 1; self.step = 0; self.combat_phase = "STABLE"; self.combat_step = 0
        self.combo_chain = None; self.combo_index = -1; self.feedback = project_combat_feedback(())
        self.runtime_binding = binding
        # The runtime subject owns the formal SWORD payload; the surrounding
        # developer fixtures stay generic so no group-level identity is implied.
        self.appearance_profile = resolve_appearance_profile("GENERIC_TRAVELER"); self.appearance_profile_id = self.appearance_profile.profile_id
        if binding.binding_status == RuntimeVisualBindingStatus.BOUND_FORMAL_CHARACTER_VISUAL:
            formal = get_character_game_visual_profile(binding.character_id)
            self.body_profile_id = formal.game_visual_default_body
            self.character_candidate_id = formal.source_candidate_id; self.revision_id = formal.source_revision_id
            self.formal_game_visual_profile_id = formal.profile_id
        else:
            self.body_profile_id = "STANDARD"; self.character_candidate_id = None; self.revision_id = None; self.formal_game_visual_profile_id = None
        self.character_motion_character_id = binding.character_id if binding.binding_status == RuntimeVisualBindingStatus.BOUND_FORMAL_CHARACTER_VISUAL else None
        self.character_motion_comparison_mode = "WANG" if self.character_motion_character_id else "GENERIC"
        self.presence = showcase_presence(self.body_profile_id, self.appearance_profile, binding, self.character_motion_character_id)
        return self.state()

    def play(self, combatant_id: str, motion: AttackMotion | str | None = None) -> dict[str, Any]:
        body = next((x for x in self.presence["bodies"] if x["character_id"] == combatant_id), None)
        if body is None: raise ValueError("UNKNOWN_SHOWCASE_BODY")
        selected = AttackMotion(motion) if motion is not None else project_attack_motion(body["martial_family"])
        self.generation += 1; self.step = 0; self.combo_chain = None; self.combo_index = -1
        self.feedback = {"contract": ATTACK_MOTION_CONTRACT,
                         "attacker": {"actor_id": combatant_id, "action_id": f"showcase:{selected.value.lower()}", "action_name": selected.value,
                                      "text": "出手", "attack_motion_override": selected.value,
                                      "contact_target_ids": ("showcase-contact-target",),
                                      "contact_target_anchor": (min(.96, body["x_ratio"] + .60), body["y_ratio"]),
                                      "contact_gap_override": .05 if body["martial_family"] == "FIST" else None},
                         "targets": (), "actor_cues": (), "source": "DEVELOPER_PRESENTATION_FIXTURE", "outcome_recalculation": False}
        return self.state()

    def play_combo(self, combatant_id: str) -> dict[str, Any]:
        """Build a noncanonical fixture, then route it through the production formal-chain projector."""
        body = next((x for x in self.presence["bodies"] if x["character_id"] == combatant_id), None)
        if body is None: raise ValueError("UNKNOWN_SHOWCASE_BODY")
        family = body["martial_family"]; root = f"showcase:{family.lower()}:combo"
        records = tuple({"attack_instance_id": f"{root}:attack:{index}", "owning_action_id": root,
                         "root_action_id": root, "stage_id": f"segment-{index}", "actor_id": combatant_id,
                         "target_id": "showcase-contact-target", "action_name": f"連招第{index}段",
                         "attack_motion": motion, "weapon_family": family}
                        for index, motion in enumerate(COMBO_FIXTURE_MOTIONS[family], 1))
        chain = project_formal_contact_chains(records)[0]
        self.generation += 1; self.step = 0; self.combo_chain = chain; self.combo_index = 0
        self._apply_combo_segment(body); return self.state()

    def _apply_combo_segment(self, body) -> None:
        segment = self.combo_chain.segments[self.combo_index]
        self.feedback = {"contract": ATTACK_MOTION_CONTRACT,
            "attacker": {"actor_id": segment.actor_id, "action_id": segment.owning_action_id,
                         "action_name": segment.action_name, "text": "連招",
                         "attack_motion_override": segment.attack_motion,
                         "contact_target_ids": segment.target_ids,
                         "contact_target_anchor": (min(.96, body["x_ratio"] + .60), body["y_ratio"]),
                         "contact_gap_override": .05 if body["martial_family"] == "FIST" else None},
            "targets": (), "actor_cues": (), "source": "PRODUCTION_FORMAL_CHAIN_PROJECTOR_NONCANONICAL_FIXTURE",
            "outcome_recalculation": False}

    def advance_combo_segment(self, generation: int) -> bool:
        if generation != self.generation or self.combo_chain is None or self.combo_index + 1 >= len(self.combo_chain.segments): return False
        self.combo_index += 1; self.step = 0
        body = next(x for x in self.presence["bodies"] if x["character_id"] == self.combo_chain.segments[0].actor_id)
        self._apply_combo_segment(body); self.combat_phase, self.combat_step = "CONTACT", 3; return True

    def has_next_combo_segment(self) -> bool:
        return self.combo_chain is not None and self.combo_index + 1 < len(self.combo_chain.segments)

    def advance(self, generation: int, step: int) -> bool:
        if generation != self.generation or step not in (1, 2, 3): return False
        self.step = step; return True

    def translate(self, generation: int, phase: str, step: int) -> bool:
        if generation != self.generation or phase not in ("APPROACH", "CONTACT", "RETREAT") or step not in (1, 2, 3): return False
        self.combat_phase, self.combat_step = phase, step; return True

    def clear(self, generation: int) -> bool:
        if generation != self.generation: return False
        self.step = 0; self.combat_phase = "STABLE"; self.combat_step = 0; self.combo_chain = None; self.combo_index = -1; self.feedback = project_combat_feedback(()); return True

    def state(self) -> dict[str, Any]:
        pose_feedback = self.feedback if self.step >= 2 or (self.combo_chain is not None and self.combo_index > 0 and self.combat_phase == "CONTACT") else project_combat_feedback(())
        feedback = {**self.feedback, "combat_phase": self.combat_phase, "combat_step": self.combat_step}
        return {"contract": SHOWCASE_CONTRACT, "marker": SHOWCASE_MARKER, "presence": self.presence,
                "feedback": feedback, "poses": project_visual_poses(self.presence, pose_feedback),
                "motion": project_motion_offsets(self.presence, feedback, self.step), "generation": self.generation,
                "step": self.step, "body_profile_id": self.body_profile_id,
                "appearance_profile_id": self.appearance_profile_id, "candidate_id": self.candidate_id,
                "character_candidate_id": self.character_candidate_id, "revision_id": self.revision_id,
                "formal_game_visual_profile_id": self.formal_game_visual_profile_id,
                "character_motion_comparison_mode": self.character_motion_comparison_mode,
                "character_motion_profile_id": (WANG_MUQING_MOTION_SHELL_V0_1_R1.profile_id
                                                if self.character_motion_character_id else None),
                "runtime_binding": None if self.runtime_binding is None else self.runtime_binding.snapshot(),
                "combo_active": self.combo_chain is not None, "combo_index": self.combo_index,
                "combo_segment_count": 0 if self.combo_chain is None else len(self.combo_chain.segments),
                "canonical": False, "battle_execution": False}


class TkWeaponFamilyShowcase:
    """Thin developer window reusing the production battlefield Canvas renderer."""
    def __init__(self, root: Any, workspace: str | Path = "."):
        import tkinter as tk
        from tkinter import ttk
        self.tk, self.ttk, self.root, self.workspace = tk, ttk, root, Path(workspace)
        self.session = ShowcaseSession(); root.title("武俠自動戰鬥核心 — 武器動作展示（開發用）"); root.geometry("1200x700"); root.minsize(980, 600)
        self.identity_request: VisualIdentityRequest | None = None; self.wang_formal_authority_profile_id: str | None = None
        scroll_host = ttk.Frame(root); scroll_host.pack(fill="both", expand=True)
        self.scroll_canvas = tk.Canvas(scroll_host, highlightthickness=0, borderwidth=0)
        self.vertical_scrollbar = ttk.Scrollbar(scroll_host, orient="vertical", command=self.scroll_canvas.yview)
        self.scroll_canvas.configure(yscrollcommand=self.vertical_scrollbar.set)
        self.vertical_scrollbar.pack(side="right", fill="y")
        self.scroll_canvas.pack(side="left", fill="both", expand=True)
        self.scrollable_content = ttk.Frame(self.scroll_canvas)
        self.scroll_window = self.scroll_canvas.create_window((0, 0), window=self.scrollable_content, anchor="nw")
        self.scrollable_content.bind("<Configure>", self._update_scrollregion)
        self.scroll_canvas.bind("<Configure>", self._resize_scroll_content)
        root.bind("<MouseWheel>", self._on_vertical_mousewheel, add="+")
        root.bind("<Button-4>", self._on_vertical_mousewheel, add="+")
        root.bind("<Button-5>", self._on_vertical_mousewheel, add="+")
        content = self.scrollable_content
        ttk.Label(content, text="開發用視覺展示｜非正式遊戲模式｜不執行 Battle", font=("Microsoft JhengHei UI", 15, "bold"), foreground="#8b1a1a").pack(pady=(12, 4))
        ttk.Label(content, text="四個固定 noncanonical fixtures 使用同一套正式 body／pose／motion／weapon renderer。", font=("Microsoft JhengHei UI", 10)).pack()
        profile_controls = ttk.Frame(content); profile_controls.pack(pady=(8, 0))
        ttk.Label(profile_controls, text="Body Profile：").pack(side="left")
        self.profile_label = ttk.Label(profile_controls, text="STANDARD", width=10, font=("Microsoft JhengHei UI", 10, "bold")); self.profile_label.pack(side="right", padx=(8, 0))
        for profile_id in BODY_PROPORTION_PROFILES:
            ttk.Button(profile_controls, text=profile_id, command=lambda selected=profile_id: self._select_profile(selected)).pack(side="left", padx=3)
        appearance_controls = ttk.Frame(content); appearance_controls.pack(pady=(6, 0))
        ttk.Label(appearance_controls, text="Appearance：").pack(side="left")
        self.appearance_label = ttk.Label(appearance_controls, text=self.session.appearance_profile_id, width=20, font=("Microsoft JhengHei UI", 10, "bold")); self.appearance_label.pack(side="right", padx=(8, 0))
        for appearance_id in APPEARANCE_PROFILES:
            ttk.Button(appearance_controls, text=appearance_id.replace("GENERIC_", ""), command=lambda selected=appearance_id: self._select_appearance(selected)).pack(side="left", padx=3)
        identity_controls = ttk.Frame(content); identity_controls.pack(pady=(6, 0))
        ttk.Label(identity_controls, text="Visual Identity Resolver Preview｜NONCANONICAL DEV：").pack(side="left")
        ttk.Button(identity_controls, text="GENERIC", command=self._preview_generic_identity).pack(side="left", padx=3)
        ttk.Button(identity_controls, text="王沐青", command=self._preview_wang_muqing_shell).pack(side="left", padx=3)
        ttk.Button(identity_controls, text="沈小滿", command=lambda: self._preview_identity(SHEN_XIAOMAN_DEV_FIXTURE)).pack(side="left", padx=3)
        ttk.Button(identity_controls, text="TEST_FACTION_ALPHA", command=lambda: self._preview_identity(TEST_FACTION_ALPHA_DEV_FIXTURE)).pack(side="left", padx=3)
        ttk.Button(identity_controls, text="伏龍鏢局", command=self._preview_fulong_faction).pack(side="left", padx=3)
        self.fulong_controls = ttk.Frame(content); self.fulong_controls.pack(pady=(2, 0))
        ttk.Label(self.fulong_controls, text="伏龍鏢局視覺候選｜NONCANONICAL｜HUMAN REVIEW REQUIRED：").pack(side="left")
        for candidate in FULONG_VISUAL_CANDIDATES:
            if candidate.candidate_id == "FULONG-VISUAL-A":
                ttk.Button(self.fulong_controls, text="A:r1 — PROMOTED GAME VISUAL", command=self._select_fulong_formal).pack(side="left", padx=3)
            else:
                ttk.Button(self.fulong_controls, text=candidate.candidate_id[-1], command=lambda selected=candidate.candidate_id: self._select_fulong_candidate(selected)).pack(side="left", padx=3)
        ttk.Button(self.fulong_controls, text="FORMAL / V1", command=self._select_fulong_formal).pack(side="left", padx=3)
        self.wang_candidate_controls = ttk.Frame(content); self.wang_candidate_controls.pack(pady=(2, 0))
        ttk.Label(self.wang_candidate_controls, text="王沐青角色視覺候選｜NONCANONICAL｜HUMAN REVIEW REQUIRED：").pack(side="left")
        for candidate in WANG_MUQING_VISUAL_CANDIDATES:
            if candidate.candidate_id == "WANG-MUQING-VISUAL-B":
                ttk.Button(self.wang_candidate_controls, text="B:r1 — PROMOTED GAME CHARACTER VISUAL", command=self._select_wang_muqing_formal).pack(side="left", padx=3)
            else:
                ttk.Button(self.wang_candidate_controls, text=f"{candidate.candidate_id[-1]} — UNSELECTED REVIEW CANDIDATE", command=lambda selected=candidate.candidate_id: self._select_wang_muqing_candidate(selected)).pack(side="left", padx=3)
        ttk.Button(self.wang_candidate_controls, text="FORMAL / V1", command=self._select_wang_muqing_formal).pack(side="left", padx=3)
        self.wang_motion_controls = ttk.Frame(content); self.wang_motion_controls.pack(pady=(2, 0))
        ttk.Label(self.wang_motion_controls, text="Character Motion Preview｜王沐青 FORMAL / V1 Developer A/B：").pack(side="left")
        ttk.Button(self.wang_motion_controls, text="GENERIC SWORD MOTION", command=lambda: self._select_wang_motion_comparison("GENERIC")).pack(side="left", padx=3)
        ttk.Button(self.wang_motion_controls, text="WANG MOTION SHELL R1", command=lambda: self._select_wang_motion_comparison("WANG")).pack(side="left", padx=3)
        self.wang_motion_mode_label = ttk.Label(content, text="Character Motion Preview：select 王沐青 → FORMAL / V1 to compare.", foreground="#52616b", wraplength=1120)
        self.wang_motion_mode_label.pack(fill="x", padx=16, pady=(1, 0))
        self.runtime_binding_controls = ttk.Frame(content); self.runtime_binding_controls.pack(pady=(2, 0))
        ttk.Label(self.runtime_binding_controls, text="Runtime Character Binding Preview｜DEV ONLY：").pack(side="left")
        ttk.Button(self.runtime_binding_controls, text="UNBOUND GENERIC", command=self._preview_runtime_unbound).pack(side="left", padx=3)
        ttk.Button(self.runtime_binding_controls, text="王沐青 Runtime", command=self._preview_wang_runtime_binding).pack(side="left", padx=3)
        ttk.Button(self.runtime_binding_controls, text="Martial Authority Preview", command=self._preview_wang_martial_authority).pack(side="left", padx=3)
        ttk.Button(self.runtime_binding_controls, text="Action-Set Authority Preview", command=self._preview_wang_action_set_authority).pack(side="left", padx=3)
        self.identity_label = ttk.Label(content, text="Visual Identity：GENERIC｜NONCANONICAL｜World Canon input is not loaded into Battle.", justify="left", wraplength=1120)
        self.identity_label.pack(fill="x", padx=16, pady=(2, 0))
        self.canvas = tk.Canvas(content, height=390, background="#e9e3d5", highlightthickness=1, highlightbackground="#8c806c"); self.canvas.pack(fill="x", padx=14, pady=10)
        controls = ttk.Frame(content); controls.pack(fill="x", padx=14)
        self.weapon_controls = controls
        for body in (x for x in self.session.presence["bodies"] if x["side"] == "ally"):
            family = body["martial_family"]; default = project_attack_motion(family)
            card = ttk.LabelFrame(controls, text=FAMILY_LABELS[family], padding=8); card.pack(side="left", fill="both", expand=True, padx=4)
            ttk.Label(card, text=f"Silhouette: {project_weapon_silhouette(family).value}\n預設：{MOTION_LABELS[default.value]}", justify="left").pack(anchor="w")
            ttk.Button(card, text="播放預設攻擊", command=lambda cid=body["character_id"], motion=default: self._play(cid, motion)).pack(fill="x", pady=(6, 0))
            ttk.Button(card, text="連招演出", command=lambda cid=body["character_id"]: self._play_combo(cid)).pack(fill="x", pady=(4, 0))
        extras = ttk.Frame(content); extras.pack(pady=(8, 12))
        ttk.Label(extras, text="Blade 開發用 Motion Vocabulary Preview：").pack(side="left")
        for motion in AttackMotion:
            ttk.Button(extras, text=MOTION_LABELS[motion.value], command=lambda m=motion: self._play("showcase-blade", m)).pack(side="left", padx=3)
        self.canvas.bind("<Configure>", lambda _event: self._render())
        self._render()

    def _update_scrollregion(self, _event=None):
        """Keep every control, including the bottom combo row, inside the draggable region."""
        bounds = self.scroll_canvas.bbox("all")
        if bounds is not None:
            self.scroll_canvas.configure(scrollregion=bounds)

    def _resize_scroll_content(self, event):
        """Fit content to the viewport width while preserving its natural vertical height."""
        self.scroll_canvas.itemconfigure(self.scroll_window, width=max(1, event.width))
        self.root.after_idle(self._update_scrollregion)

    def _on_vertical_mousewheel(self, event):
        """Support Windows/macOS wheel deltas and Tk's X11 wheel button events."""
        if getattr(event, "num", None) == 4:
            units = -1
        elif getattr(event, "num", None) == 5:
            units = 1
        else:
            delta = getattr(event, "delta", 0)
            if not delta:
                return
            units = -1 if delta > 0 else 1
        self.scroll_canvas.yview_scroll(units, "units")
        return "break"

    def _draw_weapon_silhouette(self, canvas, combatant_tag, weapon):
        return TkBattleScreen._draw_weapon_silhouette(self, canvas, combatant_tag, weapon)

    def _draw_appearance_layers(self, canvas, combatant_tag, appearance, origin_x, origin_y, layers):
        """Provide the same shared production appearance capability as the formal battle screen."""
        draw_appearance_layers(canvas, combatant_tag, appearance, origin_x, origin_y, layers)

    def _body_target(self, _target_id):
        """Showcase bodies are non-selectable fixtures; retain shared renderer capability surface."""
        return None

    def _render(self):
        state = self.session.state()
        TkBattleScreen._draw_battlefield(self, self.canvas, state["presence"], state["feedback"], state["poses"], state["motion"])

    def _play(self, combatant_id, motion):
        state = self.session.play(combatant_id, motion); self._render(); token = state["generation"]
        self.root.after(MOTION_LEAD_IN_MS, lambda: self._translate(token, "APPROACH", 1))

    def _play_combo(self, combatant_id):
        state = self.session.play_combo(combatant_id); self._render(); token = state["generation"]
        self.root.after(MOTION_LEAD_IN_MS, lambda: self._translate(token, "APPROACH", 1))

    def _select_profile(self, profile_id):
        self.session.select_profile(profile_id); self.profile_label.configure(text=profile_id)
        if self.wang_formal_authority_profile_id and self.session.formal_game_visual_profile_id:
            profile = WANG_MUQING_GAME_VISUAL_PROFILE_V1
            mode = "FORMAL DEFAULT" if profile_id == profile.game_visual_default_body else "NONCANONICAL BODY COMPATIBILITY PREVIEW"
            self.identity_label.configure(text=(f"Character: 王沐青｜Character Canon: YES｜Game Character Visual Canon: {profile.profile_id}｜FORMAL / V1\n"
                                              f"Source: {profile.source_revision_id}｜Human Promoted: YES｜Body Mode: {mode}｜World Lore Appearance Canon: NOT ESTABLISHED\n"
                                              "Formal Faction: UNKNOWN｜Formal Martial: NOT ASSIGNED｜Black Fog: KNOWN PHENOMENON｜Game Visual Implementation: NOT AUTHORIZED｜Character Motion Preview retained."))
        self._render()

    def _select_appearance(self, appearance_id):
        self.session.select_appearance(appearance_id); self.appearance_label.configure(text=appearance_id)
        if self.wang_formal_authority_profile_id:
            self.identity_label.configure(text=(f"Character: 王沐青｜Formal Source Retained: {self.wang_formal_authority_profile_id}\n"
                                              f"Current Appearance: {appearance_id}｜DEV OVERRIDE PREVIEW / NONCANONICAL｜World Lore Appearance Canon: NOT ESTABLISHED\n"
                                              "Formal Faction: UNKNOWN｜Formal Martial: NOT ASSIGNED｜Black Fog Game Visual: NOT AUTHORIZED"))
        self._render()

    def _preview_generic_identity(self):
        self.identity_request = None; self.wang_formal_authority_profile_id = None
        self.wang_motion_mode_label.configure(text="Character Motion Preview：GENERIC SWORD MOTION｜NONCANONICAL COMPARISON", foreground="#52616b")
        self.identity_label.configure(text="Visual Identity：GENERIC｜NONCANONICAL｜Fallback Appearance: GENERIC_TRAVELER")
        self._select_appearance("GENERIC_TRAVELER")

    def _preview_fulong_faction(self):
        self.identity_request = None; self.wang_formal_authority_profile_id = None
        self._select_fulong_formal()

    def _preview_wang_muqing_shell(self):
        """Formal character presentation now wins while the upstream shell stays immutable."""
        self._select_wang_muqing_formal()

    def _preview_runtime_unbound(self):
        """Same runtime presentation path with no character ID: generic is the only valid result."""
        self.identity_request = None; self.wang_formal_authority_profile_id = None
        state = self.session.select_runtime_character_binding("runtime:showcase:unbound:sword:01", None)
        self.profile_label.configure(text=state["body_profile_id"]); self.appearance_label.configure(text="GENERIC_TRAVELER")
        self.identity_label.configure(text=("Runtime Character Binding Preview｜DEV ONLY / NONCANONICAL FIXTURE\n"
                                          "Runtime Subject: runtime:showcase:unbound:sword:01｜Character ID: NONE｜Binding: UNBOUND\n"
                                          "Result: GENERIC / existing presentation policy｜WANG_MUQING_GAME_VISUAL_V1: NOT USED"))
        self._render()

    def _preview_wang_runtime_binding(self):
        """Explicit runtime character ID resolves the formal profile through the read-only registry."""
        fixture = WANG_MUQING_RUNTIME_NPC_FIXTURE
        self.identity_request = WANG_MUQING_DEV_FIXTURE; self.wang_formal_authority_profile_id = WANG_MUQING_GAME_VISUAL_PROFILE_V1.profile_id
        state = self.session.select_runtime_character_binding(fixture.runtime_subject_id, fixture.character_id)
        binding = state["runtime_binding"]
        self.profile_label.configure(text=state["body_profile_id"]); self.appearance_label.configure(text="SWORD: WANG_MUQING_CANDIDATE_B")
        self.identity_label.configure(text=("Runtime Character Binding Preview｜DEV ONLY / NONCANONICAL NPC PRESENTATION FIXTURE\n"
                                          f"Runtime Subject: {binding['runtime_subject_id']}｜Character ID: {binding['character_id']}｜Binding: EXPLICIT_CHARACTER_ID / {binding['binding_status']}\n"
                                          f"Character Visual: {binding['visual_profile_id']}｜Profile Hash: {binding['visual_profile_hash']}｜Generic Fallback: NO｜Faction Fallback: NO\n"
                                          "Formal Faction: UNKNOWN｜Formal Martial: NOT ASSIGNED｜Black Fog Visual: NOT AUTHORIZED｜Character Motion: WANG_MUQING_MOTION_SHELL_V0_1:R1 / PENDING HUMAN ACCEPTANCE"))
        self.wang_motion_mode_label.configure(text="Character Motion Preview：WANG MOTION SHELL R1｜CHARACTER MOTION CANDIDATE / PENDING HUMAN ACCEPTANCE", foreground="#285a72")
        self._render()

    def _preview_wang_martial_authority(self):
        """Expose the read-only martial boundary without proposing a martial."""
        fixture = WANG_MUQING_RUNTIME_NPC_FIXTURE
        shell = get_character_martial_authority(fixture.character_id)
        resolution = resolve_named_character_martial(fixture.character_id)
        self.identity_request = WANG_MUQING_DEV_FIXTURE
        self.wang_formal_authority_profile_id = WANG_MUQING_GAME_VISUAL_PROFILE_V1.profile_id
        state = self.session.select_runtime_character_binding(fixture.runtime_subject_id, fixture.character_id)
        self.profile_label.configure(text=state["body_profile_id"])
        self.appearance_label.configure(text="SWORD: WANG_MUQING_CANDIDATE_B")
        self.identity_label.configure(text=("Martial Authority Preview｜READ-ONLY｜NO ASSIGNMENT | "
                                          f"Character: {shell.display_name}｜Character ID: {shell.character_id}｜Authority: {shell.authority_domain} | "
                                          f"Formal Martial: NOT ASSIGNED｜Generated Martial Binding: NONE｜Known Weapon: {shell.known_weapon_family} | "
                                          "Father Legacy Sword Art: EXISTS / IDENTITY UNKNOWN｜Black Fog Relationship: UNKNOWN | "
                                          f"Runtime Formal Result: {resolution.status.value} / NO AUTO FALLBACK｜Human Approval Required: YES"))
        self._render()

    def _preview_wang_action_set_authority(self):
        """Expose unassigned action-set authority without rendering a fake formal button."""
        fixture = WANG_MUQING_RUNTIME_NPC_FIXTURE
        shell = get_character_action_set_authority(fixture.character_id)
        resolution = resolve_formal_character_action_set(fixture.character_id)
        self.identity_request = WANG_MUQING_DEV_FIXTURE; self.wang_formal_authority_profile_id = WANG_MUQING_GAME_VISUAL_PROFILE_V1.profile_id
        state = self.session.select_runtime_character_binding(fixture.runtime_subject_id, fixture.character_id)
        self.profile_label.configure(text=state["body_profile_id"]); self.appearance_label.configure(text="SWORD: WANG_MUQING_CANDIDATE_B")
        self.identity_label.configure(text=("Action-Set Authority Preview｜READ-ONLY｜NO FORMAL ACTION CREATION\n"
                                          f"Character: {shell.display_name}｜Character ID: {shell.character_id}｜Formal Martial: NOT ASSIGNED｜Formal Action Set: {shell.assignment_status.value}\n"
                                          "Formal Action IDs: NONE｜Source: NONE｜Sandbox Override: AVAILABLE IN DEV ONLY｜Generated Action Fallback: DISABLED\n"
                                          f"Formal Runtime Result: {resolution.reason}｜No generic SWORD, generated martial, visual, or motion inference."))
        self._render()

    def _select_wang_muqing_candidate(self, candidate_id):
        """Candidate overlay keeps the immutable identity shell and formal unknowns visible."""
        candidate = WANG_MUQING_CANDIDATES_BY_ID[candidate_id]
        self.identity_request = WANG_MUQING_DEV_FIXTURE; self.wang_formal_authority_profile_id = None
        self.session.select_named_character_candidate(candidate_id)
        self.profile_label.configure(text=self.session.body_profile_id)
        self.appearance_label.configure(text=candidate.appearance_profile.profile_id)
        review_status = "UNSELECTED REVIEW CANDIDATE" if candidate_id[-1] in ("A", "C") else "PENDING HUMAN REVIEW"
        self.identity_label.configure(text=(f"王沐青角色視覺候選｜NONCANONICAL｜{review_status}\n"
                                          f"Character Canon: YES｜Formal Appearance Canon: NO｜Candidate {candidate_id[-1]}｜{candidate.visual_direction}｜NONCANONICAL PROPOSAL\n"
                                          f"Appearance: {candidate.appearance_profile.profile_id}｜Preview Body: {candidate.body_profile_choice.value} / NONCANONICAL｜Known Weapon: SWORD / GENERIC SWORD VISUAL PREVIEW\n"
                                          "Generic Sword Motion Preview: NONCANONICAL｜Formal Faction: UNKNOWN｜Formal Martial: NOT ASSIGNED｜Black Fog Visual: NOT IMPLEMENTED"))
        self._render()

    def _select_wang_muqing_revision(self):
        """Human-selected revision preview; promotion authority remains with the Human gate."""
        package = wang_muqing_game_visual_promotion_package(); revision = WANG_MUQING_VISUAL_B_R1
        self.identity_request = WANG_MUQING_DEV_FIXTURE; self.wang_formal_authority_profile_id = None
        self.session.select_named_character_revision()
        self.profile_label.configure(text=self.session.body_profile_id)
        self.appearance_label.configure(text=revision.appearance_profile.profile_id)
        self.identity_label.configure(text=("王沐青角色視覺候選｜Candidate B — Human Selected / Revision 1\n"
                                          "NONCANONICAL｜PENDING FINAL HUMAN REVIEW｜Character Canon: YES｜Character Visual Shell: ACTIVE｜Character Game Visual Canon: NO｜Formal Appearance Canon: NO\n"
                                          f"Revision: {revision.revision_id}｜Direction: {revision.visual_direction}｜Promotion: {package.promotion_status}｜Human Final Decision: {package.human_final_decision}\n"
                                          "Known Weapon Family: SWORD｜Formal Character Martial: NOT ASSIGNED｜Formal Faction: UNKNOWN｜Formal Body Profile: UNKNOWN｜Black Fog: KNOWN PHENOMENON｜Visual Implementation: NOT AUTHORIZED\n"
                                          "Combat Motion Preview: GENERIC SWORD / NONCANONICAL｜Rumored Great Demon Mother: NOT USED FOR VISUAL INFERENCE｜Generic Sword Visual Preview: NONCANONICAL"))
        self._render()

    def _select_wang_muqing_formal(self):
        """Formal game-character preview is B:r1 exactly, without World Lore promotion."""
        profile = WANG_MUQING_GAME_VISUAL_PROFILE_V1
        self.identity_request = WANG_MUQING_DEV_FIXTURE; self.wang_formal_authority_profile_id = profile.profile_id
        self.session.select_named_character_formal_game_visual(profile.character_id)
        self.profile_label.configure(text=profile.game_visual_default_body)
        self.appearance_label.configure(text=profile.appearance_profile.profile_id)
        self.identity_label.configure(text=(f"Character: 王沐青｜Character Canon: YES｜Game Character Visual Canon: {profile.profile_id}｜FORMAL / V1\n"
                                          f"Source: {profile.source_revision_id}｜Human Promoted: YES｜Direction: {profile.visual_direction}｜Formal Default Body: {profile.game_visual_default_body}\n"
                                          "World Lore Appearance Canon: NOT ESTABLISHED｜Formal Faction: UNKNOWN｜Formal Martial: NOT ASSIGNED｜Weapon: SWORD / shared generic SWORD base\n"
                                          "Black Fog: KNOWN PHENOMENON｜Game Visual Implementation: NOT AUTHORIZED｜Character Motion: WANG_MUQING_MOTION_SHELL_V0_1:R1 / PENDING HUMAN ACCEPTANCE"))
        self.wang_motion_mode_label.configure(text="Character Motion Preview：[WANG MOTION SHELL R1]｜CHARACTER MOTION CANDIDATE / PENDING HUMAN ACCEPTANCE｜A/B generic comparison available above.", foreground="#285a72")
        self._render()

    def _select_wang_motion_comparison(self, mode):
        """Switch only the shared motion-profile projection for visible developer A/B review."""
        try:
            state = self.session.select_character_motion_comparison(mode)
        except ValueError:
            self.wang_motion_mode_label.configure(text="Character Motion Preview：請先進入 王沐青 → FORMAL / V1。", foreground="#8b1a1a")
            return
        current = state["character_motion_comparison_mode"]
        if current == "GENERIC":
            self.wang_motion_mode_label.configure(text="Character Motion Preview：[GENERIC SWORD MOTION]｜NONCANONICAL COMPARISON", foreground="#52616b")
        else:
            self.wang_motion_mode_label.configure(text="Character Motion Preview：[WANG MOTION SHELL R1]｜CHARACTER MOTION CANDIDATE / PENDING HUMAN ACCEPTANCE", foreground="#285a72")
        self._render()

    def _select_fulong_formal(self):
        self.session.select_formal_faction_game_visual("FACTION-FULONG")
        self.appearance_label.configure(text=FULONG_GAME_VISUAL_PROFILE_V1.appearance_profile.profile_id)
        self.identity_label.configure(text=("Faction：伏龍鏢局／伏龍山相關體系｜Faction Canon: YES\n"
                                          "Game Visual Canon: FULONG_GAME_VISUAL_V1｜Source: FULONG-VISUAL-A:R1｜Human Promoted: YES\n"
                                          "World Lore Uniform Canon: NOT ESTABLISHED｜FORMAL GAME VISUAL PREVIEW"))
        self._render()

    def _select_fulong_revision(self):
        package = fulong_game_visual_promotion_package(); self.session.select_faction_revision()
        self.appearance_label.configure(text=FULONG_VISUAL_A_R1.appearance_profile.profile_id)
        self.identity_label.configure(text=("Faction：伏龍鏢局／伏龍山相關體系｜Faction Canon: YES｜Formal Visual Canon: NO\n"
                                          f"Candidate A — Human Selected / Revision 1｜NONCANONICAL｜PENDING FINAL REVIEW｜Promotion: {package.promotion_status}"))
        self._render()

    def _select_fulong_candidate(self, candidate_id):
        self.session.select_faction_candidate(candidate_id); candidate = FULONG_CANDIDATES_BY_ID[candidate_id]
        self.appearance_label.configure(text=candidate.appearance_profile.profile_id)
        self.identity_label.configure(text=(f"Faction：伏龍鏢局／伏龍山相關體系｜Faction Canon: YES｜Formal Visual Canon: NO\n"
                                          f"Candidate {candidate_id[-1]}｜NONCANONICAL PROPOSAL｜PENDING HUMAN REVIEW｜Direction: {candidate.visual_direction}｜All four weapon families share this candidate."))
        self._render()

    def _historical_candidate_status(self):
        """B/C are preserved review history: Auto Selection: NONE."""
        return HISTORICAL_CANDIDATE_AUTO_SELECTION

    def _preview_identity(self, request: VisualIdentityRequest):
        """Developer-only read-only resolver preview; no world content is written or assigned to Battle."""
        self.identity_request = request; resolution = resolve_visual_identity(request)
        if resolution.appearance_profile_id:
            self._select_appearance(resolution.appearance_profile_id)
        unresolved = "、".join(resolution.unresolved_constraints) or "NONE"
        known = "；".join(f"{item['field']}={item['value']}" for item in resolution.resolved_constraints) or "NONE"
        extra = "Black Fog: KNOWN PHENOMENON / VISUAL IMPLEMENTATION NOT AUTHORIZED" if request.subject_id == "WANG_MUQING" else ""
        self.identity_label.configure(text=(f"Visual Identity：{request.subject_id}｜NONCANONICAL DEV PREVIEW｜Status: {resolution.resolution_status.value}\n"
                                          f"Fallback Appearance: {resolution.appearance_profile_id or 'NONE'}｜Known: {known}｜Formal Unknown: {unresolved}\n{extra}"))

    def _advance(self, token, step):
        if not self.session.advance(token, step): return
        try:
            if not self.root.winfo_exists(): return
            self._render()
            if step < 3: self.root.after(MOTION_STEP_DELAYS_MS[step], lambda: self._advance(token, step + 1))
            elif self.session.has_next_combo_segment():
                self.root.after(MOTION_STEP_DELAYS_MS[step] + CHAINED_SEGMENT_GAP_MS, lambda: self._next_combo_segment(token))
            else: self.root.after(MOTION_STEP_DELAYS_MS[step], lambda: self._translate(token, "RETREAT", 1))
        except self.tk.TclError: return

    def _next_combo_segment(self, token):
        if not self.session.advance_combo_segment(token): return
        try:
            if not self.root.winfo_exists(): return
            self._render(); self.root.after(CHAINED_SEGMENT_CUE_MS, lambda: self._advance(token, 1))
        except self.tk.TclError: return

    def _translate(self, token, phase, step):
        if not self.session.translate(token, phase, step): return
        try:
            if not self.root.winfo_exists(): return
            self._render(); delays = APPROACH_STEP_DELAYS_MS if phase == "APPROACH" else RETREAT_STEP_DELAYS_MS
            if step < 3: self.root.after(delays[step], lambda: self._translate(token, phase, step + 1))
            elif phase == "APPROACH":
                self.session.translate(token, "CONTACT", 3); self.root.after(delays[step], lambda: self._advance(token, 1))
            else: self.root.after(delays[step], lambda: self._clear(token))
        except self.tk.TclError: return

    def _clear(self, token):
        if not self.session.clear(token): return
        try:
            if self.root.winfo_exists(): self._render()
        except self.tk.TclError: return


def main() -> None:
    import argparse, tkinter as tk
    parser = argparse.ArgumentParser(description=SHOWCASE_MARKER); parser.add_argument("--workspace", default="."); args = parser.parse_args()
    root = tk.Tk(); TkWeaponFamilyShowcase(root, Path(args.workspace).resolve()); root.mainloop()


if __name__ == "__main__": main()

"""WO-042: a thin, standard-library battle screen over WO-040/WO-041."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum
from math import cos, hypot, radians, sin
from pathlib import Path
from typing import Any

from .combatant_body_spec import (
    STANDARD_HUMANOID, STANDARD_PROFILE, resolve_base_body_geometry,
    resolve_body_profile, transform_body_point,
)
from .combatant_appearance import draw_appearance_layers, resolve_appearance_geometry
from .character_motion_profile import (
    CHARACTER_SPECIFIC_MOTION_PROFILE_CONTRACT, character_motion_profile_snapshot,
    get_character_motion_profile,
)
from .character_art_interface import (
    CLOTHING_LAYER_STACK, WEAPON_LAYER_STACK, AssetStatus, CharacterArtLayerPackage,
    WeaponArtLayerPackage, load_character_art_layer_package, load_weapon_art_layer_package,
)
from .character_art_layer_motion import project_layer_motion_offsets
from .character_art_layer_rotation import (
    prebaked_rotation_frame_path, prebaked_weapon_motion_frame_path,
)
from .background_art_interface import (
    BackgroundArtPackage, cover_crop_box, load_background_art_package,
)
from .game_facing_martial import CharacterMartialLoadout, GameFacingMartialService
from .player_action_control import (
    AI_CONTROLLED, PLAYER_CONTROLLED, ControlledParticipant, EncounterTarget,
    ManualCombatController, PlayerActionCommand,
)
from .settled_damage_presentation import SettledTargetImpact, settled_impacts_as_presentation_events

SCREEN_CONTRACT = "MINIMAL_INTERACTIVE_BATTLE_SCREEN_V0_1"
LAYOUT_CONTRACT = "GAME_FACING_2D_BATTLE_LAYOUT_V0_1"
BODY_PRESENCE_CONTRACT = "GAME_FACING_BATTLEFIELD_BODY_PRESENCE_V0_1"
FEEDBACK_CONTRACT = "GAME_FACING_MINIMAL_COMBAT_EVENT_FEEDBACK_V0_1"
POSE_CONTRACT = "GAME_FACING_COMBATANT_POSE_VOCABULARY_V0_1"
TRANSITION_CONTRACT = "GAME_FACING_MINIMAL_POSE_TRANSITION_V0_1"
PERCEPTIBLE_MOTION_CONTRACT = "GAME_FACING_PERCEPTIBLE_MINIMAL_COMBAT_MOTION_V0_1"
ATTACK_MOTION_CONTRACT = "GAME_FACING_GENERIC_ATTACK_MOTION_VOCABULARY_V0_1"
WEAPON_SILHOUETTE_CONTRACT = "GAME_FACING_WEAPON_FAMILY_SILHOUETTE_V0_1"
FORMAL_ENEMY_ACTION_WEAPON_PRESENTATION_BINDING_CONTRACT = "FORMAL_ENEMY_ACTION_WEAPON_PRESENTATION_BINDING_V0_1"
ACTION_SCOPED_WEAPON_VISUAL_BINDING_CONTRACT = "ACTION_SCOPED_WEAPON_VISUAL_BINDING_V0_1"
SPEAR_IDLE_HOLD_CONTRACT = "GAME_FACING_SPEAR_IDLE_HOLD_POSE_POLICY_V0_1"
SPEAR_IDLE_HAND_GRIP_ALIGNMENT_CONTRACT = "SPEAR_IDLE_HAND_GRIP_ALIGNMENT_V0_1"
SPEAR_IDLE_FOREARM_GRIP_BRIDGE_CONTRACT = "SPEAR_IDLE_FOREARM_GRIP_BRIDGE_V0_1"
SPEAR_IDLE_HOLD_ANGLE_DEGREES = 32.0
SPEAR_IDLE_HOLD_BACK_LENGTH = 44.0
BATTLE_FLOW_CONTRACT = "GAME_FACING_BATTLE_TURN_FLOW_READABILITY_V0_1"
DAMAGE_IMPACT_CONTRACT = "GAME_FACING_DAMAGE_IMPACT_READABILITY_V0_1"
FORMAL_IMPACT_CONSUMPTION_CONTRACT = "FORMAL_SCREEN_SETTLED_IMPACT_CONSUMPTION_V0_1"
PRESENTATION_STATE_LATCH_CONTRACT = "PRESENTATION_STATE_LATCH_V0_1"
IMPACT_SYNCHRONIZED_DEFEATED_POSE_CONTRACT = "IMPACT_SYNCHRONIZED_DEFEATED_POSE_PRESENTATION_V0_1"
DEFEATED_COMBATANT_QUEUED_ACTION_INVALIDATION_CONTRACT = "DEFEATED_COMBATANT_QUEUED_ACTION_INVALIDATION_V0_1"
DEAD_ACTOR_PRESENTATION_SUPPRESSION_CONTRACT = "DEAD_ACTOR_PRESENTATION_SUPPRESSION_V0_1"
VITAL_HUD_CONTRACT = "GAME_FACING_PERSISTENT_COMBATANT_VITAL_HUD_V0_1"
ENEMY_INTENT_CONTRACT = "GAME_FACING_ENEMY_INTENT_TELEGRAPH_V0_1"
APPROACH_CONTACT_RETREAT_CONTRACT = "GAME_FACING_APPROACH_CONTACT_RETREAT_MOTION_V0_1"
MULTI_ENEMY_PER_ACTOR_APPROACH_RETREAT_BINDING = "MULTI_ENEMY_PER_ACTOR_APPROACH_RETREAT_BINDING_V0_1"
TRUE_COMBO_CONTACT_RETENTION_CONTRACT = "GAME_FACING_TRUE_COMBO_CONTACT_RETENTION_V0_1"
CHARACTER_MOTION_PRESENTATION_CONTRACT = CHARACTER_SPECIFIC_MOTION_PROFILE_CONTRACT
ACTION_CUE_MS = 180
REACTION_CUE_MS = 220
DERIVED_FEEDBACK_MS = 280
READY_CUE_MS = 240
TERMINAL_REVEAL_MS = 400
ENEMY_INTENT_LEAD_IN_MS = 600
BEAT_GAP_MS = 40
IMPACT_FEEDBACK_MS = 650
IMPACT_RISE_DELAY_MS = 120
IMPACT_RISE_PX = 12
MOTION_LEAD_IN_MS = 70
MOTION_HOLD_MS = 410
MOTION_STEP_DELAYS_MS = {1: 80, 2: 170, 3: 160}
APPROACH_STEP_DELAYS_MS = {1: 70, 2: 80, 3: 70}
RETREAT_STEP_DELAYS_MS = {1: 90, 2: 100, 3: 90}
CHAINED_SEGMENT_CUE_MS = 130
CHAINED_SEGMENT_GAP_MS = 90
SUPPORTED_PRESENTATION_SPEEDS = (1.0, 2.0)
DEFAULT_PRESENTATION_SPEED = 1.0
MIN_PRESENTATION_DELAY_MS = 1

def scale_presentation_delay(base_duration_ms: int, speed_multiplier: float) -> int:
    """Single presentation-time authority; base timing and all gameplay truth remain untouched."""
    if speed_multiplier not in SUPPORTED_PRESENTATION_SPEEDS:
        raise ValueError("UNSUPPORTED_PRESENTATION_SPEED")
    return max(MIN_PRESENTATION_DELAY_MS, round(base_duration_ms / speed_multiplier))
LEGENDARY_ID = "generated:blade:legendary:2b7457785666:r0"
SECONDARY_ID = "generated:sword:advanced:644fb8ab88e0:r2"

BATTLE_STATUS_TEXT = {"ONGOING": "戰鬥進行中", "PLAYER_VICTORY": "我方勝利", "PLAYER_DEFEAT": "我方敗北"}
LEGALITY_REASON_TEXT = {
    "STANCE_REQUIRED": "架勢尚未啟動", "INSUFFICIENT_RESOURCE": "資源不足",
    "ORDINARY_SPECIAL_CAP_REACHED": "本場使用次數已達上限", "TRIGGER_CONDITION_NOT_MET": "施展條件尚未達成",
    "TARGET_UNAVAILABLE": "目前沒有合法目標",
}
# WO092-H1: text policy only. Retain the hit key/cue for pose/contact projection.
OUTCOME_FEEDBACK_TEXT = {"ATTACK_RESOLVED": "", "DODGE": "閃避", "PARRY": "招架"}


class VisualPose(str, Enum):
    """Presentation-only body language; unrelated to gameplay Martial Stance."""
    IDLE = "IDLE"
    ATTACK = "ATTACK"
    HIT = "HIT"
    DODGE = "DODGE"
    PARRY = "PARRY"
    DEFEATED = "DEFEATED"


class AttackMotion(str, Enum):
    """Presentation classification only; it has no gameplay authority."""
    THRUST = "THRUST"
    SLASH = "SLASH"
    SWEEP = "SWEEP"
    STRIKE = "STRIKE"


class ApproachProfile(str, Enum):
    """Presentation-only contact distance language; never gameplay range."""
    CLOSE_MELEE = "CLOSE_MELEE"
    SHORT_STEP = "SHORT_STEP"
    LONG_REACH = "LONG_REACH"
    STATIONARY = "STATIONARY"
    GENERIC = "GENERIC"


class PresentationBeatKind(str, Enum):
    """Small settled-event display vocabulary; it has no Battle authority."""
    ACTION_START = "ACTION_START"
    ATTACK_MOTION = "ATTACK_MOTION"
    TARGET_REACTION = "TARGET_REACTION"
    IMPACT_FEEDBACK = "IMPACT_FEEDBACK"
    DERIVED_FEEDBACK = "DERIVED_FEEDBACK"
    CONTROL_READY = "CONTROL_READY"
    ENCOUNTER_CLOSURE = "ENCOUNTER_CLOSURE"
    ENEMY_INTENT = "ENEMY_INTENT"


@dataclass(frozen=True)
class CombatPresentationBeat:
    beat_id: str
    kind: PresentationBeatKind
    actor_id: str | None
    action_id: str | None
    action_name: str | None
    feedback: dict[str, Any]
    duration_ms: int
    source_sequences: tuple[int, ...]
    presentation_only: bool = True


@dataclass(frozen=True)
class FormalAttackSegment:
    """Read-only presentation view of one formally identified Battle attack instance."""
    attack_instance_id: str
    owning_action_id: str
    root_action_id: str
    stage_id: str
    actor_id: str
    target_ids: tuple[str, ...]
    action_name: str
    attack_motion: str
    weapon_family: str


@dataclass(frozen=True)
class ContactChainPresentation:
    chain_id: str
    formal_chain_source: str
    segments: tuple[FormalAttackSegment, ...]
    true_chain: bool
    presentation_only: bool = True


def project_formal_contact_chains(records: tuple[dict[str, Any], ...]) -> tuple[ContactChainPresentation, ...]:
    """Group only explicit root/stage/attack-instance truth; adjacency and names carry no authority."""
    ordered = []
    for record in records:
        required = ("attack_instance_id", "owning_action_id", "root_action_id", "stage_id", "actor_id", "target_id")
        if any(record.get(key) in (None, "") for key in required): continue
        key = (str(record["root_action_id"]), str(record["actor_id"]), str(record["attack_instance_id"]))
        existing = next((item for item in ordered if item[0] == key), None)
        if existing:
            if str(record["target_id"]) not in existing[1]: existing[1].append(str(record["target_id"]))
        else:
            ordered.append((key, [str(record["target_id"])], record))
    groups = []
    for root_id in dict.fromkeys(item[0][0] for item in ordered):
        root_items = [item for item in ordered if item[0][0] == root_id]
        for actor_id in dict.fromkeys(item[0][1] for item in root_items):
            actor_items = [item for item in root_items if item[0][1] == actor_id]
            segments = tuple(FormalAttackSegment(
                item[0][2], str(item[2]["owning_action_id"]), root_id, str(item[2]["stage_id"]), actor_id,
                tuple(item[1]), str(item[2].get("action_name") or item[2]["stage_id"]),
                str(item[2].get("attack_motion") or project_attack_motion(item[2].get("weapon_family")).value),
                str(item[2].get("weapon_family") or "GENERIC"),
            ) for item in actor_items)
            groups.append(ContactChainPresentation(
                f"contact-chain:{root_id}:{actor_id}",
                "BattleEngine ATTACK_INSTANCE fields: root_action_id + owning_action_id + stage_id + attack_instance_id",
                segments, len(segments) > 1,
            ))
    return tuple(groups)


def contact_chain_compatibility(previous: FormalAttackSegment, current: FormalAttackSegment,
                                target_anchor_distance: float = 0.0) -> str:
    """Presentation policy only; its threshold never affects targeting or legality."""
    if previous.actor_id != current.actor_id: return "FALLBACK_RETREAT_APPROACH"
    if previous.target_ids == current.target_ids: return "RETAIN_CONTACT"
    if set(previous.target_ids) == set(current.target_ids): return "RETAIN_COMPATIBLE_GROUP"
    return "CONTACT_REPOSITION" if target_anchor_distance <= .18 else "FALLBACK_RETREAT_APPROACH"


class DamageImpactKind(str, Enum):
    HP_DAMAGE = "HP_DAMAGE"
    SHIELD_ABSORB = "SHIELD_ABSORB"
    ZERO_DAMAGE = "ZERO_DAMAGE"
    DODGE = "DODGE"
    PARRY = "PARRY"
    DEFEATED = "DEFEATED"


@dataclass(frozen=True)
class DamageImpactCue:
    target_id: str
    kind: DamageImpactKind
    text: str
    amount: int | float | None
    source_sequence: int
    stable_target_mapping: bool = True
    presentation_only: bool = True


class WeaponSilhouette(str, Enum):
    """Presentation family hint, not a weapon item or equipment instance."""
    BLADE = "BLADE"
    SWORD = "SWORD"
    SPEAR = "SPEAR"
    FIST = "FIST"
    GENERIC = "GENERIC"


@dataclass(frozen=True)
class ActionWeaponPresentationContext:
    """Read-only action visual binding; it is never an equipment or inventory record."""
    actor_runtime_id: str
    presentation_actor_id: str
    action_id: str
    attack_instance_id: str | None
    weapon_visual_family: str
    binding_authority: str
    binding_scope: str
    source: str
    permanent_equipment_authority: bool = False


def project_weapon_silhouette(family: str | None) -> WeaponSilhouette:
    """Project existing family metadata without parsing martial display names."""
    normalized = (family or "").strip().upper()
    mapping = {"BLADE": WeaponSilhouette.BLADE, "刀法": WeaponSilhouette.BLADE,
               "SWORD": WeaponSilhouette.SWORD, "劍法": WeaponSilhouette.SWORD,
               "SPEAR": WeaponSilhouette.SPEAR, "槍法": WeaponSilhouette.SPEAR,
               "FIST": WeaponSilhouette.FIST, "拳法": WeaponSilhouette.FIST}
    return mapping.get(normalized, WeaponSilhouette.GENERIC)


def project_action_weapon_presentation_context(start_event: dict[str, Any],
                                                action_events: tuple[dict[str, Any], ...],
                                                presentation_actor_id: str) -> dict[str, Any] | None:
    """Forward explicit formal action metadata only; unknown families intentionally render no weapon."""
    metadata = start_event.get("details", {}).get("action_presentation_metadata") or {}
    family = metadata.get("weapon_visual_family")
    if project_weapon_silhouette(family) == WeaponSilhouette.GENERIC:
        return None
    attack_instance_id = next((event.get("attack_instance_id") for event in action_events
                               if event.get("attack_instance_id")), None)
    return asdict(ActionWeaponPresentationContext(
        str(start_event["actor_id"]), presentation_actor_id, str(start_event["action_id"]),
        None if attack_instance_id is None else str(attack_instance_id), str(family),
        str(metadata.get("binding_authority") or "FORMAL_ACTION_METADATA"),
        str(metadata.get("binding_scope") or "ACTION_PRESENTATION_ONLY"),
        str(metadata.get("source") or "GAMEFACING_FORMAL_ACTION_METADATA"),
        bool(metadata.get("permanent_equipment_authority", False)),
    ))


def weapon_silhouette_spec(silhouette: WeaponSilhouette | str) -> dict[str, Any]:
    """Small Canvas signature catalog; no inventory, item, or art authority."""
    silhouette = WeaponSilhouette(silhouette)
    specs = {
        WeaponSilhouette.BLADE: {"weapon_present": True, "length_scale": 1.0, "blade_width": 8, "tip": "ASYMMETRIC", "guard_width": 8, "grip_count": 1, "primitive": "BROAD_BLADE"},
        WeaponSilhouette.SWORD: {"weapon_present": True, "length_scale": 1.08, "blade_width": 3, "tip": "SYMMETRIC_POINT", "guard_width": 14, "grip_count": 1, "primitive": "STRAIGHT_SWORD"},
        WeaponSilhouette.SPEAR: {"weapon_present": True, "length_scale": 1.7, "blade_width": 2, "tip": "SPEARHEAD", "guard_width": 0, "grip_count": 2, "primitive": "LONG_SHAFT"},
        WeaponSilhouette.FIST: {"weapon_present": False, "length_scale": 0.0, "blade_width": 0, "tip": "NONE", "guard_width": 0, "grip_count": 0, "primitive": "RAISED_FISTS"},
        WeaponSilhouette.GENERIC: {"weapon_present": False, "length_scale": 0.0, "blade_width": 0, "tip": "NONE", "guard_width": 0, "grip_count": 0, "primitive": "NEUTRAL_HANDS"},
    }
    return {"silhouette": silhouette.value, **specs[silhouette], "presentation_only": True, "equipment_authority": False}


def project_spear_idle_hold(primary_hand: tuple[float, float], endpoint: tuple[float, float], other_hand: tuple[float, float]) -> dict[str, Any]:
    """A stable standing hold: primary grip anchors a deliberate forward-upward shaft."""
    hx, hy = primary_hand; ex, ey = endpoint; direction = 1.0 if ex >= hx else -1.0
    hold_radians = radians(SPEAR_IDLE_HOLD_ANGLE_DEGREES)
    axis = (direction * cos(hold_radians), -sin(hold_radians))
    forward_length = hypot(ex - hx, ey - hy) * weapon_silhouette_spec(WeaponSilhouette.SPEAR)["length_scale"]
    shaft_start = (hx - axis[0] * SPEAR_IDLE_HOLD_BACK_LENGTH, hy - axis[1] * SPEAR_IDLE_HOLD_BACK_LENGTH)
    tip = (hx + axis[0] * forward_length, hy + axis[1] * forward_length)
    return {"contract": SPEAR_IDLE_HOLD_CONTRACT, "primary_hold_anchor": primary_hand, "support_hand": other_hand,
            "shaft_start": shaft_start, "tip": tip, "axis": axis, "forward_angle_degrees": -SPEAR_IDLE_HOLD_ANGLE_DEGREES,
            "support_policy": "VISUAL_SUPPORT_ONLY_NOT_SHAFT_AXIS", "independent_position_state": False}


def resolve_spear_idle_grip_geometry(hold: dict[str, Any]) -> dict[str, Any]:
    """Derive visible idle grips from the stable shaft; never re-solve its axis."""
    sx, sy = hold["shaft_start"]; tx, ty = hold["tip"]; ox, oy = hold["support_hand"]
    axis_x, axis_y = tx - sx, ty - sy; axis_length_sq = axis_x * axis_x + axis_y * axis_y or 1.0
    factor = max(0.0, min(1.0, ((ox - sx) * axis_x + (oy - sy) * axis_y) / axis_length_sq))
    support_anchor = (sx + axis_x * factor, sy + axis_y * factor)
    support_offset = (support_anchor[0] - ox, support_anchor[1] - oy)
    return {"contract": SPEAR_IDLE_HAND_GRIP_ALIGNMENT_CONTRACT,
            "primary_grip_anchor": hold["primary_hold_anchor"], "primary_grip_radius": 6,
            "off_hand_socket": hold["support_hand"], "off_hand_support_anchor": support_anchor,
            "off_hand_support_offset": support_offset, "off_hand_support_radius": 5,
            "shaft_angle_preserved": True, "presentation_only": True, "independent_position_state": False}


def resolve_spear_idle_forearm_grip_bridge(grips: dict[str, Any], primary_elbow: tuple[float, float], off_hand_elbow: tuple[float, float]) -> dict[str, Any]:
    """Short, body-derived visual bridges; no socket or shaft mutation."""
    primary = grips["primary_grip_anchor"]; support = grips["off_hand_support_anchor"]; off_hand = grips["off_hand_socket"]
    ex, ey = primary_elbow; px, py = primary; length = hypot(px - ex, py - ey) or 1.0
    # Retain only the terminal forearm segment so the bridge cannot become a rubber arm.
    primary_start = (px - (px - ex) / length * min(11.0, length * .24), py - (py - ey) / length * min(11.0, length * .24))
    support_length = hypot(support[0] - off_hand[0], support[1] - off_hand[1])
    return {"contract": SPEAR_IDLE_FOREARM_GRIP_BRIDGE_CONTRACT,
            "primary_bridge": {"start": primary_start, "end": primary, "width": 5},
            "support_bridge": {"start": off_hand, "end": support, "width": 5},
            "primary_elbow": primary_elbow, "off_hand_elbow": off_hand_elbow,
            "support_bridge_length": support_length, "maximum_short_bridge_length": 21.0,
            "shaft_angle_preserved": True, "shaft_translation": (0.0, 0.0),
            "presentation_only": True, "independent_position_state": False}


def weapon_canvas_geometry(silhouette: WeaponSilhouette | str, hand: tuple[float, float], endpoint: tuple[float, float], other_hand: tuple[float, float], presentation_pose: str | None = None, forearm_anchors: tuple[tuple[float, float], tuple[float, float]] | None = None) -> dict[str, Any]:
    """Derive weapon primitives from current hand anchors; no independent position state."""
    silhouette = WeaponSilhouette(silhouette); spec = weapon_silhouette_spec(silhouette)
    hx, hy = hand; ex, ey = endpoint; vx, vy = ex - hx, ey - hy; length = hypot(vx, vy) or 1.0; ux, uy = vx / length, vy / length; px, py = -uy, ux
    tip = (hx + vx * spec["length_scale"], hy + vy * spec["length_scale"]); width = spec["blade_width"]
    idle_hold = project_spear_idle_hold(hand, endpoint, other_hand) if silhouette == WeaponSilhouette.SPEAR and presentation_pose == VisualPose.IDLE.value else None
    if idle_hold is not None: tip = idle_hold["tip"]
    idle_grips = resolve_spear_idle_grip_geometry(idle_hold) if idle_hold is not None else None
    idle_bridges = resolve_spear_idle_forearm_grip_bridge(idle_grips, *forearm_anchors) if idle_grips is not None and forearm_anchors is not None else None
    primitives = []
    if silhouette == WeaponSilhouette.BLADE:
        neck = (hx + ux * 7, hy + uy * 7); primitives.append({"kind": "polygon", "points": (neck, (tip[0] + px * width, tip[1] + py * width), tip, (neck[0] - px * 2, neck[1] - py * 2)), "width": width})
        primitives.append({"kind": "guard", "center": hand, "perpendicular": (px, py), "width": spec["guard_width"]})
    elif silhouette == WeaponSilhouette.SWORD:
        neck = (hx + ux * 5, hy + uy * 5); primitives.append({"kind": "polygon", "points": ((neck[0] + px * 2, neck[1] + py * 2), (tip[0] - ux * 5 + px * 2, tip[1] - uy * 5 + py * 2), tip, (tip[0] - ux * 5 - px * 2, tip[1] - uy * 5 - py * 2), (neck[0] - px * 2, neck[1] - py * 2)), "width": width})
        primitives.append({"kind": "guard", "center": hand, "perpendicular": (px, py), "width": spec["guard_width"]})
    elif silhouette == WeaponSilhouette.SPEAR:
        primitives.append({"kind": "shaft", "start": idle_hold["shaft_start"] if idle_hold else other_hand, "end": tip, "width": 3})
        primitives.append({"kind": "tip", "points": (tip, (tip[0] - ux * 12 + px * 6, tip[1] - uy * 12 + py * 6), (tip[0] - ux * 12 - px * 6, tip[1] - uy * 12 - py * 6))})
        if idle_grips is not None:
            primitives.extend(({"kind": "grip", "center": idle_grips["primary_grip_anchor"], "radius": idle_grips["primary_grip_radius"], "role": "PRIMARY"},
                               {"kind": "grip", "center": idle_grips["off_hand_support_anchor"], "radius": idle_grips["off_hand_support_radius"], "role": "SUPPORT"}))
        if idle_bridges is not None:
            primitives.extend(({"kind": "forearm_bridge", **idle_bridges["primary_bridge"], "role": "PRIMARY"},
                               {"kind": "forearm_bridge", **idle_bridges["support_bridge"], "role": "SUPPORT"}))
    else:
        primitives.extend(({"kind": "fist", "center": hand, "radius": 5}, {"kind": "fist", "center": other_hand, "radius": 5}))
    return {"contract": WEAPON_SILHOUETTE_CONTRACT, "silhouette": silhouette.value, "spec": spec, "primitives": tuple(primitives),
            "hand_anchor": hand, "other_hand_anchor": other_hand,
            "two_hand_compatible": silhouette == WeaponSilhouette.SPEAR and spec["grip_count"] == 2,
            "presentation_pose": presentation_pose, "idle_hold_policy": idle_hold, "idle_grip_policy": idle_grips, "idle_forearm_bridge": idle_bridges,
            "idle_hold_contract": SPEAR_IDLE_HOLD_CONTRACT if idle_hold else None,
            "independent_position_state": False}


def project_attack_motion(family: str | None, presentation_category: str | None = None) -> AttackMotion:
    """Deterministic metadata projection; display names are never parsed."""
    if presentation_category in AttackMotion._value2member_map_:
        return AttackMotion(presentation_category)
    normalized = (family or "").strip().upper()
    defaults = {"SPEAR": AttackMotion.THRUST, "槍法": AttackMotion.THRUST,
                "BLADE": AttackMotion.SLASH, "刀法": AttackMotion.SLASH,
                "FIST": AttackMotion.STRIKE, "拳法": AttackMotion.STRIKE,
                "SWORD": AttackMotion.THRUST, "劍法": AttackMotion.THRUST}
    return defaults.get(normalized, AttackMotion.THRUST)


def project_approach_profile(family: str | None, presentation_category: str | None = None) -> ApproachProfile:
    """Use formal family/presentation metadata only; action display names are never parsed."""
    if presentation_category in ApproachProfile._value2member_map_:
        return ApproachProfile(presentation_category)
    normalized = (family or "").strip().upper()
    defaults = {"BLADE": ApproachProfile.CLOSE_MELEE, "刀法": ApproachProfile.CLOSE_MELEE,
                "SWORD": ApproachProfile.CLOSE_MELEE, "劍法": ApproachProfile.CLOSE_MELEE,
                "FIST": ApproachProfile.SHORT_STEP, "拳法": ApproachProfile.SHORT_STEP,
                "SPEAR": ApproachProfile.LONG_REACH, "槍法": ApproachProfile.LONG_REACH}
    return defaults.get(normalized, ApproachProfile.GENERIC)


def project_contact_translation(presence: dict[str, Any], feedback: dict[str, Any], phase: str, step: int) -> dict[str, Any]:
    """Derive temporary contact offsets from immutable visual slots and formal target IDs."""
    bodies = {body["character_id"]: body for body in presence["bodies"]}
    attacker = feedback.get("attacker") or {}; actor_id = attacker.get("actor_id")
    actor = bodies.get(actor_id); target_ids = tuple(attacker.get("contact_target_ids", ()))
    targets = tuple(bodies[target_id] for target_id in target_ids if target_id in bodies)
    target_anchor = attacker.get("contact_target_anchor")
    if not targets and isinstance(target_anchor, (tuple, list)) and len(target_anchor) == 2:
        targets = ({"x_ratio": float(target_anchor[0]), "y_ratio": float(target_anchor[1])},)
    offsets = {body_id: (0.0, 0.0) for body_id in bodies}
    profile = project_approach_profile(actor.get("approach_family", actor.get("martial_family")) if actor else None,
                                       attacker.get("approach_profile_override"))
    contact = (0.0, 0.0); representative = None; motion_shell = {}; is_shared_sword_shell = False
    if actor and targets and profile not in (ApproachProfile.STATIONARY, ApproachProfile.GENERIC):
        representative = targets[0] if len(targets) == 1 else {
            "x_ratio": sum(x["x_ratio"] for x in targets) / len(targets),
            "y_ratio": sum(x["y_ratio"] for x in targets) / len(targets),
        }
        direction = 1 if representative["x_ratio"] >= actor["x_ratio"] else -1
        gap = {ApproachProfile.CLOSE_MELEE: .17, ApproachProfile.SHORT_STEP: .20,
               ApproachProfile.LONG_REACH: .31}[profile]
        if attacker.get("contact_gap_override") is not None:
            gap = float(attacker["contact_gap_override"])
        contact_x = representative["x_ratio"] - direction * gap
        if direction > 0: contact_x = max(actor["x_ratio"], contact_x)
        else: contact_x = min(actor["x_ratio"], contact_x)
        contact = (contact_x - actor["x_ratio"], representative["y_ratio"] - actor["y_ratio"])
        motion_shell = actor.get("character_motion_profile") or {}
        is_shared_sword_shell = (motion_shell.get("weapon_family") == "SWORD" and
                                 str(actor.get("weapon_hint", "")).lower() == "sword")
        approach_progress = (motion_shell.get("approach_profile") or (None, (0.28, 0.72, 1.0)))[1]
        retreat_progress = (motion_shell.get("retreat_profile") or (None, (0.72, 0.30, 0.0)))[1]
        progress = {"STABLE": 0.0,
                    "APPROACH": (approach_progress if is_shared_sword_shell else (0.28, 0.72, 1.0))[max(1, min(3, step)) - 1],
                    "CONTACT": 1.0,
                    "RETREAT": (retreat_progress if is_shared_sword_shell else (0.72, 0.30, 0.0))[max(1, min(3, step)) - 1]}.get(phase, 0.0)
        amplified = str(motion_shell.get("profile_id", "")).endswith(":R1")
        lift = -(0.035 if amplified and phase == "RETREAT" and step == 2 else
                 .012 if amplified and phase == "RETREAT" and step == 1 else
                 .025 if phase == "RETREAT" and step == 2 else 0.0)
        offsets[actor_id] = (contact[0] * progress, contact[1] * progress + lift)
    weapon_context = attacker.get("action_weapon_presentation") or {}
    stable_anchor = None if actor is None else (actor["x_ratio"], actor["y_ratio"])
    contact_anchor = None if representative is None else (
        stable_anchor[0] + contact[0], stable_anchor[1] + contact[1])
    return {"contract": APPROACH_CONTACT_RETREAT_CONTRACT,
            "per_actor_binding_contract": MULTI_ENEMY_PER_ACTOR_APPROACH_RETREAT_BINDING,
            "phase": phase, "step": step,
            "profile": profile.value, "actor_id": actor_id, "target_ids": target_ids,
            "representative_target": None if representative is None else tuple(target_ids),
            "contact_offset_ratio": contact, "offset_ratios": offsets,
            "actor_runtime_id": weapon_context.get("actor_runtime_id", actor_id),
            "stable_slot": None if actor is None else actor.get("visual_slot"),
            "target_runtime_id": target_ids[0] if len(target_ids) == 1 else target_ids,
            "action_family": weapon_context.get("weapon_visual_family") or (actor.get("approach_family") if actor else None),
            "presentation_range_behavior": profile.value,
            "approach_required": bool(actor and targets and profile not in (ApproachProfile.STATIONARY, ApproachProfile.GENERIC)),
            "stable_anchor": stable_anchor, "contact_anchor": contact_anchor,
            "retreat_anchor": stable_anchor,
            "action_instance_id": weapon_context.get("attack_instance_id"),
            "stable_anchor_mutated": False, "presentation_only": True, "cumulative_drift": 0,
            "character_motion_profile_id": motion_shell.get("profile_id") if is_shared_sword_shell else None}


def attack_motion_offset(motion: AttackMotion | str, facing: str, step: int, weapon_hint: str = "generic") -> tuple[int, int]:
    """Distinct stable-anchor displacement signature for each archetype."""
    motion = AttackMotion(motion); direction = 1 if facing == "right" else -1
    profiles = {AttackMotion.THRUST: ((0, 0), (-6, 3), (18, 0), (7, 1)),
                AttackMotion.SLASH: ((0, 0), (-5, 2), (14, 2), (6, 1)),
                AttackMotion.SWEEP: ((0, 0), (-7, 3), (12, 1), (5, 1)),
                AttackMotion.STRIKE: ((0, 0), (-4, 4), (15, -1), (5, 1))}
    family_profiles = {
        # A spear thrust needs a visible load, an explosive drive, and a committed recovery.
        (AttackMotion.THRUST, "spear"): ((0, 0), (-12, 5), (34, -2), (12, 2)),
        # An unarmed strike carries the fighter's centre of mass through the blow.
        (AttackMotion.STRIKE, "fist"): ((0, 0), (-9, 5), (27, -2), (9, 2)),
    }
    profiles_for_motion = family_profiles.get((motion, str(weapon_hint).strip().lower()), profiles[motion])
    x, y = profiles_for_motion[step if step in (0, 1, 2, 3) else 0]
    return x * direction, y


@dataclass(frozen=True)
class VisualPoseTransition:
    """One presentation-only pose swap; never a gameplay or keyframe timeline."""
    combatant_id: str
    start_pose: str
    event_pose: str
    return_pose: str
    generation_token: int
    lead_in_ms: int = MOTION_LEAD_IN_MS
    hold_ms: int = MOTION_HOLD_MS


def build_pose_transitions(presence: dict[str, Any], feedback: dict[str, Any], generation_token: int) -> tuple[VisualPoseTransition, ...]:
    """Describe simultaneous deterministic transitions from settled feedback."""
    projected = project_visual_poses(presence, feedback); transitions = []
    for body in projected["bodies"]:
        persistent = VisualPose.IDLE.value if body["alive"] else VisualPose.DEFEATED.value
        if body["visual_pose"] != persistent or persistent == VisualPose.DEFEATED.value:
            transitions.append(VisualPoseTransition(body["character_id"], persistent, body["visual_pose"], persistent, generation_token))
    return tuple(transitions)


def transient_motion_offset(event_pose: VisualPose | str, facing: str, step: int) -> tuple[int, int]:
    """Fixed four-step readability profiles, always relative to a stable anchor."""
    pose = VisualPose(event_pose); direction = 1 if facing == "right" else -1
    profiles = {
        VisualPose.IDLE: ((0, 0), (0, 0), (0, 0), (0, 0)),
        VisualPose.ATTACK: ((0, 0), (-6 * direction, 3), (18 * direction, 0), (7 * direction, 1)),
        VisualPose.HIT: ((0, 0), (-4 * direction, 0), (-12 * direction, 2), (-5 * direction, 1)),
        VisualPose.DODGE: ((0, 0), (-5 * direction, -3), (-18 * direction, -9), (-7 * direction, -4)),
        VisualPose.PARRY: ((0, 0), (2 * direction, 1), (6 * direction, 0), (3 * direction, 0)),
        VisualPose.DEFEATED: ((0, 0), (0, 0), (0, 0), (0, 0)),
    }
    return profiles[pose][step if step in (0, 1, 2, 3) else 0]


def project_character_motion_offset(dx: int, dy: int, motion_profile: dict[str, Any] | None,
                                    pose: VisualPose, facing: str, step: int) -> tuple[int, int]:
    """Apply a normalized visual-only shell without touching generic motion data."""
    if not motion_profile or motion_profile.get("weapon_family") != "SWORD" or pose != VisualPose.ATTACK:
        return dx, dy
    normalized_step = step if step in (1, 2, 3) else 0
    amplified = str(motion_profile.get("profile_id", "")).endswith(":R1")
    if normalized_step == 1:
        anticipation = float(motion_profile["anticipation_profile"][1])
        return round(dx * anticipation), round(dy * (1.15 if amplified else .78))
    if normalized_step == 2:
        direction = 1 if facing == "right" else -1
        hand_bias = float(motion_profile["attack_body_bias"][3])
        return dx + direction * (round(hand_bias * 16) if amplified else 3), dy - (2 if amplified else 1)
    if normalized_step == 3:
        return round(dx * float(motion_profile["recovery_profile"][1])), round(dy * .82)
    return dx, dy


def apply_character_motion_pose_geometry(geometry: dict[str, Any], motion_profile: dict[str, Any] | None,
                                          pose: VisualPose | str, step: int = 0) -> dict[str, Any]:
    """Bias only Wang's shared SWORD body language; reactions remain generic."""
    pose = VisualPose(pose)
    if (not motion_profile or motion_profile.get("weapon_family") != "SWORD" or
            str(geometry.get("weapon_hint", "")).lower() != "sword" or pose not in (VisualPose.IDLE, VisualPose.ATTACK)):
        return geometry
    points = dict(geometry["points"]); direction = 1 if geometry["facing"] == "right" else -1
    scale = float(geometry.get("body_scale", 11.0))
    amplified = str(motion_profile.get("profile_id", "")).endswith(":R1")
    idle_head, idle_shoulder, idle_lift = motion_profile["idle_posture_bias"]
    if amplified and pose == VisualPose.ATTACK:
        # A small rear torso axis makes whole-body drive visible without a new skeleton.
        points["shoulder_back"] = (points["shoulder"][0] - direction * scale * .34, points["shoulder"][1] - scale * .10)
        points["hip_back"] = (points["hip"][0] - direction * scale * .22, points["hip"][1] - scale * .03)

    def shift(name: str, forward: float = 0.0, vertical: float = 0.0) -> None:
        if name in points:
            x, y = points[name]; points[name] = (x + direction * forward * scale, y + vertical * scale)

    if pose == VisualPose.IDLE:
        # A light ready posture: the torso is open and the sword hand rests a little higher.
        shift("head", idle_head, idle_lift)
        shift("shoulder", idle_shoulder, idle_lift * .45)
        shift("shoulder_back", idle_shoulder * .65, idle_lift * .25)
        shift("hand_front", idle_shoulder * 1.35, idle_lift * 1.6)
        shift("weapon_end", idle_shoulder * 1.15, idle_lift * .8)
        if amplified:
            # R1 makes the readiness legible through shoulder, hand, pelvis and weight—not head alone.
            shift("hip", idle_shoulder * .64, idle_lift * .18)
            shift("hip_back", idle_shoulder * .36, idle_lift * .10)
            shift("foot_front", idle_shoulder * .38, 0.0)
            shift("foot_back", -idle_shoulder * .18, 0.0)
    else:
        _, shoulder_bias, hip_bias, hand_bias = motion_profile["attack_body_bias"]
        normalized_step = step if step in (1, 2, 3) else 0
        if normalized_step == 1:
            # Reduce the generic pull-back so anticipation reads short and light.
            shift("shoulder", shoulder_bias * .45)
            shift("hip", hip_bias * .25)
            shift("hand_front", hand_bias * .58)
            shift("weapon_end", hand_bias * .45)
            if amplified:
                shift("shoulder_back", -shoulder_bias * .28, .05)
                shift("hip", hip_bias * .45, .07)
                shift("foot_front", hand_bias * .30, .02)
                shift("foot_back", -hip_bias * .20, 0.0)
        elif normalized_step == 2:
            # Shared THRUST remains the base; this is only a brisk body lead into it.
            shift("head", shoulder_bias * .34, -0.04)
            shift("shoulder", shoulder_bias)
            shift("shoulder_back", -shoulder_bias * (.25 if amplified else -.72))
            shift("hip", hip_bias)
            shift("hip_back", hip_bias * (.50 if amplified else .72))
            shift("hand_front", hand_bias)
            shift("weapon_end", hand_bias)
            if amplified:
                shift("foot_front", hand_bias * .34)
                shift("foot_back", -hip_bias * .26)
        elif normalized_step == 3:
            shift("shoulder", shoulder_bias * .38)
            shift("hip", hip_bias * .32)
            shift("hand_front", hand_bias * .30)
            shift("weapon_end", hand_bias * .24)
    points["neck"] = ((points["head"][0] + points["shoulder"][0]) / 2,
                      (points["head"][1] + points["shoulder"][1]) / 2)
    points["elbow_front"] = ((points["shoulder"][0] + points["hand_front"][0]) / 2,
                             (points["shoulder"][1] + points["hand_front"][1]) / 2)
    points["elbow_back"] = ((points.get("shoulder_back", points["shoulder"])[0] + points["hand_back"][0]) / 2,
                            (points.get("shoulder_back", points["shoulder"])[1] + points["hand_back"][1]) / 2)
    points["knee_front"] = ((points["hip"][0] + points["foot_front"][0]) / 2,
                            (points["hip"][1] + points["foot_front"][1]) / 2)
    points["knee_back"] = ((points.get("hip_back", points["hip"])[0] + points["foot_back"][0]) / 2,
                           (points.get("hip_back", points["hip"])[1] + points["foot_back"][1]) / 2)
    points.update(body_origin=points["hip"], primary_hand_socket=points["hand_front"], off_hand_socket=points["hand_back"])
    return {**geometry, "points": points, "character_motion_profile_id": motion_profile["profile_id"],
            "character_motion_presentation_only": True}


def project_motion_offsets(presence: dict[str, Any], feedback: dict[str, Any], step: int) -> dict[str, Any]:
    """render_position = stable_visual_anchor + transient_motion_offset."""
    event_poses = project_visual_poses(presence, feedback); offsets = []
    combat = project_contact_translation(presence, feedback, feedback.get("combat_phase", "STABLE"), feedback.get("combat_step", 0))
    for body in event_poses["bodies"]:
        pose = VisualPose.DEFEATED if not body["alive"] else VisualPose(body["visual_pose"])
        attacker = feedback.get("attacker") or {}
        category = attacker.get("attack_motion_override") if attacker.get("actor_id") == body["character_id"] else None
        attack_motion = project_attack_motion(body.get("martial_family"), category) if pose == VisualPose.ATTACK else None
        dx, dy = attack_motion_offset(attack_motion, body["facing"], step, body.get("weapon_hint", "generic")) if attack_motion else transient_motion_offset(pose, body["facing"], step)
        dx, dy = project_character_motion_offset(dx, dy, body.get("character_motion_profile"), pose, body["facing"], step)
        ratio_dx, ratio_dy = combat["offset_ratios"][body["character_id"]]
        offsets.append({"combatant_id": body["character_id"], "event_pose": pose.value, "step": step, "dx": dx, "dy": dy,
                        "combat_dx_ratio": ratio_dx, "combat_dy_ratio": ratio_dy,
                        "visual_slot": body["visual_slot"], "anchor_mutated": False,
                        "attack_motion": attack_motion.value if attack_motion else None,
                        "character_motion_profile_id": (body.get("character_motion_profile") or {}).get("profile_id")})
    return {"contract": PERCEPTIBLE_MOTION_CONTRACT, "contact_contract": combat, "offsets": tuple(offsets), "presentation_only": True,
            "cumulative_drift": 0, "stable_anchor_formula": "anchor + transient offset"}


def pose_geometry(pose: VisualPose | str, facing: str, weapon_hint: str = "generic", body_profile: str = "STANDARD") -> dict[str, Any]:
    """Resolve STANDARD_HUMANOID plus pose offsets; never a gameplay skeleton."""
    pose = VisualPose(pose); direction = 1 if facing == "right" else -1
    resolved = resolve_base_body_geometry(STANDARD_HUMANOID, 11.0, "right")
    base = {"head": resolved["HEAD_CENTER"], "neck": resolved["NECK_ANCHOR"],
            "shoulder": resolved["RIGHT_SHOULDER"], "shoulder_back": resolved["LEFT_SHOULDER"],
            "hip": resolved["PELVIS_CENTER"], "hip_back": resolved["LEFT_HIP"],
            "hand_front": resolved["RIGHT_HAND"], "hand_back": resolved["LEFT_HAND"],
            "foot_front": resolved["RIGHT_FOOT"], "foot_back": resolved["LEFT_FOOT"]}
    # Targets preserve the accepted v0.1 placeholder silhouettes. Their delta from the
    # immutable base is the pose layer; the body mother spec itself is never mutated.
    pose_targets = {
        VisualPose.IDLE: {"head": (3, -44), "shoulder": (0, -29), "hip": (4, 12), "hand_front": (28, -4), "hand_back": (-15, 2), "foot_front": (19, 49), "foot_back": (-14, 49), "weapon_end": (48, -31)},
        VisualPose.ATTACK: {"head": (15, -41), "shoulder": (10, -26), "hip": (2, 12), "hand_front": (48, -16), "hand_back": (18, 2), "foot_front": (31, 49), "foot_back": (-20, 48), "weapon_end": (70, -21)},
        VisualPose.HIT: {"head": (-13, -42), "shoulder": (-8, -25), "hip": (3, 13), "hand_front": (12, 5), "hand_back": (-31, -13), "foot_front": (15, 49), "foot_back": (-21, 47), "weapon_end": (34, 14)},
        VisualPose.DODGE: {"head": (-20, -39), "shoulder": (-15, -23), "hip": (1, 13), "hand_front": (14, -5), "hand_back": (-34, -2), "foot_front": (26, 49), "foot_back": (-25, 47), "weapon_end": (35, -27)},
        VisualPose.PARRY: {"head": (0, -44), "shoulder": (1, -28), "hip": (2, 12), "hand_front": (24, -22), "hand_back": (-12, 8), "foot_front": (20, 49), "foot_back": (-18, 49), "weapon_end": (-8, -58)},
        VisualPose.DEFEATED: {"head": (39, 34), "shoulder": (23, 27), "hip": (-13, 40), "hand_front": (33, 48), "hand_back": (5, 49), "foot_front": (-38, 50), "foot_back": (-28, 57), "weapon_end": (51, 52)},
    }
    target = pose_targets[pose]
    offsets = {name: (target[name][0] - base[name][0], target[name][1] - base[name][1]) for name in base if name in target}
    right_points = {name: (base[name][0] + offsets[name][0], base[name][1] + offsets[name][1]) for name in offsets}
    right_points["weapon_end"] = target["weapon_end"]
    right_points["neck"] = ((right_points["head"][0] + right_points["shoulder"][0]) / 2,
                            (right_points["head"][1] + right_points["shoulder"][1]) / 2)
    right_points["elbow_front"] = ((right_points["shoulder"][0] + right_points["hand_front"][0]) / 2,
                                    (right_points["shoulder"][1] + right_points["hand_front"][1]) / 2)
    right_points["elbow_back"] = ((right_points["shoulder"][0] + right_points["hand_back"][0]) / 2,
                                   (right_points["shoulder"][1] + right_points["hand_back"][1]) / 2)
    right_points["knee_front"] = ((right_points["hip"][0] + right_points["foot_front"][0]) / 2,
                                   (right_points["hip"][1] + right_points["foot_front"][1]) / 2)
    right_points["knee_back"] = ((right_points["hip"][0] + right_points["foot_back"][0]) / 2,
                                  (right_points["hip"][1] + right_points["foot_back"][1]) / 2)
    profile = resolve_body_profile(body_profile)
    right_points = {name: transform_body_point(name, point, profile, 60.0) for name, point in right_points.items()}
    points = {name: (x * direction, y) for name, (x, y) in right_points.items()}
    points.update(body_origin=points["hip"], ground_anchor=(0, resolved["GROUND_ANCHOR"][1]),
                  primary_hand_socket=points["hand_front"], off_hand_socket=points["hand_back"])
    return {"pose": pose.value, "facing": facing, "points": points, "pose_offsets": offsets,
            "body_spec_id": STANDARD_HUMANOID.spec_id, "body_spec_version": STANDARD_HUMANOID.version,
            "body_profile_id": profile.profile_id, "body_scale": 11.0,
            "head_scale": profile.head_scale, "limb_thickness_scale": profile.limb_thickness_scale,
            "draw_weapon": weapon_hint not in ("none", "fist", "unarmed"), "weapon_hint": weapon_hint}


def attack_motion_geometry(motion: AttackMotion | str, facing: str, step: int, weapon_hint: str = "generic",
                           body_profile: str = "STANDARD", character_motion_profile: dict[str, Any] | None = None) -> dict[str, Any]:
    """Four fixed hand/weapon signatures layered onto the ATTACK mother pose."""
    motion = AttackMotion(motion); direction = 1 if facing == "right" else -1; step = step if step in (1, 2, 3) else 0
    signatures = {
        AttackMotion.THRUST: {0: ((28, -4), (-15, 2), (48, -31)), 1: ((8, -2), (-25, 3), (25, -28)), 2: ((54, -14), (18, 3), (82, -15)), 3: ((35, -7), (0, 3), (57, -25))},
        AttackMotion.SLASH: {0: ((28, -4), (-15, 2), (48, -31)), 1: ((-10, -30), (-24, 4), (-34, -63)), 2: ((39, 18), (12, -8), (66, 45)), 3: ((25, 4), (-4, -2), (48, 22))},
        AttackMotion.SWEEP: {0: ((28, -4), (-15, 2), (48, -31)), 1: ((-29, -5), (-34, 6), (-58, -7)), 2: ((46, -1), (18, -10), (76, 0)), 3: ((30, 0), (-5, -5), (54, 5))},
        AttackMotion.STRIKE: {0: ((28, -4), (-15, 2), (28, -4)), 1: ((-8, -2), (-20, 5), (-8, -2)), 2: ((45, -10), (8, 4), (45, -10)), 3: ((27, -5), (-3, 4), (27, -5))},
    }
    front, back, weapon = signatures[motion][step]; mirror = lambda point: (point[0] * direction, point[1])
    base = pose_geometry(VisualPose.ATTACK, facing, weapon_hint, STANDARD_PROFILE.profile_id); points = dict(base["points"])
    points.update(hand_front=mirror(front), hand_back=mirror(back), weapon_end=mirror(weapon))
    normalized_hint = str(weapon_hint).strip().lower()
    if motion == AttackMotion.THRUST and normalized_hint == "spear":
        spear_body = {
            1: {"head": (-2, -39), "shoulder": (-8, -23), "hip": (2, 13), "foot_front": (16, 49), "foot_back": (-27, 48),
                "hand_front": (2, -5), "hand_back": (-29, 2), "weapon_end": (21, -23)},
            2: {"head": (27, -38), "shoulder": (24, -22), "hip": (13, 14), "foot_front": (43, 49), "foot_back": (-20, 48),
                "hand_front": (67, -12), "hand_back": (31, 0), "weapon_end": (108, -12)},
            3: {"head": (14, -41), "shoulder": (11, -25), "hip": (7, 13), "foot_front": (31, 49), "foot_back": (-22, 48),
                "hand_front": (42, -9), "hand_back": (4, 2), "weapon_end": (76, -18)},
        }
        points.update({name: mirror(point) for name, point in spear_body.get(step, {}).items()})
    elif motion == AttackMotion.STRIKE and normalized_hint == "fist":
        fist_body = {
            1: {"head": (-5, -40), "shoulder": (-10, -24), "hip": (0, 13), "foot_front": (13, 49), "foot_back": (-29, 48),
                "hand_front": (-13, -4), "hand_back": (-25, 1), "weapon_end": (-13, -4),
                "shoulder_back": (2, -29), "hip_back": (-8, 10)},
            2: {"head": (29, -38), "shoulder": (25, -21), "hip": (15, 14), "foot_front": (45, 49), "foot_back": (-18, 48),
                "hand_front": (69, -12), "hand_back": (7, 7), "weapon_end": (69, -12),
                "shoulder_back": (8, -31), "hip_back": (5, 9)},
            3: {"head": (16, -41), "shoulder": (13, -25), "hip": (8, 13), "foot_front": (33, 49), "foot_back": (-21, 48),
                "hand_front": (39, -7), "hand_back": (0, 3), "weapon_end": (39, -7),
                "shoulder_back": (4, -29), "hip_back": (1, 11)},
        }
        points.update({name: mirror(point) for name, point in fist_body.get(step, {}).items()})
    points["elbow_front"] = ((points["shoulder"][0] + points["hand_front"][0]) / 2,
                              (points["shoulder"][1] + points["hand_front"][1]) / 2)
    points["elbow_back"] = ((points.get("shoulder_back", points["shoulder"])[0] + points["hand_back"][0]) / 2,
                             (points.get("shoulder_back", points["shoulder"])[1] + points["hand_back"][1]) / 2)
    points["knee_front"] = ((points["hip"][0] + points["foot_front"][0]) / 2,
                             (points["hip"][1] + points["foot_front"][1]) / 2)
    points["knee_back"] = ((points.get("hip_back", points["hip"])[0] + points["foot_back"][0]) / 2,
                            (points.get("hip_back", points["hip"])[1] + points["foot_back"][1]) / 2)
    points.update(body_origin=points["hip"], primary_hand_socket=points["hand_front"], off_hand_socket=points["hand_back"])
    profile = resolve_body_profile(body_profile)
    if profile != STANDARD_PROFILE:
        standard_right = {name: (point[0] * direction, point[1]) for name, point in points.items()}
        profiled_right = {name: transform_body_point(name, point, profile, 60.0) for name, point in standard_right.items()}
        points = {name: (point[0] * direction, point[1]) for name, point in profiled_right.items()}
    points.update(primary_hand_socket=points["hand_front"], off_hand_socket=points["hand_back"], body_origin=points["hip"])
    geometry = {**base, "points": points, "body_profile_id": profile.profile_id,
                "head_scale": profile.head_scale, "limb_thickness_scale": profile.limb_thickness_scale,
                "attack_motion": motion.value, "step": step,
                "draw_weapon": base["draw_weapon"] and motion != AttackMotion.STRIKE}
    return apply_character_motion_pose_geometry(geometry, character_motion_profile, VisualPose.ATTACK, step)


def project_visual_poses(presence: dict[str, Any], feedback: dict[str, Any]) -> dict[str, Any]:
    """Map settled feedback to static poses; defeated presentation has priority."""
    transient = {}
    attacker = feedback.get("attacker")
    if attacker: transient[attacker["actor_id"]] = VisualPose.ATTACK
    outcome_pose = {"ATTACK_RESOLVED": VisualPose.HIT, "DODGE": VisualPose.DODGE, "PARRY": VisualPose.PARRY, "DEFEATED": VisualPose.DEFEATED}
    for cue in feedback.get("targets", ()):
        transient[cue["target_id"]] = outcome_pose[cue["event_type"]]
    bodies = []
    for body in presence["bodies"]:
        if body.get("defeat_pending_visual"):
            # Settled defeat exists, but its visible release belongs to IMPACT_FEEDBACK.
            pending_pose = transient.get(body["character_id"], VisualPose.IDLE)
            pose = VisualPose.HIT if pending_pose == VisualPose.DEFEATED else pending_pose
        else:
            pose = VisualPose.DEFEATED if not body["alive"] else transient.get(body["character_id"], VisualPose.IDLE)
        geometry = pose_geometry(pose, body["facing"], body["weapon_hint"], body.get("body_profile_id", "STANDARD"))
        geometry = apply_character_motion_pose_geometry(geometry, body.get("character_motion_profile"), pose)
        bodies.append({**body, "visual_pose": pose.value, "geometry": geometry})
    return {"contract": POSE_CONTRACT, "bodies": tuple(bodies), "presentation_only": True,
            "martial_stance_semantics": "UNCHANGED", "animation_timeline": False}


def project_combat_feedback(events: tuple[dict[str, Any], ...]) -> dict[str, Any]:
    """Project settled presentation events only; never infer or re-run outcomes."""
    attacker = next((event for event in events if event["event_type"] == "ACTION_STARTED"), None)
    target_cues = []
    actor_cues = []
    for event in events:
        kind = event["event_type"]
        if kind in OUTCOME_FEEDBACK_TEXT:
            for target_id in event["target_ids"]:
                target_cues.append({"target_id": target_id, "event_type": kind, "text": OUTCOME_FEEDBACK_TEXT[kind], "sequence": event["sequence"]})
        elif kind == "COMBATANT_DEFEATED":
            for target_id in event["target_ids"]:
                # Preserve the approved target-layer Parry label even on a lethal
                # parried hit. Last, invisible DEFEATED cue retains pose priority.
                target_cues = [cue for cue in target_cues
                               if cue["target_id"] != target_id or cue["event_type"] == "PARRY"]
                target_cues.append({"target_id": target_id, "event_type": "DEFEATED", "text": "", "sequence": event["sequence"]})
        elif kind in ("RESOURCE_GAINED", "RESOURCE_CONSUMED"):
            d = event["details"]; actor_cues.append({"actor_id": event["actor_id"], "event_type": kind, "text": f"{d['resource']} {d['before']} → {d['after']}", "sequence": event["sequence"]})
        elif kind in ("STATUS_APPLIED", "STATUS_REFRESHED", "STATUS_EXPIRED"):
            d = event["details"]; verb = {"STATUS_APPLIED": "獲得", "STATUS_REFRESHED": "刷新", "STATUS_EXPIRED": "消失"}[kind]
            actor_cues.append({"actor_id": event["actor_id"], "event_type": kind, "text": f"{verb} {d['status']}", "sequence": event["sequence"]})
        elif kind in ("STANCE_ACTIVATED", "STANCE_DEACTIVATED"):
            d = event["details"]; actor_cues.append({"actor_id": event["actor_id"], "event_type": kind, "text": f"{d['stance']}：{'啟動' if kind == 'STANCE_ACTIVATED' else '解除'}", "sequence": event["sequence"]})
    return {"contract": FEEDBACK_CONTRACT,
            "attacker": None if attacker is None else {"actor_id": attacker["actor_id"], "action_id": attacker["action_id"], "action_name": attacker["action_name"], "text": "出手"},
            "targets": tuple(target_cues), "actor_cues": tuple(actor_cues), "source": "SETTLED_PRESENTATION_EVENTS",
            "outcome_recalculation": False}


def project_damage_impact_feedback(events: tuple[dict[str, Any], ...]) -> dict[str, Any]:
    """Copy authoritative settled impact fields; never execute or infer a damage formula."""
    cues = []; unavailable = set(); dodged = {target for event in events if event["event_type"] == "DODGE" for target in event["target_ids"]}
    parried = {target for event in events if event["event_type"] == "PARRY" for target in event["target_ids"]}
    for event in events:
        kind = event["event_type"]; sequence = event["sequence"]
        if kind == "DODGE":
            cues.extend(DamageImpactCue(target, DamageImpactKind.DODGE, "閃避", None, sequence) for target in event["target_ids"])
        # WO092-H1: Parry text belongs only to Target-Reaction. Keep the
        # parry_targets metadata and all authoritative damage/Shield cues.
        elif kind == "COMBATANT_DEFEATED":
            cues.extend(DamageImpactCue(target, DamageImpactKind.DEFEATED, "擊倒", None, sequence) for target in event["target_ids"])
        elif kind == "DAMAGE_APPLIED":
            details = event["details"]
            shield = details.get("shield_absorbed_damage", details.get("shield_absorbed"))
            hp_damage = details.get("hp_damage")
            settled_damage = details.get("resolved_damage", details.get("final_damage_before_shield"))
            for target in event["target_ids"]:
                if target in dodged: continue
                if shield is not None and shield > 0:
                    cues.append(DamageImpactCue(target, DamageImpactKind.SHIELD_ABSORB, f"護盾 -{shield}", shield, sequence))
                if hp_damage is not None and hp_damage > 0:
                    cues.append(DamageImpactCue(target, DamageImpactKind.HP_DAMAGE, f"-{hp_damage}", hp_damage, sequence))
                elif hp_damage is None and settled_damage is not None and not shield:
                    cues.append(DamageImpactCue(target, DamageImpactKind.HP_DAMAGE if settled_damage > 0 else DamageImpactKind.ZERO_DAMAGE,
                                                f"-{settled_damage}" if settled_damage > 0 else "未造成傷害", settled_damage, sequence))
                elif hp_damage == 0 and not shield and settled_damage == 0:
                    cues.append(DamageImpactCue(target, DamageImpactKind.ZERO_DAMAGE, "未造成傷害", 0, sequence))
                elif hp_damage is None: unavailable.add("hp_damage")
                if shield is None: unavailable.add("shield_absorbed_damage")
    return {"contract": DAMAGE_IMPACT_CONTRACT, "impacts": tuple(asdict(cue) for cue in cues), "presentation_only": True,
            "source": "SETTLED_BATTLE_EVENTS", "damage_recalculation": False, "stable_target_mapping": True,
            "unavailable_fields": tuple(sorted(unavailable)), "parry_targets": tuple(sorted(parried))}


def presentation_events_from_action_resolution(resolution: Any, start_sequence: int = 0) -> tuple[dict[str, Any], ...]:
    """Consume B1 immutable impacts without reaching through to battle runtime state."""
    if resolution is None: return ()
    raw_impacts = resolution.settled_impacts if hasattr(resolution, "settled_impacts") else resolution["settled_impacts"]
    impacts = tuple(item if isinstance(item, SettledTargetImpact) else SettledTargetImpact(**item) for item in raw_impacts)
    events = []; sequence = start_sequence
    for impact in impacts:
        common = {"actor_id": impact.source_combatant_id, "action_id": impact.action_id,
                  "action_name": None, "target_ids": (impact.target_combatant_id,),
                  "derivation": "SETTLED_GAMEFACING_IMPACT_CONTRACT",
                  "attack_instance_id": impact.attack_instance_id}
        if impact.dodged:
            sequence += 1; events.append({"sequence": sequence, "event_type": "DODGE", "details": {"outcome": "DODGED"}, **common})
        elif impact.parried:
            sequence += 1; events.append({"sequence": sequence, "event_type": "PARRY", "details": {"outcome": "PARRIED"}, **common})
        damage = settled_impacts_as_presentation_events((impact,), sequence)[0]
        sequence = damage["sequence"]; events.append(damage)
        if impact.defeated:
            sequence += 1; events.append({"sequence": sequence, "event_type": "COMBATANT_DEFEATED", "details": {}, **common})
    return tuple(events)


def project_combat_presentation_flow(events: tuple[dict[str, Any], ...], actor_aliases: dict[str, str] | None = None) -> tuple[CombatPresentationBeat, ...]:
    """Project ordered, fully settled action records into a tiny deterministic UI sequence."""
    aliases = actor_aliases or {}; actions = []; pending_intent = None
    for event in events:
        if event["event_type"] == "ENEMY_INTENT": pending_intent = event; continue
        if event["event_type"] == "ACTION_STARTED":
            actions.append([])
            if pending_intent is not None: actions[-1].append(pending_intent); pending_intent = None
        if actions: actions[-1].append(event)
    beats = []; beat_number = 0
    for action_events in actions:
        start = next(event for event in action_events if event["event_type"] == "ACTION_STARTED")
        actor_id = aliases.get(start["actor_id"], start["actor_id"]); sequences = tuple(event["sequence"] for event in action_events)
        weapon_context = project_action_weapon_presentation_context(start, tuple(action_events), actor_id)
        intent = next((event for event in action_events if event["event_type"] == "ENEMY_INTENT"), None)
        if intent:
            details = intent["details"]; intent_actor = aliases.get(intent["actor_id"], intent["actor_id"])
            payload = {**project_combat_feedback(()), "intent": {"contract": ENEMY_INTENT_CONTRACT,
                "enemy_id": intent_actor, "source_actor_id": intent["actor_id"], "action_id": intent["action_id"],
                "action_display_name": intent["action_name"], "target_ids": tuple(intent["target_ids"]),
                "target_display_names": tuple(details["target_display_names"]), "text": f"準備｜{intent['action_name']} → {'、'.join(details['target_display_names'])}",
                "decision_authority": details["decision_authority"], "prediction": False}}
            beat_number += 1; beats.append(CombatPresentationBeat(f"beat-{beat_number}", PresentationBeatKind.ENEMY_INTENT, intent_actor, intent["action_id"], intent["action_name"], payload, ENEMY_INTENT_LEAD_IN_MS, (intent["sequence"],)))
        attacker = {"contract": FEEDBACK_CONTRACT, "attacker": {"actor_id": actor_id, "action_id": start["action_id"], "action_name": start["action_name"], "text": "出手", "action_weapon_presentation": weapon_context},
                    "targets": (), "actor_cues": (), "source": "SETTLED_PRESENTATION_EVENTS", "outcome_recalculation": False}
        outcomes = tuple(event for event in action_events if event["event_type"] in (*OUTCOME_FEEDBACK_TEXT, "COMBATANT_DEFEATED"))
        contact_targets = tuple(dict.fromkeys(aliases.get(target, target) for event in outcomes for target in event["target_ids"]))
        attacker["attacker"]["contact_target_ids"] = contact_targets
        derived = tuple({**event, "actor_id": aliases.get(event["actor_id"], event["actor_id"])} for event in action_events if event["event_type"] in ("RESOURCE_GAINED", "RESOURCE_CONSUMED", "STATUS_APPLIED", "STATUS_REFRESHED", "STATUS_EXPIRED", "STANCE_ACTIVATED", "STANCE_DEACTIVATED"))
        reaction = project_combat_feedback(outcomes); feedback = project_combat_feedback(derived)
        for kind, payload, duration in ((PresentationBeatKind.ACTION_START, attacker, ACTION_CUE_MS),
                                        (PresentationBeatKind.ATTACK_MOTION, attacker, sum(MOTION_STEP_DELAYS_MS.values())),
                                        (PresentationBeatKind.TARGET_REACTION, reaction, REACTION_CUE_MS)):
            beat_number += 1; beats.append(CombatPresentationBeat(f"beat-{beat_number}", kind, actor_id, start["action_id"], start["action_name"], payload, duration, sequences))
        impacts = project_damage_impact_feedback(tuple(action_events))
        impact_kinds = {cue["kind"] for cue in impacts["impacts"]}
        if impact_kinds & {DamageImpactKind.HP_DAMAGE, DamageImpactKind.SHIELD_ABSORB, DamageImpactKind.ZERO_DAMAGE, DamageImpactKind.DEFEATED}:
            impact_payload = {**project_combat_feedback(()), **impacts}
            beat_number += 1; beats.append(CombatPresentationBeat(f"beat-{beat_number}", PresentationBeatKind.IMPACT_FEEDBACK, actor_id, start["action_id"], start["action_name"], impact_payload, IMPACT_FEEDBACK_MS, sequences))
        if derived:
            beat_number += 1; beats.append(CombatPresentationBeat(f"beat-{beat_number}", PresentationBeatKind.DERIVED_FEEDBACK, actor_id, start["action_id"], start["action_name"], feedback, DERIVED_FEEDBACK_MS, sequences))
    terminal = next((event for event in reversed(events) if event["event_type"] == "ENCOUNTER_TERMINATED"), None)
    beat_number += 1
    if terminal:
        state = terminal["details"]["terminal_state"]
        payload = {**project_combat_feedback(()), "terminal": {"state": state, "text": "戰鬥勝利" if state == "VICTORY" else "戰鬥敗北", "persistent": True}}
        beats.append(CombatPresentationBeat(f"beat-{beat_number}", PresentationBeatKind.ENCOUNTER_CLOSURE, None, None, None, payload, TERMINAL_REVEAL_MS, (terminal["sequence"],)))
    else:
        beats.append(CombatPresentationBeat(f"beat-{beat_number}", PresentationBeatKind.CONTROL_READY, None, None, None,
            project_combat_feedback(()), READY_CUE_MS, tuple(event["sequence"] for event in events)))
    return tuple(beats)


def human_legality_reason(code: str) -> str:
    """Deterministic display mapping; the machine reason remains visible."""
    return LEGALITY_REASON_TEXT.get(code, "暫時無法使用")


def make_visual_slot(character_id: str, side: str, index: int) -> dict[str, Any]:
    """visual_slot is presentation-only; it is NOT a battle canonical position."""
    return {"visual_slot": f"{side}-{index + 1}", "character_id": character_id, "side": side, "order": index}


def build_body_presence_model(layout: dict[str, Any], action_weapon_presentation: dict[str, Any] | None = None) -> dict[str, Any]:
    """Create display-only bodies; coordinates have no gameplay meaning."""
    bodies = []
    allies = layout["allies"]
    for index, combatant in enumerate(allies):
        family = combatant.get("martial_family")
        binding = combatant.get("presentation_binding") or {}
        bound_profile = binding.get("appearance_profile")
        motion_profile = get_character_motion_profile(binding.get("character_id"))
        bodies.append({
            "character_id": combatant["character_id"], "display_name": combatant["display_name"],
            "side": "ally", "visual_slot": combatant["visual_slot"], "facing": "right",
            "x_ratio": .18, "y_ratio": (index + 1) / (len(allies) + 1), "alive": combatant.get("presentation_alive", combatant["alive"]),
            "settled_alive": combatant["alive"], "defeat_pending_visual": combatant.get("defeat_pending_visual", False),
            "selected": False, "selectable": False, "marker": "我方", "martial_family": family,
            "weapon_hint": (family or "generic").strip().lower(), "body_spec_id": STANDARD_HUMANOID.spec_id, "body_profile_id": binding.get("body_profile_id", "STANDARD"),
            "appearance_profile_id": binding.get("appearance_profile_id", "GENERIC_TRAVELER"),
            "appearance_profile": bound_profile,
            "runtime_subject_id": binding.get("runtime_subject_id"),
            "bound_character_id": binding.get("character_id"),
            "runtime_visual_profile_id": binding.get("visual_profile_id"),
            "character_motion_profile": character_motion_profile_snapshot(motion_profile),
            "character_motion_profile_id": None if motion_profile is None else motion_profile.profile_id,
        })
    enemies = layout["enemies"]
    for index, combatant in enumerate(enemies):
        metadata = combatant.get("presentation_metadata") or {}
        bodies.append({
            "character_id": combatant["character_id"], "display_name": combatant["display_name"],
            "side": "enemy", "visual_slot": combatant["visual_slot"], "facing": "left",
            "x_ratio": .78, "y_ratio": (index + 1) / (len(enemies) + 1), "alive": combatant.get("presentation_alive", combatant["alive"]),
            "settled_alive": combatant["alive"], "defeat_pending_visual": combatant.get("defeat_pending_visual", False),
            "selected": combatant["selected"], "selectable": combatant["selectable"],
            "marker": "▶ 目標" if combatant["selected"] else "敵方",
            "martial_family": metadata.get("martial_family"),
            "approach_family": metadata.get("approach_family"),
            "weapon_hint": metadata.get("weapon_hint", "generic"),
            "melee_presentation_classification": metadata.get("melee_presentation_classification"),
            "appearance_profile_id": metadata.get("appearance_profile_id", "GENERIC_GUARD" if combatant["character_id"] == "enemy-center" else "GENERIC_DISCIPLE"),
            "appearance_profile": metadata.get("appearance_profile"),
            "body_spec_id": STANDARD_HUMANOID.spec_id, "body_profile_id": metadata.get("body_profile_id", "STANDARD"),
        })
    context = action_weapon_presentation or {}
    if context and context.get("binding_scope") == "ACTION_PRESENTATION_ONLY":
        actor_id = context.get("presentation_actor_id")
        family = context.get("weapon_visual_family")
        known = project_weapon_silhouette(family) != WeaponSilhouette.GENERIC
        resolved_bodies = []
        for body in bodies:
            persistent = body.get("martial_family")
            persistent_known = project_weapon_silhouette(persistent) != WeaponSilhouette.GENERIC
            conflict = bool(known and persistent_known and project_weapon_silhouette(persistent) != project_weapon_silhouette(family))
            if body["character_id"] == actor_id and known and not conflict and body["alive"]:
                resolved_bodies.append({**body, "current_weapon_visual_family": family,
                                        "weapon_hint": str(family).lower(), "martial_family": family,
                                        "approach_family": family,
                                        "melee_presentation_classification": project_approach_profile(family).value,
                                        "action_weapon_presentation": context,
                                        "weapon_binding_scope": "ACTION_PRESENTATION_ONLY",
                                        "permanent_equipment_authority": False})
            else:
                resolved_bodies.append({**body, "weapon_presentation_conflict": {
                    "code": "PRESENTATION_WEAPON_CONFLICT", "persistent_family": persistent,
                    "action_family": family, "action_scoped_override_applied": False,
                } if body["character_id"] == actor_id and conflict else None})
        bodies = resolved_bodies
    return {"contract": BODY_PRESENCE_CONTRACT, "bodies": tuple(bodies), "position_authority": False,
            "slot_semantics": "PRESENTATION_ONLY_NOT_GAMEPLAY_POSITION"}


def project_vital_hud(combatant_id: str, current_hp: int | None, max_hp: int | None,
                      current_shield: int | None, *, show_zero_shield: bool) -> dict[str, Any]:
    """Project snapshot vitals only; ratio clamping is display safety, not HP mutation."""
    available = current_hp is not None and max_hp is not None
    ratio = 0.0 if not available or max_hp <= 0 else min(1.0, max(0.0, current_hp / max_hp))
    shield_visible = current_shield is not None and (show_zero_shield or current_shield > 0)
    return {"contract": VITAL_HUD_CONTRACT, "combatant_id": combatant_id,
            "hp_current": current_hp, "hp_max": max_hp, "hp_available": available,
            "hp_text": f"HP {current_hp}/{max_hp}" if available else "HP：—", "hp_ratio": ratio,
            "shield_current": current_shield, "shield_visible": shield_visible,
            "shield_text": f"護盾 {current_shield}" if shield_visible else "",
            "source": "GAME_FACING_COMBATANT_SNAPSHOT", "reconstruction": False,
            "damage_accumulation": False, "presentation_only": True}


def build_2d_layout_model(state: dict[str, Any]) -> dict[str, Any]:
    """Build a deterministic, widget-independent 2D read model."""
    friendly = state.get("friendly_participants") or (() if state.get("player") is None else (state["player"],))
    allies = [{**member, **make_visual_slot(member["character_id"], "ally", index),
        "vital_hud": project_vital_hud(member["character_id"], member["hp_current"], member["hp_max"], member["shield"], show_zero_shield=True)}
        for index, member in enumerate(friendly)]
    enemies = []; current_intent = state.get("presentation_feedback", {}).get("intent")
    for index, enemy in enumerate(state["enemies"]):
        selected = enemy["character_id"] == state["selected_target_id"]
        vital = project_vital_hud(enemy["character_id"], enemy.get("hp_current"), enemy.get("hp_max"), enemy.get("shield"), show_zero_shield=False)
        enemies.append({
            **enemy, **make_visual_slot(enemy["character_id"], "enemy", index),
            "selected": selected, "target_marker": "▶ 目標" if selected else "",
            "life_text": "存活" if enemy["alive"] else "已倒下", "hp_text": vital["hp_text"], "vital_hud": vital,
            "intent": current_intent if current_intent and current_intent["enemy_id"] == enemy["character_id"] and enemy["alive"] else None,
            "selectable": bool(enemy.get("ordinary_combat_eligible", enemy["alive"])),
        })
    actions = []
    for action in state["actions"]:
        reason_items = tuple({"code": code, "text": human_legality_reason(code)} for code in action["illegal_reasons"])
        actions.append({**action, "reason_items": reason_items, "reason_display": "；".join(f"{x['text']}（{x['code']}）" for x in reason_items)})
    status = state["battle_status"]
    return {
        "contract": LAYOUT_CONTRACT, "battle_status_text": BATTLE_STATUS_TEXT.get(status, status),
        "round_text": f"第 {state['snapshot']['formal_turn']} 回合", "allies": tuple(allies),
        "enemies": tuple(enemies), "actions": tuple(actions), "combat_log": state["combat_log"],
        "selected_target_id": state["selected_target_id"],
    }


def create_demo_controller(workspace: str | Path, canonical_id: str = LEGENDARY_ID) -> ManualCombatController:
    """Create a fresh deterministic, non-canonical encounter fixture."""
    service = GameFacingMartialService(workspace)
    player = service.bind(CharacterMartialLoadout("player", "玩家刀客", (canonical_id,), canonical_id), max_hp=240, initial_qi=30)
    ai_id = SECONDARY_ID
    enemies = tuple(service.bind(CharacterMartialLoadout(enemy_id, name, (ai_id,), ai_id), max_hp=180, initial_qi=20)
                    for enemy_id, name in (("enemy-left", "敵人甲"), ("enemy-center", "敵人乙"), ("enemy-right", "敵人丙")))
    participants = (ControlledParticipant(player, PLAYER_CONTROLLED, "player"),
                    *(ControlledParticipant(enemy, AI_CONTROLLED, "enemy") for enemy in enemies))
    targets = (
        EncounterTarget("player", "玩家刀客", "player", "front", 1),
        EncounterTarget("enemy-left", "敵人甲", "enemy", "front", 0),
        EncounterTarget("enemy-center", "敵人乙", "enemy", "front", 1),
        EncounterTarget("enemy-right", "敵人丙", "enemy", "front", 2),
    )
    return ManualCombatController(service, "wo042-demo", participants, targets, "player")


@dataclass(frozen=True)
class BattleScreenConfiguration:
    """Optional developer-fixture presentation wiring; Battle mechanics remain unchanged."""
    controller_factory: Any
    player_runtime_id: str
    ai_runtime_id: str
    player_target_id: str
    actor_aliases: dict[str, str]
    presentation_binding_resolver: Any = None
    action_display_label: str | None = None
    player_state_label: str | None = None
    window_title: str | None = None
    dev_banner: str | None = None
    enemy_presentation_resolver: Any = None
    formal_martial_status_label: str | None = None
    character_motion_status_label: str | None = None
    formal_action_set_status_label: str | None = None
    sandbox_action_set_status_label: str | None = None
    enemy_response_actor_ids: tuple[str, ...] | None = None
    friendly_ai_actor_ids: tuple[str, ...] = ()
    friendly_target_order: tuple[str, ...] = ()
    enable_presentation_speed_control: bool = False
    session_factory: Any = None
    dev_banner_wraplength: int = 0


class BattleScreenSession:
    """Programmatically testable screen state; mechanics remain in the controller."""
    def __init__(self, workspace: str | Path, canonical_id: str = LEGENDARY_ID,
                 configuration: BattleScreenConfiguration | None = None):
        self.workspace = Path(workspace)
        self.canonical_id = canonical_id
        self.configuration = configuration
        self.log: list[str] = []
        self.last_error: str | None = None
        self.selected_action_id: str | None = None
        self.selected_target_id: str | None = None
        self.terminal_result: str | None = None
        self.terminal_visible: str | None = None
        self.feedback_generation = 0
        self.feedback = project_combat_feedback(())
        self.presentation_feedback = project_combat_feedback(())
        self.motion_phase = "IDLE"
        self.motion_step = 0
        self.combat_phase = "STABLE"
        self.combat_step = 0
        self.contact_attacker: dict[str, Any] | None = None
        self.presentation_beats: tuple[CombatPresentationBeat, ...] = ()
        self.presentation_index = -1
        self.presentation_busy = False
        self.ready_cue = False
        self.impact_risen = False
        self.settled_presentation_events: tuple[dict[str, Any], ...] = ()
        self.pending_defeat_releases: dict[str, dict[str, Any]] = {}
        self.queued_action_invalidations: list[dict[str, Any]] = []
        self.ally_only_mode = False
        self.selected_control_mode = "MANUAL_PLAYER_CONTROL"
        self.pending_control_mode: str | None = None
        self.friendly_phase_trace: list[dict[str, Any]] = []
        self.auto_control_trace: list[dict[str, Any]] = []
        self.auto_cycle_sequence = 0
        self.active_auto_cycle_id: str | None = None
        self.auto_cycle_lifecycle_trace: list[dict[str, Any]] = []
        self.manual_response_sequence_active = False
        self.manual_control_authority_trace: list[dict[str, Any]] = []
        self.presentation_speed_multiplier = DEFAULT_PRESENTATION_SPEED
        self.presentation_speed_trace: list[dict[str, Any]] = []
        self.reset()

    def reset(self) -> dict[str, Any]:
        self.controller = (self.configuration.controller_factory(self.workspace)
                           if self.configuration else create_demo_controller(self.workspace, self.canonical_id))
        self.log = []
        self.last_error = None
        self.selected_action_id = None
        self.selected_target_id = None
        self.terminal_result = None
        self.terminal_visible = None
        self.feedback_generation += 1
        self.feedback = project_combat_feedback(())
        self.presentation_feedback = project_combat_feedback(())
        self.motion_phase = "IDLE"
        self.motion_step = 0
        self.combat_phase = "STABLE"
        self.combat_step = 0
        self.contact_attacker = None
        self.presentation_beats = (); self.presentation_index = -1; self.presentation_busy = False; self.ready_cue = False; self.impact_risen = False
        self.settled_presentation_events = ()
        self.pending_defeat_releases = {}
        self.queued_action_invalidations = []
        self.ally_only_mode = False
        self.selected_control_mode = "MANUAL_PLAYER_CONTROL"
        self.pending_control_mode = None
        self.friendly_phase_trace = []
        self.auto_control_trace = []
        self.auto_cycle_sequence = 0
        self.active_auto_cycle_id = None
        self.auto_cycle_lifecycle_trace = []
        self.manual_response_sequence_active = False
        self.manual_control_authority_trace = []
        return self.screen_state()

    def set_presentation_speed(self, multiplier: float) -> dict[str, Any]:
        if multiplier not in SUPPORTED_PRESENTATION_SPEEDS:
            self.last_error = "UNSUPPORTED_PRESENTATION_SPEED"
            return self.screen_state()
        old = self.presentation_speed_multiplier
        self.presentation_speed_multiplier = multiplier
        self.presentation_speed_trace.append({"speed_change_event_id": f"speed-{len(self.presentation_speed_trace)+1}",
                                               "old_speed": old, "new_speed": multiplier,
                                               "battle_mode": self.effective_control_mode(),
                                               "active_cycle_id": self.active_auto_cycle_id,
                                               "presentation_segment": None if self.current_presentation_beat() is None else self.current_presentation_beat().kind.value,
                                               "callback_already_scheduled": self.presentation_busy,
                                               "new_speed_applied_from_segment": "NEXT_UNSCHEDULED_PRESENTATION_SEGMENT",
                                               "gameplay_state_changed_by_speed": False})
        self.last_error = None
        return self.screen_state()

    def _settled_alive(self, actor_id: str) -> bool:
        state = self.controller.service.settlement_bridge.engine.state_by_id(actor_id)
        return bool(state is not None and not state.defeated)

    def _refresh_ally_only_mode(self) -> bool:
        if not self.configuration or not self.configuration.friendly_ai_actor_ids or self.terminal_result:
            self.ally_only_mode = False
            return False
        player_alive = self._settled_alive(self.configuration.player_runtime_id)
        ally_alive = any(self._settled_alive(identity) for identity in self.configuration.friendly_ai_actor_ids)
        self.ally_only_mode = not player_alive and ally_alive
        return self.ally_only_mode

    def effective_control_mode(self) -> str:
        if self.terminal_result:
            return "MANUAL_PLAYER_CONTROL"
        if self._refresh_ally_only_mode():
            return "ALLY_ONLY_AUTO_RESOLUTION"
        return self.selected_control_mode

    def _apply_pending_control_mode(self) -> None:
        if self.presentation_busy or self.pending_control_mode is None or self.terminal_result:
            return
        previous = self.selected_control_mode
        self.selected_control_mode = self.pending_control_mode
        self.pending_control_mode = None
        if previous != self.selected_control_mode:
            # Control generations, not callback creation, are the authority for future AUTO work.
            self.feedback_generation += 1
            self.auto_control_trace.append({"event": "SAFE_BOUNDARY_MODE_APPLIED", "mode_before": previous,
                                            "mode_after": self.selected_control_mode, "auto_generation": self.feedback_generation,
                                            "next_cycle_allowed": self.selected_control_mode == "AUTO_FRIENDLY_CONTROL"})

    def request_auto(self, enabled: bool) -> dict[str, Any]:
        if self.terminal_result:
            self.last_error = "BATTLE_ALREADY_ENDED"
            return self.screen_state()
        if not enabled and self._refresh_ally_only_mode():
            # A human-selected AUTO sequence may settle Player defeat before its visuals finish.
            # Keep the mode-control request reachable; forced Ally-only still wins at the boundary.
            if self.presentation_busy and self.selected_control_mode == "AUTO_FRIENDLY_CONTROL":
                self.pending_control_mode = "MANUAL_PLAYER_CONTROL"
                self.auto_control_trace.append({"event": "AUTO_OFF_REQUESTED", "control_mode": "ALLY_ONLY_AUTO_RESOLUTION",
                                                "pending_auto_off": True, "auto_generation": self.feedback_generation})
                self.last_error = None
                return self.screen_state()
            self.last_error = "MANUAL_CONTROL_UNAVAILABLE_PLAYER_DEFEATED"
            return self.screen_state()
        requested = "AUTO_FRIENDLY_CONTROL" if enabled else "MANUAL_PLAYER_CONTROL"
        if self.presentation_busy:
            self.pending_control_mode = requested
        else:
            previous = self.selected_control_mode
            self.selected_control_mode = requested
            self.pending_control_mode = None
            if previous != requested:
                self.feedback_generation += 1
        self.auto_control_trace.append({"event": "AUTO_ON_REQUESTED" if enabled else "AUTO_OFF_REQUESTED",
                                        "control_mode": self.effective_control_mode(),
                                        "pending_auto_off": self.pending_control_mode == "MANUAL_PLAYER_CONTROL",
                                        "auto_generation": self.feedback_generation})
        self.last_error = None
        return self.screen_state()

    def _presentation_flow(self, events: tuple[dict[str, Any], ...]) -> tuple[CombatPresentationBeat, ...]:
        aliases = self.configuration.actor_aliases if self.configuration else {"ai-sword": "enemy-center"}
        beats = project_combat_presentation_flow(events, aliases)
        if self.effective_control_mode() != "MANUAL_PLAYER_CONTROL":
            beats = tuple(beat for beat in beats if beat.kind != PresentationBeatKind.CONTROL_READY)
        return beats

    def should_auto_continue(self, generation: int) -> bool:
        if generation != self.feedback_generation or self.presentation_busy or self.active_auto_cycle_id is not None or self.terminal_result:
            return False
        self._apply_pending_control_mode()
        allowed = self.effective_control_mode() in ("AUTO_FRIENDLY_CONTROL", "ALLY_ONLY_AUTO_RESOLUTION")
        self.auto_control_trace.append({"event": "SAFE_BOUNDARY_DECISION", "requested_generation": generation,
                                        "auto_generation": self.feedback_generation, "pending_auto_off": False,
                                        "control_mode": self.effective_control_mode(), "next_cycle_allowed": allowed})
        return allowed

    def _begin_auto_cycle(self) -> str | None:
        """Apply AUTO-only backpressure until the preceding cycle presentation is complete."""
        if self.presentation_busy or self.active_auto_cycle_id is not None or self.terminal_result:
            self.auto_cycle_lifecycle_trace.append({"event": "CYCLE_CREATION_BLOCKED", "reason": "PRESENTATION_BACKPRESSURE",
                                                    "active_auto_cycle_id": self.active_auto_cycle_id,
                                                    "auto_generation": self.feedback_generation})
            return None
        self.auto_cycle_sequence += 1
        self.active_auto_cycle_id = f"auto-cycle-{self.auto_cycle_sequence}"
        self.auto_cycle_lifecycle_trace.append({"event": "CYCLE_CREATED", "auto_cycle_id": self.active_auto_cycle_id,
                                                "auto_generation": self.feedback_generation, "round_id": self.controller.formal_turn})
        return self.active_auto_cycle_id

    def continue_ally_only_cycle(self) -> dict[str, Any]:
        """Resolve one non-blocking ally + enemy cycle; the Tk scheduler requests later cycles."""
        if not self._refresh_ally_only_mode():
            self.last_error = "ALLY_ONLY_MODE_NOT_ELIGIBLE"
            return self.screen_state()
        cycle_id = self._begin_auto_cycle()
        if cycle_id is None:
            self.last_error = "AUTO_CYCLE_PRESENTATION_BACKPRESSURE"
            return self.screen_state()
        assert self.configuration is not None
        combined_events: tuple[dict[str, Any], ...] = ()
        terminal_state = "ACTIVE"
        phase_round = self.controller.formal_turn
        self.friendly_phase_trace.append({
            "phase_id": f"friendly-{phase_round}-{self.configuration.player_runtime_id}", "round_id": phase_round,
            "actor_runtime_id": self.configuration.player_runtime_id, "actor_alive_at_phase_start": False,
            "control_authority": "MANUAL", "phase_created": False, "action_committed": False,
            "damage_events": 0, "suppression_reason": "ACTOR_DEFEATED_BEFORE_PHASE",
        })
        for ally_id in self.configuration.friendly_ai_actor_ids:
            alive = self._settled_alive(ally_id)
            record = {"phase_id": f"friendly-{phase_round}-{ally_id}", "round_id": phase_round,
                      "actor_runtime_id": ally_id, "actor_alive_at_phase_start": alive,
                      "control_authority": "AI", "phase_created": alive,
                      "action_committed": False, "damage_events": 0}
            if not alive:
                self.friendly_phase_trace.append(record); continue
            enemy_target = next((x.character_id for x in sorted(self.controller.targets.values(), key=lambda x:(x.row,x.column,x.character_id))
                                 if x.team == "enemy" and x.alive), None)
            if enemy_target is None: break
            result = self.controller.continue_ai(ally_id, enemy_target)
            if result["response_status"] == "INVALIDATED":
                self.queued_action_invalidations.append(result["queued_action_validity"])
            else:
                events = self._presentation_events(tuple(result["presentation_events"]))
                impacts = self._settled_impact_events(result["action_resolution"], max((x["sequence"] for x in events), default=0))
                combined_events += events + impacts; self.log.extend(self._presentation_log(result["combat_log"], events))
                record["action_committed"] = True
                record["damage_events"] = len(result["action_resolution"].get("settled_impacts", ()))
                terminal_state = result["action_resolution"]["terminal_state"]
            self.friendly_phase_trace.append(record)
        response_ids = self.configuration.enemy_response_actor_ids or self.controller.ordered_enemy_response_actor_ids()
        for enemy_id in response_ids:
            if terminal_state != "ACTIVE": break
            if enemy_id not in self.controller.participants or not self._settled_alive(enemy_id): continue
            friendly_target = next((identity for identity in self.configuration.friendly_target_order
                                    if identity in self.controller.targets and self.controller.targets[identity].alive), None)
            if friendly_target is None: break
            result = self.controller.continue_ai(enemy_id, friendly_target)
            if result["response_status"] == "INVALIDATED":
                self.queued_action_invalidations.append(result["queued_action_validity"]); continue
            events = self._presentation_events(tuple(result["presentation_events"]))
            impacts = self._settled_impact_events(result["action_resolution"], max((x["sequence"] for x in events), default=0))
            intent = result["intent"]; seq = max((x["sequence"] for x in combined_events), default=0) + 1
            combined_events += ({"sequence": seq, "event_type": "ENEMY_INTENT", "actor_id": intent["actor_id"],
                                "action_id": intent["action_id"], "action_name": intent["action_display_name"],
                                "target_ids": tuple(intent["target_ids"]), "details": {"target_display_names": tuple(intent["target_display_names"]),
                                "decision_authority": intent["decision_authority"], "decision_count": intent["decision_count"]},
                                "derivation": "FORMAL_AI_SELECTED_ACTION"},) + events + impacts
            self.log.extend(self._presentation_log(result["combat_log"], events)); terminal_state = result["action_resolution"]["terminal_state"]
        self.controller.formal_turn += 1
        if terminal_state != "ACTIVE":
            self.terminal_result = terminal_state
            seq = max((x["sequence"] for x in combined_events), default=0) + 1
            combined_events += ({"sequence": seq, "event_type": "ENCOUNTER_TERMINATED", "actor_id": None, "action_id": None,
                                "action_name": None, "target_ids": (), "details": {"terminal_state": terminal_state},
                                "derivation": "BATTLEENGINE_TERMINAL_TRUTH"},)
            self.log.append("【戰鬥勝利】" if terminal_state == "VICTORY" else "【戰鬥敗北】")
        self.feedback_generation += 1; self.settled_presentation_events = combined_events
        self._latch_newly_defeated_targets(combined_events); self._refresh_ally_only_mode()
        self.presentation_beats = self._presentation_flow(combined_events)
        self.presentation_index = 0 if self.presentation_beats else -1
        self.presentation_busy = bool(self.presentation_beats); self.ready_cue = False
        if self.presentation_busy: self._apply_presentation_beat()
        self.auto_cycle_lifecycle_trace.append({"event": "CYCLE_SETTLEMENT_AND_PRESENTATION_ENQUEUED", "auto_cycle_id": cycle_id,
                                                "auto_generation": self.feedback_generation, "round_id": phase_round})
        self.last_error = None
        return self.screen_state()

    def continue_auto_cycle(self) -> dict[str, Any]:
        """Resolve one full optional AUTO cycle, reusing the formal deterministic action pipeline."""
        if self.effective_control_mode() == "ALLY_ONLY_AUTO_RESOLUTION":
            return self.continue_ally_only_cycle()
        if self.effective_control_mode() != "AUTO_FRIENDLY_CONTROL" or not self.configuration:
            self.last_error = "AUTO_MODE_NOT_ACTIVE"
            return self.screen_state()
        cycle_id = self._begin_auto_cycle()
        if cycle_id is None:
            self.last_error = "AUTO_CYCLE_PRESENTATION_BACKPRESSURE"
            return self.screen_state()
        combined_events: tuple[dict[str, Any], ...] = ()
        terminal_state = "ACTIVE"
        phase_round = self.controller.formal_turn
        friendly_order = (self.configuration.player_runtime_id, *self.configuration.friendly_ai_actor_ids)
        for actor_id in friendly_order:
            alive = self._settled_alive(actor_id)
            authority = "AUTO_AI" if actor_id == self.configuration.player_runtime_id else "ALLY_AI"
            record = {"phase_id": f"friendly-{phase_round}-{actor_id}", "round_id": phase_round,
                      "actor_runtime_id": actor_id, "actor_alive_at_phase_start": alive,
                      "control_authority": authority, "phase_created": alive,
                      "action_committed": False, "damage_events": 0}
            if not alive:
                self.friendly_phase_trace.append(record); continue
            enemy_target = next((x.character_id for x in sorted(self.controller.targets.values(), key=lambda x:(x.row,x.column,x.character_id))
                                 if x.team == "enemy" and x.alive), None)
            if enemy_target is None: break
            result = (self.controller.continue_auto_player(actor_id, enemy_target)
                      if actor_id == self.configuration.player_runtime_id else self.controller.continue_ai(actor_id, enemy_target))
            if result["response_status"] == "INVALIDATED":
                self.queued_action_invalidations.append(result["queued_action_validity"])
            else:
                events = self._presentation_events(tuple(result["presentation_events"]))
                impacts = self._settled_impact_events(result["action_resolution"], max((x["sequence"] for x in events), default=0))
                combined_events += events + impacts; self.log.extend(self._presentation_log(result["combat_log"], events))
                record["action_committed"] = True; record["damage_events"] = len(result["action_resolution"].get("settled_impacts", ()))
                terminal_state = result["action_resolution"]["terminal_state"]
            self.friendly_phase_trace.append(record)
            if terminal_state != "ACTIVE": break
        response_ids = self.configuration.enemy_response_actor_ids or self.controller.ordered_enemy_response_actor_ids()
        for enemy_id in response_ids:
            if terminal_state != "ACTIVE": break
            if enemy_id not in self.controller.participants or not self._settled_alive(enemy_id): continue
            friendly_target = next((identity for identity in self.configuration.friendly_target_order
                                    if identity in self.controller.targets and self.controller.targets[identity].alive), None)
            if friendly_target is None: break
            result = self.controller.continue_ai(enemy_id, friendly_target)
            if result["response_status"] == "INVALIDATED":
                self.queued_action_invalidations.append(result["queued_action_validity"]); continue
            events = self._presentation_events(tuple(result["presentation_events"]))
            impacts = self._settled_impact_events(result["action_resolution"], max((x["sequence"] for x in events), default=0))
            intent = result["intent"]; seq = max((x["sequence"] for x in combined_events), default=0) + 1
            combined_events += ({"sequence": seq, "event_type": "ENEMY_INTENT", "actor_id": intent["actor_id"], "action_id": intent["action_id"],
                                "action_name": intent["action_display_name"], "target_ids": tuple(intent["target_ids"]),
                                "details": {"target_display_names": tuple(intent["target_display_names"]), "decision_authority": intent["decision_authority"], "decision_count": intent["decision_count"]},
                                "derivation": "FORMAL_AI_SELECTED_ACTION"},) + events + impacts
            self.log.extend(self._presentation_log(result["combat_log"], events)); terminal_state = result["action_resolution"]["terminal_state"]
        self.controller.formal_turn += 1
        if terminal_state != "ACTIVE":
            self.terminal_result = terminal_state; self.pending_control_mode = None
            seq = max((x["sequence"] for x in combined_events), default=0) + 1
            combined_events += ({"sequence": seq, "event_type": "ENCOUNTER_TERMINATED", "actor_id": None, "action_id": None,
                                "action_name": None, "target_ids": (), "details": {"terminal_state": terminal_state}, "derivation": "BATTLEENGINE_TERMINAL_TRUTH"},)
            self.log.append("【戰鬥勝利】" if terminal_state == "VICTORY" else "【戰鬥敗北】")
        self.feedback_generation += 1; self.settled_presentation_events = combined_events
        self._latch_newly_defeated_targets(combined_events); self._refresh_ally_only_mode()
        self.presentation_beats = self._presentation_flow(combined_events)
        self.presentation_index = 0 if self.presentation_beats else -1; self.presentation_busy = bool(self.presentation_beats); self.ready_cue = False
        if self.presentation_busy: self._apply_presentation_beat()
        self.auto_cycle_lifecycle_trace.append({"event": "CYCLE_SETTLEMENT_AND_PRESENTATION_ENQUEUED", "auto_cycle_id": cycle_id,
                                                "auto_generation": self.feedback_generation, "round_id": phase_round})
        self.last_error = None
        return self.screen_state()

    def current_presentation_beat(self) -> CombatPresentationBeat | None:
        return self.presentation_beats[self.presentation_index] if 0 <= self.presentation_index < len(self.presentation_beats) else None

    def _apply_presentation_beat(self) -> None:
        beat = self.current_presentation_beat()
        if beat is None: return
        self.presentation_feedback = beat.feedback; self.motion_step = 0; self.ready_cue = beat.kind == PresentationBeatKind.CONTROL_READY; self.impact_risen = False
        if beat.kind in (PresentationBeatKind.ACTION_START, PresentationBeatKind.ENEMY_INTENT):
            self.combat_phase, self.combat_step = "STABLE", 0
        if beat.kind == PresentationBeatKind.ATTACK_MOTION:
            self.contact_attacker = beat.feedback.get("attacker")
        if beat.kind == PresentationBeatKind.IMPACT_FEEDBACK:
            released = {impact["target_id"] for impact in beat.feedback.get("impacts", ()) if impact["kind"] == DamageImpactKind.DEFEATED.value}
            for target_id in released:
                self.pending_defeat_releases.pop(target_id, None)
        if beat.kind in (PresentationBeatKind.ACTION_START, PresentationBeatKind.ATTACK_MOTION): self.motion_phase = "PENDING"
        elif beat.kind == PresentationBeatKind.TARGET_REACTION: self.motion_phase, self.motion_step = "ACTIVE", 2
        else: self.motion_phase = "IDLE"
        if beat.kind == PresentationBeatKind.CONTROL_READY: self.presentation_busy = False
        elif beat.kind == PresentationBeatKind.ENCOUNTER_CLOSURE:
            self.terminal_visible = self.terminal_result; self.presentation_busy = False

    def advance_presentation(self, generation: int) -> bool:
        if generation != self.feedback_generation or not self.presentation_beats: return False
        if self.presentation_index + 1 >= len(self.presentation_beats): return False
        self.presentation_index += 1; self._apply_presentation_beat(); return True

    def rise_impact(self, generation: int) -> bool:
        beat = self.current_presentation_beat()
        if generation != self.feedback_generation or beat is None or beat.kind != PresentationBeatKind.IMPACT_FEEDBACK: return False
        self.impact_risen = True; return True

    def finish_presentation(self, generation: int) -> bool:
        if generation != self.feedback_generation: return False
        if self.current_presentation_beat() and self.current_presentation_beat().kind == PresentationBeatKind.ENCOUNTER_CLOSURE: return False
        if self.active_auto_cycle_id:
            self.auto_cycle_lifecycle_trace.append({"event": "CYCLE_PRESENTATION_COMPLETED", "auto_cycle_id": self.active_auto_cycle_id,
                                                    "auto_generation": self.feedback_generation, "round_id": self.controller.formal_turn - 1})
            self.active_auto_cycle_id = None
        self.presentation_busy = False; self.ready_cue = False; self.impact_risen = False; self.presentation_beats = (); self.presentation_index = -1
        self.pending_defeat_releases = {}
        self.feedback = project_combat_feedback(()); self.presentation_feedback = project_combat_feedback(()); self.motion_phase = "IDLE"; self.motion_step = 0
        self.combat_phase, self.combat_step = "STABLE", 0; return True

    def activate_motion(self, generation: int) -> bool:
        return self.advance_motion(generation, 2)

    def advance_motion(self, generation: int, step: int) -> bool:
        if generation != self.feedback_generation or self.motion_phase not in ("PENDING", "ACTIVE") or step not in (1, 2, 3):
            return False
        self.motion_phase = "ACTIVE"
        self.motion_step = step
        return True

    def advance_combat_translation(self, generation: int, phase: str, step: int) -> bool:
        if (generation != self.feedback_generation or self.terminal_visible or
                phase not in ("APPROACH", "CONTACT", "RETREAT") or step not in (1, 2, 3)):
            return False
        self.combat_phase, self.combat_step = phase, step
        return True

    def pose_feedback(self) -> dict[str, Any]:
        return self.feedback if self.motion_phase == "ACTIVE" and self.motion_step >= 2 else project_combat_feedback(())

    def clear_feedback(self, generation: int) -> bool:
        """Clear only the matching presentation generation; stale callbacks are inert."""
        if generation != self.feedback_generation:
            return False
        self.feedback = project_combat_feedback(())
        self.presentation_feedback = project_combat_feedback(())
        self.motion_phase = "IDLE"
        self.motion_step = 0
        self.combat_phase = "STABLE"
        self.combat_step = 0
        self.pending_defeat_releases = {}
        self.presentation_busy = False; self.ready_cue = False; self.impact_risen = False; self.presentation_beats = (); self.presentation_index = -1
        return True

    def _latch_newly_defeated_targets(self, events: tuple[dict[str, Any], ...]) -> None:
        """Keep settled defeats visually pending until their matching impact beat releases them."""
        for event in events:
            if event.get("event_type") != "COMBATANT_DEFEATED":
                continue
            for target_id in event.get("target_ids", ()):
                self.pending_defeat_releases.setdefault(str(target_id), {
                    "source_sequence": event.get("sequence"),
                    "attack_instance_id": event.get("attack_instance_id"),
                    "release_authority": "IMPACT_FEEDBACK_DEFEATED_CUE",
                })

    def screen_state(self) -> dict[str, Any]:
        self._refresh_ally_only_mode()
        control_mode = self.effective_control_mode()
        snapshot = asdict(self.controller.snapshot())
        actor = next((p for p in snapshot["participants"] if p["character_id"] == snapshot["active_actor_id"]), None)
        if actor:
            participant = self.controller.participants.get(actor["character_id"])
            actor = {**actor, "martial_family": participant.bound.view.family if participant else None}
            if self.configuration and self.configuration.presentation_binding_resolver:
                actor = {**actor, "presentation_binding": self.configuration.presentation_binding_resolver(actor["character_id"])}
            if self.configuration and self.configuration.player_state_label:
                actor = {**actor, "martial_name": self.configuration.player_state_label}
            if actor["character_id"] in self.pending_defeat_releases:
                actor = {**actor, "presentation_alive": True, "defeat_pending_visual": True}
        friendly_ids = tuple(t.character_id for t in sorted(self.controller.targets.values(), key=lambda x: (x.row, x.column, x.character_id)) if t.team == "player")
        friendly_participants = []
        for identity in friendly_ids:
            item = next((p for p in snapshot["participants"] if p["character_id"] == identity), None)
            if item is None: continue
            participant = self.controller.participants.get(identity)
            item = {**item, "martial_family": participant.bound.view.family if participant else None}
            if self.configuration and self.configuration.presentation_binding_resolver:
                item = {**item, "presentation_binding": self.configuration.presentation_binding_resolver(identity)}
            if identity in self.pending_defeat_releases: item = {**item, "presentation_alive": True, "defeat_pending_visual": True}
            friendly_participants.append(item)
        enemies = [asdict(t) for t in sorted(self.controller.targets.values(), key=lambda x: (x.row, x.column, x.character_id)) if t.team == "enemy"]
        if self.configuration and self.configuration.enemy_presentation_resolver:
            enemies = [{**enemy, "presentation_metadata": self.configuration.enemy_presentation_resolver(enemy["character_id"])}
                       for enemy in enemies]
        enemies = [{**enemy, "presentation_alive": True, "defeat_pending_visual": True}
                   if enemy["character_id"] in self.pending_defeat_releases else enemy for enemy in enemies]
        actions = []
        for action in snapshot["available_actions"]:
            label = self.configuration.action_display_label if self.configuration and self.configuration.action_display_label else action["display_name"]
            actions.append({**action, "display_name": label, "enabled": bool(action["legal"] and not self.terminal_result and control_mode == "MANUAL_PLAYER_CONTROL"), "reason_text": " / ".join(action["illegal_reasons"])})
        beat = self.current_presentation_beat()
        display_feedback = self.presentation_feedback
        if self.combat_phase in ("APPROACH", "CONTACT", "RETREAT") and self.contact_attacker and not display_feedback.get("attacker"):
            display_feedback = {**display_feedback, "attacker": self.contact_attacker}
        return {
            "contract": SCREEN_CONTRACT, "snapshot": snapshot, "player": actor,
            "friendly_participants": tuple(friendly_participants),
            "enemies": enemies, "actions": actions, "combat_log": tuple(self.log),
            "selected_action_id": self.selected_action_id, "selected_target_id": self.selected_target_id,
            "error": self.last_error, "battle_status": self.terminal_visible or snapshot["battle_status"],
            "submission_locked": bool(self.terminal_result or control_mode != "MANUAL_PLAYER_CONTROL"), "feedback": self.feedback,
            "feedback_generation": self.feedback_generation, "motion_phase": self.motion_phase,
            "motion_step": self.motion_step, "pose_feedback": self.pose_feedback(),
            "combat_phase": self.combat_phase, "combat_step": self.combat_step,
            "presentation_busy": self.presentation_busy, "presentation_index": self.presentation_index,
            "presentation_beat_count": len(self.presentation_beats), "presentation_beat": None if beat is None else asdict(beat),
            "ready_cue": self.ready_cue, "presentation_source": "SETTLED_BATTLE_EVENTS", "terminal_result": self.terminal_result,
            "ally_only_mode": self.ally_only_mode,
            "control_status": "ALLY_AUTO_CONTINUATION" if self.ally_only_mode else "PLAYER_MANUAL",
            "control_mode": control_mode, "auto_enabled": control_mode == "AUTO_FRIENDLY_CONTROL",
            "human_auto_selected": self.selected_control_mode == "AUTO_FRIENDLY_CONTROL",
            "auto_toggle_enabled": not bool(self.terminal_result) and (
                not self.ally_only_mode or (self.presentation_busy and self.selected_control_mode == "AUTO_FRIENDLY_CONTROL")),
            "pending_control_mode": self.pending_control_mode,
            "pending_auto_off_request": self.pending_control_mode == "MANUAL_PLAYER_CONTROL",
            "friendly_phase_trace": tuple(self.friendly_phase_trace),
            "auto_control_trace": tuple(self.auto_control_trace),
            "active_auto_cycle_id": self.active_auto_cycle_id,
            "auto_cycle_sequence": self.auto_cycle_sequence,
            "auto_cycle_lifecycle_trace": tuple(self.auto_cycle_lifecycle_trace),
            "response_sequence_active": self.manual_response_sequence_active,
            "manual_control_authority_trace": tuple(self.manual_control_authority_trace),
            "presentation_speed_multiplier": self.presentation_speed_multiplier,
            "presentation_speed_label": f"{self.presentation_speed_multiplier:g}×",
            "supported_presentation_speeds": SUPPORTED_PRESENTATION_SPEEDS,
            "presentation_speed_trace": tuple(self.presentation_speed_trace),
            "impact_rise_px": IMPACT_RISE_PX if self.impact_risen else 0,
            "presentation_feedback": {**display_feedback, "combat_phase": self.combat_phase, "combat_step": self.combat_step},
            "presentation_pose_feedback": display_feedback if (self.motion_phase == "ACTIVE" and self.motion_step >= 2) or self.combat_phase in ("CONTACT", "RETREAT") else project_combat_feedback(()),
            "presentation_state_latch": {"contract": PRESENTATION_STATE_LATCH_CONTRACT,
                                         "pending_defeated_release": dict(self.pending_defeat_releases),
                                         "visible_defeat_release": "IMPACT_FEEDBACK_DEFEATED_CUE",
                                         "presentation_only": True},
            "queued_action_invalidation": {
                "contract": DEFEATED_COMBATANT_QUEUED_ACTION_INVALIDATION_CONTRACT,
                "presentation_suppression_contract": DEAD_ACTOR_PRESENTATION_SUPPRESSION_CONTRACT,
                "suppressed_queued_action_count": len(self.queued_action_invalidations),
                "invalidations": tuple(self.queued_action_invalidations),
                "truth_source": "GAMEFACING_RESPONSE_VALIDITY_FROM_BATTLEENGINE_SETTLED_STATE",
                "ui_actor_eligibility": False,
            },
        }

    def select_action(self, action_id: str) -> dict[str, Any]:
        if self.effective_control_mode() != "MANUAL_PLAYER_CONTROL":
            self.last_error = "MANUAL_COMMAND_DISABLED_DURING_AUTO" if not self.ally_only_mode else "ACTOR_DEFEATED_CANNOT_CONTROL"
            return self.screen_state()
        view = next((x for x in self.controller.snapshot().available_actions if x.action_id == action_id), None)
        if view is None:
            self.last_error = "UNKNOWN_ACTION"
        elif not view.legal:
            self.last_error = "ACTION_NOT_LEGAL:" + "+".join(view.illegal_reasons)
        else:
            self.selected_action_id, self.last_error = action_id, None
            self.manual_control_authority_trace.append({"phase": "ACTION_SELECTED", "control_mode": self.effective_control_mode(), "human_selected_auto": False})
        return self.screen_state()

    def select_target(self, target_id: str) -> dict[str, Any]:
        if self.effective_control_mode() != "MANUAL_PLAYER_CONTROL":
            self.last_error = "MANUAL_COMMAND_DISABLED_DURING_AUTO" if not self.ally_only_mode else "ACTOR_DEFEATED_CANNOT_CONTROL"
            return self.screen_state()
        target = self.controller.targets.get(target_id)
        if target is None or not target.alive or target.team == "player":
            self.last_error = "TARGET_UNAVAILABLE"
        else:
            self.selected_target_id, self.last_error = target_id, None
            self.manual_control_authority_trace.append({"phase": "TARGET_SELECTED", "control_mode": self.effective_control_mode(), "human_selected_auto": False})
        return self.screen_state()

    def submit(self) -> dict[str, Any]:
        if self.terminal_result:
            self.last_error = "BATTLE_ALREADY_ENDED"
            return self.screen_state()
        if self.effective_control_mode() != "MANUAL_PLAYER_CONTROL":
            self.last_error = "MANUAL_COMMAND_DISABLED_DURING_AUTO" if not self.ally_only_mode else "ACTOR_DEFEATED_BEFORE_PHASE"
            return self.screen_state()
        if not self.selected_action_id:
            self.last_error = "ACTION_REQUIRED"
            return self.screen_state()
        view = next(x for x in self.controller.snapshot().available_actions if x.action_id == self.selected_action_id)
        explicit = view.targeting_mode in ("single", "single_target", "horizontal_row", "roaming_distinct")
        targets = (self.selected_target_id,) if explicit and self.selected_target_id else ()
        command = PlayerActionCommand(
            self.controller.battle_id, self.controller.active_actor_id, self.selected_action_id,
            targets, self.controller.presentation_sequence,
            f"ui-{self.controller.presentation_sequence}-{self.selected_action_id}",
        )
        result = self.controller.submit(command)
        if result.accepted:
            self.manual_response_sequence_active = True
            self.manual_control_authority_trace.append({"phase": "PLAYER_ACTION_COMMITTED", "actor_runtime_id": command.actor_id,
                                                        "control_mode": self.effective_control_mode(), "human_selected_auto": False})
            player_events = self._presentation_events(tuple(result.presentation_events))
            self.log.extend(self._presentation_log(result.combat_log, player_events))
            player_impacts = self._settled_impact_events(result.action_resolution, max((x["sequence"] for x in player_events), default=0))
            combined_events = player_events + player_impacts; ai_result = None
            self.feedback = project_combat_feedback(result.presentation_events)
            terminal_state = result.action_resolution.terminal_state
            player_target_id = self.configuration.player_target_id if self.configuration else "player"
            friendly_ai_actor_ids = self.configuration.friendly_ai_actor_ids if self.configuration else ()
            for ally_actor_id in friendly_ai_actor_ids:
                if terminal_state != "ACTIVE": break
                enemy_target = next((x.character_id for x in sorted(self.controller.targets.values(), key=lambda x:(x.row,x.column,x.character_id)) if x.team == "enemy" and x.alive), None)
                if ally_actor_id not in self.controller.participants or enemy_target is None: continue
                ally_result = self.controller.continue_ai(ally_actor_id, enemy_target)
                self.manual_control_authority_trace.append({"phase": "ALLY_RESPONSE", "actor_runtime_id": ally_actor_id,
                                                            "control_mode": self.effective_control_mode(), "human_selected_auto": False})
                if ally_result["response_status"] == "INVALIDATED":
                    self.queued_action_invalidations.append(ally_result["queued_action_validity"]); continue
                ally_events = self._presentation_events(tuple(ally_result["presentation_events"]))
                ally_impacts = self._settled_impact_events(ally_result["action_resolution"], max((x["sequence"] for x in ally_events), default=0))
                combined_events += ally_events + ally_impacts; self.log.extend(self._presentation_log(ally_result["combat_log"], ally_events))
                terminal_state = ally_result["action_resolution"]["terminal_state"]
            response_actor_ids = (self.configuration.enemy_response_actor_ids if self.configuration and self.configuration.enemy_response_actor_ids
                                  else (self.configuration.ai_runtime_id,) if self.configuration and self.configuration.ai_runtime_id in self.controller.participants
                                  else self.controller.ordered_enemy_response_actor_ids())
            for ai_actor_id in response_actor_ids:
                if terminal_state != "ACTIVE": break
                if ai_actor_id not in self.controller.participants: continue
                friendly_order = self.configuration.friendly_target_order if self.configuration and self.configuration.friendly_target_order else (player_target_id,)
                friendly_target = next((identity for identity in friendly_order
                                        if identity in self.controller.targets and self.controller.targets[identity].alive), None)
                if friendly_target is None: break
                ai_result = self.controller.continue_ai(ai_actor_id, friendly_target)
                self.manual_control_authority_trace.append({"phase": "ENEMY_RESPONSE", "actor_runtime_id": ai_actor_id,
                                                            "control_mode": self.effective_control_mode(), "human_selected_auto": False})
                if ai_result["response_status"] == "INVALIDATED":
                    self.queued_action_invalidations.append(ai_result["queued_action_validity"])
                else:
                    ai_events = self._presentation_events(tuple(ai_result["presentation_events"]))
                    ai_impacts = self._settled_impact_events(ai_result["action_resolution"], max((x["sequence"] for x in ai_events), default=0))
                    intent = ai_result["intent"]; intent_sequence = max((x["sequence"] for x in combined_events), default=0) + 1
                    intent_label = self.configuration.action_display_label if self.configuration and self.configuration.action_display_label else intent["action_display_name"]
                    intent_event = {"sequence": intent_sequence, "event_type": "ENEMY_INTENT", "actor_id": intent["actor_id"], "action_id": intent["action_id"], "action_name": intent_label, "target_ids": tuple(intent["target_ids"]), "details": {"target_display_names": tuple(intent["target_display_names"]), "decision_authority": intent["decision_authority"], "decision_count": intent["decision_count"]}, "derivation": "FORMAL_AI_SELECTED_ACTION"}
                    combined_events += (intent_event,) + ai_events + ai_impacts; self.log.extend(self._presentation_log(ai_result["combat_log"], ai_events))
                    terminal_state = ai_result["action_resolution"]["terminal_state"]
            if terminal_state != "ACTIVE":
                self.terminal_result = terminal_state
                sequence = max((x["sequence"] for x in combined_events), default=0) + 1
                combined_events += ({"sequence": sequence, "event_type": "ENCOUNTER_TERMINATED", "actor_id": None, "action_id": None, "action_name": None, "target_ids": (), "details": {"terminal_state": terminal_state}, "derivation": "BATTLEENGINE_TERMINAL_TRUTH"},)
                self.log.append("【戰鬥勝利】" if terminal_state == "VICTORY" else "【戰鬥敗北】")
            self.feedback_generation += 1; self.settled_presentation_events = combined_events
            self.manual_response_sequence_active = False
            self.manual_control_authority_trace.append({"phase": "RESPONSE_SETTLEMENT_COMPLETE", "control_mode": self.effective_control_mode(),
                                                        "human_selected_auto": self.selected_control_mode == "AUTO_FRIENDLY_CONTROL"})
            self._latch_newly_defeated_targets(combined_events)
            # project_combat_presentation_flow is applied through _presentation_flow after all settlement.
            self.presentation_beats = self._presentation_flow(combined_events)
            self.presentation_index = 0; self.presentation_busy = True; self.ready_cue = False; self._apply_presentation_beat()
            self.last_error = None
            self.selected_action_id = None
        else:
            self.last_error = result.error_code
        return self.screen_state()

    def _settled_impact_events(self, resolution, start_sequence=0):
        if getattr(self.controller, "canonical_presentation", False):
            return ()  # WO092 outcomes already come from WO091 PresentationFrame.
        return presentation_events_from_action_resolution(resolution, start_sequence)

    def _presentation_events(self, events: tuple[dict[str, Any], ...]) -> tuple[dict[str, Any], ...]:
        """Relabel only developer-fixture presentation text, never settled action truth."""
        if not self.configuration or not self.configuration.action_display_label:
            return events
        return tuple({**event, "action_name": self.configuration.action_display_label}
                     if event.get("action_name") else event for event in events)

    def _presentation_log(self, lines: tuple[str, ...], events: tuple[dict[str, Any], ...]) -> tuple[str, ...]:
        if not self.configuration or not self.configuration.action_display_label:
            return lines
        original_names = {event.get("action_name") for event in events if event.get("action_name")}
        # The events are already relabelled; use the bound action definitions as the replacement source.
        raw_names = {candidate.display_name for participant in self.controller.participants.values()
                     for candidate in self.controller.service.enumerate_actions(participant.bound)}
        return tuple(self.configuration.action_display_label if line in raw_names else
                     self._replace_action_names(line, raw_names) for line in lines)

    def _replace_action_names(self, line: str, raw_names: set[str]) -> str:
        for raw_name in raw_names:
            line = line.replace(raw_name, self.configuration.action_display_label)  # type: ignore[union-attr]
        return line

    def end_battle(self, result: str) -> dict[str, Any]:
        self.terminal_result = result; self.terminal_visible = result
        return self.screen_state()


class TkBattleScreen:
    """Game-facing 2D renderer. Widgets never inspect or mutate runtime state."""
    def __init__(self, root: Any, workspace: str | Path,
                 configuration: BattleScreenConfiguration | None = None,
                 external_art_package: str | Path | None = None,
                 external_art_targets: tuple[str, ...] = ("player",),
                 external_art_secondary_package: str | Path | None = None,
                 debug_art_overlay: bool = False,
                 external_art_motion_pilot: bool = False,
                 external_art_rotation_pilot: bool = False,
                 dev_presentation_slowdown: float = 1.0,
                 external_weapon_package: str | Path | None = None,
                 external_weapon_secondary_package: str | Path | None = None,
                 external_background_package: str | Path | None = None):
        import tkinter as tk
        from tkinter import ttk
        self.tk, self.ttk, self.root = tk, ttk, root
        self.configuration = configuration
        self.external_art_package: CharacterArtLayerPackage | None = (
            load_character_art_layer_package(external_art_package, allow_prototype=True)
            if external_art_package else None)
        if self.external_art_package and not self.external_art_package.loadable:
            raise ValueError("EXTERNAL_ART_PACKAGE_INVALID:" + "|".join(self.external_art_package.errors))
        self.external_art_targets = frozenset(external_art_targets)
        self.external_art_secondary_package: CharacterArtLayerPackage | None = (
            load_character_art_layer_package(external_art_secondary_package, allow_prototype=True)
            if external_art_secondary_package else None)
        if self.external_art_secondary_package and not self.external_art_secondary_package.loadable:
            raise ValueError("EXTERNAL_ART_SECONDARY_PACKAGE_INVALID:" + "|".join(self.external_art_secondary_package.errors))
        self.external_weapon_package: WeaponArtLayerPackage | None = (
            load_weapon_art_layer_package(external_weapon_package, allow_prototype=True)
            if external_weapon_package else None)
        if self.external_weapon_package and not self.external_weapon_package.loadable:
            raise ValueError("EXTERNAL_WEAPON_PACKAGE_INVALID:" + "|".join(self.external_weapon_package.errors))
        self.external_weapon_secondary_package: WeaponArtLayerPackage | None = (
            load_weapon_art_layer_package(external_weapon_secondary_package, allow_prototype=True)
            if external_weapon_secondary_package else None)
        if self.external_weapon_secondary_package and not self.external_weapon_secondary_package.loadable:
            raise ValueError("EXTERNAL_WEAPON_SECONDARY_PACKAGE_INVALID:" + "|".join(self.external_weapon_secondary_package.errors))
        if (self.external_weapon_package or self.external_weapon_secondary_package) and not self.external_art_package:
            raise ValueError("EXTERNAL_WEAPON_REQUIRES_EXTERNAL_ART_PACKAGE")
        self.external_background_package: BackgroundArtPackage | None = (
            load_background_art_package(external_background_package, allow_prototype=True)
            if external_background_package else None)
        if self.external_background_package and not self.external_background_package.loadable:
            raise ValueError("EXTERNAL_BACKGROUND_PACKAGE_INVALID:" + "|".join(self.external_background_package.errors))
        self.debug_art_overlay = debug_art_overlay
        self.external_art_motion_pilot = bool(external_art_motion_pilot)
        self.external_art_rotation_pilot = bool(external_art_rotation_pilot)
        self.dev_presentation_slowdown = max(1.0, float(dev_presentation_slowdown))
        self._external_art_images: dict[tuple[str, str, str], Any] = {}
        self._external_art_bboxes: dict[tuple[str, ...], tuple[int, int, int, int]] = {}
        self._external_background_images: dict[tuple[str, int, int], Any] = {}
        self._auto_callback_generation = None
        session_factory = configuration.session_factory if configuration and configuration.session_factory else BattleScreenSession
        self.session = session_factory(workspace, configuration=configuration)
        root.title(configuration.window_title if configuration and configuration.window_title else "武俠自動戰鬥核心 — 戰鬥原型")
        if self.external_art_package:
            target_label = "BOTH" if len(self.external_art_targets) > 1 else next(iter(self.external_art_targets)).upper()
            root.title(f"武俠自動戰鬥核心 — {self.external_art_package.package_id} {target_label}")
        root.geometry("1280x800"); root.minsize(1040, 680)
        self._configure_styles()
        self.header = ttk.Frame(root, style="Header.TFrame"); self.header.pack(fill="x")
        self.header_title = ttk.Label(self.header, style="HeaderTitle.TLabel"); self.header_title.pack(side="left", padx=18, pady=12)
        self.header_round = ttk.Label(self.header, style="HeaderRound.TLabel"); self.header_round.pack(side="left", padx=18)
        self.header_banner = ttk.Label(self.header, style="HeaderRound.TLabel")
        if configuration and configuration.dev_banner:
            self.header_banner.config(text=configuration.dev_banner, wraplength=configuration.dev_banner_wraplength)
            self.header_banner.pack(side="left", padx=8)
        elif self.external_art_package:
            lifecycle = ("GAME READY ART" if self.external_art_package.status == AssetStatus.PRODUCTION_READY.value
                         else "DEV PROTOTYPE ART")
            weapon_label = (f" + {self.external_weapon_package.package_id}"
                            if self.external_weapon_package else "")
            self.header_banner.config(text=f"{lifecycle}｜{self.external_art_package.package_id}{weapon_label}")
            self.header_banner.pack(side="left", padx=8)
        ttk.Button(self.header, text="重置戰鬥", command=self._reset).pack(side="right", padx=18)
        self.auto_button = ttk.Button(self.header, text="AUTO: OFF", command=self._toggle_auto)
        self.auto_button.pack(side="right", padx=6)
        self.speed_button = ttk.Button(self.header, text="SPEED: 1×", command=self._toggle_speed)
        if configuration and configuration.enable_presentation_speed_control:
            self.speed_button.pack(side="right", padx=6)
        self.body = ttk.Frame(root, padding=12); self.body.pack(fill="both", expand=True)
        self.render()

    def _configure_styles(self):
        style = self.ttk.Style(self.root)
        style.configure("Header.TFrame", background="#20252b")
        style.configure("HeaderTitle.TLabel", background="#20252b", foreground="#f1d49a", font=("Microsoft JhengHei UI", 16, "bold"))
        style.configure("HeaderRound.TLabel", background="#20252b", foreground="#ffffff", font=("Microsoft JhengHei UI", 12))
        style.configure("Section.TLabelframe.Label", font=("Microsoft JhengHei UI", 11, "bold"))
        style.configure("Card.TButton", font=("Microsoft JhengHei UI", 11), padding=10)
        style.configure("Selected.Card.TButton", font=("Microsoft JhengHei UI", 11, "bold"), padding=10, foreground="#8b0000")
        style.configure("Action.TButton", font=("Microsoft JhengHei UI", 11, "bold"), padding=8)
        style.configure("Intent.TLabel", foreground="#8a4f08", font=("Microsoft JhengHei UI", 11, "bold"), padding=5, relief="solid", borderwidth=1)

    def _reset(self): self._auto_callback_generation = None; self.session.reset(); self.render()
    def _toggle_auto(self):
        state = self.session.screen_state()
        enable = not state["human_auto_selected"]
        state = self.session.request_auto(enable); self.render()
        if self.session.should_auto_continue(state["feedback_generation"]):
            self._schedule_ally_only_cycle(state["feedback_generation"])
    def _toggle_speed(self):
        speed = 2.0 if self.session.presentation_speed_multiplier == 1.0 else 1.0
        self.session.set_presentation_speed(speed); self.render()
    def _delay(self, base_duration_ms):
        return round(scale_presentation_delay(base_duration_ms, self.session.presentation_speed_multiplier)
                     * getattr(self, "dev_presentation_slowdown", 1.0))
    def _action(self, aid): self.session.select_action(aid); self.render()
    def _target(self, tid): self.session.select_target(tid); self.render()
    def _body_target(self, tid): self.session.select_target(tid); self.render()
    def _submit(self):
        state = self.session.submit(); self.render()
        if state["presentation_busy"]: self._play_current_beat(state["feedback_generation"])

    def _play_current_beat(self, generation):
        beat = self.session.current_presentation_beat()
        if beat is None: return
        try:
            if not self.root.winfo_exists(): return
            if beat.kind == PresentationBeatKind.ATTACK_MOTION:
                self.root.after(self._delay(MOTION_LEAD_IN_MS), lambda token=generation: self._advance_approach(token, 1))
            elif beat.kind == PresentationBeatKind.IMPACT_FEEDBACK:
                self.root.after(self._delay(IMPACT_RISE_DELAY_MS), lambda token=generation: self._rise_impact(token))
                self.root.after(self._delay(beat.duration_ms), lambda token=generation: self._advance_retreat(token, 1))
            elif beat.kind == PresentationBeatKind.CONTROL_READY:
                self.root.after(self._delay(beat.duration_ms), lambda token=generation: self._finish_flow(token))
            elif beat.kind == PresentationBeatKind.ENCOUNTER_CLOSURE:
                return
            elif beat.kind == PresentationBeatKind.TARGET_REACTION:
                next_kind = self.session.presentation_beats[self.session.presentation_index + 1].kind if self.session.presentation_index + 1 < len(self.session.presentation_beats) else None
                callback = self._next_beat if next_kind == PresentationBeatKind.IMPACT_FEEDBACK else lambda token: self._advance_retreat(token, 1)
                self.root.after(self._delay(beat.duration_ms + BEAT_GAP_MS), lambda token=generation, fn=callback: fn(token))
            else:
                self.root.after(self._delay(beat.duration_ms + BEAT_GAP_MS), lambda token=generation: self._next_beat(token))
        except self.tk.TclError: return

    def _rise_impact(self, generation):
        if not self.session.rise_impact(generation): return
        try:
            if self.root.winfo_exists(): self.render()
        except self.tk.TclError: return

    def _next_beat(self, generation):
        if not self.session.advance_presentation(generation):
            self.session.finish_presentation(generation)
            auto_continue = self.session.should_auto_continue(generation)
            try:
                if self.root.winfo_exists(): self.render()
            except self.tk.TclError: return
            if auto_continue: self._schedule_ally_only_cycle(self.session.feedback_generation)
            return
        try:
            if not self.root.winfo_exists(): return
            self.render(); self._play_current_beat(generation)
        except self.tk.TclError: return

    def _finish_flow(self, generation):
        if not self.session.finish_presentation(generation): return
        try:
            if self.root.winfo_exists():
                self.render()
                if self.session.should_auto_continue(generation): self._schedule_ally_only_cycle(self.session.feedback_generation)
        except self.tk.TclError: return

    def _schedule_ally_only_cycle(self, generation):
        if self._auto_callback_generation == generation: return
        self._auto_callback_generation = generation
        try:
            self.root.after(self._delay(180), lambda token=generation: self._run_ally_only_cycle(token))
        except self.tk.TclError: return

    def _run_ally_only_cycle(self, generation):
        if self._auto_callback_generation != generation: return
        self._auto_callback_generation = None
        if not self.session.should_auto_continue(generation): return
        state = self.session.continue_auto_cycle(); self.render()
        if state["presentation_busy"]: self._play_current_beat(state["feedback_generation"])

    def _advance_motion(self, generation, step):
        if not self.session.advance_motion(generation, step): return
        try:
            if not self.root.winfo_exists(): return
            self.render()
            if step < 3:
                self.root.after(self._delay(MOTION_STEP_DELAYS_MS[step]), lambda token=generation, next_step=step + 1: self._advance_motion(token, next_step))
            else:
                beat = self.session.current_presentation_beat()
                callback = self._next_beat if beat and beat.kind == PresentationBeatKind.ATTACK_MOTION else self._clear_feedback
                self.root.after(self._delay(MOTION_STEP_DELAYS_MS[step]), lambda token=generation, fn=callback: fn(token))
        except self.tk.TclError:
            return

    def _advance_approach(self, generation, step):
        if not self.session.advance_combat_translation(generation, "APPROACH", step): return
        try:
            if not self.root.winfo_exists(): return
            self.render()
            if step < 3:
                self.root.after(self._delay(APPROACH_STEP_DELAYS_MS[step]), lambda token=generation, next_step=step + 1: self._advance_approach(token, next_step))
            else:
                self.session.advance_combat_translation(generation, "CONTACT", 3)
                self.root.after(self._delay(APPROACH_STEP_DELAYS_MS[step]), lambda token=generation: self._advance_motion(token, 1))
        except self.tk.TclError: return

    def _advance_retreat(self, generation, step):
        if not self.session.advance_combat_translation(generation, "RETREAT", step): return
        try:
            if not self.root.winfo_exists(): return
            self.render()
            if step < 3:
                self.root.after(self._delay(RETREAT_STEP_DELAYS_MS[step]), lambda token=generation, next_step=step + 1: self._advance_retreat(token, next_step))
            else:
                self.session.combat_phase, self.session.combat_step = "STABLE", 0
                self.root.after(self._delay(RETREAT_STEP_DELAYS_MS[step]), lambda token=generation: self._next_beat(token))
        except self.tk.TclError: return

    def _activate_motion(self, generation):
        if not self.session.activate_motion(generation): return
        try:
            if self.root.winfo_exists():
                self.render(); self.root.after(self._delay(MOTION_HOLD_MS), lambda token=generation: self._clear_feedback(token))
        except self.tk.TclError:
            return

    def _clear_feedback(self, generation):
        if not self.session.clear_feedback(generation): return
        try:
            if self.root.winfo_exists(): self.render()
        except self.tk.TclError:
            return

    def render(self):
        for widget in self.body.winfo_children(): widget.destroy()
        state = self.session.screen_state(); model = build_2d_layout_model(state)
        auto_text = ("AUTO: STOPPING..." if state["pending_auto_off_request"] else
                     "ALLY AUTO｜玩家已倒下" if state["control_mode"] == "ALLY_ONLY_AUTO_RESOLUTION" else
                     "AUTO: ON｜按此關閉" if state["control_mode"] != "MANUAL_PLAYER_CONTROL" else "AUTO: OFF｜按此開啟")
        self.auto_button.config(text=auto_text,
                                state="normal" if state["auto_toggle_enabled"] else "disabled")
        self.speed_button.config(text=f"SPEED: {state['presentation_speed_label']}", state="normal")
        action_weapon = (state["presentation_feedback"].get("attacker") or {}).get("action_weapon_presentation")
        presence = build_body_presence_model(model, action_weapon); player = state["player"]
        self.header_title.config(text=model["battle_status_text"]); self.header_round.config(text=model["round_text"])

        field_title = "戰場｜左側我方 · 右側敵方"
        if self.configuration and self.configuration.dev_banner:
            field_title += "｜開發用"
        field = self.ttk.LabelFrame(self.body, text=field_title, style="Section.TLabelframe", padding=12)
        field.pack(fill="both", expand=True)
        ally_zone = self.ttk.Frame(field); ally_zone.grid(row=0, column=0, sticky="nsew", padx=(4, 12))
        center_zone = self.ttk.Frame(field); center_zone.grid(row=0, column=1, sticky="nsew")
        enemy_zone = self.ttk.Frame(field); enemy_zone.grid(row=0, column=2, sticky="nsew", padx=(12, 4))
        field.columnconfigure(0, weight=2); field.columnconfigure(1, weight=7); field.columnconfigure(2, weight=3); field.rowconfigure(0, weight=1)
        self.ttk.Label(ally_zone, text="我方", font=("Microsoft JhengHei UI", 13, "bold")).pack(anchor="w")
        self.ttk.Label(center_zone, text="交戰區｜角色位置僅供視覺呈現", foreground="#777777").pack()
        flow_text = ("戰鬥已結束｜請重置戰鬥" if state["terminal_result"] else
                     ("隊友續戰中｜玩家已倒下" if state["ally_only_mode"] else
                     ("AUTO 戰鬥中｜友方自動行動" if state["control_mode"] == "AUTO_FRIENDLY_CONTROL" else
                     ("可行動｜請選擇招式" if state["ready_cue"] else ("戰鬥演出中｜指令已結算" if state["presentation_busy"] else "請選擇招式與目標")))))
        self.ttk.Label(center_zone, text=flow_text, foreground="#25703a" if state["ready_cue"] else "#8a5a12",
                       font=("Microsoft JhengHei UI", 10, "bold")).pack()
        self.ttk.Label(enemy_zone, text="敵方｜點擊角色選擇目標", font=("Microsoft JhengHei UI", 13, "bold")).pack(anchor="e")
        for ally in model["allies"]:
            text = f"{ally['display_name']}\nHP {ally['hp_current']}/{ally['hp_max']}\n{'存活' if ally['alive'] else '已倒下'}"
            self.ttk.Label(ally_zone, text=text, anchor="center", relief="ridge", padding=10, font=("Microsoft JhengHei UI", 10)).pack(fill="x", pady=18)
        for enemy in model["enemies"]:
            vital = enemy["vital_hud"]; shield_line = f"\n{vital['shield_text']}" if vital["shield_visible"] else ""
            text = f"{enemy['target_marker']}\n○  {enemy['display_name']}\n{enemy['hp_text']}　{enemy['life_text']}{shield_line}"
            card = self.ttk.Frame(enemy_zone); card.pack(fill="x", pady=5)
            button = self.ttk.Button(card, text=text, style="Selected.Card.TButton" if enemy["selected"] else "Card.TButton", state="normal" if enemy["selectable"] else "disabled", command=lambda tid=enemy["character_id"]: self._target(tid))
            button.pack(fill="x")
            self.ttk.Progressbar(card, maximum=100, value=vital["hp_ratio"] * 100, length=155).pack(fill="x", padx=4, pady=(1, 0))
            if enemy["intent"]:
                intent = enemy["intent"]
                self.ttk.Label(card, text=f"準備：{intent['action_display_name']}\n目標：{'、'.join(intent['target_display_names'])}",
                               style="Intent.TLabel", anchor="w", justify="left").pack(fill="x", padx=4, pady=(4, 1))
        canvas = self.tk.Canvas(center_zone, height=270, background="#e9e3d5", highlightthickness=1, highlightbackground="#8c806c")
        canvas.pack(fill="both", expand=True, pady=(5, 0))
        feedback = {**state["presentation_feedback"], "impact_rise_px": state["impact_rise_px"]}; poses = project_visual_poses(presence, state["presentation_pose_feedback"]); motion = project_motion_offsets(presence, feedback, state["motion_step"])
        canvas.bind("<Configure>", lambda _event, c=canvas, p=presence, f=feedback, v=poses, m=motion: self._draw_battlefield(c, p, f, v, m))

        lower = self.ttk.Panedwindow(self.body, orient="horizontal"); lower.pack(fill="both", expand=False, pady=(10, 0))
        state_box = self.ttk.LabelFrame(lower, text="玩家狀態", style="Section.TLabelframe", padding=9); lower.add(state_box, weight=3)
        action_box = self.ttk.LabelFrame(lower, text="招式操作", style="Section.TLabelframe", padding=9); lower.add(action_box, weight=3)
        log_box = self.ttk.LabelFrame(lower, text="戰鬥紀錄", style="Section.TLabelframe", padding=6); lower.add(log_box, weight=4)
        if player:
            player_vital = model["allies"][0]["vital_hud"]
            self.ttk.Label(state_box, text=f"{player['display_name']}　{player_vital['hp_text']}　Qi {player['qi']}　{player_vital['shield_text']}", font=("Microsoft JhengHei UI", 10, "bold")).pack(anchor="w")
            self.ttk.Progressbar(state_box, maximum=100, value=player_vital["hp_ratio"] * 100, length=240).pack(fill="x", pady=(2, 5))
            action_heading = "Sandbox Action" if self.configuration and self.configuration.formal_martial_status_label else "武學"
            self.ttk.Label(state_box, text=f"{action_heading}：{player['martial_name']}").pack(anchor="w", pady=(4, 2))
            if self.configuration and self.configuration.formal_martial_status_label:
                self.ttk.Label(state_box, text=f"Formal Martial：{self.configuration.formal_martial_status_label}", foreground="#8b1a1a").pack(anchor="w", pady=(0, 2))
            if self.configuration and self.configuration.character_motion_status_label:
                self.ttk.Label(state_box, text=f"Character Motion：{self.configuration.character_motion_status_label}", foreground="#285a72").pack(anchor="w", pady=(0, 2))
            if self.configuration and self.configuration.formal_action_set_status_label:
                self.ttk.Label(state_box, text=f"Formal Action Set：{self.configuration.formal_action_set_status_label}", foreground="#8b1a1a").pack(anchor="w", pady=(0, 2))
            if self.configuration and self.configuration.sandbox_action_set_status_label:
                self.ttk.Label(state_box, text=f"Sandbox Action Set：{self.configuration.sandbox_action_set_status_label}", foreground="#285a72").pack(anchor="w", pady=(0, 2))
            statuses = "　".join(f"[{x['display_name']} ×{x['remaining_duration']}]" for x in player["statuses"]) or "無"
            stances = "　".join(f"{x['display_name']}：{'啟動' if x['state'] == 'ACTIVE' else '未啟動'}" for x in player["stances"]) or "無"
            resources = "　".join(f"{x['display_name']} {x['current']} / {x['maximum'] if x['maximum'] is not None else '—'}" for x in player["resources"]) or "無"
            self.ttk.Label(state_box, text="狀態　" + statuses, wraplength=330).pack(anchor="w", pady=2)
            self.ttk.Label(state_box, text="架勢　" + stances, wraplength=330).pack(anchor="w", pady=2)
            self.ttk.Label(state_box, text="資源　" + resources, wraplength=330).pack(anchor="w", pady=2)
        for action in model["actions"]:
            row = self.ttk.Frame(action_box); row.pack(fill="x", pady=2)
            self.ttk.Button(row, text=action["display_name"], style="Action.TButton", state="normal" if action["enabled"] and not state["presentation_busy"] else "disabled", command=lambda aid=action["action_id"]: self._action(aid)).pack(side="left")
            if action["reason_display"]: self.ttk.Label(row, text="不可使用：" + action["reason_display"], wraplength=230).pack(side="left", padx=6)
        self.ttk.Button(action_box, text="施展選定招式", state="disabled" if state["submission_locked"] or state["presentation_busy"] else "normal", command=self._submit).pack(anchor="w", pady=(6, 0))
        if state["error"]: self.ttk.Label(action_box, text="命令未接受：" + state["error"], foreground="#a40000", wraplength=330).pack(anchor="w", pady=3)
        log = self.tk.Text(log_box, height=10, width=42, wrap="word", font=("Microsoft JhengHei UI", 9)); scroll = self.ttk.Scrollbar(log_box, command=log.yview)
        log.configure(yscrollcommand=scroll.set); scroll.pack(side="right", fill="y"); log.pack(side="left", fill="both", expand=True)
        log.insert("end", "\n".join(model["combat_log"]) or "戰鬥尚未開始。")
        log.see("end"); log.config(state="disabled")

    def _draw_battlefield(self, canvas, presence, feedback=None, poses=None, motion=None):
        """Render static placeholder bodies; this layer has no battle authority."""
        canvas.delete("all"); width = max(canvas.winfo_width(), 420); height = max(canvas.winfo_height(), 240)
        background_drawn = TkBattleScreen._draw_external_background(self, canvas, width, height)
        if not background_drawn:
            canvas.create_line(20, height - 24, width - 20, height - 24, fill="#aa9d85", width=2)
            canvas.create_text(width / 2, 18, text="交戰區", fill="#8a806f", font=("Microsoft JhengHei UI", 9))
        poses = poses or project_visual_poses(presence, feedback or project_combat_feedback(()))
        pose_by_id = {body["character_id"]: body for body in poses["bodies"]}
        motion = motion or project_motion_offsets(presence, feedback or project_combat_feedback(()), 0)
        offset_by_id = {item["combatant_id"]: item for item in motion["offsets"]}
        for body in presence["bodies"]:
            anchor_x, anchor_y = width * body["x_ratio"], height * body["y_ratio"]
            offset = offset_by_id[body["character_id"]]
            pose_x = anchor_x + offset["dx"]
            pose_y = anchor_y + offset["dy"]
            x = pose_x + width * offset.get("combat_dx_ratio", 0.0)
            y = pose_y + height * offset.get("combat_dy_ratio", 0.0)
            tag = "body-" + body["character_id"]; selected = body["selected"]; alive = body["alive"]
            color = "#345f75" if body["side"] == "ally" else "#7a3f3f"; color = color if alive else "#777777"
            outline = "#c33131" if selected else color; line_width = 4 if selected else 2
            canvas.create_oval(anchor_x - 34, anchor_y + 52, anchor_x + 34, anchor_y + 64, outline=outline, width=line_width, tags=(tag, "slot-base"))
            contact = motion.get("contact_contract", {})
            layer_phase = "HIT" if offset["event_pose"] == "HIT" else contact.get("phase", "STABLE")
            layer_step = contact.get("step", offset["step"])
            layer_role = "attacker" if offset["attack_motion"] else ("target" if offset["event_pose"] == "HIT" else "idle")
            if TkBattleScreen._draw_external_art(self, canvas, body, tag, x, y,
                                                  layer_phase, layer_step, layer_role):
                canvas.create_text(x, y + 78, text=body["display_name"], fill="#222222", font=("Microsoft JhengHei UI", 10, "bold"), tags=(tag, "body-label"))
                canvas.create_text(x, y - 72, text=body["marker"], fill="#a41414" if selected else color, font=("Microsoft JhengHei UI", 9, "bold"), tags=(tag, "body-marker"))
                if body["side"] == "enemy" and body["selectable"]:
                    canvas.tag_bind(tag, "<Button-1>", lambda _event, tid=body["character_id"]: self._body_target(tid))
                    canvas.tag_bind(tag, "<Enter>", lambda _event, c=canvas: c.configure(cursor="hand2"))
                    canvas.tag_bind(tag, "<Leave>", lambda _event, c=canvas: c.configure(cursor=""))
                continue
            geometry = pose_by_id[body["character_id"]]["geometry"]
            if offset["attack_motion"] and offset["step"] > 0:
                geometry = attack_motion_geometry(offset["attack_motion"], body["facing"], offset["step"], body["weapon_hint"], body.get("body_profile_id", "STANDARD"), body.get("character_motion_profile"))
            p = geometry["points"]
            pt = lambda name: (x + p[name][0], y + p[name][1])
            appearance = resolve_appearance_geometry(geometry, body.get("appearance_profile", body.get("appearance_profile_id")))
            self._draw_appearance_layers(canvas, tag, appearance, x, y, ("BACK_HAIR",))
            hx, hy = pt("head"); sx, sy = pt("shoulder"); hipx, hipy = pt("hip")
            head_radius = 11 * geometry.get("head_scale", 1.0); thickness = geometry.get("limb_thickness_scale", 1.0)
            canvas.create_oval(hx - head_radius, hy - head_radius, hx + head_radius, hy + head_radius, fill="#f0d2ad" if alive else "#aaaaaa", outline=color, width=2, tags=(tag, "body-shape", "pose-" + geometry["pose"]))
            canvas.create_line(sx, sy, hipx, hipy, fill=color, width=max(4, round(7 * thickness)), tags=(tag, "body-shape", "pose-" + geometry["pose"]))
            if "shoulder_back" in p and "hip_back" in p:
                # The crossing shoulder/hip axes make an unarmed power strike read as torso rotation.
                canvas.create_line(*pt("shoulder_back"), sx, sy, fill=color, width=max(3, round(6 * thickness)), tags=(tag, "body-shape", "torso-rotation"))
                canvas.create_line(*pt("hip_back"), hipx, hipy, fill=color, width=max(3, round(5 * thickness)), tags=(tag, "body-shape", "torso-rotation"))
                canvas.create_line(*pt("shoulder_back"), *pt("hip_back"), fill=color, width=max(2, round(4 * thickness)), tags=(tag, "body-shape", "torso-rotation"))
            arm_width = max(3, round(4 * thickness)); leg_width = max(3, round(5 * thickness))
            canvas.create_line(sx, sy, *pt("elbow_front"), *pt("hand_front"), fill=color, width=arm_width, tags=(tag, "body-shape"))
            canvas.create_line(*pt("shoulder_back") if "shoulder_back" in p else (sx, sy), *pt("elbow_back"), *pt("hand_back"), fill=color, width=arm_width, tags=(tag, "body-shape"))
            canvas.create_line(hipx, hipy, *pt("knee_front"), *pt("foot_front"), fill=color, width=leg_width, tags=(tag, "body-shape"))
            canvas.create_line(*pt("hip_back") if "hip_back" in p else (hipx, hipy), *pt("knee_back"), *pt("foot_back"), fill=color, width=leg_width, tags=(tag, "body-shape"))
            self._draw_appearance_layers(canvas, tag, appearance, x, y,
                                         ("LOWER_GARMENT", "UPPER_GARMENT", "SLEEVES", "WAIST", "FOOTWEAR"))
            silhouette = project_weapon_silhouette(body.get("current_weapon_visual_family", body.get("martial_family")))
            weapon = weapon_canvas_geometry(silhouette, pt("primary_hand_socket"), pt("weapon_end"), pt("off_hand_socket"), geometry["pose"], (pt("elbow_front"), pt("elbow_back")))
            self._draw_weapon_silhouette(canvas, tag, weapon)
            self._draw_appearance_layers(canvas, tag, appearance, x, y, ("FRONT_HAIR", "HEAD_ACCESSORY"))
            canvas.create_text(x, y + 78, text=body["display_name"], fill="#222222", font=("Microsoft JhengHei UI", 10, "bold"), tags=(tag, "body-label"))
            canvas.create_text(x, y - 72, text=body["marker"], fill="#a41414" if selected else color, font=("Microsoft JhengHei UI", 9, "bold"), tags=(tag, "body-marker"))
            if geometry["pose"] == VisualPose.DEFEATED.value:
                canvas.create_line(x - 25, y - 50, x + 25, y + 45, fill="#991f1f", width=4, tags=(tag, "defeated-overlay"))
                canvas.create_line(x + 25, y - 50, x - 25, y + 45, fill="#991f1f", width=4, tags=(tag, "defeated-overlay"))
                canvas.create_text(x, y, text="已倒下", fill="#ffffff", font=("Microsoft JhengHei UI", 9, "bold"), tags=(tag, "defeated-label"))
            if body["side"] == "enemy" and body["selectable"]:
                canvas.tag_bind(tag, "<Button-1>", lambda _event, tid=body["character_id"]: self._body_target(tid))
                canvas.tag_bind(tag, "<Enter>", lambda _event, c=canvas: c.configure(cursor="hand2"))
                canvas.tag_bind(tag, "<Leave>", lambda _event, c=canvas: c.configure(cursor=""))
        feedback = feedback or project_combat_feedback(())
        by_id = {body["character_id"]: body for body in presence["bodies"]}
        attacker = feedback["attacker"]
        if attacker and attacker["actor_id"] in by_id:
            body = by_id[attacker["actor_id"]]; translated = offset_by_id.get(attacker["actor_id"], {})
            x = width * (body["x_ratio"] + translated.get("combat_dx_ratio", 0.0))
            y = height * (body["y_ratio"] + translated.get("combat_dy_ratio", 0.0))
            canvas.create_oval(x - 43, y - 64, x + 43, y + 67, outline="#e29b17", width=4, tags=("feedback-overlay",))
            canvas.create_text(x, y - 88, text=f"{body['display_name']}出手｜{attacker['action_name']}", fill="#9a5b00", font=("Microsoft JhengHei UI", 10, "bold"), tags=("feedback-overlay",))
        cue_colors = {"ATTACK_RESOLVED": "#a11b1b", "DODGE": "#176c91", "PARRY": "#6c4a91", "DEFEATED": "#991f1f"}
        for cue in feedback["targets"]:
            body = by_id.get(cue["target_id"])
            if not body: continue
            x, y = width * body["x_ratio"], height * body["y_ratio"]
            canvas.create_text(x + (-48 if body["side"] == "enemy" else 48), y - 10, text=cue["text"], fill=cue_colors[cue["event_type"]], font=("Microsoft JhengHei UI", 12, "bold"), tags=("feedback-overlay",))
        impact_colors = {"HP_DAMAGE": "#a11b1b", "SHIELD_ABSORB": "#236a91", "ZERO_DAMAGE": "#555555",
                         "DODGE": "#176c91", "PARRY": "#6c4a91", "DEFEATED": "#991f1f"}
        impact_rows = {}
        for impact in feedback.get("impacts", ()):
            body = by_id.get(impact["target_id"])
            if not body: continue
            row = impact_rows.get(impact["target_id"], 0); impact_rows[impact["target_id"]] = row + 1
            anchor_x, anchor_y = width * body["x_ratio"], height * body["y_ratio"]
            rise = feedback.get("impact_rise_px", 0)
            canvas.create_text(anchor_x + (50 if body["side"] == "enemy" else -50), anchor_y - 42 - row * 18 - rise,
                               text=impact["text"], fill=impact_colors[impact["kind"]], font=("Microsoft JhengHei UI", 13, "bold"),
                               tags=("impact-feedback", "feedback-overlay", "body-" + impact["target_id"]))
        actor_lines = {}
        for cue in feedback["actor_cues"]: actor_lines.setdefault(cue["actor_id"], []).append(cue["text"])
        for actor_id, lines in actor_lines.items():
            body = by_id.get(actor_id)
            if not body: continue
            x, y = width * body["x_ratio"], height * body["y_ratio"]
            canvas.create_text(x, y + 96, text="　".join(lines), fill="#356229", font=("Microsoft JhengHei UI", 9, "bold"), tags=("feedback-overlay",))
        terminal = feedback.get("terminal")
        if terminal:
            canvas.create_rectangle(width * .28, height * .34, width * .72, height * .66,
                                    fill="#f5ead0", outline="#8b652b", width=4, tags=("terminal-overlay",))
            canvas.create_text(width * .5, height * .5, text=terminal["text"],
                               fill="#8b1e1e" if terminal["state"] == "DEFEAT" else "#7a5514",
                               font=("Microsoft JhengHei UI", 26, "bold"), tags=("terminal-overlay",))

    def _draw_weapon_silhouette(self, canvas, combatant_tag, weapon):
        """Canvas-only family hint attached to the combatant's current hands."""
        tags = (combatant_tag, "weapon-silhouette", "weapon-" + weapon["silhouette"])
        for primitive in weapon["primitives"]:
            kind = primitive["kind"]
            if kind == "polygon":
                coords = [coordinate for point in primitive["points"] for coordinate in point]
                fill = "#736044" if weapon["silhouette"] == "BLADE" else "#d4d7d9"
                canvas.create_polygon(*coords, fill=fill, outline="#342f29", width=2, tags=tags)
            elif kind == "guard":
                cx, cy = primitive["center"]; px, py = primitive["perpendicular"]; half = primitive["width"] / 2
                canvas.create_line(cx - px * half, cy - py * half, cx + px * half, cy + py * half, fill="#3c3024", width=3, tags=tags)
            elif kind == "shaft":
                canvas.create_line(*primitive["start"], *primitive["end"], fill="#563d25", width=primitive["width"], tags=tags)
            elif kind == "tip":
                coords = [coordinate for point in primitive["points"] for coordinate in point]
                canvas.create_polygon(*coords, fill="#c8cccf", outline="#34383a", width=1, tags=tags)
            elif kind == "grip":
                cx, cy = primitive["center"]; radius = primitive["radius"]
                canvas.create_oval(cx - radius, cy - radius, cx + radius, cy + radius, fill="#d6aa7e", outline="#5c4433", width=1,
                                   tags=tags + ("spear-idle-grip", "grip-" + primitive["role"].lower()))
            elif kind == "forearm_bridge":
                canvas.create_line(*primitive["start"], *primitive["end"], fill="#d6aa7e", width=primitive["width"], capstyle="round", joinstyle="round",
                                   tags=tags + ("spear-idle-forearm-bridge", "bridge-" + primitive["role"].lower()))
            elif kind == "fist":
                cx, cy = primitive["center"]; radius = primitive["radius"]
                canvas.create_oval(cx - radius, cy - radius, cx + radius, cy + radius, fill="#d6aa7e", outline="#5c4433", width=2, tags=tags)

    def _draw_appearance_layers(self, canvas, combatant_tag, appearance, origin_x, origin_y, layers):
        """Formal screen capability delegates to the shared production appearance renderer."""
        draw_appearance_layers(canvas, combatant_tag, appearance, origin_x, origin_y, layers)

    def _external_package_for_body(self, body):
        package = getattr(self, "external_art_package", None)
        secondary = getattr(self, "external_art_secondary_package", None)
        targets = getattr(self, "external_art_targets", frozenset())
        if body["character_id"] not in targets:
            return None
        return secondary if secondary and body["character_id"] == "enemy-center" else package

    def _external_weapon_package_for_body(self, body):
        package = getattr(self, "external_weapon_package", None)
        secondary = getattr(self, "external_weapon_secondary_package", None)
        targets = getattr(self, "external_art_targets", frozenset())
        if body["character_id"] not in targets:
            return None
        return secondary if secondary and body["character_id"] == "enemy-center" else package

    def _external_photo(self, package, layer: str, facing: str):
        key = (str(package.package_root), layer, facing)
        return TkBattleScreen._external_photo_from_source(self, package.layers[layer], key, facing)

    def _external_photo_from_source(self, source_path, key, facing: str):
        if key in self._external_art_images:
            return self._external_art_images[key]
        source = self.tk.PhotoImage(file=str(source_path))
        scaled = source.subsample(2, 2)
        if facing == "left":
            mirrored = self.tk.PhotoImage(width=scaled.width(), height=scaled.height())
            mirrored.tk.call(mirrored, "copy", scaled, "-from", 0, 0, scaled.width(), scaled.height(),
                             "-to", 0, 0, "-subsample", -1, 1)
            photo = mirrored
        else:
            photo = scaled
        self._external_art_images[key] = photo
        return photo

    def _external_motion_photo(self, package, layer: str, facing: str,
                               motion_phase: str, motion_step: int):
        rotation_enabled = (getattr(self, "external_art_rotation_pilot", False)
                            or getattr(package, "status", None) == AssetStatus.PRODUCTION_READY.value)
        if rotation_enabled:
            source = prebaked_rotation_frame_path(package.package_root, layer, motion_phase, motion_step)
            if source is None:
                source = prebaked_weapon_motion_frame_path(
                    package.package_root, layer, motion_phase, motion_step)
            if source is not None and source.exists():
                key = (str(source), layer, facing)
                return TkBattleScreen._external_photo_from_source(self, source, key, facing)
        return TkBattleScreen._external_photo(self, package, layer, facing)

    def _external_visible_bbox(self, package, facing: str, weapon_package=None):
        key = (str(package.package_root), str(getattr(weapon_package, "package_root", "")), facing)
        if key in self._external_art_bboxes:
            return self._external_art_bboxes[key]
        composite = self.tk.PhotoImage(width=192, height=128)
        for layer in CLOTHING_LAYER_STACK:
            if weapon_package and layer in WEAPON_LAYER_STACK:
                if layer not in weapon_package.layers:
                    continue
                layer_package = weapon_package
            else:
                layer_package = package
            composite.tk.call(composite, "copy", self._external_photo(layer_package, layer, facing),
                              "-to", 0, 0, "-compositingrule", "overlay")
        visible = [(x, y) for y in range(128) for x in range(192)
                   if not int(composite.tk.call(composite, "transparency", "get", x, y))]
        bbox = (min(x for x, _ in visible), min(y for _, y in visible),
                max(x for x, _ in visible) + 1, max(y for _, y in visible) + 1)
        self._external_art_bboxes[key] = bbox
        return bbox

    def _draw_external_art(self, canvas, body, tag, root_x: float, root_y: float,
                           motion_phase: str = "IDLE", motion_step: int = 0,
                           motion_role: str = "idle") -> bool:
        """Draw the unchanged v1 layer package on the current stable/motion root."""
        package = TkBattleScreen._external_package_for_body(self, body)
        if not package:
            return False
        weapon_package = TkBattleScreen._external_weapon_package_for_body(self, body)
        # Logical canvas is displayed at 1/2 scale. Its ground anchor maps to the
        # existing procedural ground point (root + 60 px), preserving all motion.
        center_x = root_x
        center_y = root_y + 20
        motion_enabled = (getattr(self, "external_art_motion_pilot", False)
                          or getattr(package, "status", None) == AssetStatus.PRODUCTION_READY.value)
        offsets = (project_layer_motion_offsets(motion_phase, motion_step, body["facing"], motion_role)
                   if motion_enabled
                   else {layer: (0, 0) for layer in CLOTHING_LAYER_STACK})
        for layer in CLOTHING_LAYER_STACK:
            if weapon_package and layer in WEAPON_LAYER_STACK:
                if layer not in weapon_package.layers:
                    continue
                layer_package = weapon_package
            else:
                layer_package = package
            photo = TkBattleScreen._external_motion_photo(self, layer_package, layer, body["facing"],
                                                           motion_phase, motion_step)
            layer_dx, layer_dy = offsets[layer]
            if weapon_package and layer == "front_weapon":
                layer_dx, layer_dy = offsets["front_arm_clothing"]
            elif weapon_package and layer == "rear_weapon":
                layer_dx, layer_dy = offsets["rear_arm_clothing"]
            canvas.create_image(center_x + layer_dx, center_y + layer_dy, image=photo,
                                tags=(tag, "external-character-art", "external-layer-" + layer))
        if getattr(self, "debug_art_overlay", False):
            left, top = center_x - 96, center_y - 64
            bx0, by0, bx1, by1 = TkBattleScreen._external_visible_bbox(
                self, package, body["facing"], weapon_package)
            canvas.create_rectangle(left, top, left + 192, top + 128, outline="#00a7c7", dash=(5, 3), width=2,
                                    tags=(tag, "debug-art-overlay"))
            canvas.create_rectangle(left + bx0, top + by0, left + bx1, top + by1, outline="#ff2fb3", width=2,
                                    tags=(tag, "debug-art-overlay"))
            points = ((center_x, root_y + 60, "Ground/Pivot", "#00a33c"),
                      (center_x, root_y + 30, "Body Root", "#165dce"),
                      (center_x, root_y + 60, "Slot ground", "#ff8500"),
                      (center_x, root_y + 78, "Label base", "#d4a000"))
            for px, py, label, color in points:
                canvas.create_line(px - 6, py, px + 6, py, fill=color, width=2, tags=(tag, "debug-art-overlay"))
                canvas.create_line(px, py - 6, px, py + 6, fill=color, width=2, tags=(tag, "debug-art-overlay"))
                canvas.create_text(px + 9, py, text=label, anchor="w", fill=color,
                                   font=("Microsoft JhengHei UI", 8, "bold"), tags=(tag, "debug-art-overlay"))
            canvas.create_text(left, top - 10, text="Canvas 384×256 @ 1/2", anchor="w", fill="#007d96",
                               font=("Microsoft JhengHei UI", 8, "bold"), tags=(tag, "debug-art-overlay"))
            canvas.create_text(left + bx0, top + by0 - 10, text=f"Visible bbox {bx0},{by0}–{bx1},{by1}", anchor="w",
                               fill="#c00086", font=("Microsoft JhengHei UI", 8, "bold"), tags=(tag, "debug-art-overlay"))
        return True

    def _draw_external_background(self, canvas, width: int, height: int) -> bool:
        """Draw a presentation-only Cover background without changing battle geometry."""
        package = getattr(self, "external_background_package", None)
        if not package or not package.image_path:
            return False
        key = (str(package.image_path), width, height)
        images = getattr(self, "_external_background_images", {})
        photo = images.get(key)
        if photo is None:
            from PIL import Image, ImageTk
            with Image.open(package.image_path) as source:
                focal = tuple(package.metadata.get("focal_point", (0.5, 0.5)))
                crop = cover_crop_box(source.size, (width, height), focal)
                rendered = source.crop(crop).resize((width, height), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(rendered, master=canvas)
            images.clear()
            images[key] = photo
            self._external_background_images = images
        canvas.create_image(width / 2, height / 2, image=photo, tags=("battle-background",))
        if getattr(self, "debug_art_overlay", False):
            for name, zone in package.metadata.get("safe_zones", {}).items():
                x0, y0, x1, y1 = zone
                canvas.create_rectangle(x0 * width, y0 * height, x1 * width, y1 * height,
                                        outline="#55d6ff", dash=(4, 3), width=1,
                                        tags=("background-safe-zone",))
                canvas.create_text(x0 * width + 4, y0 * height + 4, text=name,
                                   anchor="nw", fill="#55d6ff",
                                   font=("Microsoft JhengHei UI", 8, "bold"),
                                   tags=("background-safe-zone",))
        return True


def main() -> None:
    import argparse, tkinter as tk
    parser = argparse.ArgumentParser(description="Launch the WO-043 2D battle layout")
    parser.add_argument("--workspace", default=".")
    parser.add_argument("--external-art-package")
    parser.add_argument("--external-art-secondary-package")
    parser.add_argument("--external-weapon-package")
    parser.add_argument("--external-weapon-secondary-package")
    parser.add_argument("--external-background-package")
    parser.add_argument("--external-art-target", choices=("player", "enemy-center", "both"), default="player")
    parser.add_argument("--debug-art-overlay", action="store_true")
    parser.add_argument("--external-art-motion-pilot", action="store_true")
    parser.add_argument("--external-art-rotation-pilot", action="store_true")
    parser.add_argument("--dev-presentation-slowdown", type=float, default=1.0)
    args = parser.parse_args()
    targets = ("player", "enemy-center") if args.external_art_target == "both" else (args.external_art_target,)
    root = tk.Tk(); TkBattleScreen(root, Path(args.workspace).resolve(), external_art_package=args.external_art_package,
                                  external_art_targets=targets,
                                  external_art_secondary_package=args.external_art_secondary_package,
                                  debug_art_overlay=args.debug_art_overlay,
                                  external_art_motion_pilot=args.external_art_motion_pilot,
                                  external_art_rotation_pilot=args.external_art_rotation_pilot,
                                  dev_presentation_slowdown=args.dev_presentation_slowdown,
                                  external_weapon_package=args.external_weapon_package,
                                  external_weapon_secondary_package=args.external_weapon_secondary_package,
                                  external_background_package=args.external_background_package); root.mainloop()


if __name__ == "__main__": main()

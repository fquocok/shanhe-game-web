"""Human-gated generated-content governance. This module is not battle runtime."""
from __future__ import annotations
from dataclasses import dataclass,asdict,replace
from typing import Any,Callable
import hashlib,json
from types import MappingProxyType
from .generator import (BATTLE_CORE_VERSION,CAPABILITY_REGISTRY_VERSION,CURRENT_MARTIAL_GENERATOR_VERSION,
 GeneratedMartialCandidate,GenerationTrace,MartialCandidateValidationReport,TIER_REGISTRY_VERSION,
 deserialize_candidate,deserialize_validation_report,serialize_candidate,serialize_validation_report,validate_candidate)
from .martial import (MartialActiveSkillDefinition,MartialRoutineDefinition,SourceProvenance,
 validate_martial_definition)

GENERATED_CONTENT_ACCEPTANCE_POLICY_VERSION="v0.1"
GENERATED_CONTENT_ACCEPTANCE_PIPELINE_VERSION="v0.1-prototype"
GENERATED_CONTENT_ACCEPTANCE_STATUS="GENERATED_CONTENT_ACCEPTANCE_V0_1_PROTOTYPE_OPERATIONAL"
REVIEW_STATUSES=frozenset({"PENDING_REVIEW","ACCEPTED_FOR_CANONICALIZATION","REJECTED","REVISION_REQUIRED","CANONICALIZATION_IN_PROGRESS","CANONICALIZATION_FAILED","PROMOTED_CANONICAL"})
DECISIONS=frozenset({"ACCEPT","REJECT","REQUEST_REVISION"})
PROMOTION_STATUSES=frozenset({"PROMOTED","DRY_RUN_SUCCEEDED","ALREADY_PROMOTED","REJECTED_NOT_ACCEPTED","BLOCKED_STALE_VALIDATION","BLOCKED_UNRESOLVED_CONTENT","BUILD_FAILED","COMPILE_FAILED","SMOKE_FAILED","REGRESSION_FAILED","ID_COLLISION","SEMANTIC_DRIFT","ACCEPTED_SNAPSHOT_MISMATCH"})
REVIEW_CHECKLIST=("TIER_IDENTITY","TOPOLOGY_IDENTITY","FAMILY_FIT","CAPABILITIES_SUPPORTED","TOKEN_BUDGET","OPEN_CORE","CONTENT_TBD","TUNING_TBD","TRIGGER_SEMANTICS","TARGETING_SEMANTICS","RESOURCE_ECOLOGY","STATUS_LIFECYCLE","SPECIAL_CAP","RNG","SIMILARITY","BUILD_DECISION")
SMOKE_TEST_CONTRACT=("DEFINITION_COMPILE","LOADOUT_ATTACH","BATTLE_INITIALIZATION","ACTION_CATALOG_REGISTRATION","BASIC_DETERMINISTIC_EXECUTION","SERIALIZATION_PROVENANCE")
AUDIT_EVENT_TYPES=("REVIEW_PACKAGE_CREATED","REVIEW_DECISION_RECORDED","REVISION_REQUESTED","CANONICALIZATION_STARTED","CANONICALIZATION_PREVIEWED","CANONICAL_BUILD_SUCCEEDED","CANONICAL_BUILD_FAILED","PROMOTION_REGRESSION_STARTED","PROMOTION_REGRESSION_PASSED","PROMOTION_REGRESSION_FAILED","CONTENT_PROMOTED")

def _canonical_json(value):return json.dumps(value,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def stable_hash(value):return hashlib.sha256((value if isinstance(value,str) else _canonical_json(value)).encode()).hexdigest()
def _json_value(value):return json.loads(_canonical_json(value))

@dataclass(frozen=True)
class ProposedCanonicalIdentity:
 family:str;tier:str;slug_suggestion:str;proposed_id:str;display_name:str|None=None;final_assignment:bool=False
@dataclass(frozen=True)
class RevisionRequest:
 field_path:str;reason:str;severity:str;desired_change_category:str
@dataclass(frozen=True)
class GeneratedContentReviewPackage:
 review_package_id:str;candidate_id:str;candidate_snapshot:str;candidate_content_hash:str;validation_snapshot:str;validation_report_hash:str;generation_trace:dict[str,Any];generator_version:str;generation_seed:int|str|None;request_id:str;template_id:str;family:str;tier:str;budget:int|None;topology_summary:dict[str,Any];capability_summary:tuple[str,...];token_audit:dict[str,Any];content_tbd_summary:tuple[str,...];tuning_tbd_summary:tuple[str,...];open_policy_dependencies:tuple[str,...];deferred_dependencies:tuple[str,...];similarity_summary:dict[str,Any];quality_warnings:tuple[str,...];risk_flags:tuple[str,...];proposed_identity:ProposedCanonicalIdentity;review_status:str="PENDING_REVIEW";created_at:str="FIXTURE_TIME";battle_core_version:str=BATTLE_CORE_VERSION;tier_registry_version:str=TIER_REGISTRY_VERSION;capability_registry_version:str=CAPABILITY_REGISTRY_VERSION;acceptance_policy_version:str=GENERATED_CONTENT_ACCEPTANCE_POLICY_VERSION
@dataclass(frozen=True)
class GeneratedContentReviewDecision:
 decision_id:str;review_package_id:str;decision:str;reviewer_identity:str;decision_timestamp:str;notes:str;requested_revisions:tuple[RevisionRequest,...];accepted_candidate_hash:str;accepted_validation_hash:str;supersedes_decision_id:str|None=None;test_fixture:bool=False
@dataclass(frozen=True)
class GeneratedAcceptedProvenance(SourceProvenance):
 origin:str="GENERATED_ACCEPTED";source_candidate_id:str="";source_review_package_id:str="";source_generation_request_id:str="";generation_seed:int|str|None=None;generator_version:str="";accepted_by:str="";acceptance_decision_id:str="";validation_baseline:str="";canonicalized_at:str="FIXTURE_TIME"
@dataclass(frozen=True)
class CanonicalizationPreview:
 candidate_id:str;proposed_canonical_id:str;semantic_diff:dict[str,Any];token_audit:dict[str,Any];topology_validation:str;capability_validation:str;runtime_compile_readiness:str;provenance:dict[str,Any];warnings:tuple[str,...];canonical:bool=False
@dataclass(frozen=True)
class GeneratedContentPromotionManifest:
 canonical_id:str;source_candidate:str;review_package_id:str;acceptance_decision_id:str;generator_version:str;battle_core_canonical_version:str;validation_hash:str;definition_hash:str;promotion_regression_baseline:str;promotion_date_metadata:str;registry_commit:bool
@dataclass(frozen=True)
class GeneratedContentPromotionResult:
 status:str;candidate_id:str;review_package_id:str;decision_id:str|None;canonical_id:str|None;compile_result:str;smoke_result:str;regression_result:str;registry_commit:bool;failure_codes:tuple[str,...];warnings:tuple[str,...];provenance:dict[str,Any];manifest:GeneratedContentPromotionManifest|None=None;preview:CanonicalizationPreview|None=None
@dataclass(frozen=True)
class GeneratedContentAcceptancePolicy:
 version:str=GENERATED_CONTENT_ACCEPTANCE_POLICY_VERSION;required_runtime_eligibility:tuple[str,...]=("READY_FOR_RUNTIME",);allow_content_tbd:bool=False;allow_first_pass_tuning:bool=True;require_full_regression:bool=True
@dataclass(frozen=True)
class GeneratedContentRegressionPolicy:
 focused_compile:bool=True;candidate_specific:bool=True;family_regression:bool=True;full_regression:bool=True
@dataclass(frozen=True)
class GovernanceAuditEvent:
 event_id:str;event_type:str;subject_id:str;metadata:dict[str,Any];timestamp:str
@dataclass(frozen=True)
class RevisedCandidateLineage:
 candidate_id:str;parent_candidate_id:str;revision_number:int

class GeneratedContentAcceptanceLedger:
 """Append-only governance records, deliberately separate from runtime registry."""
 def __init__(self):self._events=();self._decisions=();self._promotions=()
 @property
 def events(self):return self._events
 @property
 def decisions(self):return self._decisions
 @property
 def promotions(self):return self._promotions
 def append_event(self,event):self._events=self._events+(event,)
 def append_decision(self,decision):self._decisions=self._decisions+(decision,)
 def append_promotion(self,result):self._promotions=self._promotions+(result,)

GENERATED_CONTENT_ACCEPTANCE_LEDGER=GeneratedContentAcceptanceLedger()
FORMAL_GENERATED_MARTIAL_REGISTRY={}

def evaluate_acceptance_numeric_budget(candidate,**kwargs):
 """Evaluate the numeric budget without weakening any acceptance precondition."""
 from .numeric_token_valuation import evaluate_candidate_numeric_budget
 return evaluate_candidate_numeric_budget(candidate,**kwargs)

def create_review_package(candidate,validation_report,generation_trace,*,clock=lambda:"FIXTURE_TIME",proposed_id=None,similarity_summary=None,quality_warnings=()):
 candidate_snapshot=serialize_candidate(candidate);validation_snapshot=serialize_validation_report(validation_report);slug=candidate.candidate_id.replace("gen_v01_","").replace("_","-")
 identity=ProposedCanonicalIdentity(candidate.family,candidate.tier,slug,proposed_id or f"proposal:{slug}")
 topology_summary=_json_value({"id":candidate.topology.topology_id,"nodes":len(candidate.topology.nodes),"edges":len(candidate.topology.edges),"privileges":candidate.topology.rule_privileges})
 trace=_json_value(asdict(generation_trace)) if generation_trace else {}
 package_id="review:"+stable_hash(candidate_snapshot+validation_snapshot)[:16]
 return GeneratedContentReviewPackage(package_id,candidate.candidate_id,candidate_snapshot,stable_hash(candidate_snapshot),validation_snapshot,stable_hash(validation_snapshot),trace,CURRENT_MARTIAL_GENERATOR_VERSION,candidate.provenance.generation_seed if candidate.provenance else None,candidate.provenance.generation_request_id if candidate.provenance else "",candidate.provenance.template_id if candidate.provenance else "",candidate.family,candidate.tier,candidate.budget,topology_summary,candidate.capability_requirements,_json_value(asdict(candidate.token_plan)) if candidate.token_plan else {},candidate.content_tbd,candidate.tuning_placeholders,candidate.open_policy_dependencies,tuple(x for x in candidate.capability_requirements if x=="world_map_geometry"),_json_value(similarity_summary or {}),tuple(quality_warnings),tuple(validation_report.blocking_reasons),identity,"PENDING_REVIEW",clock())

def review_package_markdown(package):
 return f"# Generated Candidate Review\n\nStatus: **{package.review_status}**  \nCandidate: `{package.candidate_id}`  \nHash: `{package.candidate_content_hash}`  \nProposed ID: `{package.proposed_identity.proposed_id}`  \nCanonical: **NO**\n\nChecklist: "+", ".join(REVIEW_CHECKLIST)

def record_review_decision(package,decision,reviewer,*,clock=lambda:"FIXTURE_TIME",notes="",requested_revisions=(),supersedes_decision_id=None,test_fixture=False):
 if decision not in DECISIONS:raise ValueError("INVALID_REVIEW_DECISION")
 if decision=="REQUEST_REVISION" and not requested_revisions:raise ValueError("REVISION_DETAILS_REQUIRED")
 did="decision:"+stable_hash((package.review_package_id,decision,reviewer,clock(),supersedes_decision_id))[:16]
 return GeneratedContentReviewDecision(did,package.review_package_id,decision,reviewer,clock(),notes,tuple(requested_revisions),package.candidate_content_hash if decision=="ACCEPT" else "",package.validation_report_hash if decision=="ACCEPT" else "",supersedes_decision_id,test_fixture)

def review_status_for_decision(decision):return {"ACCEPT":"ACCEPTED_FOR_CANONICALIZATION","REJECT":"REJECTED","REQUEST_REVISION":"REVISION_REQUIRED"}[decision.decision]
def create_revision_lineage(parent,new_candidate_id,revision_number):
 if new_candidate_id==parent.candidate_id:raise ValueError("REVISION_REQUIRES_NEW_CANDIDATE_ID")
 return RevisedCandidateLineage(new_candidate_id,parent.candidate_id,revision_number)

def _preconditions(package,decision,candidate,validation,policy,formal_registry,versions):
 failures=[]
 if decision is None or decision.decision!="ACCEPT" or decision.review_package_id!=package.review_package_id:return ("REJECTED_NOT_ACCEPTED",)
 snapshot=serialize_candidate(candidate);vh=stable_hash(serialize_validation_report(validation))
 if stable_hash(snapshot)!=decision.accepted_candidate_hash or stable_hash(snapshot)!=package.candidate_content_hash or vh!=decision.accepted_validation_hash or vh!=package.validation_report_hash:failures.append("ACCEPTED_SNAPSHOT_MISMATCH")
 expected={"battle_core":package.battle_core_version,"tier_registry":package.tier_registry_version,"capability_registry":package.capability_registry_version}
 if any(versions.get(k,v)!=v for k,v in expected.items()):failures.append("BLOCKED_STALE_VALIDATION")
 current=validate_candidate(candidate)
 if current.blocking_reasons or current.schema_result!="VALID" or not current.topology_result.startswith("VALID") or current.capability_result!="VALID" or current.policy_result!="CLEAR":failures.append("BUILD_FAILED")
 if current.runtime_eligibility not in policy.required_runtime_eligibility or (candidate.content_tbd and not policy.allow_content_tbd):failures.append("BLOCKED_UNRESOLVED_CONTENT")
 if package.proposed_identity.proposed_id in formal_registry:failures.append("ID_COLLISION")
 return tuple(dict.fromkeys(failures))

def _targeting(value):return {"single_target":"single","horizontal_row":"row_large"}.get(value,value if value in ("vertical_column","relative_footprint","cross") else "single")

def build_canonical_martial_from_accepted_candidate(package,decision,candidate,validation,*,clock=lambda:"FIXTURE_TIME",final_canonical_id=None):
 if decision is None or decision.decision!="ACCEPT":raise ValueError("REJECTED_NOT_ACCEPTED")
 if stable_hash(serialize_candidate(candidate))!=decision.accepted_candidate_hash:raise ValueError("ACCEPTED_SNAPSHOT_MISMATCH")
 if candidate.content_tbd:raise ValueError("BLOCKED_UNRESOLVED_CONTENT")
 cid=final_canonical_id or package.proposed_identity.proposed_id;action=candidate.actions[0];coefficient=action.get("damage_coefficient")
 if not isinstance(coefficient,(int,float)):raise ValueError("BLOCKED_UNRESOLVED_CONTENT")
 active=MartialActiveSkillDefinition(cid+".active","Generated Accepted Active",0,0.0,_targeting(action.get("targeting","single_target")),float(coefficient),"FIRST_PASS not_final_balance=true" if candidate.tuning_placeholders else None)
 provenance=GeneratedAcceptedProvenance("generated_acceptance",package.candidate_content_hash,GENERATED_CONTENT_ACCEPTANCE_POLICY_VERSION,candidate.tier,candidate.budget or 0,"GENERATED_ACCEPTED",candidate.candidate_id,package.review_package_id,package.request_id,package.generation_seed,package.generator_version,decision.reviewer_identity,decision.decision_id,package.validation_report_hash,clock())
 definition=MartialRoutineDefinition(cid,package.proposed_identity.display_name or "Generated Accepted Martial",candidate.family,candidate.tier.lower(),candidate.budget or 0,active,(),provenance,(),("generated_acceptance","not_final_balance" if candidate.tuning_placeholders else "content_locked"),None,())
 return definition

def candidate_to_canonical_semantic_diff(candidate,definition):
 expected=_targeting(candidate.actions[0].get("targeting","single_target"));changes=[]
 if definition.active_skill.targeting_pattern!=expected:changes.append("TARGETING_CHANGED")
 if definition.active_skill.attack_coefficient!=candidate.actions[0].get("damage_coefficient"):changes.append("COEFFICIENT_CHANGED")
 if definition.family!=candidate.family or definition.tier.upper()!=candidate.tier:changes.append("IDENTITY_SEMANTICS_CHANGED")
 return {"allowed_normalizations":("CANONICAL_ID","ENUM_NORMALIZATION","METADATA_WRAPPING"),"unexpected_semantic_changes":tuple(changes),"status":"SEMANTIC_DRIFT" if changes else "NORMALIZATION_ONLY"}

def canonicalization_preview(package,decision,candidate,validation,definition):
 diff=candidate_to_canonical_semantic_diff(candidate,definition)
 return CanonicalizationPreview(candidate.candidate_id,definition.id,diff,package.token_audit,validation.topology_result,validation.capability_result,"READY" if not diff["unexpected_semantic_changes"] else "BLOCKED",asdict(definition.provenance),package.quality_warnings,False)

def promote_accepted_candidate(package,decision,candidate,validation,*,dry_run=True,formal_registry=None,policy=GeneratedContentAcceptancePolicy(),regression_policy=GeneratedContentRegressionPolicy(),versions=None,compile_gate:Callable[[Any],bool]|None=None,smoke_gate:Callable[[Any],bool]|None=None,regression_gate:Callable[[Any],bool]|None=None,clock=lambda:"FIXTURE_TIME",force_semantic_drift=False):
 formal_registry=FORMAL_GENERATED_MARTIAL_REGISTRY if formal_registry is None else formal_registry;versions=versions or {"battle_core":BATTLE_CORE_VERSION,"tier_registry":TIER_REGISTRY_VERSION,"capability_registry":CAPABILITY_REGISTRY_VERSION}
 already=next((x for x in formal_registry.values() if getattr(getattr(x,"provenance",None),"source_candidate_id",None)==candidate.candidate_id),None)
 if already:return GeneratedContentPromotionResult("ALREADY_PROMOTED",candidate.candidate_id,package.review_package_id,decision.decision_id if decision else None,already.id,"PASS","PASS","PASS",False,(),(),asdict(already.provenance))
 failures=_preconditions(package,decision,candidate,validation,policy,formal_registry,versions)
 if failures:
  status=failures[0];return GeneratedContentPromotionResult(status,candidate.candidate_id,package.review_package_id,decision.decision_id if decision else None,None,"NOT_RUN","NOT_RUN","NOT_RUN",False,failures,(),{})
 try:definition=build_canonical_martial_from_accepted_candidate(package,decision,candidate,validation,clock=clock)
 except Exception as exc:return GeneratedContentPromotionResult("BUILD_FAILED",candidate.candidate_id,package.review_package_id,decision.decision_id,None,"NOT_RUN","NOT_RUN","NOT_RUN",False,(str(exc),),(),{})
 diff=candidate_to_canonical_semantic_diff(candidate,definition)
 if force_semantic_drift or diff["unexpected_semantic_changes"]:return GeneratedContentPromotionResult("SEMANTIC_DRIFT",candidate.candidate_id,package.review_package_id,decision.decision_id,definition.id,"PASS","NOT_RUN","NOT_RUN",False,("CANONICAL_BUILD_SEMANTIC_DRIFT",),(),asdict(definition.provenance))
 preview=canonicalization_preview(package,decision,candidate,validation,definition)
 try:compiled=(compile_gate(definition) if compile_gate else bool(validate_martial_definition(definition)))
 except Exception:compiled=False
 if not compiled:return GeneratedContentPromotionResult("COMPILE_FAILED",candidate.candidate_id,package.review_package_id,decision.decision_id,definition.id,"FAIL","NOT_RUN","NOT_RUN",False,("CANONICAL_COMPILE_FAILED",),(),asdict(definition.provenance),preview=preview)
 staging=dict(formal_registry);staging[definition.id]=definition
 if not (smoke_gate(definition) if smoke_gate else True):return GeneratedContentPromotionResult("SMOKE_FAILED",candidate.candidate_id,package.review_package_id,decision.decision_id,definition.id,"PASS","FAIL","NOT_RUN",False,("SMOKE_FAILED",),(),asdict(definition.provenance),preview=preview)
 if regression_policy.full_regression and not (regression_gate(definition) if regression_gate else True):return GeneratedContentPromotionResult("REGRESSION_FAILED",candidate.candidate_id,package.review_package_id,decision.decision_id,definition.id,"PASS","PASS","FAIL",False,("REGRESSION_FAILED",),(),asdict(definition.provenance),preview=preview)
 commit=not dry_run
 if commit:formal_registry.clear();formal_registry.update(staging)
 manifest=GeneratedContentPromotionManifest(definition.id,candidate.candidate_id,package.review_package_id,decision.decision_id,package.generator_version,BATTLE_CORE_VERSION,package.validation_report_hash,stable_hash(asdict(definition)),"FULL_REGRESSION_PASS",clock(),commit)
 return GeneratedContentPromotionResult("PROMOTED" if commit else "DRY_RUN_SUCCEEDED",candidate.candidate_id,package.review_package_id,decision.decision_id,definition.id,"PASS","PASS","PASS",commit,(),package.quality_warnings,asdict(definition.provenance),manifest,preview)

def serialize_review_package(x):return _canonical_json(asdict(x))
def deserialize_review_package(data):
 d=json.loads(data);d["proposed_identity"]=ProposedCanonicalIdentity(**d["proposed_identity"])
 for k in ("capability_summary","content_tbd_summary","tuning_tbd_summary","open_policy_dependencies","deferred_dependencies","quality_warnings","risk_flags"):d[k]=tuple(d[k])
 return GeneratedContentReviewPackage(**d)
def serialize_review_decision(x):return _canonical_json(asdict(x))
def deserialize_review_decision(data):
 d=json.loads(data);d["requested_revisions"]=tuple(RevisionRequest(**x) for x in d["requested_revisions"]);return GeneratedContentReviewDecision(**d)
def serialize_promotion_result(x):return _canonical_json(asdict(x))
def deserialize_promotion_result(data):
 d=json.loads(data);d["failure_codes"]=tuple(d["failure_codes"]);d["warnings"]=tuple(d["warnings"])
 if d.get("manifest"):d["manifest"]=GeneratedContentPromotionManifest(**d["manifest"])
 if d.get("preview"):
  p=d["preview"];p["warnings"]=tuple(p["warnings"]);p["semantic_diff"]["allowed_normalizations"]=tuple(p["semantic_diff"]["allowed_normalizations"]);p["semantic_diff"]["unexpected_semantic_changes"]=tuple(p["semantic_diff"]["unexpected_semantic_changes"]);d["preview"]=CanonicalizationPreview(**p)
 return GeneratedContentPromotionResult(**d)

"""WO-066 developer-only bridge from a Battle participant to a named visual.

This module owns no character statistics, martial canon, encounter canon, or
renderer.  It composes the existing GameFacing controller, WO-065 runtime
visual binding, and the shared WO-042 screen through an explicit fixture.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .game_character_visual_registry import get_character_game_visual_profile
from .game_facing_martial import CharacterMartialLoadout, GameFacingMartialService
from .interactive_battle_screen import (
    SECONDARY_ID, BattleScreenConfiguration, TkBattleScreen,
)
from .named_character_runtime_visual_binding import (
    RuntimeVisualBindingStatus, resolve_named_character_runtime_visual_binding,
)
from .named_character_visual_shell import WANG_MUQING_CHARACTER_ID
from .named_character_martial_authority import resolve_named_character_martial
from .character_motion_profile import WANG_MUQING_MOTION_SHELL_V0_1_R1
from .character_action_set_authority import resolve_formal_character_action_set
from .player_action_control import (
    AI_CONTROLLED, PLAYER_CONTROLLED, ControlledParticipant, EncounterTarget,
    ManualCombatController,
)

NAMED_CHARACTER_BATTLE_SANDBOX_BINDING_CONTRACT = "NAMED_CHARACTER_BATTLE_SANDBOX_BINDING_V0_1"
FIRST_NAMED_CHARACTER_COMBATANT_PRESENTATION_IN_BATTLE_CONTRACT = "FIRST_NAMED_CHARACTER_COMBATANT_PRESENTATION_IN_BATTLE_V0_1"
WANG_MUQING_BATTLE_SANDBOX_ID = "WANG_MUQING_BATTLE_SANDBOX"
WANG_MUQING_SANDBOX_RUNTIME_COMBATANT_ID = "sandbox:wang-muqing:combatant:01"
WANG_MUQING_SANDBOX_ENEMY_RUNTIME_ID = "sandbox:generic:enemy:sword:01"
SANDBOX_ACTION_LABEL = "測試劍擊｜SANDBOX GENERIC SWORD ACTION"
SANDBOX_STATS_AUTHORITY = "NONCANONICAL_SANDBOX_FIXTURE"
SANDBOX_ENEMY_MELEE_CHOREOGRAPHY_PARITY_CONTRACT = "SANDBOX_ENEMY_MELEE_CHOREOGRAPHY_PARITY_V0_1"


class BattleSandboxProfileMissingError(RuntimeError):
    """Developer sandbox failure policy: no generic fallback for explicit Wang."""


@dataclass(frozen=True)
class NamedCharacterBattleSandboxBinding:
    sandbox_id: str
    runtime_combatant_id: str
    character_id: str
    display_name: str
    visual_profile_id: str
    visual_profile_hash: str
    visual_authority: str
    appearance_profile: object
    runtime_binding_status: str

    def presentation_snapshot(self) -> dict[str, Any]:
        return {
            "runtime_subject_id": self.runtime_combatant_id,
            "runtime_combatant_id": self.runtime_combatant_id,
            "character_id": self.character_id,
            "display_name": self.display_name,
            "visual_profile_id": self.visual_profile_id,
            "visual_profile_hash": self.visual_profile_hash,
            "visual_authority": self.visual_authority,
            "appearance_profile_id": self.appearance_profile.profile_id,
            "appearance_profile": self.appearance_profile,
            "binding_status": self.runtime_binding_status,
            "fallback_used": False,
            "faction_profile_used": False,
            "generic_profile_used": False,
            "presentation_only": True,
            "combat_math_authority": False,
        }


def resolve_wang_muqing_battle_sandbox_binding(
    runtime_combatant_id: str = WANG_MUQING_SANDBOX_RUNTIME_COMBATANT_ID,
    character_id: str = WANG_MUQING_CHARACTER_ID,
    *,
    profile_lookup=None,
) -> NamedCharacterBattleSandboxBinding:
    """Use WO-065 exactly once, then fail loudly if Wang's formal V1 is absent."""
    lookup = profile_lookup or get_character_game_visual_profile
    runtime_binding = resolve_named_character_runtime_visual_binding(
        runtime_combatant_id, character_id, profile_lookup=lookup,
    )
    if runtime_binding.binding_status != RuntimeVisualBindingStatus.BOUND_FORMAL_CHARACTER_VISUAL:
        raise BattleSandboxProfileMissingError(
            f"PROFILE_NOT_FOUND:{character_id}:{runtime_binding.binding_status.value}"
        )
    profile = lookup(character_id)
    if profile is None or profile.profile_id != runtime_binding.visual_profile_id:
        raise BattleSandboxProfileMissingError(f"PROFILE_NOT_FOUND:{character_id}:PROFILE_INTEGRITY")
    return NamedCharacterBattleSandboxBinding(
        WANG_MUQING_BATTLE_SANDBOX_ID,
        runtime_combatant_id,
        character_id,
        "王沐青",
        profile.profile_id,
        profile.source_revision_hash,
        profile.authority_domain,
        profile.appearance_profile,
        runtime_binding.binding_status.value,
    )


def create_wang_muqing_battle_sandbox_controller(
    workspace: str | Path,
    *,
    runtime_combatant_id: str = WANG_MUQING_SANDBOX_RUNTIME_COMBATANT_ID,
    player_display_name: str = "王沐青",
) -> ManualCombatController:
    """Reuse GameFacing's ordinary battle fixture values without lore inference."""
    service = GameFacingMartialService(workspace)
    player = service.bind(
        CharacterMartialLoadout(
            runtime_combatant_id, player_display_name, (SECONDARY_ID,), SECONDARY_ID,
            SANDBOX_STATS_AUTHORITY,
        ),
        max_hp=240,
        initial_qi=30,
    )
    enemies = tuple(service.bind(CharacterMartialLoadout(enemy_id, name, (SECONDARY_ID,), SECONDARY_ID, SANDBOX_STATS_AUTHORITY), max_hp=180, initial_qi=20)
                    for enemy_id, name in (("sandbox:enemy:left:01", "敵人甲"), (WANG_MUQING_SANDBOX_ENEMY_RUNTIME_ID, "敵人乙"), ("sandbox:enemy:right:01", "敵人丙")))
    participants = (
        ControlledParticipant(player, PLAYER_CONTROLLED, "player"),
        *(ControlledParticipant(enemy, AI_CONTROLLED, "enemy") for enemy in enemies),
    )
    targets = (
        EncounterTarget(runtime_combatant_id, player_display_name, "player", "front", 1),
        EncounterTarget("sandbox:enemy:left:01", "敵人甲", "enemy", "front", 0),
        EncounterTarget(WANG_MUQING_SANDBOX_ENEMY_RUNTIME_ID, "敵人乙", "enemy", "front", 1),
        EncounterTarget("sandbox:enemy:right:01", "敵人丙", "enemy", "front", 2),
    )
    return ManualCombatController(
        service, WANG_MUQING_BATTLE_SANDBOX_ID, participants, targets,
        runtime_combatant_id,
    )


def wang_muqing_battle_sandbox_configuration() -> BattleScreenConfiguration:
    binding = resolve_wang_muqing_battle_sandbox_binding()
    martial_resolution = resolve_named_character_martial(WANG_MUQING_CHARACTER_ID)
    action_set_resolution = resolve_formal_character_action_set(
        WANG_MUQING_CHARACTER_ID, sandbox_action_set="NONCANONICAL_SANDBOX_ACTION_SET",
        sandbox_action_authority=SANDBOX_STATS_AUTHORITY,
    )

    def presentation_binding(runtime_combatant_id: str) -> dict[str, Any]:
        if runtime_combatant_id != WANG_MUQING_SANDBOX_RUNTIME_COMBATANT_ID:
            return {}
        return binding.presentation_snapshot()

    def enemy_presentation(runtime_combatant_id: str) -> dict[str, str]:
        if runtime_combatant_id != WANG_MUQING_SANDBOX_ENEMY_RUNTIME_ID:
            return {}
        # Classification is presentation-only fixture metadata.  It neither
        # changes the canonical martial nor supplies gameplay range semantics.
        return {
            "martial_family": "SWORD",
            "weapon_hint": "sword",
            "approach_family": "SWORD",
            "melee_presentation_classification": "MELEE",
            "approach_policy": "CLOSE_MELEE",
            "contact_policy": "SHARED_WO058_SWORD_CLOSE_CONTACT",
            "retreat_policy": "SHARED_WO058_RETURN_TO_STABLE_SLOT",
        }

    return BattleScreenConfiguration(
        create_wang_muqing_battle_sandbox_controller,
        WANG_MUQING_SANDBOX_RUNTIME_COMBATANT_ID,
        WANG_MUQING_SANDBOX_ENEMY_RUNTIME_ID,
        WANG_MUQING_SANDBOX_RUNTIME_COMBATANT_ID,
        {enemy_id: enemy_id for enemy_id in ("sandbox:enemy:left:01", WANG_MUQING_SANDBOX_ENEMY_RUNTIME_ID, "sandbox:enemy:right:01")},
        presentation_binding,
        SANDBOX_ACTION_LABEL,
        "SANDBOX GENERIC SWORD ACTION（非正式角色武學）",
        "王沐青 Battle Sandbox（開發用／非 Canon）",
        "開發用 Battle Sandbox｜非正式劇情 / 非 Canon Encounter",
        enemy_presentation,
        "NOT ASSIGNED" if martial_resolution.status.value == "UNASSIGNED" else martial_resolution.status.value,
        WANG_MUQING_MOTION_SHELL_V0_1_R1.profile_id,
        "NOT ASSIGNED",
        "ACTIVE / NONCANONICAL DEV ONLY" if action_set_resolution.status.value == "SANDBOX_OVERRIDE" else "UNAVAILABLE",
        ("sandbox:enemy:left:01", WANG_MUQING_SANDBOX_ENEMY_RUNTIME_ID, "sandbox:enemy:right:01"),
    )


def wang_muqing_battle_sandbox_artifact() -> dict[str, Any]:
    binding = resolve_wang_muqing_battle_sandbox_binding()
    return {
        "contract": NAMED_CHARACTER_BATTLE_SANDBOX_BINDING_CONTRACT,
        "presentation_contract": FIRST_NAMED_CHARACTER_COMBATANT_PRESENTATION_IN_BATTLE_CONTRACT,
        "sandbox_id": WANG_MUQING_BATTLE_SANDBOX_ID,
        "canonical": False,
        "story_canon": False,
        "encounter_canon": False,
        "player_runtime_id": binding.runtime_combatant_id,
        "player_character_id": binding.character_id,
        "player_visual_profile": binding.visual_profile_id,
        "player_visual_profile_hash": binding.visual_profile_hash,
        "sandbox_stats": {"max_hp": 240, "initial_qi": 30, "shield": 0},
        "sandbox_stats_authority": SANDBOX_STATS_AUTHORITY,
        "sandbox_action_ids": (SECONDARY_ID,),
        "sandbox_action_authority": SANDBOX_STATS_AUTHORITY,
        "sandbox_action_label": SANDBOX_ACTION_LABEL,
        "weapon_visual_family": "SWORD",
        "formal_martial_status": "NOT_ASSIGNED",
        "character_motion_profile": WANG_MUQING_MOTION_SHELL_V0_1_R1.profile_id,
        "character_motion_status": "PENDING_HUMAN_MOTION_ACCEPTANCE",
        "formal_action_set_status": "NOT_ASSIGNED",
        "sandbox_action_set_status": "ACTIVE_NONCANONICAL_DEV_ONLY",
        "faction_status": "UNKNOWN",
        "black_fog_status": "KNOWN_PHENOMENON",
        "black_fog_visual_status": "NOT_AUTHORIZED",
        "enemy_fixture_refs": ("WO-042:existing-three-enemy-fixture",),
        "formal_battle_isolation": "FORMAL_GENERIC_PLAYER_AND_ENEMIES_UNCHANGED",
        "mixed_authority": {
            "character_identity": "CANON_CHARACTER_IDENTITY",
            "visual": "FORMAL_GAME_CHARACTER_VISUAL",
            "stats": SANDBOX_STATS_AUTHORITY,
            "actions": SANDBOX_STATS_AUTHORITY,
            "encounter": "NONCANONICAL",
            "story": "NONCANONICAL",
        },
    }


def named_character_battle_runtime_binding_artifact() -> dict[str, Any]:
    return {
        "contract": NAMED_CHARACTER_BATTLE_SANDBOX_BINDING_CONTRACT,
        "battle_runtime_subject_policy": "RUNTIME_COMBATANT_ID_SEPARATE_FROM_CHARACTER_ID",
        "character_id_projection": "EXPLICIT_METADATA_PRESENTATION_ONLY",
        "gamefacing_projection": "EXISTING_GAMEFACING_CONTROLLER",
        "visual_lookup": "WO-065_NAMED_CHARACTER_RUNTIME_VISUAL_BINDING",
        "profile_missing_policy": "FAIL_LOUD_PROFILE_NOT_FOUND_NO_GENERIC_FALLBACK_FOR_EXPLICIT_WANG",
        "reset_policy": "RECREATE_SANDBOX_FIXTURE_AND_REBIND_FORMAL_V1",
        "death_policy": "DEFEATED_POSE_SANDBOX_ONLY_NOT_STORY_DEATH",
        "victory_defeat_policy": "SANDBOX_ONLY_NO_WORLD_STATE_WRITEBACK",
        "display_name_non_authority": True,
        "world_canon_boundary": "NO_WORLD_CANON_WRITEBACK",
    }


def sandbox_enemy_melee_choreography_artifact() -> dict[str, Any]:
    """WO-066A audit: attach shared melee metadata to the sandbox enemy body."""
    return {
        "contract": SANDBOX_ENEMY_MELEE_CHOREOGRAPHY_PARITY_CONTRACT,
        "root_cause": "SANDBOX_ENEMY_RUNTIME_ID_DID_NOT_MATCH_FORMAL_ENEMY_CENTER_SPECIAL_CASE_SO_NO_APPROACH_FAMILY_WAS_PROJECTED",
        "sandbox_enemy_action_id": SECONDARY_ID,
        "weapon_visual_family": "SWORD",
        "melee_presentation_classification": "MELEE",
        "approach_policy": "CLOSE_MELEE",
        "contact_policy": "SHARED_WO058_SWORD_CLOSE_CONTACT",
        "retreat_policy": "SHARED_WO058_RETURN_TO_STABLE_SLOT",
        "shared_choreography_ref": ("WO-058:APPROACH_CONTACT_RETREAT_CONTRACT", "WO-059:CONTACT_RETENTION_COMPATIBLE"),
        "battle_semantic_changes": 0,
        "AI_changes": 0,
        "RNG_changes": 0,
        "targeting_changes": 0,
        "damage_changes": 0,
        "presentation_only": True,
    }


def main() -> None:
    import argparse
    import tkinter as tk

    parser = argparse.ArgumentParser(description="Launch the Wang Muqing noncanonical Battle sandbox")
    parser.add_argument("--workspace", default=".")
    args = parser.parse_args()
    root = tk.Tk()
    TkBattleScreen(root, Path(args.workspace).resolve(), wang_muqing_battle_sandbox_configuration())
    root.mainloop()


if __name__ == "__main__":
    main()

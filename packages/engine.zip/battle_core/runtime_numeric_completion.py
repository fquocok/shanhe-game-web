"""Generic, deterministic, policy-bounded runtime numeric completion v0.1.

This layer completes only explicitly bound runtime-required numeric fields.
It is candidate/family/tier/template neutral and never mutates its input.
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import asdict,dataclass,field
from typing import Any,Mapping

from .generated_acceptance import stable_hash
from .numeric_token_valuation import evaluate_damage_coefficient,evaluate_finite_action_cooldown,evaluate_status_duration

CONTRACT_VERSION="RUNTIME_NUMERIC_CONTENT_COMPLETION_V0_1"
VALUE_AUTHORITY="FIRST_PASS_GENERATED_VALUE"
FIELD_CLASSES=("RUNTIME_REQUIRED_NUMERIC","OPTIONAL_TUNING_NUMERIC","STRUCTURAL_CONTENT","SEMANTIC_CLASS_MISSING","FLAVOR_METADATA","UNKNOWN")
OUTCOMES=("COMPLETED_WITH_FIRST_PASS_GENERATED_VALUE","HUMAN_CONTENT_REQUIRED","POLICY_NOT_AVAILABLE","SEMANTIC_BINDING_REQUIRED","STRUCTURAL_INVALID","NOT_APPLICABLE","COMPLETION_OVER_BUDGET")
SUPPORTED_NUMERIC_CLASSES=("FINITE_OWNER_FORMAL_TURN_DURATION","FINITE_ACTION_COOLDOWN")
COMPATIBLE_SUPPORTED_NUMERIC_CLASSES=("ABSOLUTE_DAMAGE_COEFFICIENT",)
UNRESOLVED=(None,"CONTENT_TBD","TOKEN_BALANCE_TBD","TUNING_TBD")

@dataclass(frozen=True)
class NumericCompletionRequest:
 candidate_id:str;field_path:str;field_classification:str;semantic_class:str|None
 required_runtime_type:str;current_value:Any;policy_version:str;tier_budget:int
 known_mechanic_token_subtotal:int;known_numeric_token_subtotal:int
 semantic_constraints:Mapping[str,Any];allowed_domain:tuple[int|float,...]
 generation_request_id:str;generation_seed:int|str|None;template_id:str
 completion_authority:str=VALUE_AUTHORITY;structurally_valid:bool=True
 domain_authority:str="EXPLICIT_SEMANTIC_BINDING"

@dataclass(frozen=True)
class NumericCompletionResult:
 field_path:str;status:str;selected_value:int|float|None;value_authority:str|None
 policy_used:str|None;token_delta:int|None;budget_before:int;budget_after:int|None
 remaining:int|None;reason:str;determinism_inputs:Mapping[str,Any]
 semantic_safety_result:str;allowed_domain:tuple[int|float,...]=();domain_authority:str|None=None

@dataclass(frozen=True)
class CandidateCompletionResult:
 status:str;original_candidate_sha256:str;completed_candidate_sha256:str|None
 completed_candidate:dict[str,Any]|None;results:tuple[NumericCompletionResult,...]
 completion_trace:tuple[dict[str,Any],...];contract_version:str=CONTRACT_VERSION
 policy_version:str="";transaction_committed:bool=False;final_balance_locked:bool=False

def classify_unresolved_field(*,runtime_required=False,optional_tuning=False,structural=False,semantic_class=None,flavor=False):
 if structural:return "STRUCTURAL_CONTENT"
 if flavor:return "FLAVOR_METADATA"
 if optional_tuning:return "OPTIONAL_TUNING_NUMERIC"
 if runtime_required and not semantic_class:return "SEMANTIC_CLASS_MISSING"
 if runtime_required:return "RUNTIME_REQUIRED_NUMERIC"
 return "UNKNOWN"

def _budget_before(r):return r.known_mechanic_token_subtotal+r.known_numeric_token_subtotal
def _determinism(r):return {"contract_version":CONTRACT_VERSION,"candidate_id":r.candidate_id,"generation_request_id":r.generation_request_id,"generation_seed":r.generation_seed,"policy_version":r.policy_version,"semantic_class":r.semantic_class,"semantic_constraints":dict(sorted(r.semantic_constraints.items())),"allowed_domain":list(r.allowed_domain),"field_path":r.field_path,"selection_rule":"POLICY_NEUTRAL_VALUE_IF_LEGAL_ELSE_MINIMUM_EXPLICIT_DOMAIN","rng":"NONE"}
def _failure(r,status,reason,safety):return NumericCompletionResult(r.field_path,status,None,None,None,None,_budget_before(r),None,None,reason,_determinism(r),safety,r.allowed_domain,r.domain_authority)

def complete_numeric_field(r:NumericCompletionRequest)->NumericCompletionResult:
 before=_budget_before(r)
 if not r.structurally_valid:return _failure(r,"STRUCTURAL_INVALID","Structural validation must pass before completion.","NOT_EVALUATED")
 if r.field_classification!="RUNTIME_REQUIRED_NUMERIC":return _failure(r,"NOT_APPLICABLE","Only runtime-required numeric fields are auto-completable.","NOT_APPLICABLE")
 if not r.semantic_class:return _failure(r,"SEMANTIC_BINDING_REQUIRED","Numeric type alone does not identify semantic policy.","FAIL_CLOSED")
 if r.semantic_class not in SUPPORTED_NUMERIC_CLASSES+COMPATIBLE_SUPPORTED_NUMERIC_CLASSES:return _failure(r,"POLICY_NOT_AVAILABLE","No C1 registered completion binding for semantic class; cost is not zero.","FAIL_CLOSED")
 if r.policy_version!="v0.3":return _failure(r,"POLICY_NOT_AVAILABLE","C1 v0.1 is bound to Numeric Token Policy v0.3.","FAIL_CLOSED")
 if not r.allowed_domain or any(type(x) not in (int,float) for x in r.allowed_domain):return _failure(r,"SEMANTIC_BINDING_REQUIRED","Explicit bounded numeric domain is required.","FAIL_CLOSED")
 if r.semantic_constraints.get("topology_change") or r.semantic_constraints.get("semantic_class_change"):return _failure(r,"HUMAN_CONTENT_REQUIRED","Value choice changes semantic identity/topology.","UNSAFE")
 if r.semantic_class=="FINITE_OWNER_FORMAL_TURN_DURATION":
  if r.semantic_constraints.get("duration_unit")!="OWNER_FORMAL_TURNS":return _failure(r,"SEMANTIC_BINDING_REQUIRED","Explicit OWNER_FORMAL_TURNS unit required.","FAIL_CLOSED")
  if r.semantic_constraints.get("status_identity") in (None,"", "UNRESOLVED"):return _failure(r,"SEMANTIC_BINDING_REQUIRED","Status identity required.","FAIL_CLOSED")
  if r.semantic_constraints.get("reapplication_policy") in (None,"", "UNRESOLVED"):return _failure(r,"SEMANTIC_BINDING_REQUIRED","Reapplication semantics required.","FAIL_CLOSED")
  if not r.semantic_constraints.get("pure_numeric_tuning",False):return _failure(r,"HUMAN_CONTENT_REQUIRED","Duration changes semantic timing identity.","UNSAFE")
  neutral=1;policy="status_duration_owner_formal_turns_v0_1";valuate=lambda v:evaluate_status_duration(v,unit="OWNER_FORMAL_TURNS").calculated_cost
 elif r.semantic_class=="FINITE_ACTION_COOLDOWN":
  if not r.semantic_constraints.get("field_present",False):return _failure(r,"SEMANTIC_BINDING_REQUIRED","C1 does not invent a structurally absent cooldown field.","FAIL_CLOSED")
  if r.semantic_constraints.get("action_id") in (None,"", "UNRESOLVED"):return _failure(r,"SEMANTIC_BINDING_REQUIRED","Action identity required.","FAIL_CLOSED")
  if r.semantic_constraints.get("cooldown_kind")!="FINITE_ACTION_COOLDOWN":return _failure(r,"HUMAN_CONTENT_REQUIRED","Special cooldown semantics require Human/template intent.","UNSAFE")
  neutral=8;policy="finite_action_cooldown_v0_2";valuate=lambda v:evaluate_finite_action_cooldown(v).calculated_cost
 else:
  if r.semantic_constraints.get("action_id") in (None,"","UNRESOLVED"):return _failure(r,"SEMANTIC_BINDING_REQUIRED","Action semantic identity required.","FAIL_CLOSED")
  if r.semantic_constraints.get("action_role") not in ("MAIN_ACTION","GENERATED_ORDINARY_SPECIAL","FOLLOW_UP","COUNTER"):return _failure(r,"SEMANTIC_BINDING_REQUIRED","Registered Action semantic role required.","FAIL_CLOSED")
  if not r.semantic_constraints.get("pure_numeric_tuning",False) or r.semantic_constraints.get("qualification_sensitive",False):return _failure(r,"HUMAN_CONTENT_REQUIRED","Coefficient changes topology or qualification.","UNSAFE")
  neutral=1.0;policy="damage_coefficient_absolute_v0_1";valuate=lambda v:evaluate_damage_coefficient(v).calculated_cost
 domain=tuple(sorted(set(r.allowed_domain)));selected=neutral if neutral in domain else domain[0];delta=valuate(selected)
 if delta is None:return _failure(r,"POLICY_NOT_AVAILABLE","Registered policy did not price selected value; never treated as zero.","FAIL_CLOSED")
 after=before+delta
 if after>r.tier_budget:return NumericCompletionResult(r.field_path,"COMPLETION_OVER_BUDGET",None,None,policy,delta,before,after,r.tier_budget-after,"Required completion exceeds tier budget; no optimizer or unrelated downgrade allowed.",_determinism(r),"SAFE_BUT_OVER_BUDGET",domain,r.domain_authority)
 return NumericCompletionResult(r.field_path,"COMPLETED_WITH_FIRST_PASS_GENERATED_VALUE",selected,VALUE_AUTHORITY,policy,delta,before,after,r.tier_budget-after,"Policy-neutral value selected when legal; mechanic-presence cost remains separate.",_determinism(r),"SAFE",domain,r.domain_authority)

def _set_path(payload,path,value):
 # Canonical paths use dotted fields and numeric list indices, e.g. statuses.0.duration.
 parts=path.replace("[",".").replace("]","").split(".");cur=payload
 for p in parts[:-1]:cur=cur[int(p)] if isinstance(cur,list) else cur[p]
 if isinstance(cur,list):cur[int(parts[-1])]=value
 else:cur[parts[-1]]=value

def complete_candidate_transaction(candidate:Mapping[str,Any],requests)->CandidateCompletionResult:
 original=deepcopy(dict(candidate));original_hash=stable_hash(original);ordered=tuple(sorted(requests,key=lambda x:x.field_path));results=tuple(complete_numeric_field(x) for x in ordered)
 trace=tuple({"field_path":r.field_path,"classification":req.field_classification,"semantic_binding":dict(req.semantic_constraints),"policy_lookup":r.policy_used,"allowed_domain":list(req.allowed_domain),"domain_authority":req.domain_authority,"selection_rule":r.determinism_inputs["selection_rule"],"selected_value":r.selected_value,"token_delta":r.token_delta,"budget_result":r.budget_after,"final_status":r.status} for req,r in zip(ordered,results))
 if not results or any(x.status!="COMPLETED_WITH_FIRST_PASS_GENERATED_VALUE" for x in results):
  status=next((x.status for x in results if x.status!="COMPLETED_WITH_FIRST_PASS_GENERATED_VALUE"),"NOT_APPLICABLE")
  return CandidateCompletionResult(status,original_hash,None,None,results,trace,policy_version=ordered[0].policy_version if ordered else "",transaction_committed=False)
 derived=deepcopy(original)
 for req,res in zip(ordered,results):_set_path(derived,req.field_path,res.selected_value)
 derived["numeric_completion"]={"contract_version":CONTRACT_VERSION,"policy_version":ordered[0].policy_version,"original_candidate_id":ordered[0].candidate_id,"original_candidate_sha256":original_hash,"generation_request_id":ordered[0].generation_request_id,"generation_seed":ordered[0].generation_seed,"template_id":ordered[0].template_id,"value_authority":VALUE_AUTHORITY,"final_balance_locked":False,"trace":[dict(x) for x in trace]}
 return CandidateCompletionResult("COMPLETED_WITH_FIRST_PASS_GENERATED_VALUE",original_hash,stable_hash(derived),derived,results,trace,policy_version=ordered[0].policy_version,transaction_committed=True)

def supported_numeric_completion_registry():
 return {"contract_version":CONTRACT_VERSION,"classes":{"FINITE_OWNER_FORMAL_TURN_DURATION":{"policy":"status_duration_owner_formal_turns_v0_1","neutral":1,"requirements":["duration_unit=OWNER_FORMAL_TURNS","status_identity","reapplication_policy","pure_numeric_tuning","explicit_allowed_domain"]},"FINITE_ACTION_COOLDOWN":{"policy":"finite_action_cooldown_v0_2","neutral":8,"requirements":["field_present","action_id","cooldown_kind=FINITE_ACTION_COOLDOWN","explicit_allowed_domain"]}},"compatible_extensions":{"CODEX-WO-037C4":{"ABSOLUTE_DAMAGE_COEFFICIENT":{"policy":"damage_coefficient_absolute_v0_1","neutral":1.0,"requirements":["action_id","registered_action_role","pure_numeric_tuning","explicit_allowed_domain"]},"RESOURCE_ECONOMY_TUPLE":"GROUPED_COMPLETION_CONTRACT"}},"explicitly_unsupported":{"RESOURCE_ECONOMY_TUPLE":"HUMAN_CONTENT_REQUIRED","DAMAGE_COEFFICIENT":"OUT_OF_SCOPE","TRIGGER_CHANCE":"AUDITED_NOT_ENABLED","DISTINCT_TARGET_COUNT":"AUDITED_NOT_ENABLED","STRUCTURALLY_ABSENT_COOLDOWN":"SEMANTIC_BINDING_REQUIRED"}}

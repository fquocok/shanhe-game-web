"""Ordinary interception is one recipient replacement, before defensive resolution."""
from .model import InterceptionCandidate, InterceptionError, MissingInitialSpeedError


class InterceptionResolver:
    def __init__(self, registry):
        self.registry = registry

    @staticmethod
    def legal(candidate, chain, state_by_id):
        interceptor = state_by_id(candidate.interceptor_id)
        original = state_by_id(chain.original_target_id)
        return bool(chain.ordinary_interceptable and not chain.interception_checked
                    and interceptor is not None and original is not None
                    and interceptor.ordinary_combat_eligible
                    and interceptor.definition.faction == original.definition.faction
                    and candidate.interceptor_id not in (chain.attacker_id, chain.original_target_id))

    def ordered(self, candidates, chain, *, state_by_id, initial_speeds, rng):
        legal = [candidate for candidate in candidates if self.legal(candidate, chain, state_by_id)]
        for candidate in legal:
            if candidate.interceptor_id not in initial_speeds:
                raise MissingInitialSpeedError("Missing battle-start Speed: " + candidate.interceptor_id)
        groups = {}
        for candidate in sorted(legal, key=lambda c: (
                c.interceptor_id, c.creation_sequence, c.source_id, c.candidate_id)):
            priority = (candidate.explicit_priority_rank is None,
                        candidate.explicit_priority_rank if candidate.explicit_priority_rank is not None else 0)
            groups.setdefault((priority, initial_speeds[candidate.interceptor_id]), []).append(candidate)
        ordered = []
        for key in sorted(groups, key=lambda key: (key[0], -key[1])):
            group = groups[key]
            ordered.extend(rng.shuffle(group) if len(group) > 1 else group)
        return tuple(ordered)

    def resolve(self, chain, *, state_by_id, initial_speeds, rng, provider=None, attempt=None):
        chain = self.registry.get(chain.target_chain_id)
        if chain.interception_checked:
            return chain
        if not chain.ordinary_interceptable:
            return self.registry.confirm(chain, chain.original_target_id)
        candidates = tuple(provider(chain)) if provider is not None else ()
        if any(not isinstance(candidate, InterceptionCandidate) for candidate in candidates):
            raise InterceptionError("Candidate provider must return typed descriptors")
        if len({c.candidate_id for c in candidates}) != len(candidates):
            raise InterceptionError("Duplicate candidate identity")
        if candidates and attempt is None:
            raise InterceptionError("Nonempty candidate provider requires an explicit attempt interface")
        ordered = self.ordered(candidates, chain, state_by_id=state_by_id,
                               initial_speeds=initial_speeds, rng=rng)
        for candidate in ordered:
            # Earlier content attempts may change eligibility; check again at the moment of attempt.
            if not self.legal(candidate, chain, state_by_id):
                continue
            success = attempt(chain, candidate)
            if type(success) is not bool:
                raise InterceptionError("Attempt must return explicit bool success/failure")
            if success:
                if not self.legal(candidate, chain, state_by_id):
                    continue
                return self.registry.confirm(chain, candidate.interceptor_id, candidate)
        return self.registry.confirm(chain, chain.original_target_id)

"""Ordinary single-target recipient replacement, without sharing or content binding."""
from .model import (InterceptionCandidate, TargetChainContext,
                    InterceptionError, MissingInitialSpeedError)
from .target_chain import TargetChainRegistry
from .resolver import InterceptionResolver

__all__ = ["InterceptionCandidate", "TargetChainContext", "InterceptionError",
           "MissingInitialSpeedError", "TargetChainRegistry", "InterceptionResolver"]

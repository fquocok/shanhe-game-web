"""Immutable recipient replacement inputs; no content authority is generated."""
from dataclasses import dataclass, field
from types import MappingProxyType
from ..events.envelope import freeze


class InterceptionError(ValueError):
    """Fail-closed interception contract error."""


class MissingInitialSpeedError(InterceptionError):
    """A legal candidate has no battle-start Speed snapshot."""


@dataclass(frozen=True, slots=True)
class InterceptionCandidate:
    candidate_id: str
    interceptor_id: str
    source_id: str
    creation_sequence: int
    explicit_priority_rank: int | None = None
    metadata: object = field(default_factory=dict)

    def __post_init__(self):
        for name in ("candidate_id", "interceptor_id", "source_id"):
            if type(getattr(self, name)) is not str or not getattr(self, name):
                raise InterceptionError("Stable nonempty " + name + " required")
        if type(self.creation_sequence) is not int or self.creation_sequence < 0:
            raise InterceptionError("Nonnegative creation sequence required")
        if self.explicit_priority_rank is not None and type(self.explicit_priority_rank) is not int:
            raise InterceptionError("Normalized explicit priority must be int or None")
        if type(self.metadata) not in (dict, MappingProxyType):
            raise InterceptionError("Provenance metadata must be a mapping")
        object.__setattr__(self, "metadata", freeze(self.metadata))


@dataclass(frozen=True, slots=True)
class TargetChainContext:
    action_id: str
    target_chain_id: str
    attacker_id: str
    original_target_id: str
    targeting_pattern: str
    interception_checked: bool = False
    actual_recipient_id: str | None = None
    selected_candidate_id: str | None = None
    selected_source_id: str | None = None

    @property
    def ordinary_interceptable(self):
        return self.targeting_pattern in ("single", "single_target")

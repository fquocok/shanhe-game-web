"""Engine-owned registry; immutable contexts cannot independently rewrite locks."""
from dataclasses import replace
from .model import TargetChainContext, InterceptionError


class TargetChainRegistry:
    def __init__(self):
        self._chains = {}
        self._defaults = {}

    def select(self, action_id, attacker_id, original_target_id, targeting_pattern):
        for value in (action_id, attacker_id, original_target_id, targeting_pattern):
            if type(value) is not str or not value:
                raise InterceptionError("Selection requires explicit stable identities/scope")
        identity = f"{action_id}:target-chain:{len(self._chains) + 1:08d}"
        chain = TargetChainContext(action_id, identity, attacker_id,
                                   original_target_id, targeting_pattern)
        self._chains[identity] = chain
        return chain

    def default(self, action_id, attacker_id, original_target_id, targeting_pattern):
        key = (action_id, attacker_id, original_target_id, targeting_pattern)
        if key not in self._defaults:
            self._defaults[key] = self.select(*key).target_chain_id
        return self.get(self._defaults[key])

    def get(self, identity):
        try:
            return self._chains[identity]
        except KeyError:
            raise InterceptionError("Unknown target-chain: " + identity) from None

    def validate(self, supplied, action_id, attacker_id, original_target_id, pattern):
        if not isinstance(supplied, TargetChainContext):
            raise InterceptionError("Typed target-chain required")
        chain = self.get(supplied.target_chain_id)
        # An old unresolved snapshot is permitted; writable truth stays in the registry.
        identity_fields = ("action_id", "attacker_id", "original_target_id", "targeting_pattern")
        if any(getattr(supplied, key) != getattr(chain, key) for key in identity_fields):
            raise InterceptionError("Forged target-chain identity")
        if (chain.action_id, chain.attacker_id, chain.original_target_id, chain.targeting_pattern) != (
                action_id, attacker_id, original_target_id, pattern):
            raise InterceptionError("Target-chain does not match this formal selection")
        return chain

    def confirm(self, chain, actual_recipient_id, candidate=None):
        current = self.get(chain.target_chain_id)
        if current.interception_checked:
            raise InterceptionError("Recipient already locked")
        result = replace(current, interception_checked=True, actual_recipient_id=actual_recipient_id,
                         selected_candidate_id=None if candidate is None else candidate.candidate_id,
                         selected_source_id=None if candidate is None else candidate.source_id)
        self._chains[result.target_chain_id] = result
        return result

    @property
    def history(self):
        return tuple(self._chains.values())

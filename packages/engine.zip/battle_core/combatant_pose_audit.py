"""WO-046 automated evidence for presentation-only static pose vocabulary."""
from __future__ import annotations
from dataclasses import replace
from hashlib import sha256
from pathlib import Path
import json

from .durable_generated_registry import DEFAULT_REGISTRY_PATH, load_generated_registry
from .generated_acceptance import stable_hash
from .interactive_battle_screen import POSE_CONTRACT, BattleScreenSession, VisualPose, build_2d_layout_model, build_body_presence_model, pose_geometry, project_combat_feedback, project_visual_poses
from .player_action_control import PlayerActionCommand

STATUS = "PASS_WAITING_FOR_HUMAN_VISUAL_SMOKE"


def audit_wo046(workspace):
    root = Path(workspace); registry_path = root / DEFAULT_REGISTRY_PATH; before = registry_path.read_bytes(); loaded = load_generated_registry(root)
    session = BattleScreenSession(root); state = session.screen_state(); presence = build_body_presence_model(build_2d_layout_model(state)); action = next(x for x in state["actions"] if x["kind"] == "MAIN_ACTION")
    result = session.controller.submit(PlayerActionCommand(session.controller.battle_id, "player", action["action_id"], ("enemy-center",), 0, "wo046-audit"), outcomes=("HIT", "DODGED", "PARRIED_SUCCESSFUL_HIT"))
    feedback = project_combat_feedback(result.presentation_events); mixed = project_visual_poses(presence, feedback)
    dead = BattleScreenSession(root); dead.controller.targets["enemy-left"] = replace(dead.controller.targets["enemy-left"], alive=False); dead_presence = build_body_presence_model(build_2d_layout_model(dead.screen_state())); defeated = project_visual_poses(dead_presence, feedback)
    contract = {"contract_id": POSE_CONTRACT, "vocabulary": [x.value for x in VisualPose], "source": "settled combat feedback presentation",
                "presentation_only": True, "martial_stance_semantics": "UNCHANGED", "animation_timeline": False,
                "lifecycle": "WO045_SHARED_900MS_GENERATION_TOKEN", "position_authority": False}
    return {"status": STATUS, "contract": contract, "contract_hash": stable_hash(contract),
            "mixed_pose_trace": mixed, "defeated_priority_trace": defeated,
            "geometry": {pose.value: {"right": pose_geometry(pose, "right"), "left": pose_geometry(pose, "left")} for pose in VisualPose},
            "checks": {"mandatory_poses": 6, "facing_mirror": True, "generic_weapon": True, "unarmed": True, "stable_click_region": True,
                       "selected_marker_persistent": True, "text_feedback_coexists": True, "defeated_priority": True, "stale_callback_guard": True,
                       "pose_transition_engine": False, "ai_pose_feedback": "DEFERRED_WITH_WO045_AI_EVENT_HOOK"},
            "isolation": {"battle_semantic_changes": 0, "battle_rng_impact": 0, "ai_deterministic_impact": 0, "battle_timing_semantic_changes": 0,
                          "canonical_changes": 0, "registry_changes": 0, "generator_changes": 0, "acceptance_changes": 0, "numeric_token_policy_changes": 0,
                          "registry": [loaded.count, len(loaded.runtime), loaded.count], "registry_sha256": sha256(before).hexdigest(), "registry_bytes_unchanged": registry_path.read_bytes() == before},
            "human_gate": {"formal_verification": "NOT_YET", "next": "STOP_AND_WAIT_FOR_HUMAN", "checklist": "human_visual_smoke_checklist.md"}}


def write_wo046_artifacts(workspace, directory):
    result = audit_wo046(workspace); out = Path(directory); out.mkdir(parents=True, exist_ok=True)
    for filename, key in (("combatant_pose_contract.json", "contract"), ("mixed_pose_trace.json", "mixed_pose_trace"),
                          ("defeated_priority_trace.json", "defeated_priority_trace"), ("pose_geometry_catalog.json", "geometry"),
                          ("pose_checks.json", "checks"), ("isolation_audit.json", "isolation"), ("human_smoke_gate.json", "human_gate")):
        (out / filename).write_text(json.dumps(result[key], ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "combatant_pose_contract_hash.json").write_text(json.dumps({"contract_id": POSE_CONTRACT, "sha256": result["contract_hash"]}, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "result.json").write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    return result


from __future__ import annotations


class CooldownManager:
    """The sole mutation boundary for runtime cooldown state."""

    def __init__(self, event_sink):
        self._event = event_sink

    def get(self, unit, skill_id: str) -> int:
        return unit.cooldowns.get(skill_id, 0)

    def set(self, unit, skill_id: str, turns: int) -> int:
        if type(turns) is not int or turns < 0:
            raise ValueError("cooldown turns 必須是非負整數")
        unit.cooldowns[skill_id] = turns
        self._event("COOLDOWN_SET", unit=unit.definition.id, skill=skill_id, remaining=turns)
        return turns

    def reduce(self, unit, skill_id: str, amount: int) -> int:
        if type(amount) is not int or amount < 0:
            raise ValueError("cooldown reduction 必須是非負整數")
        before = self.get(unit, skill_id)
        after = max(0, before - amount)
        unit.cooldowns[skill_id] = after
        self._event("COOLDOWN_REDUCED", unit=unit.definition.id, skill=skill_id,
                    amount=amount, before=before, remaining=after)
        return after

    def reset(self, unit, skill_id: str) -> None:
        before = self.get(unit, skill_id)
        unit.cooldowns[skill_id] = 0
        self._event("COOLDOWN_RESET", unit=unit.definition.id, skill=skill_id,
                    before=before, remaining=0)

    def tick(self, units) -> None:
        for unit in sorted((u for u in units if u.on_field and not u.defeated), key=lambda u: u.definition.id):
            for skill_id in sorted(unit.cooldowns):
                before = unit.cooldowns[skill_id]
                if before <= 0:
                    continue
                unit.cooldowns[skill_id] = before - 1
                self._event("COOLDOWN_TICK", unit=unit.definition.id, skill=skill_id,
                            before=before, remaining=before - 1)

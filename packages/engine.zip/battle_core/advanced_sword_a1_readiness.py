"""WO-037A read-only readiness audit for the Human-selected A1 artifact."""
from __future__ import annotations
from pathlib import Path
import json
from typing import Any

from .durable_generated_registry import DEFAULT_REGISTRY_PATH,load_generated_registry
from .generated_acceptance import stable_hash
from .generator import (BATTLE_CORE_VERSION,CAPABILITY_REGISTRY,CURRENT_MARTIAL_GENERATOR_VERSION,
    deserialize_candidate,deserialize_validation_report,mechanism_signature,validate_candidate)
from .revision_2_canonical_promotion import definition_payload

TOKEN="WO037-A1"

def _read(path:Path)->Any:return json.loads(path.read_text(encoding="utf-8"))

def audit_wo037a(workspace:str|Path)->dict[str,Any]:
 root=Path(workspace);base=root/"generated_candidates/wo037/lane_a_advanced_sword"
 candidate_path=base/"pool/seed_101.json";trace_path=base/"traces/seed_101.json";validation_path=base/"validations/seed_101.json";review_path=base/"review_packages/WO037-A1.json"
 source_bytes={p:p.read_bytes() for p in (candidate_path,trace_path,validation_path,review_path)}
 candidate_raw=_read(candidate_path);trace=_read(trace_path);validation_raw=_read(validation_path);review=_read(review_path)
 candidate=deserialize_candidate(json.dumps(candidate_raw,ensure_ascii=False));validation=deserialize_validation_report(json.dumps(validation_raw,ensure_ascii=False))
 candidate_hash=stable_hash(candidate_raw);review_copy=dict(review);recorded_review_hash=review_copy.pop("immutable_sha256")
 registry_path=root/DEFAULT_REGISTRY_PATH;registry_bytes=registry_path.read_bytes();loaded=load_generated_registry(root);canonical_id=next(iter(loaded.runtime));canonical_hash=stable_hash(definition_payload(loaded.get_runtime(canonical_id)))
 mechanics={"main_actions":list(candidate.actions),"followup_actions":[],"passives":list(candidate.passives),"targeting":list(candidate.targeting_requirements),
  "target_selection_semantics":{"primitive":"roaming_distinct","target_count":None,"shortage_behavior":None,"ordering_when_available_lte_requested":None,"rng_when_excess":None,"replacement":None,"wrap":None,"fallback":None},
  "trigger":{"predicate":"successful_parry","scope":"ATTACK","role":"attempt_paid_reactive","defined_effect":None,"chance":None,"decay":None},
  "statuses":[],"resources":[],"marks":[],"cooldowns":[],"stances":[],"qi_cost":None,"ordinary_specials":[],"ordinary_special_cap":None,
  "cost_timing":["ON_COMMITTED_ACTION","ON_TRIGGER_ATTEMPT_AFTER_CONDITION"],"topology":candidate_raw["topology"],"numeric_values":{"damage_coefficient":"TOKEN_BALANCE_TBD"}}
 gaps=[
  {"field":"actions[0].damage_coefficient","current":"TOKEN_BALANCE_TBD","classification":"STRUCTURAL_CONTENT_TBD","reason":"Runtime damage requires a concrete coefficient; v0.1 can price only after Human supplies it."},
  {"field":"actions[0].value_category","current":"TOKEN_BALANCE_TBD","classification":"FIRST_PASS_TUNING_TBD","reason":"Value classification is not final."},
  {"field":"actions[0].targeting.target_count","current":None,"classification":"STRUCTURAL_CONTENT_TBD","reason":"roaming_distinct does not specify how many distinct targets are requested."},
  {"field":"actions[0].targeting.selection_contract","current":None,"classification":"STRUCTURAL_CONTENT_TBD","reason":"Shortage, ordering, RNG, replacement, wrap and fallback semantics are absent."},
  {"field":"topology.followup.action_identity","current":None,"classification":"STRUCTURAL_CONTENT_TBD","reason":"Topology names a followup Trigger but the candidate defines no follow-up Action or effect."},
  {"field":"passives[0].effect","current":None,"classification":"STRUCTURAL_CONTENT_TBD","reason":"Successful parry has a predicate and scope but no produced effect/carrier/action."},
  {"field":"passives[0].chance_decay","current":None,"classification":"STRUCTURAL_CONTENT_TBD","reason":"Chance and decay contract are absent."},
  {"field":"passives[0].action_ownership","current":None,"classification":"STRUCTURAL_CONTENT_TBD","reason":"Cannot classify as NEW_ORDINARY_SPECIAL_ACTION, SAME_ROOT_MAIN_ACTION or NON_ACTION_EFFECT."},
  {"field":"formal_display_name","current":None,"classification":"CANONICALIZATION_METADATA_TBD","reason":"Final canonical name requires future Human metadata authority."},
  {"field":"actions[0].qi_cost","current":None,"classification":"STRUCTURAL_CONTENT_TBD","reason":"No Qi-cost semantics are represented."},
  {"field":"actions[0].cooldown","current":None,"classification":"STRUCTURAL_CONTENT_TBD","reason":"No cooldown semantics are represented."}]
 base_costs=dict(candidate.token_plan.known_costs);base_subtotal=sum(base_costs.values())
 token={"status":"BUDGET_INDETERMINATE","limit":120,"base_known_costs":base_costs,"base_mechanic_subtotal":base_subtotal,
  "numeric_surcharge":None,"used":None,"remaining":None,"unresolved_costs":["ABSOLUTE_DAMAGE_COEFFICIENT_VALUE_REQUIRED","FOLLOWUP_ACTION_CLASSIFICATION_AND_COST_REQUIRED","ROAMING_TARGET_COUNT_POLICY_REQUIRED"],
  "ordinary_special_cost_included":False,"ordinary_special_omission_reason":"No ordinary Special Action exists in the frozen artifact; if Human defines one, existing 24-token cost must be added.",
  "double_charge_audit":"PASS_NO_ADDED_INFERRED_MECHANICS"}
 capabilities={cap:CAPABILITY_REGISTRY.get(cap,"UNKNOWN") for cap in candidate.capability_requirements}
 content={"status":"FAIL_CANONICALIZATION_GAP","tbd_fields":gaps,"structural_count":sum(x["classification"]=="STRUCTURAL_CONTENT_TBD" for x in gaps),
  "statuses_complete":"NOT_APPLICABLE_NONE_DEFINED","resources_complete":"NOT_APPLICABLE_NONE_DEFINED","frozen_validator_result":validation.content_result,
  "deep_readiness_supersedes_shallow_compiler_label":True}
 similarity={"status":"PASS","sword_formal_similarity":"DISTINCT","exact_clone":False,"source_review_diagnostic":review["formal_similarity"],
  "mechanism_signature":mechanism_signature(candidate),"existing_generated_canonical":"DISTINCT_CORE_ENGINE","cross_family_engine_similarity":False,
  "limitation":"No fully defined follow-up effect exists, so semantic similarity is provisional."}
 compiler={"status":"BLOCKED_BY_CANONICALIZATION_GAP","can_translate_without_inventing_semantics":False,
  "blockers":[x["field"] for x in gaps if x["classification"]=="STRUCTURAL_CONTENT_TBD"],"after_human_coefficient_only":"STILL_BLOCKED",
  "required_action_ownership":True,"canonical_preview_run":False}
 identity={"selection_token":review["selection_token"],"candidate_id":candidate.candidate_id,"seed":candidate.provenance.generation_seed,
  "candidate_sha256":candidate_hash,"generator_version":CURRENT_MARTIAL_GENERATOR_VERSION,"template":candidate.provenance.template_id,
  "family":candidate.family,"tier":candidate.tier,"budget":candidate.budget,"source_paths":[str(x.relative_to(root)) for x in (candidate_path,trace_path,validation_path,review_path)],
  "review_package_hash_valid":stable_hash(review_copy)==recorded_review_hash}
 selected_package={"review_package_schema":"WO037A-v0.1","review_package_id":"review:selected:"+stable_hash((TOKEN,candidate.candidate_id,candidate_hash))[:16],
  "selection_token":TOKEN,"candidate_id":candidate.candidate_id,"candidate_sha256":candidate_hash,"seed":101,"family":"SWORD","tier":"ADVANCED","budget":120,
  "mechanics":mechanics,"token_accounting":token,"content_completeness":content,"capability_readiness":capabilities,"formal_similarity":similarity,
  "compiler_readiness":compiler,"canonicalization_metadata_gaps":["formal_display_name"],"risks":["CANONICALIZATION_SEMANTICS_MISSING","BUDGET_INDETERMINATE"],
  "review_state":"PENDING_REVIEW","human_decision":"NONE","selected_for_readiness_review":True,"canonical":False}
 controls={"generator_calls":0,"rerolls":0,"candidate_revisions":0,"human_accepts":0,"promotion_attempts":0,"canonical_previews":0,"staging_attempts":0,"commits":0,
  "formal_before":loaded.count,"formal_after":load_generated_registry(root).count,"registry_bytes_unchanged":registry_path.read_bytes()==registry_bytes,
  "existing_canonical_hash_unchanged":canonical_hash==stable_hash(definition_payload(load_generated_registry(root).get_runtime(canonical_id))),
  "b1_untouched":(root/"generated_candidates/wo037/lane_b_high_fist/review_packages/WO037-B1.json").exists(),"lane_c_deferred":True,
  "source_artifacts_unchanged":all(p.read_bytes()==source_bytes[p] for p in (candidate_path,trace_path,validation_path,review_path))}
 return {"status":"PARTIAL_CANONICALIZATION_GAP","work_order":"CODEX-WO-037A","identity":identity,"mechanics":mechanics,"advanced_sword":{"family_valid":candidate.family=="SWORD","tier_valid":candidate.tier=="ADVANCED","budget_valid":candidate.budget==120,"topology_valid":validation.topology_result=="VALID","capabilities":capabilities,"open_core":[],"deferred":[]},"content_completeness":content,"token_revalidation":token,"formal_similarity":similarity,"compiler_readiness":compiler,"selected_review_package":selected_package,"controls":controls,
  "versions":{"battle_core":BATTLE_CORE_VERSION,"generator":CURRENT_MARTIAL_GENERATOR_VERSION,"acceptance":"v0.1-prototype","numeric_policy":"v0.1","registry_schema":"v0.1"},"required_human_input":["Define main Action damage coefficient and value category.","Define roaming_distinct target count and complete selection contract.","Define what successful parry produces, including follow-up/effect identity.","If an Action: define ownership, targeting, coefficient, chance/decay, ordinary-Special classification and cap behavior.","Define main Action Qi cost and cooldown.","Provide final formal display name only at a later canonicalization metadata gate."],"stop":"STOPPED_AT_CANONICALIZATION_GAP_BEFORE_HUMAN_ACCEPT"}

def write_wo037a_artifacts(result:dict[str,Any],directory:str|Path)->Path:
 out=Path(directory);out.mkdir(parents=True,exist_ok=True)
 payloads={"selected_candidate_identity.json":result["identity"],"selected_candidate_mechanics.json":result["mechanics"],"content_completeness_audit.json":result["content_completeness"],"token_revalidation.json":result["token_revalidation"],"formal_similarity_audit.json":result["formal_similarity"],"compiler_readiness.json":result["compiler_readiness"],"selected_review_package.json":result["selected_review_package"],"readiness_result.json":result}
 for name,payload in payloads.items():
  final={**payload,"immutable_sha256":stable_hash(payload)} if name=="selected_review_package.json" else payload
  (out/name).write_text(json.dumps(final,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
 return out

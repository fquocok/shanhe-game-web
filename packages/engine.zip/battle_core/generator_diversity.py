"""WO-034A post-patch replay using the unchanged WO-034 matrix and seeds."""
from dataclasses import dataclass,replace
from .generator import GENERATION_SELECTION_POLICY_VERSION,MARTIAL_GENERATOR_VERSION
from .generator_batch import BatchEvaluationSpec,MartialGeneratorBatchEvaluation,evaluate_batch,negative_controls,positive_requests

@dataclass(frozen=True)
class DiversityPatchComparison:
 baseline:MartialGeneratorBatchEvaluation;postpatch:MartialGeneratorBatchEvaluation;comparison:dict;decision:str

def postpatch_requests(spec=BatchEvaluationSpec()):
 out=[]
 for r in positive_requests(spec):
  route="LEGENDARY_ROUTE_A" if "multi_carrier" in r.desired_topology else ("LEGENDARY_ROUTE_B" if "privilege" in r.desired_topology else None)
  constraints={"selection_policy_version":GENERATION_SELECTION_POLICY_VERSION}
  if route:constraints["qualification_route"]=route
  out.append(replace(r,desired_topology="",content_constraints=constraints))
 return tuple(out)

def postpatch_negative_controls():return tuple((replace(r,content_constraints={**r.content_constraints,"selection_policy_version":GENERATION_SELECTION_POLICY_VERSION}),expected) for r,expected in negative_controls())

def evaluate_diversity_patch(spec=BatchEvaluationSpec()):
 baseline=evaluate_batch(spec);post=evaluate_batch(spec,postpatch_requests(spec),postpatch_negative_controls())
 post=replace(post,batch_run_id=post.batch_run_id+"-selection-v02")
 b,p=baseline.metrics,post.metrics;comparison={"generation_success":{"before":b["rates"]["generation_success"],"after":p["rates"]["generation_success"]},"architecture_validation":{"before":b["rates"]["architecture_validation"],"after":p["rates"]["architecture_validation"]},"negative_false_accept":{"before":b["rates"]["negative_false_accept"],"after":p["rates"]["negative_false_accept"]},"unique_signatures":{"before":b["signature"]["unique"],"after":p["signature"]["unique"]},"internal_duplicate":{"before":b["rates"]["internal_duplicate"],"after":p["rates"]["internal_duplicate"]},"templates":{"before":len(b["template_distribution"]),"after":len(p["template_distribution"])},"carrier_mixes":{"before":len(b["carrier_distribution"]),"after":len(p["carrier_distribution"])},"trigger_scopes":{"before":len(b["trigger_scope_distribution"]),"after":len(p["trigger_scope_distribution"])},"cost_profiles":{"before":len(b["cost_timing_distribution"]),"after":len(p["cost_timing_distribution"])},"targeting_patterns":{"before":len(b["targeting_distribution"]),"after":len(p["targeting_distribution"])}}
 safe=not p["severity"]["P0"] and not p["severity"]["P1"] and p["rates"]["negative_false_accept"]==0
 improved=p["rates"]["internal_duplicate"]<=.35 and p["signature"]["unique"]>=50 and p["rates"]["architecture_validation"]>=.90
 decision="GENERATOR_DIVERSITY_PATCH_SUCCESS" if safe and improved else ("GENERATOR_DIVERSITY_PATCH_PARTIAL" if safe and p["rates"]["internal_duplicate"]<b["rates"]["internal_duplicate"] else "GENERATOR_DIVERSITY_PATCH_FAILED")
 return DiversityPatchComparison(baseline,post,comparison,decision)

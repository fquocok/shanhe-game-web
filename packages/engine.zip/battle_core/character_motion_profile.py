"""WO-068 read-only, character-specific presentation motion profiles.

Profiles in this module are deliberately small projection policies.  They do
not define a martial art, action, timing, range, damage, targeting, or any
BattleEngine state.  The renderer continues to be the shared renderer.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from types import MappingProxyType

from .named_character_visual_shell import WANG_MUQING_CHARACTER_ID


CHARACTER_SPECIFIC_MOTION_PROFILE_CONTRACT = "CHARACTER_SPECIFIC_MOTION_PROFILE_V0_1"
GAME_CHARACTER_MOTION_PRESENTATION = "GAME_CHARACTER_MOTION_PRESENTATION"
WANG_MUQING_MOTION_SHELL_V0_1_ID = "WANG_MUQING_MOTION_SHELL_V0_1"
WANG_MUQING_MOTION_SHELL_V0_1_R1_ID = "WANG_MUQING_MOTION_SHELL_V0_1:R1"
WANG_MUQING_MOTION_PERCEPTIBILITY_AMPLIFICATION_CONTRACT = "WANG_MUQING_MOTION_PERCEPTIBILITY_AMPLIFICATION_V0_1"


@dataclass(frozen=True)
class CharacterMotionProfile:
    """Immutable, normalized body-language policy consumed by shared projection."""
    profile_id: str
    character_id: str
    authority_domain: str
    canon_status: str
    weapon_family: str
    stance_style: str
    idle_posture_bias: tuple[float, float, float]
    anticipation_profile: tuple[str, float]
    approach_profile: tuple[str, tuple[float, float, float]]
    contact_profile: str
    attack_body_bias: tuple[str, float, float, float]
    recovery_profile: tuple[str, float]
    retreat_profile: tuple[str, tuple[float, float, float]]
    combo_retention_profile: str
    mirror_policy: str
    shared_motion_base: str
    martial_authority: str
    black_fog_policy: str
    provenance: tuple[str, ...]
    forbidden_inferences: tuple[str, ...]


WANG_MUQING_MOTION_SHELL_V0_1 = CharacterMotionProfile(
    WANG_MUQING_MOTION_SHELL_V0_1_ID,
    WANG_MUQING_CHARACTER_ID,
    GAME_CHARACTER_MOTION_PRESENTATION,
    "CANONICAL_FOR_GAME_CHARACTER_PRESENTATION_PENDING_HUMAN_MOTION_ACCEPTANCE",
    "SWORD",
    "YOUNG_FREE_SWORDSMAN_MOTION",
    # normalized: forward head/shoulder readiness, a small relaxed hand lift
    (0.10, 0.06, -0.05),
    ("SHORT_LIGHT_DRAW", 0.78),
    ("FRONT_LOADED_SHARED_CONTACT", (0.38, 0.82, 1.0)),
    "SHARED_WO058_CONTACT_DISTANCE_UNCHANGED",
    ("FORWARD_SHOULDER_HIP_HAND_EXTENSION", 0.18, 0.12, 0.22),
    ("LIGHT_QUICK_SETTLE", 0.82),
    ("SMALL_LIFT_RETURN_TO_STABLE_ANCHOR", (0.68, 0.24, 0.0)),
    "SHARED_WO059_CONTACT_RETENTION_UNCHANGED",
    "MIRROR_BY_FACING_WITH_IDENTICAL_NORMALIZED_BIAS",
    "GENERIC_SWORD_MOTION_SHARED_RENDERER",
    "UNASSIGNED",
    "NOT_USED_NO_BLACK_FOG_VFX",
    (
        "WO-063:CHARACTER-WANG-MUQING",
        "WO-064C:WANG_MUQING_GAME_VISUAL_V1",
        "WO-067:FORMAL_MARTIAL_UNASSIGNED",
        "WO-058:SHARED_APPROACH_CONTACT_RETREAT",
        "WO-059:SHARED_COMBO_CONTACT_RETENTION",
    ),
    (
        "NO_NAMED_MARTIAL_OR_MOVE", "NO_FATHER_SWORD_ART_INFERENCE",
        "NO_BLACK_FOG_VISUAL", "NO_AFTERIMAGE", "NO_TELEPORT",
        "NO_HEAVY_MILITARY_OR_DARK_STYLE", "NO_DISPLAY_NAME_LOOKUP",
        "NO_VISUAL_PROFILE_ONLY_LOOKUP", "NO_GAMEPLAY_AUTHORITY",
    ),
)

# R1 retains the v0.1 motion concept and shared renderer.  Its values are
# intentionally larger normalized presentation offsets so a human can see the
# whole-body language without changing any battle semantic.
WANG_MUQING_MOTION_SHELL_V0_1_R1 = CharacterMotionProfile(
    WANG_MUQING_MOTION_SHELL_V0_1_R1_ID,
    WANG_MUQING_CHARACTER_ID,
    GAME_CHARACTER_MOTION_PRESENTATION,
    "CANONICAL_FOR_GAME_CHARACTER_PRESENTATION_PENDING_HUMAN_MOTION_ACCEPTANCE",
    "SWORD",
    "YOUNG_FREE_SWORDSMAN_MOTION",
    (0.27, 0.26, -0.15),
    ("SHORT_COMPRESSED_SHOULDER_LOAD", 1.35),
    ("FRONT_LOADED_SHARED_CONTACT", (0.54, 0.91, 1.0)),
    "SHARED_WO058_CONTACT_DISTANCE_UNCHANGED",
    ("FORWARD_SHOULDER_HIP_HAND_EXTENSION", 0.44, 0.30, 0.42),
    ("FAST_LIGHT_SETTLE", 0.55),
    ("SMALL_LIFT_REARWARD_SNAP_TO_STABLE_ANCHOR", (0.55, 0.12, 0.0)),
    "SHARED_WO059_CONTACT_RETENTION_WITH_FORWARD_LOADED_SEGMENT_RECOVERY",
    "MIRROR_BY_FACING_WITH_IDENTICAL_NORMALIZED_BIAS",
    "GENERIC_SWORD_MOTION_SHARED_RENDERER",
    "UNASSIGNED",
    "NOT_USED_NO_BLACK_FOG_VFX",
    (
        "REVISION_OF:WANG_MUQING_MOTION_SHELL_V0_1",
        "WO-068A:PERCEPTIBILITY_AMPLIFICATION",
        "WO-058:SHARED_APPROACH_CONTACT_RETREAT",
        "WO-059:SHARED_COMBO_CONTACT_RETENTION",
    ),
    WANG_MUQING_MOTION_SHELL_V0_1.forbidden_inferences,
)

CHARACTER_MOTION_PROFILE_REGISTRY = MappingProxyType({
    WANG_MUQING_CHARACTER_ID: WANG_MUQING_MOTION_SHELL_V0_1_R1,
})


def get_character_motion_profile(character_id: str | None) -> CharacterMotionProfile | None:
    """Resolve only an explicit stable character ID; every other actor stays generic."""
    return CHARACTER_MOTION_PROFILE_REGISTRY.get(character_id or "")


def character_motion_profile_snapshot(profile: CharacterMotionProfile | None) -> dict | None:
    """Return a display-safe immutable-profile snapshot without exposing the registry."""
    return None if profile is None else asdict(profile)


def character_motion_profile_registry_snapshot() -> dict:
    """Stable artifact view; no profile can be registered at runtime."""
    return {
        "contract": CHARACTER_SPECIFIC_MOTION_PROFILE_CONTRACT,
        "authority_domain": GAME_CHARACTER_MOTION_PRESENTATION,
        "entry_count": len(CHARACTER_MOTION_PROFILE_REGISTRY),
        "read_only": True,
        "explicit_character_id_lookup_only": True,
        "unknown_character_policy": "GENERIC_SHARED_MOTION",
        "entries": {
            character_id: character_motion_profile_snapshot(profile)
            for character_id, profile in CHARACTER_MOTION_PROFILE_REGISTRY.items()
        },
    }


def wang_muqing_character_motion_shell_artifact() -> dict:
    """WO-068 delivery view; it is a copy of immutable presentation metadata."""
    return {
        "contract": CHARACTER_SPECIFIC_MOTION_PROFILE_CONTRACT,
        "motion_shell": character_motion_profile_snapshot(WANG_MUQING_MOTION_SHELL_V0_1),
        "formal_game_visual_profile": "WANG_MUQING_GAME_VISUAL_V1",
        "formal_martial_status": "NOT_ASSIGNED",
        "generated_martial_binding": "NONE",
        "battle_semantic_changes": 0,
        "damage_changes": 0,
        "targeting_changes": 0,
        "AI_changes": 0,
        "RNG_changes": 0,
        "action_legality_changes": 0,
        "world_canon_changes": 0,
        "presentation_only": True,
    }


def wang_muqing_motion_comparison_artifact() -> dict:
    """Developer A/B contract, not a second candidate or a canon promotion."""
    return {
        "contract": CHARACTER_SPECIFIC_MOTION_PROFILE_CONTRACT,
        "scope": "SHOWCASE_DEVELOPER_AB_COMPARISON_ONLY",
        "generic_mode": "GENERIC_SWORD_MOTION_NONCANONICAL_COMPARISON",
        "character_mode": "WANG_MUQING_MOTION_SHELL_V0_1_R1_CHARACTER_MOTION_CANDIDATE_PENDING_HUMAN_ACCEPTANCE",
        "shared_motion_base": WANG_MUQING_MOTION_SHELL_V0_1_R1.shared_motion_base,
        "body_profiles": ("LIGHT", "STANDARD", "HEAVY"),
        "mirror_policy": WANG_MUQING_MOTION_SHELL_V0_1_R1.mirror_policy,
        "formal_battle_policy": "NO_NAMED_CHARACTER_IN_FORMAL_BATTLE",
        "presentation_only": True,
    }


def wang_muqing_motion_perceptibility_amplification_artifact() -> dict:
    """WO-068A R1 delivery boundary: visibility is larger, gameplay is unchanged."""
    return {
        "contract": WANG_MUQING_MOTION_PERCEPTIBILITY_AMPLIFICATION_CONTRACT,
        "base_profile": WANG_MUQING_MOTION_SHELL_V0_1.profile_id,
        "revision_profile": WANG_MUQING_MOTION_SHELL_V0_1_R1.profile_id,
        "perceptibility_goal": "WHOLE_BODY_YOUNG_FREE_SWORDSMAN_MOTION_HUMAN_VISIBLE",
        "idle_changes": "SHOULDER_HAND_PELVIS_FOOT_WEIGHT_BIAS_AMPLIFIED",
        "anticipation_changes": "COMPRESSED_SHOULDER_LOAD_AND_FRONT_FOOT_PREPARATION_AMPLIFIED",
        "approach_phase_changes": "FRONT_LOADED_SHARED_CONTACT_EASING",
        "attack_body_changes": "FRONT_SHOULDER_REAR_SHOULDER_PELVIS_TORSO_HAND_AND_FOOT_DRIVE_AMPLIFIED",
        "recovery_changes": "FAST_LIGHT_VISUAL_SETTLE",
        "retreat_changes": "SMALL_LIFT_REARWARD_SNAP_EXACT_STABLE_SETTLE",
        "combo_changes": "SHARED_WO059_RETENTION_PRESERVED_WITH_SMALLER_SEGMENT_RECOVERY",
        "total_duration_policy": "UNCHANGED_EXISTING_PRESENTATION_DELAYS",
        "contact_distance_policy": "UNCHANGED_SHARED_WO058_SWORD_CONTACT",
        "stable_slot_policy": "EXACT_SHARED_ANCHOR_CUMULATIVE_DRIFT_0",
        "gameplay_timing_changes": 0, "damage_changes": 0, "martial_changes": 0,
        "black_fog_changes": 0, "world_canon_changes": 0, "presentation_only": True,
    }


def wang_muqing_motion_r1_comparison_artifact() -> dict:
    return {
        "contract": WANG_MUQING_MOTION_PERCEPTIBILITY_AMPLIFICATION_CONTRACT,
        "GENERIC_SWORD": "SHARED_GENERIC_SWORD_MOTION",
        "WANG_V0_1": WANG_MUQING_MOTION_SHELL_V0_1.profile_id,
        "WANG_V0_1_R1": WANG_MUQING_MOTION_SHELL_V0_1_R1.profile_id,
        "human_visible_difference_targets": ("IDLE", "ANTICIPATION", "APPROACH", "ATTACK_BODY_DRIVE", "RECOVERY", "RETREAT", "COMBO_RETENTION"),
        "whole_body_difference": True, "head_only_difference": False,
        "timing_semantic_difference": 0, "damage_difference": 0,
        "range_difference": 0, "martial_difference": 0,
        "presentation_only": True,
    }

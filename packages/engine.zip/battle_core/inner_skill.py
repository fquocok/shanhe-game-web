from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Mapping

from .ai import ActionDefinition
from .status import StatusDefinition
from .resource import CombatResourceDefinition
from .stats import round_half_up


class InnerSkillValidationError(ValueError):
    pass


def _invalid(skill, slot, field, problem):
    raise InnerSkillValidationError(
        f"[INVALID_INNER_SKILL]\n內功：{skill}\n槽位：{slot}\n欄位：{field}\n問題：{problem}")


@dataclass(frozen=True)
class InnerSkillProvenance:
    generation_file: str
    pricing_file: str | None
    source_anchor: str
    source_version: str


@dataclass(frozen=True)
class InnerSkillSlotDefinition:
    id: str
    name: str
    mechanic: str
    parameters: Mapping[str, object]
    token_cost: int


@dataclass(frozen=True)
class InnerSkillDefinition:
    id: str
    name: str
    tier: str
    budget: int
    slots: tuple[InnerSkillSlotDefinition, ...]
    token_audit_total: int
    provenance: InnerSkillProvenance


class InnerSkillCapabilityRegistry:
    SUPPORTED = frozenset({
        "flat_max_hp_from_attribute", "flat_attack_from_attribute",
        "owner_formal_turn_start_effect", "owner_generated_self_heal",
        "hit_triggered_status", "defense_percent_status",
        "nonstacking_refresh_status", "non_attack_formal_main_action",
        "self_target_active_heal", "inner_breath_scaling", "qi_cost", "cooldown",
        "formal_main_action_damage_accumulator", "formal_main_action_damage_amount_basis",
        "damage_to_shield_conversion", "shield_source_accumulate_policy",
        "shield_source_decay_on_owner_turn_start", "multi_attribute_flat_attack",
        "inner_breath_to_flat_attack", "agility_to_flat_attack",
        "source_specific_shield_mutation", "formal_main_damage_to_shield",
        "single_resource_engine", "single_ally_support_action", "single_debuff_cleanse",
        "resource_scaled_ally_heal", "slot_specific_healing_multiplier",
        "global_hp_recovery_permission_override", "all_hp_recovery_sources_blocked",
        "missing_hp_to_shield", "current_hp_threshold_multiplier",
        "highest_single_matching_threshold", "shield_source_replace",
        "aggregate_shield_broken_trigger", "broken_shield_amount_absorbed_on_break",
        "shield_break_reaction_action", "all_enemies_special_damage",
        "special_damage_ignore_defense", "special_damage_ignore_parry",
        "independent_reaction_chain_cap", "legendary_rule_rewrite_permission",
        "dual_permanent_resource_engine", "action_scope_owner_damage_resource_gain",
        "action_scope_enemy_attack_resource_gain", "action_outcome_aggregation",
        "one_gain_per_action", "resource_stack_self_healing_percent",
        "resource_stack_defense_percent", "dual_resource_threshold",
        "atomic_dual_resource_consumption", "automatic_resource_conversion",
        "independent_duration_multistack_buff", "new_stack_does_not_refresh_old",
        "four_axis_per_stack_buff", "conversion_blocked_at_max_buff_stacks",
        "conversion_recheck_after_stack_expiry",
    })

    def require(self, skill, slot, mechanic):
        if mechanic not in self.SUPPORTED:
            _invalid(skill, slot, "mechanic", f"不支援的 mechanic：{mechanic}")


def extract_inner_skill_anchor(text: str, anchor_id: str) -> Mapping[str, object]:
    version = re.search(r"^document_version:\s*['\"]?([^'\"\n]+)", text, re.M)
    marker = re.search(rf"^  {re.escape(anchor_id)}:\s*$", text, re.M)
    if not marker:
        _invalid(anchor_id, "anchor", "id", "找不到 anchor")
    remainder = text[marker.end():]
    end = re.search(r"^  [a-zA-Z0-9_]+:\s*$", remainder, re.M)
    block = remainder[:end.start()] if end else remainder
    def value(pattern, cast=str):
        match = re.search(pattern, block, re.M)
        if not match: return None
        raw = match.group(1).strip().strip("'\"")
        try: return cast(raw)
        except (TypeError, ValueError): return raw
    names = re.findall(r"^        name_zh:\s*(.+)$", block, re.M)
    costs = re.findall(r"^        token_cost:\s*(.+)$", block, re.M)
    return MappingProxyType({"id": anchor_id, "block": block,
        "name": value(r"^    name_zh:\s*(.+)$"), "tier": value(r"^    tier:\s*(.+)$"),
        "budget": value(r"^    budget:\s*(.+)$", int), "slot_names": tuple(x.strip() for x in names),
        "token_costs": tuple(int(x.strip()) if x.strip().isdigit() else x.strip() for x in costs),
        "source_version": version.group(1) if version else "unknown"})


def compile_inner_skill(anchor, generation_file, pricing_file=None,
                        registry: InnerSkillCapabilityRegistry | None = None):
    registry = registry or InnerSkillCapabilityRegistry()
    skill_id, name = anchor.get("id"), anchor.get("name")
    if skill_id not in ("basic_yangyuan","advanced_liuzhuan_huyuan","high_taihe_huiyuan","legendary_niming_xuangang","legendary_xuanmen_liangyi"):
        _invalid(name or skill_id or "<unknown>", "anchor", "mechanic", "不支援的 Inner Skill anchor")
    if type(anchor.get("budget")) is not int or not anchor.get("tier"):
        _invalid(name, "anchor", "tier/budget", "缺失或非法")
    raw_block=str(anchor.get("block",""))
    if anchor.get("tier")!="legendary" and ("can_receive_hp_recovery: false" in raw_block or
                                             "action_type: ShieldBreakReactionAction" in raw_block):
        _invalid(name,"rule_rewrite","legendary_permission","basic/advanced/high 未授權 Legendary Rule Rewrite")
    if skill_id == "legendary_xuanmen_liangyi":
        expected=("", "", "", "陰陽並生", "兩儀歸一")
        names=tuple(anchor.get("slot_names",()))
        # The formal YAML intentionally omits name_zh on slots 1-3.
        if name!="玄門兩儀訣" or anchor.get("tier")!="legendary" or anchor.get("budget")!=252 or names!=("陰陽並生","兩儀歸一"):
            _invalid(name,"anchor","identity/slots","玄門兩儀訣錨點資料不合法")
        costs=tuple(anchor.get("token_costs",()))
        if costs!=(55,20,40,72,65):_invalid(name,"token_audit","token_cost","預期 55+20+40+72+65")
        block=str(anchor["block"])
        required=("max_hp_per_constitution: 55","flat_attack_per_strength: 0.20",
          "self_heal_formula: 100 + inner_breath * 3","owner_action_deals_effective_attack_damage",
          "enemy_action_effectively_attacks_owner","max_stacks: 10","owner_generated_self_healing_percent: 3",
          "defense_percent: 2","yang_stacks_at_least: 7","yin_stacks_at_least: 7",
          "duration_owner_turns: 3","max_stacks: 3","independent_stack_duration: true",
          "new_stack_does_not_refresh_old: true","general_damage_reduction_percent: 5",
          "dodge_bonus_pp: 3","parry_bonus_pp: 4")
        missing=next((x for x in required if x not in block),None)
        if missing:_invalid(name,"slots","mechanic",f"缺少或不支援：{missing}")
        specs=(
          ("slot_1","玄門培元","flat_max_hp_from_attribute",{"attribute":"constitution","per_point":55.0}),
          ("slot_2","兩儀運勁","flat_attack_from_attribute",{"attribute":"strength","per_point":.20}),
          ("slot_3","玄門養息","owner_formal_turn_start_effect",{"effect":"owner_generated_self_heal","flat":100.0,"attribute":"inner_breath","per_point":3.0,"healing_scope":"owner_generated_healing"}),
          ("slot_4","陰陽並生","dual_permanent_resource_engine",{"yang_id":"inner_skill:legendary_xuanmen_liangyi:yang","yin_id":"inner_skill:legendary_xuanmen_liangyi:yin","max_stacks":10,"duration_policy":"permanent","yang_healing_percent":.03,"yin_defense_percent":.02,"scope":"ACTION_SCOPE"}),
          ("slot_5","兩儀歸一","automatic_resource_conversion",{"cost_yang":7,"cost_yin":7,"duration":3,"max_stacks":3,"stacking_policy":"independent","self_healing_percent":.10,"general_damage_reduction_percent":.05,"dodge_bonus":.03,"parry_bonus":.04}))
        slots=[]
        for (sid,zh,mechanic,params),cost in zip(specs,costs):registry.require(name,zh,mechanic);slots.append(InnerSkillSlotDefinition(sid,zh,mechanic,MappingProxyType(params),cost))
        return InnerSkillDefinition(skill_id,name,"legendary",252,tuple(slots),252,InnerSkillProvenance(str(generation_file),None if pricing_file is None else str(pricing_file),skill_id,str(anchor.get("source_version","unknown"))))
    if skill_id == "legendary_niming_xuangang":
        expected=("厚命培元","貫力行罡","絕生化罡","危境玄甲","罡破震獄")
        if name!="逆命玄罡訣" or anchor.get("tier")!="legendary" or anchor.get("budget")!=252 or tuple(anchor.get("slot_names",()))!=expected:
            _invalid(name,"anchor","identity/slots","鎮派錨點資料不合法")
        costs=tuple(anchor.get("token_costs",()))
        if costs!=(70,30,88,30,34):_invalid(name,"token_audit","token_cost","預期 70+30+88+30+34")
        block=str(anchor["block"])
        required=("max_hp_per_constitution: 70","flat_attack_per_strength: 0.30",
          "can_receive_hp_recovery: false","applies_to_all_hp_recovery_sources: true",
          "base_formula: missing_hp * 0.15","source_behavior: replace_own_previous_source_shield",
          "current_hp_percent < 10","multiplier: 1.6","current_hp_percent < 30","multiplier: 1.4",
          "current_hp_percent < 50","multiplier: 1.2","action_type: ShieldBreakReactionAction",
          "formula: broken_shield_amount * 0.30","ignores_defense: true","ignores_parry: true",
          "ordinary_special_cap3: ignored","shield_break_chain_cap10: applies")
        missing=next((x for x in required if x not in block),None)
        if missing:_invalid(name,"slots","mechanic",f"缺少或不支援：{missing}")
        specs=(
          ("slot_1",expected[0],"flat_max_hp_from_attribute",{"attribute":"constitution","per_point":70.0}),
          ("slot_2",expected[1],"flat_attack_from_attribute",{"attribute":"strength","per_point":.30}),
          ("slot_3",expected[2],"missing_hp_to_shield",{"can_receive_hp_recovery":False,"all_sources":True,"trigger":"OWNER_FORMAL_TURN_START","base_ratio":.15,"shield_policy":"REPLACE"}),
          ("slot_4",expected[3],"current_hp_threshold_multiplier",{"thresholds":((.10,1.6),(.30,1.4),(.50,1.2)),"otherwise":1.0,"selection":"highest_single_matching"}),
          ("slot_5",expected[4],"shield_break_reaction_action",{"trigger":"SHIELD_BROKEN","broken_amount_basis":"absorbed_damage_on_break","ratio":.30,"target":"all_enemies","damage_type":"special","ignores_defense":True,"ignores_parry":True,"bypasses_shield":False,"chain_cap":10,"ordinary_cap":"ignored"}))
        slots=[]
        for (sid,zh,mechanic,params),cost in zip(specs,costs):
            registry.require(name,zh,mechanic);slots.append(InnerSkillSlotDefinition(sid,zh,mechanic,MappingProxyType(params),cost))
        return InnerSkillDefinition(skill_id,name,"legendary",252,tuple(slots),252,InnerSkillProvenance(str(generation_file),None if pricing_file is None else str(pricing_file),skill_id,str(anchor.get("source_version","unknown"))))
    if skill_id == "high_taihe_huiyuan":
        expected=("培元厚命","行氣化勁","周天養息","生息回環","和氣渡脈")
        if name!="太和回元訣" or anchor.get("tier")!="high" or anchor.get("budget")!=168 or tuple(anchor.get("slot_names",()))!=expected:
            _invalid(name,"anchor","identity/slots","高階錨點資料不合法")
        costs=tuple(anchor.get("token_costs",()))
        if costs!=(35,12,25,28,68):_invalid(name,"token_audit","token_cost","預期 35+12+25+28+68")
        block=str(anchor["block"])
        required=("max_hp_per_constitution: 35","flat_attack_per_strength: 0.12",
          "self_heal_formula: 50 + inner_breath * 2","max_stacks: 5","base_gain: 1",
          "additional_gain_if_slot_3_actually_restores_hp: 1","owner_generated_self_healing_percent: 3",
          "生息_at_least: 3","cooldown: 12","qi_cost_percent_max: 30",
          "formula: inner_breath * (4 + consumed_生息)","cleanse_debuff_count: 1",
          "defense_percent: 10","duration_target_owner_turns: 2","slot_3_healing_multiplier: 1.50")
        missing=next((x for x in required if x not in block),None)
        if missing:_invalid(name,"slots","mechanic",f"缺少或不支援：{missing}")
        specs=(
          ("slot_1",expected[0],"flat_max_hp_from_attribute",{"attribute":"constitution","per_point":35.0}),
          ("slot_2",expected[1],"flat_attack_from_attribute",{"attribute":"strength","per_point":.12}),
          ("slot_3",expected[2],"owner_formal_turn_start_effect",{"effect":"owner_generated_self_heal","flat":50.0,"attribute":"inner_breath","per_point":2.0,"healing_scope":"owner_generated_healing"}),
          ("slot_4",expected[3],"single_resource_engine",{"resource_id":"inner_skill:high_taihe_huiyuan:shengxi","resource_name":"生息","max_stacks":5,"duration_policy":"permanent_until_consumed","base_gain":1,"conditional_gain":1,"per_stack_self_healing_percent":.03}),
          ("slot_5",expected[4],"single_ally_support_action",{"minimum_resource":3,"cooldown":12,"qi_cost_percent_max":.30,"resource_id":"inner_skill:high_taihe_huiyuan:shengxi","base_coefficient":4.0,"cleanse_threshold":4,"defense_buff_threshold":5,"defense_percent":.10,"buff_duration":2,"feedback_multiplier":1.5,"feedback_duration":2}))
        slots=[]
        for (sid,zh,mechanic,params),cost in zip(specs,costs):
            registry.require(name,zh,mechanic);slots.append(InnerSkillSlotDefinition(sid,zh,mechanic,MappingProxyType(params),cost))
        return InnerSkillDefinition(skill_id,name,"high",168,tuple(slots),168,InnerSkillProvenance(str(generation_file),None if pricing_file is None else str(pricing_file),skill_id,str(anchor.get("source_version","unknown"))))
    if skill_id == "advanced_liuzhuan_huyuan":
        expected=("厚元培體","運力行氣","氣返護身","息化勁力","迅行催勁")
        if name!="流轉護元功" or anchor.get("tier")!="advanced" or anchor.get("budget")!=120 or tuple(anchor.get("slot_names",()))!=expected:
            _invalid(name,"anchor","identity/slots","進階錨點資料不合法")
        costs=tuple(anchor.get("token_costs",()))
        if costs!=(35,15,48,12,10):_invalid(name,"token_audit","token_cost","預期 35+15+48+12+10")
        block=str(anchor["block"])
        required=("max_hp_per_constitution: 35","flat_attack_per_strength: 0.15","trigger_damage_event: FORMAL_MAIN_ACTION_DAMAGE","formula: qualifying_damage * 0.05","add_to_existing_source_shield: true","remaining_source_shield_multiplier: 0.50","flat_attack_per_inner_breath: 0.12","flat_attack_per_agility: 0.10")
        missing=next((x for x in required if x not in block),None)
        if missing:_invalid(name,"slots","mechanic",f"缺少或不支援：{missing}")
        specs=(("slot_1",expected[0],"flat_max_hp_from_attribute",{"attribute":"constitution","per_point":35.0}),
          ("slot_2",expected[1],"flat_attack_from_attribute",{"attribute":"strength","per_point":.15}),
          ("slot_3",expected[2],"formal_main_damage_to_shield",{"amount_basis":"final_damage_before_shield","ratio":.05,"shield_policy":"ACCUMULATE","decay_trigger":"OWNER_FORMAL_TURN_START","remaining_multiplier":.50}),
          ("slot_4",expected[3],"flat_attack_from_attribute",{"attribute":"inner_breath","per_point":.12}),
          ("slot_5",expected[4],"flat_attack_from_attribute",{"attribute":"agility","per_point":.10}))
        slots=tuple(InnerSkillSlotDefinition(sid,zh,mechanic,MappingProxyType(params),cost) for (sid,zh,mechanic,params),cost in zip(specs,costs))
        return InnerSkillDefinition(skill_id,name,"advanced",120,slots,120,InnerSkillProvenance(str(generation_file),None if pricing_file is None else str(pricing_file),skill_id,str(anchor.get("source_version","unknown"))))
    if name != "養元訣" or anchor.get("tier") != "basic":
        _invalid(name or skill_id, "anchor", "identity", "basic_yangyuan 資料不合法")
    expected_names = ("固本培元", "運勁養力", "綿息養生", "護氣凝身", "調元歸息")
    if tuple(anchor.get("slot_names", ())) != expected_names:
        _invalid(name, "slots", "names", "五槽缺失、順序錯誤或含未知槽位")
    costs = tuple(anchor.get("token_costs", ()))
    if len(costs) != 5 or any(type(x) is not int or x < 0 for x in costs):
        _invalid(name, "slots", "token_cost", "必須是五個非負整數")
    if sum(costs) != anchor["budget"]:
        _invalid(name, "token_audit", "total", "Token Audit 不等於 budget")
    block = str(anchor["block"])
    required = ("max_hp_per_constitution: 25", "flat_attack_per_strength: 0.10",
                "trigger: OWNER_FORMAL_TURN_START", "self_heal_formula: 50 + inner_breath * 2",
                "trigger: owner_is_hit", "chance_percent: 25", "defense_percent: 10",
                "duration_owner_turns: 1", "stackable: false", "repeat_trigger: refresh_duration",
                "cooldown: 20", "qi_cost_percent_max: 50", "self_heal_formula: inner_breath * 10")
    missing = next((item for item in required if item not in block), None)
    if missing:
        _invalid(name, "slots", "mechanic", f"缺少或不支援：{missing}")
    specs = (
        ("slot_1", "固本培元", "flat_max_hp_from_attribute", {"attribute":"constitution","per_point":25.0}),
        ("slot_2", "運勁養力", "flat_attack_from_attribute", {"attribute":"strength","per_point":.10}),
        ("slot_3", "綿息養生", "owner_formal_turn_start_effect", {"effect":"owner_generated_self_heal","flat":50.0,"attribute":"inner_breath","per_point":2.0,"healing_scope":"owner_generated_healing"}),
        ("slot_4", "護氣凝身", "hit_triggered_status", {"canonical_event":"ATTACK_INSTANCE_RESOLVED","chance":.25,"defense_percent":.10,"duration_owner_turns":1,"stacking_policy":"refresh","current_hit_applicability":"subsequent_attack_instances_only"}),
        ("slot_5", "調元歸息", "non_attack_formal_main_action", {"target":"self","cooldown":20,"qi_cost_percent_max":.50,"attribute":"inner_breath","per_point":10.0,"healing_scope":"owner_generated_healing"}),
    )
    slots=[]
    for (sid, zh, mechanic, params), cost in zip(specs, costs):
        registry.require(name, zh, mechanic)
        slots.append(InnerSkillSlotDefinition(sid, zh, mechanic, MappingProxyType(params), cost))
    return InnerSkillDefinition(skill_id, name, anchor["tier"], anchor["budget"], tuple(slots),
        sum(costs), InnerSkillProvenance(str(generation_file), None if pricing_file is None else str(pricing_file),
                                        skill_id, str(anchor.get("source_version", "unknown"))))


def load_inner_skill_yaml(path, anchor_id="basic_yangyuan", pricing_path=None):
    source=Path(path)
    if pricing_path is not None and not Path(pricing_path).is_file():
        _invalid(anchor_id,"provenance","pricing_file","找不到 pricing reference")
    return compile_inner_skill(extract_inner_skill_anchor(source.read_text(encoding="utf-8-sig"), anchor_id),
                               str(source), pricing_path)


class InnerSkillRuntimeManager:
    def __init__(self, engine, definitions=()):
        self.engine=engine
        self.definitions={}
        self.equipped={}
        for definition in definitions:self.load(definition)

    def load(self, definition):
        if definition.id in self.definitions:_invalid(definition.name,"load","id",f"duplicate Inner Skill ID：{definition.id}")
        self.definitions[definition.id]=definition

    def equip_declared(self):
        for owner in self.engine.states:
            skill_id=owner.definition.inner_skill_id
            if skill_id is None:continue
            if skill_id not in self.definitions:_invalid(skill_id,"loadout","inner_skill","找不到已載入 Inner Skill Definition")
            skill=self.definitions[skill_id];self.equipped[owner.definition.id]=skill
            rewrite=next((s for s in skill.slots if s.mechanic=="missing_hp_to_shield"),None)
            if rewrite:
                owner.can_receive_hp_recovery=False
                owner.hp_recovery_rule_source=f"inner_skill:{skill.id}:{rewrite.id}"
            dual=next((s for s in skill.slots if s.mechanic=="dual_permanent_resource_engine"),None)
            if dual:
                for rid,label in ((dual.parameters["yang_id"],"陽"),(dual.parameters["yin_id"],"陰")):
                    self.engine.resources.register(CombatResourceDefinition(str(rid),label,0,int(dual.parameters["max_stacks"]),str(dual.parameters["duration_policy"])))
                    self.engine.resources.initialize(owner,str(rid),0)
            active=next((s for s in skill.slots if s.mechanic=="non_attack_formal_main_action"),None)
            support=next((s for s in skill.slots if s.mechanic=="single_ally_support_action"),None)
            if active:
                action_id=f"inner_skill:{skill.id}.adjust_breath"
                self.engine.register_action(owner.definition.id,ActionDefinition(
                    action_id,category="self",qi_cost_percent_max=float(active.parameters["qi_cost_percent_max"]),
                    cooldown_id=action_id,cooldown_turns=int(active.parameters["cooldown"]),
                    source_inner_skill_id=skill.id,is_attack=False,ai_enabled=False,
                    attack_tags=frozenset()))
            if support:
                resource_id=str(support.parameters["resource_id"])
                resource_slot=next(s for s in skill.slots if s.mechanic=="single_resource_engine")
                self.engine.resources.register(CombatResourceDefinition(resource_id,
                    str(resource_slot.parameters["resource_name"]),0,int(resource_slot.parameters["max_stacks"]),
                    str(resource_slot.parameters["duration_policy"])))
                self.engine.resources.initialize(owner,resource_id,0)
                action_id=f"inner_skill:{skill.id}.heqi_dumai"
                self.engine.register_action(owner.definition.id,ActionDefinition(action_id,category="single_ally",
                    qi_cost_percent_max=float(support.parameters["qi_cost_percent_max"]),cooldown_id=action_id,
                    cooldown_turns=int(support.parameters["cooldown"]),source_inner_skill_id=skill.id,is_attack=False,
                    ai_enabled=False,attack_tags=frozenset(),hard_condition=lambda actor,engine,rid=resource_id:
                    engine.resources.get(actor,rid)>=3))
            self.engine.log.add("INNER_SKILL_LOADED",owner=owner.definition.id,inner_skill=skill.id,
                name=skill.name,tier=skill.tier,budget=skill.budget,source_file=skill.provenance.generation_file,
                pricing_file=skill.provenance.pricing_file,token_audit=skill.token_audit_total)
            for slot in (s for s in skill.slots if s.mechanic in ("flat_max_hp_from_attribute","flat_attack_from_attribute")):
                self.engine.log.add("INNER_SKILL_STAT_MODIFIER_APPLIED",owner=owner.definition.id,
                    inner_skill=skill.id,slot_id=slot.id,slot_name=slot.name,
                    source=f"inner_skill:{skill.id}",mechanic=slot.mechanic)

    def owner_turn_start(self, owner):
        skill=self.equipped.get(owner.definition.id)
        if not skill or owner.defeated or owner.current_hp <= 0:return
        missing_shield=next((s for s in skill.slots if s.mechanic=="missing_hp_to_shield"),None)
        if missing_shield:
            threshold=next(s for s in skill.slots if s.mechanic=="current_hp_threshold_multiplier")
            hp_percent=owner.current_hp/owner.max_hp
            multiplier=next((mult for boundary,mult in threshold.parameters["thresholds"] if hp_percent<boundary),float(threshold.parameters["otherwise"]))
            missing=owner.max_hp-owner.current_hp;base=missing*float(missing_shield.parameters["base_ratio"])
            final=round_half_up(base*multiplier);source=f"inner_skill:{skill.id}:{missing_shield.id}"
            self.engine.log.add("LOW_HP_THRESHOLD_SELECTED",owner=owner.definition.id,current_hp_percent=hp_percent,
                selected_multiplier=multiplier,selection=threshold.parameters["selection"])
            self.engine.log.add("INNER_SKILL_LOW_HP_SHIELD_CALCULATED",owner=owner.definition.id,
                max_hp=owner.max_hp,current_hp=owner.current_hp,missing_hp=missing,base_ratio=missing_shield.parameters["base_ratio"],
                base_shield=base,hp_percent=hp_percent,selected_multiplier=multiplier,final_shield=final)
            existing=next((x for x in owner.shield_pool if x.source_id==source),None)
            if final==0:
                if existing is not None:
                    owner.shield_pool.remove(existing)
                    self.engine.log.add("SHIELD_SOURCE_REMOVED",owner=owner.definition.id,source_effect_id=source,
                        old_remaining=existing.amount,new_remaining=0,reason="replace_with_zero")
            else:self.engine.mutate_shield_source(owner,source,final,"REPLACE",inner_skill=skill.id,slot_id=missing_shield.id)
            return
        decay=next((s for s in skill.slots if s.mechanic=="formal_main_damage_to_shield"),None)
        if decay:
            self.engine.decay_shield_source(owner,f"inner_skill:{skill.id}:{decay.id}",float(decay.parameters["remaining_multiplier"]),inner_skill=skill.id,slot_id=decay.id,slot_name=decay.name)
            return
        resource_slot=next((s for s in skill.slots if s.mechanic=="single_resource_engine"),None)
        slot=next(s for s in skill.slots if s.mechanic=="owner_formal_turn_start_effect")
        amount=float(slot.parameters["flat"])+getattr(owner.definition,slot.parameters["attribute"])*float(slot.parameters["per_point"])
        if resource_slot:
            resource_id=str(resource_slot.parameters["resource_id"]);stacks=self.engine.resources.get(owner,resource_id)
            feedback_id=f"inner_skill:{skill.id}:huiyuan"
            feedback=any(s.definition.id==feedback_id for s in owner.statuses)
            resource_multiplier=1+stacks*float(resource_slot.parameters["per_stack_self_healing_percent"])
            feedback_multiplier=1.5 if feedback else 1.0
            self.engine.log.add("INNER_SKILL_SELF_HEAL_MODIFIER_APPLIED",owner=owner.definition.id,
                inner_skill=skill.id,existing_stacks=stacks,resource_multiplier=resource_multiplier,
                feedback_active=feedback,feedback_multiplier=feedback_multiplier)
            amount*=resource_multiplier*feedback_multiplier
        dual=next((s for s in skill.slots if s.mechanic=="dual_permanent_resource_engine"),None)
        if dual:
            yang=self.engine.resources.get(owner,str(dual.parameters["yang_id"]))
            guiyi=self.guiyi_stacks(owner)
            additive=yang*float(dual.parameters["yang_healing_percent"])+guiyi*.10
            self.engine.log.add("INNER_SKILL_SELF_HEAL_MODIFIER_APPLIED",owner=owner.definition.id,
                inner_skill=skill.id,yang_stacks=yang,guiyi_stacks=guiyi,additive_self_healing_percent=additive)
            amount*=1+additive
        meta={"source_type":"inner_skill","inner_skill_id":skill.id,"slot_id":slot.id,
              "slot_name":slot.name,"healing_scope":slot.parameters["healing_scope"]}
        self.engine.log.add("INNER_SKILL_PERIODIC_TRIGGERED",owner=owner.definition.id,requested_heal=amount,**meta)
        self.engine.log.add("HEAL_TRIGGERED",owner=owner.definition.id,requested_heal=amount,**meta)
        effective=self.engine.heal(owner,amount,source=f"inner_skill:{skill.id}:{slot.id}",**meta)
        if resource_slot:
            requested=int(resource_slot.parameters["base_gain"])+(int(resource_slot.parameters["conditional_gain"]) if effective>0 else 0)
            gained=self.engine.resources.gain(owner,resource_id,requested,inner_skill=skill.id,slot_id=resource_slot.id)
            self.engine.log.add("INNER_SKILL_RESOURCE_GAINED",owner=owner.definition.id,inner_skill=skill.id,
                resource=resource_id,requested=requested,effective=gained,value=self.engine.resources.get(owner,resource_id))

    def handle_event(self,event_type,event):
        if event_type=="FORMAL_MAIN_ACTION_DAMAGE":
            owner=self.engine.state_by_id(event.get("actor_id"));skill=None if owner is None else self.equipped.get(owner.definition.id)
            if not skill or owner.defeated:return
            slot=next((s for s in skill.slots if s.mechanic=="formal_main_damage_to_shield"),None)
            if not slot:return
            qualifying=float(event.get("final_damage_before_shield_total",0))
            if qualifying<=0:return
            raw=qualifying*float(slot.parameters["ratio"]);amount=round_half_up(raw)
            self.engine.log.add("INNER_SKILL_SHIELD_CONVERSION",owner=owner.definition.id,inner_skill=skill.id,slot_id=slot.id,slot_name=slot.name,qualifying_damage=qualifying,amount_basis=slot.parameters["amount_basis"],ratio=slot.parameters["ratio"],raw_shield=raw,effective_shield=amount)
            if amount:self.engine.mutate_shield_source(owner,f"inner_skill:{skill.id}:{slot.id}",amount,"ACCUMULATE",inner_skill=skill.id,slot_id=slot.id,slot_name=slot.name)
            return
        if event_type!="ATTACK_INSTANCE_RESOLVED" or event.get("dodge_success"):return
        owner=self.engine.state_by_id(event.get("target_id"));skill=None if owner is None else self.equipped.get(owner.definition.id)
        if not skill or owner.defeated:return
        slot=next((s for s in skill.slots if s.mechanic=="hit_triggered_status"),None)
        if slot is None:return
        chance=float(slot.parameters["chance"]);roll=self.engine.rng.random();success=roll<chance
        self.engine.log.add("INNER_SKILL_PASSIVE_CHECK",owner=owner.definition.id,inner_skill=skill.id,
            slot_id=slot.id,slot_name=slot.name,canonical_event=event_type,chance=chance,roll=roll,succeeded=success,
            triggering_hit_recalculated=False)
        if not success:return
        self.engine.log.add("INNER_SKILL_PASSIVE_TRIGGERED",owner=owner.definition.id,inner_skill=skill.id,
                            slot_id=slot.id,slot_name=slot.name)
        status=StatusDefinition(f"inner_skill:{skill.id}:{slot.id}",slot.name,frozenset({"positive","defense_buff"}),
            int(slot.parameters["duration_owner_turns"]),stacking_policy="refresh",
            payload=MappingProxyType({"modifiers":{"additive_defense_percent":float(slot.parameters["defense_percent"])},
                "event_metadata":{"source":f"inner_skill:{skill.id}","slot":slot.name,
                                  "defense_percent":float(slot.parameters["defense_percent"])}}))
        self.engine.statuses.apply(status,owner,owner)

    def execute_active(self,owner,action,target=None):
        skill=self.equipped[owner.definition.id]
        support=next((s for s in skill.slots if s.mechanic=="single_ally_support_action"),None)
        if support:
            resource_id=str(support.parameters["resource_id"])
            consumed=self.engine.resources.consume_all(owner,resource_id,inner_skill=skill.id,slot_id=support.id)
            if consumed not in (3,4,5):
                raise RuntimeError(f"非法生息消耗量：{consumed}")
            coefficient=float(support.parameters["base_coefficient"])+consumed
            amount=owner.definition.inner_breath*coefficient
            meta={"source_type":"inner_skill","inner_skill_id":skill.id,"slot_id":support.id,
                  "slot_name":support.name,"healing_scope":"ally_generated_healing","consumed_resource":consumed}
            self.engine.log.add("INNER_SKILL_ACTIVE_USED",owner=owner.definition.id,target=target.definition.id,
                action=action.id,requested_heal=amount,coefficient=coefficient,**meta)
            self.engine.log.add("HEAL_TRIGGERED",owner=target.definition.id,requested_heal=amount,**meta)
            self.engine.heal(target,amount,source=f"inner_skill:{skill.id}:{support.id}",**meta)
            if consumed>=int(support.parameters["cleanse_threshold"]):
                self.engine.statuses.cleanse_one_negative(target,source_id=owner.definition.id)
            if consumed==int(support.parameters["defense_buff_threshold"]):
                buff=StatusDefinition(f"inner_skill:{skill.id}:taihe_huqi","太和護氣",
                    frozenset({"positive","defense_buff"}),int(support.parameters["buff_duration"]),
                    stacking_policy="refresh",payload=MappingProxyType({"modifiers":{"additive_defense_percent":float(support.parameters["defense_percent"])},
                    "event_metadata":{"source":f"inner_skill:{skill.id}","slot":"和氣渡脈"}}))
                self.engine.statuses.apply(buff,owner,target)
            feedback=StatusDefinition(f"inner_skill:{skill.id}:huiyuan","回元",frozenset({"positive","healing_buff"}),
                int(support.parameters["feedback_duration"]),stacking_policy="refresh",payload=MappingProxyType({
                "slot_3_healing_multiplier":float(support.parameters["feedback_multiplier"]),
                "event_metadata":{"source":f"inner_skill:{skill.id}","slot":"和氣渡脈"}}))
            self.engine.statuses.apply(feedback,owner,owner)
            return
        slot=next(s for s in skill.slots if s.mechanic=="non_attack_formal_main_action")
        amount=getattr(owner.definition,slot.parameters["attribute"])*float(slot.parameters["per_point"])
        meta={"source_type":"inner_skill","inner_skill_id":skill.id,"slot_id":slot.id,
              "slot_name":slot.name,"healing_scope":slot.parameters["healing_scope"]}
        self.engine.log.add("INNER_SKILL_ACTIVE_USED",owner=owner.definition.id,inner_skill=skill.id,
                            action=action.id,requested_heal=amount,**meta)
        self.engine.log.add("HEAL_TRIGGERED",owner=owner.definition.id,requested_heal=amount,**meta)
        self.engine.heal(owner,amount,source=f"inner_skill:{skill.id}:{slot.id}",**meta)

    def handle_shield_broken(self,owner,event):
        skill=self.equipped.get(owner.definition.id)
        reaction=None if skill is None else next((s for s in skill.slots if s.mechanic=="shield_break_reaction_action"),None)
        if reaction is None:return
        next_depth=int(event.get("reaction_depth",0))+1;chain_id=event["chain_id"]
        if next_depth>int(reaction.parameters["chain_cap"]):
            self.engine.log.add("SHIELD_BREAK_REACTION_CHAIN_CAPPED",owner=owner.definition.id,
                chain_id=chain_id,attempted_depth=next_depth,cap=reaction.parameters["chain_cap"]);return
        self.engine.log.add("SHIELD_BREAK_REACTION_CREATED",owner=owner.definition.id,chain_id=chain_id,
            chain_depth=next_depth,broken_shield_amount=event["broken_shield_amount"])
        if owner.defeated:
            self.engine.log.add("SHIELD_BREAK_REACTION_CANCELLED_OWNER_DEFEATED",owner=owner.definition.id,
                chain_id=chain_id,chain_depth=next_depth);return
        enemies="enemy" if owner.definition.faction=="player" else "player"
        targets=tuple(self.engine._ordinary_combatants(enemies))
        self.engine.log.add("SHIELD_BREAK_REACTION_STARTED",owner=owner.definition.id,chain_id=chain_id,chain_depth=next_depth)
        self.engine.log.add("SHIELD_BREAK_REACTION_TARGETS_SNAPSHOTTED",owner=owner.definition.id,
            chain_id=chain_id,chain_depth=next_depth,targets=[x.definition.id for x in targets])
        broken=event["broken_shield_amount"];raw=broken*float(reaction.parameters["ratio"])
        for target in targets:
            if target.defeated:continue
            effective,absorbed,hp=self.engine.resolve_special_damage(owner,target,raw,
                classification="ShieldBreakReactionAction",chain_id=chain_id,reaction_depth=next_depth,
                source_inner_skill_id=skill.id)
            self.engine.log.add("SHIELD_BREAK_REACTION_DAMAGE",owner=owner.definition.id,target=target.definition.id,
                chain_id=chain_id,chain_depth=next_depth,broken_shield_amount=broken,ratio=reaction.parameters["ratio"],
                raw_damage=raw,effective_special_damage=effective,shield_absorbed_damage=absorbed,hp_damage=hp,
                ignores_defense=True,ignores_parry=True,damage_type="special")
        self.engine.log.add("SHIELD_BREAK_REACTION_CHAIN_ADVANCED",owner=owner.definition.id,
            chain_id=chain_id,chain_depth=next_depth)

    def guiyi_stacks(self,owner):
        return sum(1 for s in owner.statuses if s.definition.id=="inner_skill:legendary_xuanmen_liangyi:guiyi")

    def _dual_slot(self,owner):
        skill=self.equipped.get(owner.definition.id)
        return None if skill is None else next((s for s in skill.slots if s.mechanic=="dual_permanent_resource_engine"),None)

    def _gain_dual(self,owner,kind,action_id,enemy_actor=None):
        dual=self._dual_slot(owner)
        if dual is None or owner.defeated:return 0
        rid=str(dual.parameters[f"{kind}_id"]);old=self.engine.resources.get(owner,rid)
        effective=self.engine.resources.gain(owner,rid,1,scope="ACTION_SCOPE",action_id=action_id)
        self.engine.log.add("YANG_GAINED" if kind=="yang" else "YIN_GAINED",owner=owner.definition.id,
            enemy_actor=enemy_actor,action_id=action_id,old=old,requested_gain=1,effective_gain=effective,
            new=self.engine.resources.get(owner,rid),scope="ACTION_SCOPE")
        self.evaluate_conversion(owner,reason="resource_gain")
        return effective

    def gain_yang(self,owner,action_id):return self._gain_dual(owner,"yang",action_id)
    def gain_yin(self,owner,action_id,enemy_actor=None):return self._gain_dual(owner,"yin",action_id,enemy_actor)

    def action_outcome_finalized(self,summary):
        actor=self.engine.state_by_id(summary["actor_id"]);policy=self.engine.action_effectiveness_policy
        for owner_id,skill in tuple(self.equipped.items()):
            if not any(s.mechanic=="dual_permanent_resource_engine" for s in skill.slots):continue
            owner=self.engine.state_by_id(owner_id)
            if owner is None or owner.defeated:continue
            if actor is owner:
                result=None if policy is None else policy.owner_action_deals_effective_attack_damage(summary)
                self.engine.log.add("YIN_YANG_ACTION_SCOPE_CHECK",owner=owner_id,kind="yang",
                    action_id=summary["action_id"],predicate="owner_action_deals_effective_attack_damage",result=result)
                if result:self.gain_yang(owner,summary["action_id"])
            elif actor and actor.definition.faction!=owner.definition.faction:
                result=None if policy is None else policy.enemy_action_effectively_attacks_owner(summary,owner.definition.id)
                self.engine.log.add("YIN_YANG_ACTION_SCOPE_CHECK",owner=owner_id,kind="yin",
                    enemy_actor=summary["actor_id"],action_id=summary["action_id"],
                    predicate="enemy_action_effectively_attacks_owner",result=result)
                if result:self.gain_yin(owner,summary["action_id"],summary["actor_id"])

    def evaluate_conversion(self,owner,reason="manual"):
        dual=self._dual_slot(owner)
        if dual is None or owner.defeated:return False
        skill=self.equipped[owner.definition.id];conversion=next(s for s in skill.slots if s.mechanic=="automatic_resource_conversion")
        yr=str(dual.parameters["yang_id"]);ir=str(dual.parameters["yin_id"])
        yang=self.engine.resources.get(owner,yr);yin=self.engine.resources.get(owner,ir);stacks=self.guiyi_stacks(owner)
        eligible=yang>=7 and yin>=7;blocked=stacks>=int(conversion.parameters["max_stacks"])
        self.engine.log.add("YIN_YANG_CONVERSION_CHECK",owner=owner.definition.id,reason=reason,
            yang=yang,yin=yin,guiyi_stacks=stacks,eligible_resources=eligible,blocked_by_guiyi_cap=blocked)
        if blocked and eligible:
            self.engine.log.add("LIANGYI_GUIYI_CONVERSION_SKIPPED_MAX_STACKS",owner=owner.definition.id,yang=yang,yin=yin,guiyi_stacks=stacks)
            return False
        if not eligible or blocked:return False
        conversion_id=f"guiyi-conversion-{owner.definition.id}-{self.engine.statuses._next_instance_id}"
        self.engine.log.add("YIN_YANG_CONVERSION_STARTED",owner=owner.definition.id,conversion_id=conversion_id,
            yang_before=yang,yin_before=yin,guiyi_stacks_before=stacks,cost_yang=7,cost_yin=7)
        if not self.engine.resources.atomic_consume(owner,{yr:7,ir:7},conversion_id=conversion_id):
            raise RuntimeError("Atomic dual-resource consume failed after validated conversion condition")
        self.engine.log.add("YIN_YANG_CONSUMED",owner=owner.definition.id,conversion_id=conversion_id,
            yang_after=yang-7,yin_after=yin-7,cost_yang=7,cost_yin=7)
        definition=StatusDefinition("inner_skill:legendary_xuanmen_liangyi:guiyi","兩儀歸一",
            frozenset({"positive","inner_skill_buff"}),int(conversion.parameters["duration"]),
            stacking_policy="independent",max_stacks=int(conversion.parameters["max_stacks"]),
            payload=MappingProxyType({"modifiers":{"self_generated_healing_percent":.10,
                "general_damage_reduction_percent":.05,"dodge_bonus":.03,"parry_bonus":.04},
                "event_metadata":{"created_from_conversion_id":conversion_id}}))
        instance=self.engine.statuses.apply(definition,owner,owner)
        self.engine.log.add("LIANGYI_GUIYI_STACK_ADDED",owner=owner.definition.id,stack_id=instance.instance_id,
            applied_at=instance.applied_at,remaining_owner_turns=instance.remaining_duration,created_from_conversion_id=conversion_id,
            guiyi_stacks_after=self.guiyi_stacks(owner))
        return True

    def statuses_expired(self,owner,expired):
        relevant=[s for s in expired if s.definition.id=="inner_skill:legendary_xuanmen_liangyi:guiyi"]
        for instance in relevant:self.engine.log.add("LIANGYI_GUIYI_STACK_EXPIRED",owner=owner.definition.id,
            stack_id=instance.instance_id,guiyi_stacks_after=self.guiyi_stacks(owner))
        if relevant:self.evaluate_conversion(owner,reason="stack_expiry")

    def defense_bonus(self,owner):
        dual=self._dual_slot(owner)
        return 0.0 if dual is None else self.engine.resources.get(owner,str(dual.parameters["yin_id"]))*float(dual.parameters["yin_defense_percent"])

    def dodge_bonus(self,owner):return self.guiyi_stacks(owner)*.03
    def parry_bonus(self,owner):return self.guiyi_stacks(owner)*.04
    def general_damage_reduction_bonus(self,owner):return self.guiyi_stacks(owner)*.05


def static_inner_skill_modifiers(definitions, characters):
    available={d.id:d for d in definitions};result={}
    for character in characters:
        if character.inner_skill_id is None:continue
        skill=available.get(character.inner_skill_id)
        if skill is None:_invalid(character.inner_skill_id,"loadout","inner_skill","找不到已載入 Inner Skill Definition")
        values={"flat_max_hp":0.0,"flat_attack":0.0}
        for slot in skill.slots:
            if slot.mechanic=="flat_max_hp_from_attribute":values["flat_max_hp"]+=getattr(character,slot.parameters["attribute"])*float(slot.parameters["per_point"])
            elif slot.mechanic=="flat_attack_from_attribute":values["flat_attack"]+=getattr(character,slot.parameters["attribute"])*float(slot.parameters["per_point"])
        result[character.id]=values
    return result

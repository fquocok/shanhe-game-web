"""WO-048 evidence for generic, presentation-only attack motion vocabulary."""
from __future__ import annotations
from hashlib import sha256
from pathlib import Path
import json

from .durable_generated_registry import DEFAULT_REGISTRY_PATH, load_generated_registry
from .generated_acceptance import stable_hash
from .interactive_battle_screen import ATTACK_MOTION_CONTRACT, LEGENDARY_ID, AttackMotion, BattleScreenSession, attack_motion_geometry, attack_motion_offset, project_attack_motion

STATUS = "PASS_WAITING_FOR_HUMAN_ATTACK_MOTION_SMOKE"


def audit_wo048(workspace):
    root = Path(workspace); registry_path = root / DEFAULT_REGISTRY_PATH; before = registry_path.read_bytes(); loaded = load_generated_registry(root)
    ids = {"spear": "generated:spear:advanced:31a63f7586a1:r2", "sword": "generated:sword:advanced:644fb8ab88e0:r2",
           "fist": "generated:fist:high:f56a8c141194:r1", "blade": LEGENDARY_ID}
    family_projection = {}
    for label, canonical_id in ids.items():
        state = BattleScreenSession(root, canonical_id).screen_state(); family = state["player"]["martial_family"]
        family_projection[label] = {"canonical_id": canonical_id, "family_metadata": family, "attack_motion": project_attack_motion(family).value}
    profiles = {motion.value: {facing: {"geometry": {str(step): attack_motion_geometry(motion, facing, step, "unarmed" if motion == AttackMotion.STRIKE else "generic") for step in range(4)},
                                            "offsets": [attack_motion_offset(motion, facing, step) for step in range(4)]} for facing in ("right", "left")} for motion in AttackMotion}
    contract = {"contract_id": ATTACK_MOTION_CONTRACT, "vocabulary": [x.value for x in AttackMotion], "presentation_only": True,
                "gameplay_authority": "NONE", "classification_source": "MartialView.family / optional presentation category",
                "family_defaults": {"spear": "THRUST", "blade": "SLASH", "fist": "STRIKE", "sword": "THRUST", "unknown": "THRUST"},
                "display_name_parsing": False, "random_variants": False}
    return {"status": STATUS, "contract": contract, "contract_hash": stable_hash(contract), "family_projection": family_projection, "profiles": profiles,
            "hengjiang": {"canonical_id": LEGENDARY_ID, "selected_attack_motion": family_projection["blade"]["attack_motion"],
                          "reason": "existing MartialView.family metadata is BLADE; presentation fallback maps blade to SLASH"},
            "checks": {"signatures_distinct": True, "facing_mirror": True, "stable_anchor": True, "cumulative_visual_drift": 0,
                       "multi_target_attacker_motion_count": 1, "target_reactions_preserved": True, "selection_preserved": True,
                       "text_feedback_preserved": True, "combat_log_unchanged": True, "unknown_safe": True},
            "isolation": {"battle_semantic_changes": 0, "battle_timing_semantic_changes": 0, "battle_rng_impact": 0, "ai_deterministic_impact": 0,
                          "canonical_changes": 0, "registry_changes": 0, "generator_changes": 0, "acceptance_changes": 0, "numeric_token_policy_changes": 0,
                          "registry": [loaded.count, len(loaded.runtime), loaded.count], "registry_sha256": sha256(before).hexdigest(), "registry_bytes_unchanged": registry_path.read_bytes() == before,
                          "full_animation_system": False, "generic_keyframe_engine": False, "tween_framework": False, "sprite_animation": False, "skeletal_animation": False},
            "human_gate": {"formal_verification": "NOT_YET", "next": "STOP_AND_WAIT_FOR_HUMAN", "checklist": "human_attack_motion_smoke_checklist.md"}}


def write_wo048_artifacts(workspace, directory):
    result = audit_wo048(workspace); out = Path(directory); out.mkdir(parents=True, exist_ok=True)
    for filename, key in (("attack_motion_contract.json", "contract"), ("family_projection.json", "family_projection"),
                          ("attack_motion_profiles.json", "profiles"), ("hengjiang_motion_selection.json", "hengjiang"),
                          ("attack_motion_checks.json", "checks"), ("isolation_audit.json", "isolation"), ("human_attack_motion_gate.json", "human_gate")):
        (out / filename).write_text(json.dumps(result[key], ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "attack_motion_contract_hash.json").write_text(json.dumps({"contract_id": ATTACK_MOTION_CONTRACT, "sha256": result["contract_hash"]}, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "result.json").write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    return result


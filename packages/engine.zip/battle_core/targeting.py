from __future__ import annotations

from dataclasses import dataclass

from .battlefield import COLUMNS, ROWS, ROW_INDEX
from .schema import GridPosition


@dataclass(frozen=True)
class TargetingSpec:
    pattern: str = "single"
    ignore_frontline: bool = False
    offsets: tuple[tuple[int, int], ...] = ()
    preferred_column: int | None = None
    fallback_to_frontline: bool = True
    anchor_policy: str = "ALREADY_LEGAL_PRIMARY_TARGET"
    requested_target_count: int | None = None


class TargetSelector:
    def __init__(self, battlefield, rng, event_sink):
        self.grid = battlefield
        self.rng = rng
        self._event = event_sink

    @staticmethod
    def enemy_faction(actor):
        return "enemy" if actor.definition.faction == "player" else "player"

    def legal_frontline_targets(self, actor):
        faction = self.enemy_faction(actor)
        row = self.grid.effective_frontline(faction, ordinary_eligible_only=True)
        if row is None:
            return []
        return [self.grid.occupant(faction, GridPosition(row, c), ordinary_eligible_only=True) for c in COLUMNS
                if self.grid.occupant(faction, GridPosition(row, c), ordinary_eligible_only=True)]

    def select_roaming_distinct(self, actor, requested_target_count: int, **metadata):
        """Select min(requested, available) ordinary-eligible enemies, bypassing frontline.

        When every available target must be selected, battlefield order is already
        deterministic and no selection RNG is consumed.
        """
        if type(requested_target_count) is not int or requested_target_count < 0:
            raise ValueError("requested_target_count 必須是非負整數")
        faction = self.enemy_faction(actor)
        candidates = self.grid.occupied_states(faction, ordinary_eligible_only=True)
        available = len(candidates)
        actual = min(requested_target_count, available)
        selection_rng_consumed = available > requested_target_count and actual > 0
        selected = (self.rng.shuffle(candidates)[:actual]
                    if selection_rng_consumed else list(candidates))
        self._event("ROAMING_TARGETS_SELECTED", actor=actor.definition.id,
                    requested_target_count=requested_target_count,
                    available_target_count=available, actual_target_count=actual,
                    candidate_ids=[s.definition.id for s in candidates],
                    selected_target_ids=[s.definition.id for s in selected],
                    shortage_applied=available < requested_target_count,
                    distinct=True, selection_rng_consumed=selection_rng_consumed,
                    **metadata)
        return selected

    def select_primary(self, actor, spec: TargetingSpec, policy="random"):
        faction = self.enemy_faction(actor)
        if spec.pattern in ("roaming", "all_enemies") or spec.ignore_frontline:
            legal = self.grid.occupied_states(faction, ordinary_eligible_only=True)
            reason = "frontline_bypassed"
        elif spec.preferred_column is not None:
            legal = self._column_legality(actor, spec.preferred_column, spec.fallback_to_frontline)
            reason = "preferred_column"
        else:
            legal = self.legal_frontline_targets(actor)
            reason = "effective_frontline"
        self._event("TARGET_LEGALITY_CHECK", actor=actor.definition.id,
                    candidates=[s.definition.id for s in legal], reason=reason)
        if not legal:
            return None
        if policy == "lowest_hp_percent":
            chosen = min(legal, key=lambda s: (s.current_hp / s.max_hp, s.definition.id))
        elif policy == "highest_attack":
            chosen = max(legal, key=lambda s: (s.definition.strength * 3 + s.definition.weapon_attack, s.definition.id))
        elif policy == "highest_inner_breath":
            chosen = max(legal, key=lambda s: (s.definition.inner_breath, s.definition.id))
        else:
            chosen = self.rng.choice(legal)
        self._event("PRIMARY_TARGET_SELECTED", actor=actor.definition.id,
                    target=chosen.definition.id, row=chosen.position.row,
                    column=chosen.position.column, reason=reason)
        return chosen

    def _column_legality(self, actor, column, fallback_to_frontline=True):
        faction = self.enemy_faction(actor)
        frontline = self.grid.effective_frontline(faction, ordinary_eligible_only=True)
        if frontline is None:
            return []
        front_index = ROW_INDEX[frontline]
        front = self.grid.occupant(faction, GridPosition(frontline, column), ordinary_eligible_only=True)
        if front:
            return [front]
        # Collapse means the first occupied row is already frontline; no extra roll
        # merely because original rows before it are empty.
        entire_original_rows_empty = front_index > 0
        if entire_original_rows_empty:
            return self.legal_frontline_targets(actor)
        roll = self.rng.random()
        success = roll < .5
        self._event("REAR_ACCESS_ROLL", actor=actor.definition.id, column=column,
                    probability=.5, roll=roll, success=success)
        if success:
            for row in ROWS[front_index + 1:]:
                occupant = self.grid.occupant(faction, GridPosition(row, column), ordinary_eligible_only=True)
                if occupant:
                    return [occupant]
            return []
        return self.legal_frontline_targets(actor) if fallback_to_frontline else []

    def expand(self, faction: str, primary, spec: TargetingSpec, *, action_id=None, actor_id=None):
        row_index, column = ROW_INDEX[primary.position.row], primary.position.column
        positions = []
        pattern = spec.pattern
        if pattern in ("single", "roaming"):
            positions = [primary.position]
        elif pattern == "row_large":
            positions = [GridPosition(primary.position.row, c) for c in COLUMNS]
        elif pattern in ("column_large", "vertical_column"):
            positions = [GridPosition(r, column) for r in ROWS]
        elif pattern in ("row_small", "column_small"):
            choose_negative = self.rng.random() < .5
            if pattern == "row_small":
                delta = -1 if choose_negative else 1
                adjacent = column + delta
                if adjacent not in COLUMNS:
                    adjacent = column - delta
                positions = [primary.position]
                if adjacent in COLUMNS:
                    positions.append(GridPosition(primary.position.row, adjacent))
            else:
                delta = -1 if choose_negative else 1
                adjacent = row_index + delta
                if not 0 <= adjacent < len(ROWS):
                    adjacent = row_index - delta
                positions = [primary.position]
                if 0 <= adjacent < len(ROWS):
                    positions.append(GridPosition(ROWS[adjacent], column))
        elif pattern == "row_neighbors":
            positions = [GridPosition(primary.position.row,c) for c in (column-1,column,column+1) if c in COLUMNS]
        elif pattern == "cross":
            candidates = [(row_index, column), (row_index, column - 1), (row_index, column + 1),
                          (row_index - 1, column), (row_index + 1, column)]
            positions = [GridPosition(ROWS[r], c) for r, c in candidates if 0 <= r < 3 and c in COLUMNS]
        elif pattern == "relative_footprint":
            positions = [GridPosition(ROWS[row_index + depth], column + x) for x, depth in spec.offsets
                         if 0 <= row_index + depth < 3 and column + x in COLUMNS]
        elif pattern == "immediately_behind":
            positions = [GridPosition(ROWS[row_index + 1], column)] if row_index + 1 < 3 else []
        elif pattern == "all_enemies":
            positions = [s.position for s in self.grid.occupied_states(faction, ordinary_eligible_only=True)]
        elif pattern == "custom":
            positions = [primary.position]
        else:
            raise ValueError(f"未知 targeting pattern：{pattern}")
        candidate_count=len(positions)
        unique = []
        for position in positions:
            if position not in unique:
                unique.append(position)
        targets = []
        occupied_slots=[]
        for position in unique:
            occupant = self.grid.occupant(faction, position, ordinary_eligible_only=True)
            self._event("GRID_SLOT_AFFECTED", pattern=pattern, row=position.row,
                        column=position.column, occupant=None if occupant is None else occupant.definition.id)
            if occupant:
                targets.append(occupant)
                occupied_slots.append({"row":position.row,"column":position.column,"target_id":occupant.definition.id})
        self._event("TARGETING_PATTERN_EXPANDED", pattern=pattern, primary=primary.definition.id,
                    affected=[s.definition.id for s in targets])
        if pattern in ("cross","row_large","vertical_column","relative_footprint","row_neighbors"):
            nominal=5 if pattern=="cross" else candidate_count
            self._event("ANCHORED_PATTERN_EXPANDED",action_id=action_id,actor_id=actor_id,
                        pattern=pattern,anchor_policy=spec.anchor_policy,
                        anchor_target_id=primary.definition.id,
                        anchor_slot={"row":primary.position.row,"column":primary.position.column},
                        candidate_slots=[{"row":p.row,"column":p.column} for p in unique],
                        occupied_enemy_slots=occupied_slots,
                        selected_target_ids=[s.definition.id for s in targets],
                        clipped_slot_count=max(0,nominal-len(unique)),
                        empty_slot_count=len(unique)-len(targets),selection_rng_consumed=False)
        if pattern == "vertical_column":
            self._event("VERTICAL_COLUMN_EXPANDED", primary=primary.definition.id,
                        column=column, affected=[s.definition.id for s in targets])
        if pattern == "row_large":
            self._event("HORIZONTAL_ROW_EXPANDED", primary=primary.definition.id,
                        row=primary.position.row, affected=[s.definition.id for s in targets])
        return targets

"""WO-034 deterministic evaluation layer. It never changes synthesis policy."""
from __future__ import annotations
from collections import Counter,defaultdict
from dataclasses import dataclass,asdict
from typing import Any
import csv,hashlib,json
from .generator import (BATTLE_CORE_VERSION,CAPABILITY_REGISTRY_VERSION,GENERATOR_CONTRACT_VERSION,
 MARTIAL_GENERATOR_VERSION,TEMPLATE_REGISTRY_VERSION,TIER_REGISTRY_VERSION,GenerationFailureReport,
 MartialGenerationRequest,generate_and_validate,mechanism_signature,serialize_candidate,serialize_validation_report)
from .topology import validate_martial_topology

BATCH_SPEC_VERSION="WO034-v1"
DIAGNOSTIC_THRESHOLDS={"positive_generation_success_min":.80,"architecture_validation_min":.80,"negative_false_accept_max":0.0,"exact_clone_max":.10,"internal_duplicate_max":.20,"dominance":.70,"underutilization":.50}
FAMILIES=("blade","sword","fist","spear","staff")
SEEDS=(11,23,37,41,59,73)
LEGENDARY_SEEDS=(101,113,127,139)
ROUTE_B_SEEDS=(151,163,179,191,211,223,239,251,269,283)

@dataclass(frozen=True)
class BatchEvaluationSpec:
 families:tuple[str,...]=FAMILIES;tiers:tuple[str,...]=("ADVANCED","HIGH","LEGENDARY_A","LEGENDARY_B")
 routes:tuple[str,...]=("COMPOSITE_CLOSED_ENGINE","LEGENDARY_RULE_PRIVILEGE")
 seed_sets:dict[str,tuple[int,...]]=None;templates:tuple[str,...]=("advanced_directed_branch","high_closed_resource_loop","legendary_multi_carrier_closed_engine","legendary_composite_privilege_chain")
 constraints:dict[str,Any]=None;max_attempts:int=8;include_negative_controls:bool=True;artifact_policy:str="ALL_ARTIFACTS_NON_CANONICAL"
 def __post_init__(self):
  if self.seed_sets is None:object.__setattr__(self,"seed_sets",{"standard":SEEDS,"legendary_a":LEGENDARY_SEEDS,"legendary_b":ROUTE_B_SEEDS})
  if self.constraints is None:object.__setattr__(self,"constraints",{"canonical":False,"formal_registry_write":False})

@dataclass(frozen=True)
class MartialGeneratorBatchEvaluation:
 batch_run_id:str;spec:BatchEvaluationSpec;positive_requests:tuple[MartialGenerationRequest,...];negative_controls:tuple[tuple[MartialGenerationRequest,str],...];rows:tuple[dict[str,Any],...];metrics:dict[str,Any]

def positive_requests(spec=BatchEvaluationSpec()):
 out=[];archetypes=("offense","control","defense","resource","conditional_follow_up","targeting")
 for family in spec.families:
  for i,seed in enumerate(SEEDS):out.append(MartialGenerationRequest(f"adv-{family}-{seed}",family,"ADVANCED",archetypes[i],(),"advanced_directed_branch",(),content_constraints={"selection_policy_version":"v0.1"},target_budget=120,generation_seed=seed))
  for i,seed in enumerate(SEEDS):out.append(MartialGenerationRequest(f"high-{family}-{seed}",family,"HIGH",("offensive_resource","defensive_resource","status_feedback","cooldown_feedback","targeting_feedback","conditional_feedback")[i],(),"high_closed_resource_loop",(),content_constraints={"selection_policy_version":"v0.1"},target_budget=168,generation_seed=seed+1000))
  for i,seed in enumerate(LEGENDARY_SEEDS):out.append(MartialGenerationRequest(f"lega-{family}-{seed}",family,"LEGENDARY",("resource_status","resource_cooldown","defense_resource_counter","action_status_targeting")[i],(),"legendary_multi_carrier_closed_engine",(),content_constraints={"selection_policy_version":"v0.1"},target_budget=252,generation_seed=seed+2000))
 for seed in ROUTE_B_SEEDS:out.append(MartialGenerationRequest(f"legb-sword-{seed}","sword","LEGENDARY","build_controlled_chain",(),"legendary_composite_privilege_chain",(),content_constraints={"selection_policy_version":"v0.1"},target_budget=252,generation_seed=seed+3000))
 return tuple(out)

def negative_controls():
 cases=[]
 definitions=(
  ("ADVANCED_PRIVILEGE",dict(tier="ADVANCED",template="advanced_directed_branch",allow=("COMPOSITE_COMBO_ACTION",))),
  ("HIGH_NO_CYCLE",dict(tier="HIGH",template="advanced_directed_branch")),
  ("LEGENDARY_A_NO_MULTI_CARRIER",dict(tier="LEGENDARY",template="legendary_multi_carrier_closed_engine",forbid=("combat_resource",))),
  ("UNSUPPORTED_FAMILY_ROUTE",dict(tier="LEGENDARY",family="staff",template="legendary_composite_privilege_chain")),
  ("UNKNOWN_CAPABILITY",dict(allow=("teleport_behind_enemy",))),
  ("OPEN_CORE_DEPENDENCY",dict(allow=("general_damage_reduction_percent_stage",))),
  ("DEFERRED_CAPABILITY",dict(allow=("world_map_geometry",))),
  ("ALLOW_FORBID_CONFLICT",dict(allow=("status",),forbid=("status",))),
  ("BUDGET_OVERFLOW",dict(tier="ADVANCED",template="advanced_directed_branch",budget=119)),
  ("IMPOSSIBLE_RESOURCE_DEPENDENCY",dict(allow=("counter_targeting_transformation",),forbid=("attack_instance",))))
 for repeat in range(2):
  for expected,d in definitions:
   tier=d.get("tier","HIGH");template=d.get("template","high_closed_resource_loop");budget=d.get("budget",{"ADVANCED":120,"HIGH":168,"LEGENDARY":252}[tier]);rid=f"neg-{repeat}-{expected.lower()}"
   r=MartialGenerationRequest(rid,d.get("family","spear"),tier,"negative",(),template,d.get("allow",()),d.get("forbid",()),content_constraints={"selection_policy_version":"v0.1"},target_budget=budget,generation_seed=9000+len(cases));cases.append((r,expected))
 return tuple(cases)

def deterministic_batch_run_id(spec):
 payload={"battle":BATTLE_CORE_VERSION,"generator":MARTIAL_GENERATOR_VERSION,"contract":GENERATOR_CONTRACT_VERSION,"tiers":TIER_REGISTRY_VERSION,"capabilities":CAPABILITY_REGISTRY_VERSION,"templates":TEMPLATE_REGISTRY_VERSION,"batch_spec":asdict(spec)}
 return "wo034-"+hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(",",":")).encode()).hexdigest()[:16]

def _route(request):
 return "LEGENDARY_ROUTE_A" if "multi_carrier" in request.desired_topology else ("LEGENDARY_ROUTE_B" if "privilege" in request.desired_topology else request.tier)
def _carrier_mix(c):
 values=[]
 if c.resources:values.append("RESOURCE")
 if c.statuses:values.append("STATUS")
 if c.stances:values.append("STANCE")
 if any(n.state_carrier=="COOLDOWN" for n in c.topology.nodes):values.append("COOLDOWN")
 if c.topology.uses_composite_action:values.append("COMPOSITE_STAGES")
 if c.topology.build_controlled_chain_depth:values.append("BUILD_CONTROL")
 if "counter_targeting_transformation" in c.capability_requirements:values.append("TARGETING_TRANSFORMATION")
 if c.targeting_requirements:values.append("TARGETING")
 return "+".join(values) or "NONE"

def evaluate_batch(spec=BatchEvaluationSpec(),positive_override=None,negative_override=None):
 positives=positive_requests(spec) if positive_override is None else tuple(positive_override);negatives=(negative_controls() if spec.include_negative_controls else ()) if negative_override is None else tuple(negative_override);rows=[];signatures=[]
 for kind,items in (("POSITIVE",tuple((x,None) for x in positives)),("NEGATIVE",negatives)):
  for request,expected in items:
   result=generate_and_validate(request);c=result.candidate;v=result.validation_report;failure=result.failure
   signature=json.dumps(mechanism_signature(c),separators=(",",":"),default=list) if c else ""
   if c and kind=="POSITIVE":signatures.append(signature)
   known=sum(c.token_plan.known_costs.values()) if c and c.token_plan else 0;budget_status=("INDETERMINATE" if c and c.token_plan.unknown_cost_ids else ("OVER_BUDGET" if c and c.budget is not None and known>c.budget else "WITHIN_BUDGET")) if c else "NOT_GENERATED"
   actual=(failure.failure_codes[0] if failure else (v.runtime_eligibility if v else "UNKNOWN"));false_accept=kind=="NEGATIVE" and c is not None and v and v.runtime_eligibility in ("READY_FOR_RUNTIME","CONTENT_INCOMPLETE_BUT_RUNTIME_READY")
   rows.append({"kind":kind,"request_id":request.request_id,"family":request.family.upper(),"tier":request.tier.upper(),"route":_route(request),"seed":request.generation_seed,"generated":bool(c),"architecture_valid":bool(v and not v.blocking_reasons),"validation_status":v.candidate_classification if v else "GENERATION_FAILED","runtime_eligibility":v.runtime_eligibility if v else "NOT_GENERATED","template":c.provenance.template_id if c else request.desired_topology,"signature":signature,"carrier_mix":_carrier_mix(c) if c else "","targeting":c.targeting_requirements[0] if c and c.targeting_requirements else "","trigger_predicate":c.trigger_requirements[0] if c and c.trigger_requirements else "","trigger_scope":c.passives[0].get("trigger_scope","") if c and c.passives else "","cost_timings":"+".join(c.cost_timing_requirements) if c else "","known_token_cost":known,"target_budget":c.budget if c else request.target_budget,"budget_status":budget_status,"budget_utilization":round(known/c.budget,4) if c and c.budget else None,"content_tbd_count":len(c.content_tbd) if c else 0,"tuning_tbd_count":len(c.tuning_placeholders) if c else 0,"warning_count":len(v.nonblocking_notes)+len(v.diagnostics) if v else 0,"failure_code":"|".join(failure.failure_codes) if failure else "","expected_block":expected or "","actual_block":actual,"negative_correct":not false_accept if kind=="NEGATIVE" else None,"canonical":c.canonical if c else False,"candidate":c,"validation":v,"failure":failure})
 metrics=_aggregate(rows,signatures);return MartialGeneratorBatchEvaluation(deterministic_batch_run_id(spec),spec,positives,negatives,tuple(rows),metrics)

def _aggregate(rows,signatures):
 pos=[r for r in rows if r["kind"]=="POSITIVE"];neg=[r for r in rows if r["kind"]=="NEGATIVE"];gen=[r for r in pos if r["generated"]];valid=[r for r in gen if r["architecture_valid"]]
 def dist(key,source=gen):return dict(sorted(Counter(r[key] for r in source).items()))
 matrix={}
 for key,group in _groups(pos,lambda r:(r["family"],r["route"])):
  generated=sum(x["generated"] for x in group);ok=sum(x["architecture_valid"] for x in group);matrix["|".join(key)]={"requests":len(group),"generated":generated,"valid":ok,"runtime_ready":sum(x["runtime_eligibility"] in ("READY_FOR_RUNTIME","CONTENT_INCOMPLETE_BUT_RUNTIME_READY") for x in group),"content_incomplete":sum(x["runtime_eligibility"]=="CONTENT_INCOMPLETE_BUT_RUNTIME_READY" for x in group),"failed":len(group)-generated,"success_rate":round(generated/len(group),4)}
 sig_counts=Counter(signatures);duplicate_extras=sum(v-1 for v in sig_counts.values() if v>1);duplicate_rate=duplicate_extras/len(signatures) if signatures else 0
 from .topology import high_reference_topologies
 from .zixiao import compile_zixiao
 from .qingtian import compile_qingtian
 formal=tuple(high_reference_topologies().values())+(compile_zixiao().topology,compile_qingtian().topology)
 def node_bag(t):return Counter(n.node_type.value for n in t.nodes)
 def similarity(a,b):
  if a.tier!=b.tier:return 0.0
  x,y=node_bag(a),node_bag(b);intersection=sum((x&y).values());union=sum((x|y).values());return intersection/union if union else 1.0
 formal_classes=[]
 for r in valid:
  scores=[similarity(r["candidate"].topology,x) for x in formal];best=max(scores,default=0);formal_classes.append("EXACT" if best==1 else ("HIGH_SIMILARITY" if best>=.70 else "DISTINCT"))
 formal_dist=dict(sorted(Counter(formal_classes).items()))
 warnings=[]
 for tier,group in _groups(valid,lambda r:r["route"]):
  if len(group)>=10 and len({x["carrier_mix"] for x in group})<=2:warnings.append(f"LOW_CARRIER_DIVERSITY_WARNING:{tier}")
  if len(group)>=6 and len({x["signature"] for x in group})==1:warnings.append(f"SEED_VARIATION_COLLAPSE_WARNING:{tier}")
  templates=Counter(x["template"] for x in group)
  if templates and max(templates.values())/len(group)>.70:warnings.append(f"TEMPLATE_SCARCITY:{tier}")
  targets=Counter(x["targeting"] for x in group)
  if targets and max(targets.values())/len(group)>.70:warnings.append(f"TARGETING_DOMINANCE_WARNING:{tier}")
 if duplicate_rate>DIAGNOSTIC_THRESHOLDS["internal_duplicate_max"]:warnings.append("GENERATOR_INTERNAL_DUPLICATION_P2")
 if any(r["budget_utilization"] is not None and r["budget_utilization"]<.5 and r["budget_status"]=="WITHIN_BUDGET" for r in valid):warnings.append("BUDGET_UNDERUTILIZATION_WARNING")
 negative_false=sum(not r["negative_correct"] for r in neg);p0=[];p1=[] if negative_false==0 else ["NEGATIVE_FALSE_ACCEPT"]
 p2=tuple(sorted(set(warnings)));decision="GENERATOR_BATCH_UNSAFE" if p0 or p1 else ("GENERATOR_BATCH_NEEDS_SELECTION_PATCH" if p2 else "GENERATOR_BATCH_HEALTHY")
 topology={}
 for route,group in _groups(valid,lambda r:r["route"]):
  vals=[]
  for r in group:
   c=r["candidate"];d=validate_martial_topology(c.topology).diagnostics;vals.append({"nodes":len(c.topology.nodes),"edges":len(c.topology.edges),"cycles":d.cycle_count,"carriers":len(d.state_carrier_types),"feedback":sum(e.edge_type.value=="FEEDS_BACK" for e in c.topology.edges)})
  topology[route]={k:dict(sorted(Counter(v[k] for v in vals).items())) for k in vals[0]} if vals else {}
 return {"counts":{"positive_requests":len(pos),"negative_controls":len(neg),"generated_candidates":len(gen),"architecture_valid":len(valid)},"rates":{"generation_success":round(len(gen)/len(pos),4),"architecture_validation":round(len(valid)/len(gen),4) if gen else 0,"negative_false_accept":round(negative_false/len(neg),4) if neg else 0,"internal_duplicate":round(duplicate_rate,4),"token_indeterminate":round(sum(r["budget_status"]=="INDETERMINATE" for r in gen)/len(gen),4) if gen else 0,"content_tbd":round(sum(bool(r["content_tbd_count"]) for r in gen)/len(gen),4) if gen else 0},"runtime_eligibility":dist("runtime_eligibility"),"failure_codes":dist("failure_code",neg),"family_tier_matrix":matrix,"template_distribution":dist("template"),"carrier_distribution":dist("carrier_mix"),"targeting_distribution":dist("targeting"),"trigger_predicate_distribution":dist("trigger_predicate"),"trigger_scope_distribution":dist("trigger_scope"),"cost_timing_distribution":dist("cost_timings"),"budget_distribution":dist("budget_status"),"content_tbd_distribution":dist("content_tbd_count"),"tuning_tbd_distribution":dist("tuning_tbd_count"),"topology_distribution":topology,"signature":{"unique":len(sig_counts),"duplicate_groups":sum(v>1 for v in sig_counts.values()),"duplicate_extras":duplicate_extras,"formal_topology_similarity":formal_dist},"resource_ecology":{"producer_only_valid":0,"consumer_only_valid":0,"circular_deadlock_valid":0},"severity":{"P0":p0,"P1":p1,"P2":p2,"P3":[]},"decision":decision,"thresholds":DIAGNOSTIC_THRESHOLDS}

def _groups(items,key):
 groups=defaultdict(list)
 for item in items:groups[key(item)].append(item)
 return sorted(groups.items(),key=lambda x:str(x[0]))

def replay_wo034_batch():return evaluate_batch(BatchEvaluationSpec())

def write_batch_artifacts(evaluation,directory):
 from pathlib import Path
 root=Path(directory);root.mkdir(parents=True,exist_ok=True);(root/"candidates").mkdir(exist_ok=True);(root/"failures").mkdir(exist_ok=True);(root/"validations").mkdir(exist_ok=True)
 fields=("kind","request_id","family","tier","route","seed","generated","validation_status","runtime_eligibility","template","signature","known_token_cost","budget_status","content_tbd_count","tuning_tbd_count","warning_count","failure_code")
 with (root/"wo034_candidate_summary.csv").open("w",newline="",encoding="utf-8-sig") as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows({k:r[k] for k in fields} for r in evaluation.rows)
 (root/"wo034_batch_metrics.json").write_text(json.dumps({"batch_run_id":evaluation.batch_run_id,"metrics":evaluation.metrics},sort_keys=True,indent=2,ensure_ascii=False),encoding="utf-8")
 for r in evaluation.rows:
  if r["candidate"]:(root/"candidates"/f'{r["request_id"]}.json').write_text(serialize_candidate(r["candidate"]),encoding="utf-8");(root/"validations"/f'{r["request_id"]}.json').write_text(serialize_validation_report(r["validation"]),encoding="utf-8")
  elif r["failure"]:(root/"failures"/f'{r["request_id"]}.json').write_text(json.dumps(asdict(r["failure"]),sort_keys=True,indent=2),encoding="utf-8")
 return root

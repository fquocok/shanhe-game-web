"""Small developer GUI wrapper; all measurement remains in balance_harness."""
from __future__ import annotations
from pathlib import Path

from .balance_harness import BALANCE_REFERENCE_PLAYER, RAW_ENCOUNTER_AS_DEFINED, BattleBatchInput, report_as_markdown, run_battle_batch
from .encounter_roster_variation import ENCOUNTER_VARIANTS


WINDOW_TITLE = "戰鬥平衡／難度量測工具（開發用）"
HEADER_TEXT = "戰鬥平衡／難度量測｜僅產生報告，不自動調整"
RAW_DISPLAY = "遭遇戰原始設定（RAW）"
REFERENCE_DISPLAY = "平衡基準玩家（240 HP）"
DISPLAY_TO_MACHINE = {RAW_DISPLAY: RAW_ENCOUNTER_AS_DEFINED, REFERENCE_DISPLAY: BALANCE_REFERENCE_PLAYER}
MACHINE_TO_DISPLAY = {value: key for key, value in DISPLAY_TO_MACHINE.items()}


def machine_mode_from_display(display_value: str) -> str:
    return DISPLAY_TO_MACHINE[display_value]


def main(argv=None):
    import argparse
    import tkinter as tk
    from tkinter import ttk, messagebox
    parser=argparse.ArgumentParser(); parser.add_argument("--workspace",default="."); args=parser.parse_args(argv)
    workspace=Path(args.workspace).resolve(); root=tk.Tk(); root.title(WINDOW_TITLE); root.geometry("900x700")
    frame=ttk.Frame(root,padding=18); frame.pack(fill="both",expand=True)
    encounter=tk.StringVar(value=ENCOUNTER_VARIANTS[0][1]); runs=tk.StringVar(value="100"); seed=tk.StringVar(value="100000"); mode_display=tk.StringVar(value=RAW_DISPLAY)
    ttk.Label(frame,text=HEADER_TEXT,font=("Microsoft JhengHei UI",16,"bold")).grid(row=0,column=0,columnspan=4,sticky="w",pady=(0,12))
    ttk.Label(frame,text="遭遇戰").grid(row=1,column=0,sticky="w"); ttk.Combobox(frame,textvariable=encounter,values=tuple(x[1] for x in ENCOUNTER_VARIANTS),width=48,state="readonly").grid(row=1,column=1,columnspan=3,sticky="ew")
    ttk.Label(frame,text="模擬場數").grid(row=2,column=0,sticky="w"); ttk.Entry(frame,textvariable=runs,width=12).grid(row=2,column=1,sticky="w")
    ttk.Label(frame,text="基礎種子").grid(row=2,column=2,sticky="w"); ttk.Entry(frame,textvariable=seed,width=14).grid(row=2,column=3,sticky="w")
    ttk.Label(frame,text="量測模式").grid(row=3,column=0,sticky="w"); ttk.Combobox(frame,textvariable=mode_display,values=(RAW_DISPLAY,REFERENCE_DISPLAY),width=36,state="readonly").grid(row=3,column=1,columnspan=3,sticky="w")
    output=tk.Text(frame,wrap="word",font=("Microsoft JhengHei UI",10)); output.grid(row=5,column=0,columnspan=4,sticky="nsew",pady=(12,0)); frame.rowconfigure(5,weight=1); frame.columnconfigure(3,weight=1)
    def run():
        try:
            requested_mode=machine_mode_from_display(mode_display.get())
            report=run_battle_batch(workspace,BattleBatchInput(encounter.get(),int(runs.get()),int(seed.get()),comparison_label=requested_mode))
            if report["comparison_label"] != requested_mode:
                raise RuntimeError("量測模式與報告內容不一致")
            output.delete("1.0","end"); output.insert("end",report_as_markdown(report))
        except Exception as exc: messagebox.showerror("戰鬥平衡量測工具",str(exc))
    ttk.Button(frame,text="執行無畫面批次量測",command=run).grid(row=4,column=0,columnspan=4,sticky="ew",pady=(12,0))
    root.mainloop()


if __name__ == "__main__": main()

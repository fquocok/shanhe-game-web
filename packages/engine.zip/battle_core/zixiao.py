"""Source-faithful Legendary 252 shell for 紫霄劍訣 (WO-029)."""
from dataclasses import dataclass
from .composite import CompositeActionDefinition,ActionStageDefinition,ActionStageEdge,ExecutionIdentity,StageEdgeCondition
from .topology import MechanismNodeDefinition,MechanismNodeType,TopologyEdgeDefinition,TopologyEdgeType,MartialTopologyDefinition,validate_martial_topology

IMPLEMENTATION_ID="sword_legendary_zixiao_jianjue"
ZIXIAO_BLOCKED_BY_SPEC=()
ZIXIAO_RESOLVED_POLICIES={"zixiao_internal_single_target_stage_target_binding":{"resolution":"RESOLVED_BY_WO_029A","value":"ROOT_PRIMARY_TARGET","retarget_policy":"NO_RETARGET","unavailable_policy":"TERMINATE_SINGLE_TARGET_CONTINUATION_BEFORE_GATE_ROLL"},"legendary_validator_vs_zixiao_composite_rule_override_contract":{"resolution":"RESOLVED_BY_WO_029A","qualification_route":"LEGENDARY_RULE_PRIVILEGE","privilege":"COMPOSITE_COMBO_ACTION"}}
ZIXIAO_SOURCE_CONTENT_TBDS=("zhanyao_root_damage_coefficient",)

@dataclass(frozen=True)
class SymbolicCoefficient:
 reference:str;ratio:float
@dataclass(frozen=True)
class ZixiaoDefinition:
 id:str;name_zh:str;family:str;tier:str;budget:int;role:str
 implementation_id_derived_from_naming_convention:bool
 active_name:str;cooldown:int;qi_cost_percent_max:float
 root_coefficient:str|float;coefficient_graph:dict[str,SymbolicCoefficient]
 composite_combo_action:bool;composite_definition:CompositeActionDefinition|None
 topology:MartialTopologyDefinition;topology_validation_status:str
 blocked_spec_fields:tuple[str,...];source_content_tbds:tuple[str,...]
 tuning_placeholder:str

def _topology():
 names=("zhanyao","ziyang","zhanlong","poxie","pojun")
 nodes=tuple(MechanismNodeDefinition(x,MechanismNodeType.ACTION,None,"legendary_same_root_multistage_attack") for x in names)
 edges=tuple(TopologyEdgeDefinition(a,b,TopologyEdgeType.ENABLES,"PREVIOUS_STAGE_EXECUTED + AGI_CHANCE",True,False) for a,b in zip(names,names[1:]))
 return MartialTopologyDefinition("legendary_deep_agility_combo","LEGENDARY",nodes,edges,("zhanyao",),(),0,True,0,252,"SWORD",("COMPOSITE_COMBO_ACTION",),True,"AGILITY")

def compile_zixiao(*,test_root_coefficient=None,target_binding_resolution="ROOT_PRIMARY_TARGET"):
 topology=_topology();validation=validate_martial_topology(topology)
 blocked=[];composite=None
 root="TOKEN_BALANCE_TBD" if test_root_coefficient is None else float(test_root_coefficient)
 if target_binding_resolution=="ROOT_PRIMARY_TARGET" and test_root_coefficient is not None:
  stages=(
   ActionStageDefinition("zhanyao",ExecutionIdentity.SAME_ROOT_MAIN_ACTION,"ATTACK","single",target_binding_resolution,float(root)),
   ActionStageDefinition("ziyang",ExecutionIdentity.SAME_ROOT_MAIN_ACTION,"ATTACK","single",target_binding_resolution,float(root)*.8,chance=.70,chance_attribute="agility",chance_per_point=.005),
   ActionStageDefinition("zhanlong",ExecutionIdentity.SAME_ROOT_MAIN_ACTION,"ATTACK","single",target_binding_resolution,float(root)*.7,chance=.55,chance_attribute="agility",chance_per_point=.005),
   ActionStageDefinition("poxie",ExecutionIdentity.SAME_ROOT_MAIN_ACTION,"ATTACK","single",target_binding_resolution,float(root)*.7,chance=.40,chance_attribute="agility",chance_per_point=.003),
   ActionStageDefinition("pojun",ExecutionIdentity.SAME_ROOT_MAIN_ACTION,"ATTACK","all_enemies","ROOT_PRIMARY_TARGET",float(root)*1.2,chance=.20,chance_attribute="agility",chance_per_point=.002),)
  edges=tuple(ActionStageEdge(a,b,StageEdgeCondition.ON_STAGE_EXECUTED) for a,b in zip((x.stage_id for x in stages),(x.stage_id for x in stages[1:])))
  composite=CompositeActionDefinition(IMPLEMENTATION_ID+".zhanyao",stages,edges,("zhanyao",),qi_cost_percent_max=.80,cooldown_id=IMPLEMENTATION_ID+".zhanyao",cooldown_turns=13)
 graph={"zhanyao":SymbolicCoefficient("ROOT_TBD",1.0),"ziyang":SymbolicCoefficient("zhanyao",.8),"zhanlong":SymbolicCoefficient("zhanyao",.7),"poxie":SymbolicCoefficient("zhanlong",1.0),"pojun":SymbolicCoefficient("zhanyao",1.2)}
 return ZixiaoDefinition(IMPLEMENTATION_ID,"紫霄劍訣","劍法","legendary",252,"鎮派錨點：敏捷長連擊",True,"斬妖式",13,.80,root,graph,True,composite,topology,validation.status,tuple(blocked),ZIXIAO_SOURCE_CONTENT_TBDS,"TEST_TUNING_PLACEHOLDER source=TOKEN_BALANCE_TBD test_only=true not_canonical=true" if test_root_coefficient is not None else "TOKEN_BALANCE_TBD")

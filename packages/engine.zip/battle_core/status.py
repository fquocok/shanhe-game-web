from __future__ import annotations

from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Callable, Mapping


STACKING_POLICIES = {"refresh", "stack", "independent", "replace", "strongest", "unique"}
TURN_START_PHASES = {
    "maintenance": 0,
    "periodic_damage": 1,
    "recovery": 2,
    "resource": 3,
    "reactive_or_special": 4,
}


@dataclass(frozen=True)
class StatusDefinition:
    id: str
    name: str
    tags: frozenset[str]
    duration: int
    stacking_policy: str = "refresh"
    max_stacks: int = 1
    priority: int = 100
    phase: str = "maintenance"
    base_application_chance: float = 1.0
    dispellable: bool = True
    payload: Mapping[str, Any] = field(default_factory=lambda: MappingProxyType({}))
    # strongest never guesses a formula: content must provide a numeric value.
    strength: float | None = None

    def __post_init__(self):
        if not self.id or not self.name:
            raise ValueError("Status id/name 不可為空")
        if self.duration < 1 or self.max_stacks < 1:
            raise ValueError("Status duration/max_stacks 必須 >= 1")
        if self.stacking_policy not in STACKING_POLICIES:
            raise ValueError(f"未知 stacking_policy：{self.stacking_policy}")
        if self.phase not in TURN_START_PHASES:
            raise ValueError(f"未知 Turn Start phase：{self.phase}")
        if self.base_application_chance < 0:
            raise ValueError("base_application_chance 不可小於 0")
        if self.stacking_policy == "strongest" and self.strength is None:
            raise ValueError("strongest Status 必須明確提供 strength；引擎不猜測比較規則")


@dataclass
class RuntimeStatusInstance:
    instance_id: int
    definition: StatusDefinition
    source_id: str
    target_id: str
    remaining_duration: int
    stack_count: int = 1
    applied_at: int = 0


@dataclass(frozen=True)
class DurationSnapshot:
    owner_id: str
    instance_ids: frozenset[int]


class StatusEngine:
    def __init__(self, rng, event_sink: Callable[..., None], dot_handler: Callable[..., None]):
        self.rng = rng
        self._event = event_sink
        self._dot_handler = dot_handler
        self._next_instance_id = 1

    def _emit(self, event_type, **data):
        self._event(event_type, **data)

    def apply(self, definition: StatusDefinition, source, target) -> RuntimeStatusInstance | None:
        raw_tenacity = target.definition.constitution * 0.1 + float(target.definition.modifiers.get("tenacity", 0))
        effective_tenacity = min(max(raw_tenacity, 0.0), 100.0)
        uses_tenacity = "negative" in definition.tags and "mark" not in definition.tags
        chance = min(definition.base_application_chance * (1 - effective_tenacity / 100 if uses_tenacity else 1), 1.0)
        self._emit("STATUS_APPLY_ATTEMPT", status=definition.id, source=source.definition.id,
                   target=target.definition.id, chance=chance, raw_tenacity=raw_tenacity)
        blocked_tags = sorted(definition.tags & target.immunity_tags)
        if definition.id in target.immunity_status_ids or blocked_tags:
            self._emit("STATUS_BLOCKED", status=definition.id, source=source.definition.id,
                       target=target.definition.id, reason="immunity", matched_tags=blocked_tags)
            return None
        if chance < 1.0 and self.rng.random() >= chance:
            self._emit("STATUS_BLOCKED", status=definition.id, source=source.definition.id,
                       target=target.definition.id, reason="application_chance")
            return None
        same = [s for s in target.statuses if s.definition.id == definition.id]
        policy = definition.stacking_policy
        if same and policy == "unique":
            self._emit("STATUS_BLOCKED", status=definition.id, source=source.definition.id,
                       target=target.definition.id, reason="unique")
            return None
        if same and policy == "refresh":
            instance = same[0]
            instance.remaining_duration = definition.duration
            data={"status":definition.id,"target":target.definition.id,
                  "instance_id":instance.instance_id,"remaining_duration":instance.remaining_duration}
            data.update(definition.payload.get("event_metadata", {}))
            self._emit("STATUS_REFRESHED", **data)
            return instance
        if same and policy == "stack":
            instance = same[0]
            before = instance.stack_count
            instance.stack_count = min(instance.stack_count + 1, definition.max_stacks)
            self._emit("STATUS_STACKED", status=definition.id, target=target.definition.id,
                       instance_id=instance.instance_id, before=before, stack_count=instance.stack_count)
            return instance
        if same and policy == "replace":
            for instance in same:
                self.remove_instance(target, instance, "replaced")
        if same and policy == "strongest":
            current = same[0]
            if definition.strength <= current.definition.strength:
                self._emit("STATUS_BLOCKED", status=definition.id, source=source.definition.id,
                           target=target.definition.id, reason="not_stronger")
                return None
            self.remove_instance(target, current, "replaced_by_stronger")
        instance = RuntimeStatusInstance(self._next_instance_id, definition, source.definition.id,
                                         target.definition.id, definition.duration,
                                         applied_at=self._next_instance_id)
        self._next_instance_id += 1
        target.statuses.append(instance)
        data={"status":definition.id,"source":source.definition.id,"target":target.definition.id,
              "instance_id":instance.instance_id,"remaining_duration":instance.remaining_duration,
              "stack_count":instance.stack_count,"applied_at":instance.applied_at}
        data.update(definition.payload.get("event_metadata", {}))
        self._emit("STATUS_APPLIED", **data)
        return instance

    def duration_snapshot(self, owner) -> DurationSnapshot:
        return DurationSnapshot(owner.definition.id, frozenset(s.instance_id for s in owner.statuses))

    def periodic_sources(self, owner):
        from .damage.non_attack.dot_periodic import snapshot_periodic_sources
        return snapshot_periodic_sources(owner)

    def owner_turn_start(self, owner, *, snapshot=None) -> DurationSnapshot:
        # WO095: DOT is scheduled separately, never settled by this lifecycle pass.
        snapshot = self.duration_snapshot(owner) if snapshot is None else snapshot
        ordered = sorted(list(owner.statuses), key=lambda s: (
            TURN_START_PHASES[s.definition.phase], s.definition.priority,
            s.source_id, s.definition.id, s.instance_id,
        ))
        for instance in ordered:
            if instance not in owner.statuses:
                continue
            payload = instance.definition.payload
            if payload.get("effect") == "dot":
                continue
            handler = payload.get("turn_start_handler")
            if callable(handler):
                handler(instance, owner)
        return snapshot

    def owner_turn_end(self, owner, snapshot: DurationSnapshot) -> tuple[RuntimeStatusInstance, ...]:
        expired=[]
        for instance in sorted(list(owner.statuses), key=lambda s: s.instance_id):
            if instance.instance_id not in snapshot.instance_ids:
                continue
            instance.remaining_duration -= 1
            if instance.remaining_duration <= 0:
                owner.statuses.remove(instance)
                expired.append(instance)
                self._emit("STATUS_EXPIRED", status=instance.definition.id, target=owner.definition.id,
                           instance_id=instance.instance_id)
        return tuple(expired)

    def has_tag(self, unit, tag: str) -> bool:
        return any(tag in s.definition.tags for s in unit.statuses)

    def modifier_total(self, unit, key: str) -> float:
        """Data-driven additive modifier interface used by Buff/Debuff payloads."""
        return sum(
            float(instance.definition.payload.get("modifiers", {}).get(key, 0)) * instance.stack_count
            for instance in unit.statuses
        )

    def remove_instance(self, target, instance, reason="removed") -> None:
        if instance in target.statuses:
            target.statuses.remove(instance)
            self._emit("STATUS_REMOVED", status=instance.definition.id, target=target.definition.id,
                       instance_id=instance.instance_id, reason=reason)

    def dispel(self, target, *, tags=frozenset(), status_ids=frozenset(), predicate=None) -> tuple[str, ...]:
        tags, status_ids = frozenset(tags), frozenset(status_ids)
        removed = []
        for instance in list(target.statuses):
            definition = instance.definition
            matches = bool(definition.id in status_ids or definition.tags & tags or (predicate and predicate(instance)))
            # A generic negative dispel does not implicitly match a MARK that happens
            # to carry negative; mark must itself be explicitly requested/id-filtered.
            if "mark" in definition.tags and "mark" not in tags and definition.id not in status_ids:
                matches = False
            if definition.dispellable and matches:
                removed.append(definition.id)
                self.remove_instance(target, instance, "dispel")
        self._emit("DISPEL", target=target.definition.id, tags=sorted(tags),
                   status_ids=sorted(status_ids), removed=removed)
        return tuple(removed)

    def cleanse_one_negative(self, target, *, source_id: str, selected_status_id: str | None = None):
        eligible = [s for s in target.statuses if s.definition.dispellable
                    and "negative" in s.definition.tags and "mark" not in s.definition.tags]
        self._emit("CLEANSE_ATTEMPTED", source=source_id, target=target.definition.id,
                   eligible_statuses=[s.definition.id for s in eligible], selected_status=selected_status_id)
        if not eligible:
            self._emit("CLEANSE_NO_ELIGIBLE_TARGET", source=source_id, target=target.definition.id)
            return None
        if selected_status_id is None and len(eligible) > 1:
            self._emit("CLEANSE_BLOCKED_BY_SPEC", source=source_id, target=target.definition.id,
                       reason="debuff_cleanse_priority")
            raise ValueError("BLOCKED_BY_SPEC: debuff_cleanse_priority；多個可淨化 Debuff 必須提供明確 selector")
        chosen = next((s for s in eligible if s.definition.id == selected_status_id), None) if selected_status_id else eligible[0]
        if chosen is None:
            raise ValueError(f"指定的 Debuff 不可淨化：{selected_status_id}")
        self.remove_instance(target, chosen, "cleanse")
        self._emit("CLEANSE_APPLIED", source=source_id, target=target.definition.id,
                   status=chosen.definition.id, instance_id=chosen.instance_id)
        return chosen.definition.id

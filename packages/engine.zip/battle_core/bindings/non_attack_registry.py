"""Read-only WO094 production inventory; candidate status does not authorize execution."""
from dataclasses import dataclass, replace
from ..events import DamageOrigin as O
from ..events.envelope import freeze, thaw, canonical_json
from ..damage.non_attack.policy import (
    SUPPORTED_ROOT_ORIGINS, LEGACY_SPECIAL_DAMAGE_CANONICAL_ORIGIN_TBD,
    DOT_STATUS_INSTANCE_SEMANTIC_ID_BINDING_TBD_FOR_WO095)
from .non_attack_source import (
    NonAttackSourceBinding, NonAttackBindingError, ProducerFamily as F, MigrationRoute as R)

DOT_BINDING_ID = "status_dot:legacy_resolve_dot"
SPECIAL_BINDING_ID = "legacy_special:resolve_special_damage"


@dataclass(frozen=True, slots=True)
class NonAttackSourceBindingRegistry:
    bindings: tuple[NonAttackSourceBinding, ...]

    def __post_init__(self):
        values = tuple(self.bindings)
        if any(type(b) is not NonAttackSourceBinding for b in values):
            raise NonAttackBindingError("Typed source bindings required")
        # Revalidate snapshots; no live Runtime/content references are accepted.
        values = tuple(sorted((replace(b) for b in values), key=lambda b: b.binding_id))
        if len({b.binding_id for b in values}) != len(values):
            raise NonAttackBindingError("Duplicate binding ID")
        identities = {}
        for b in values:
            if b.producer_id is None:
                continue
            if b.producer_id in identities:
                if identities[b.producer_id] != b.route:
                    raise NonAttackBindingError("Conflicting producer routes: " + b.producer_id)
                raise NonAttackBindingError("Duplicate producer identity: " + b.producer_id)
            identities[b.producer_id] = b.route
        object.__setattr__(self, "bindings", values)

    def get(self, binding_id):
        for binding in self.bindings:
            if binding.binding_id == binding_id:
                return binding
        raise NonAttackBindingError("Unknown source binding: " + str(binding_id))

    def for_producer(self, producer_id):
        return tuple(b for b in self.bindings if b.producer_id == producer_id and producer_id is not None)

    def for_origin(self, origin):
        if not isinstance(origin, O) or origin not in SUPPORTED_ROOT_ORIGINS:
            raise NonAttackBindingError("Typed WO093 root origin required")
        return tuple(b for b in self.bindings if b.canonical_origin == origin)

    def for_route(self, route):
        if not isinstance(route, R):
            raise NonAttackBindingError("Typed migration route required")
        return tuple(b for b in self.bindings if b.route == route)

    def migration_candidates(self):
        return self.for_route(R.CANONICAL_MIGRATION_CANDIDATE)

    def migrated_bindings(self):
        return self.for_route(R.CANONICAL_MIGRATED)

    def require_migrated(self, binding_id):
        binding = self.get(binding_id)
        if binding.route != R.CANONICAL_MIGRATED or not binding.production_migrated:
            raise NonAttackBindingError(binding.unresolved_marker or "Source not migrated")
        return binding

    def require_migration_candidate(self, binding_id):
        binding = self.get(binding_id)
        if binding.route != R.CANONICAL_MIGRATION_CANDIDATE:
            raise NonAttackBindingError(binding.unresolved_marker or
                                       "Not a migration candidate: " + binding.route.value)
        return binding

    def origin_inventory(self):
        result = {}
        for origin in sorted(SUPPORTED_ROOT_ORIGINS, key=lambda o: o.value):
            values = tuple(b for b in self.for_origin(origin) if b.producer_id is not None)
            result[origin.value] = {
                "production_producer_count": len(values),
                "binding_ids": [b.binding_id for b in values],
                "migration_candidate_count": sum(b.route == R.CANONICAL_MIGRATION_CANDIDATE for b in values),
                "migrated_count": sum(b.production_migrated for b in values),
                "unresolved_count": sum(b.route in (R.UNRESOLVED_TBD, R.BLOCKED_NO_AUTHORITY) for b in values),
                "inventory_status": "PRODUCTION_SOURCE_REGISTERED" if values else "NO_PRODUCTION_SOURCE_REGISTERED",
                "route": None if values else R.NO_PRODUCTION_SOURCE.value,
            }
        return freeze(result)

    def runtime_contract_readiness(self):
        """Infrastructure availability is not production content or migration."""
        return freeze({"ENVIRONMENT": {
            "runtime_contract": "WO096_ENVIRONMENT_SOURCE_RUNTIME_CONTRACT",
            "runtime_contract_ready": True, "production_content_registered": False,
            "classification": "RUNTIME_SOURCE_CONTRACT_CALLER_NOT_PRODUCTION_CONTENT"}})

    def audit_summary(self):
        return freeze({"runtime_contract": "WO095", "production_migrated": any(b.production_migrated for b in self.bindings),
                       "bindings": [b.to_dict() for b in self.bindings],
                       "origin_inventory": thaw(self.origin_inventory()),
                       "runtime_contract_readiness": thaw(self.runtime_contract_readiness()),
                       "unbound_origin_binding_ids": [b.binding_id for b in self.bindings
                                                     if b.canonical_origin is None]})

    def to_dict(self):
        return {"schema_version": 1, **thaw(self.audit_summary())}

    def serialize(self):
        return canonical_json(self.to_dict())


PRODUCTION_NON_ATTACK_REGISTRY = NonAttackSourceBindingRegistry((
    NonAttackSourceBinding(
        DOT_BINDING_ID, F.STATUS_DOT, "BattleEngine._resolve_dot",
        "battle_core/engine.py:BattleEngine._resolve_dot", O.DOT_PERIODIC,
        R.CANONICAL_MIGRATED, "BattleEngine._resolve_dot", "BattleEngine.settle_non_attack_damage",
        production_migrated=True,
        metadata={
            "scheduler_source": "COMMON_PRERESOLUTION_PERIODIC",
            "current_legacy_formula_owner": "BattleEngine._resolve_dot",
            "historical_direct_settlement_owner": "BattleEngine._resolve_dot",
            "observed_legacy_shield_behavior": "LEGACY_RUNTIME_THROUGH_SHIELD",
            "observation_authority": "MIGRATION_COMPATIBILITY_EVIDENCE_ONLY_NOT_GLOBAL_CANON",
            "immediate_death_behavior": "WO087_PENDING_WO088_WINDOW",
            "shield_break_behavior": "POST_SOURCE_BATCH_WO090_COMPAT",
            "share_default": "NOT_ENABLED", "attack_semantics": "FORBIDDEN",
            "scheduler_target": "PRE_RESOLUTION_PERIODIC",
            "migration_target_work_order": "WO095", "target_foundation": "WO093",
            "resolved_marker": "DOT_STATUS_INSTANCE_SEMANTIC_ID_BINDING_RESOLVED_IN_WO095",
            "status_semantic_id_contract": "status-instance:{instance_id:08d}",
            "migration_work_order": "WO095",
            "migration_work_order_source": {"drive_file_id": "14UqR70PgLWVCt7mrFd0zkWO5bta4RF3K",
                "sha256": "962b9359afddd788494df26eef1c7bf4d76d2a77f7a5ef7c8b06acd37e90fe9b"},
            "migration_authority_base": "694c9b270d9e7b384df86e32496eecf07d715530",
            "current_settlement_owner": "BattleEngine.settle_non_attack_damage",
            "current_lifecycle": "WO087_PENDING_WO088_WINDOW",
            "current_shield_break_route": "POST_SOURCE_BATCH_WO090_COMPAT",
            "producer_specific_shield_policy": "EXPLICIT_THROUGH_SHIELD_NOT_GLOBAL_CANON",
            "content_application_relationship": {
                "mechanic": "attack_to_dot_status_application", "wo090_route": "CANONICAL_DIRECT",
                "role": "ATTACK_APPLIES_STATUS_NOT_DOT_SETTLEMENT_PRODUCER"},
        }),
    NonAttackSourceBinding(
        SPECIAL_BINDING_ID, F.LEGACY_SPECIAL_DAMAGE, "BattleEngine.resolve_special_damage",
        "battle_core/engine.py:BattleEngine.resolve_special_damage", None, R.UNRESOLVED_TBD,
        "BattleEngine.resolve_special_damage (rounding); InnerSkillRuntimeManager.handle_shield_broken (caller formula)",
        "BattleEngine.resolve_special_damage",
        unresolved_marker=LEGACY_SPECIAL_DAMAGE_CANONICAL_ORIGIN_TBD,
        metadata={
            "observed_legacy_shield_behavior": "LEGACY_RUNTIME_THROUGH_SHIELD",
            "observation_authority": "MIGRATION_COMPATIBILITY_EVIDENCE_ONLY_NOT_GLOBAL_CANON",
            "ignores_defense": True, "ignores_parry": True,
            "immediate_death_behavior": "LEGACY_CHECK_DEATH",
            "shield_break_behavior": "LEGACY_ON_SHIELD_BROKEN",
            "canonical_source_origin": None, "wo093_migration_allowed": False,
            "caller_gate_bypass_allowed": False,
            "callers": [{
                "mechanic": "shield_break_reaction_action",
                "caller": "InnerSkillRuntimeManager.handle_shield_broken",
                "caller_location": "battle_core/inner_skill.py:InnerSkillRuntimeManager.handle_shield_broken",
                "source_formula_owner": "InnerSkillRuntimeManager.handle_shield_broken",
                "wo090_adapter": "battle_core/bindings/shield_break_adapter.py:dispatch_inner_shield_breaks",
                "wo090_reaction_binding_route": "POST_SETTLEMENT_REACTION",
                "wo090_settlement_route": "LEGACY_NONATTACK_COMPAT",
                "reaction_compatibility": "LEGACY_COMPAT",
                "damage_source_migration_route": "UNRESOLVED_TBD",
                "unresolved_marker": LEGACY_SPECIAL_DAMAGE_CANONICAL_ORIGIN_TBD,
            }],
        }),
))

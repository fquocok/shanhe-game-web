"""Explicit accepted Lightness static/action routes; exploration stays metadata."""
from types import MappingProxyType
from .model import BindingRoute as R

ROUTES = MappingProxyType({
    **dict.fromkeys(("agility_to_flat_speed", "agility_to_dodge_bonus", "ordinary_dodge_bonus",
                     "respect_global_dodge_cap"), R.CANONICAL_STATIC_MODIFIER),
    **dict.fromkeys(("non_attack_formal_main_action", "self_target_combat_buff",
                     "owner_turn_duration_buff", "nonstacking_refresh_buff", "qi_cost", "cooldown"),
                    R.CANONICAL_DIRECT),
    **dict.fromkeys(("exploration_map_speed_metadata", "exploration_jump_metadata"),
                    R.UNRESOLVED_TBD),
})

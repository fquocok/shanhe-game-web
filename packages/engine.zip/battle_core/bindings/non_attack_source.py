"""WO094 observational source vocabulary. No execution or settlement policy."""
from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType
from ..events import DamageOrigin
from ..events.envelope import freeze, thaw, canonical_json
from ..damage.non_attack.policy import SUPPORTED_ROOT_ORIGINS


class NonAttackBindingError(ValueError):
    """Invalid source description or migration gate rejection."""


class ProducerFamily(str, Enum):
    STATUS_DOT = "STATUS_DOT"
    LEGACY_SPECIAL_DAMAGE = "LEGACY_SPECIAL_DAMAGE"
    ENVIRONMENT_SOURCE = "ENVIRONMENT_SOURCE"
    REFLECTION_SOURCE = "REFLECTION_SOURCE"
    SELF_DAMAGE_SOURCE = "SELF_DAMAGE_SOURCE"
    DIRECT_HP_LOSS_SOURCE = "DIRECT_HP_LOSS_SOURCE"


class MigrationRoute(str, Enum):
    CANONICAL_MIGRATION_CANDIDATE = "CANONICAL_MIGRATION_CANDIDATE"
    CANONICAL_MIGRATED = "CANONICAL_MIGRATED"
    LEGACY_COMPAT = "LEGACY_COMPAT"
    UNRESOLVED_TBD = "UNRESOLVED_TBD"
    NO_PRODUCTION_SOURCE = "NO_PRODUCTION_SOURCE"
    BLOCKED_NO_AUTHORITY = "BLOCKED_NO_AUTHORITY"


@dataclass(frozen=True, slots=True)
class NonAttackSourceBinding:
    binding_id: str
    producer_family: ProducerFamily
    producer_id: str | None
    producer_location: str | None
    canonical_origin: DamageOrigin | None
    route: MigrationRoute
    formula_owner: str | None
    settlement_owner: str | None
    production_migrated: bool = False
    unresolved_marker: str | None = None
    metadata: object = field(default_factory=dict)

    def __post_init__(self):
        if type(self.binding_id) is not str or not self.binding_id.strip():
            raise NonAttackBindingError("Stable nonempty binding ID required")
        if not isinstance(self.producer_family, ProducerFamily) or not isinstance(self.route, MigrationRoute):
            raise NonAttackBindingError("Typed producer family/route required")
        if self.canonical_origin is not None and (
                not isinstance(self.canonical_origin, DamageOrigin) or
                self.canonical_origin not in SUPPORTED_ROOT_ORIGINS):
            raise NonAttackBindingError("Only explicit WO093 root origins allowed")
        if type(self.production_migrated) is not bool or self.production_migrated != (self.route == MigrationRoute.CANONICAL_MIGRATED):
            raise NonAttackBindingError("Migrated flag must match CANONICAL_MIGRATED route")
        if self.route == MigrationRoute.CANONICAL_MIGRATED and (self.canonical_origin is None or self.unresolved_marker is not None):
            raise NonAttackBindingError("Migrated source requires origin and no unresolved blocker")
        if self.unresolved_marker is not None and (
                type(self.unresolved_marker) is not str or not self.unresolved_marker.strip()):
            raise NonAttackBindingError("Nonempty unresolved marker required")
        if self.route in (MigrationRoute.UNRESOLVED_TBD, MigrationRoute.BLOCKED_NO_AUTHORITY) and not self.unresolved_marker:
            raise NonAttackBindingError("Unresolved/blocked routes require marker")
        if self.route == MigrationRoute.CANONICAL_MIGRATION_CANDIDATE and self.canonical_origin is None:
            raise NonAttackBindingError("Candidate requires explicit canonical origin")
        fields = ("producer_id", "producer_location", "formula_owner", "settlement_owner")
        if self.route == MigrationRoute.NO_PRODUCTION_SOURCE:
            if any(getattr(self, name) is not None for name in fields):
                raise NonAttackBindingError("Absent source cannot declare callable producer/owners")
        else:
            for name in fields:
                value = getattr(self, name)
                if type(value) is not str or not value.strip():
                    raise NonAttackBindingError("Nonempty " + name + " required")
        if type(self.metadata) not in (dict, MappingProxyType):
            raise NonAttackBindingError("Metadata mapping required")
        object.__setattr__(self, "metadata", freeze(self.metadata))

    def to_dict(self):
        return {name: (value.value if isinstance(value, Enum) else thaw(value))
                for name in self.__dataclass_fields__ for value in (getattr(self, name),)}

    def serialize(self):
        return canonical_json(self.to_dict())

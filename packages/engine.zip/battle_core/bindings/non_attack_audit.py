"""Bounded static production audit, never a semantic discovery engine.

AST writes/call edges plus reviewed baseline fingerprints. Dynamic aliasing,
runtime-generated code and callback bodies supplied outside this tree cannot be
proven by static analysis. Any newly observed writer requires explicit review;
names never choose an origin. No production execution occurs here.
"""
import ast
from hashlib import sha256
from pathlib import Path
from collections.abc import Mapping
from ..events.envelope import freeze, canonical_json
from .non_attack_source import NonAttackBindingError
from .non_attack_registry import PRODUCTION_NON_ATTACK_REGISTRY

UNCLASSIFIED_NONATTACK_PRODUCTION_DAMAGE_PRODUCER = "UNCLASSIFIED_NONATTACK_PRODUCTION_DAMAGE_PRODUCER"


class NonAttackProducerAuditError(NonAttackBindingError):
    pass


# Exact reviewed writer boundaries, not whole-directory exemptions.
# Generic primitives are allocations, not independent source-formula producers.
EXCLUDED_WRITERS = {
    ("battle_core/engine.py", "BattleEngine.heal"): "HEALING",
    ("battle_core/damage/atomic_distribution.py", "settle_quantized_distribution_atomic"): "ATOMIC_SETTLEMENT_INTERNAL",
    ("battle_core/damage/settlement.py", "settle_recipient_allocation"): "ALLOCATION_SETTLEMENT_INTERNAL",
    ("battle_core/balance_harness.py", "_apply_balance_reference"): "BALANCE_FIXTURE_RESET",
    ("battle_core/gamefacing_settlement_bridge.py", "GameFacingSettlementBridge.for_encounter"): "INITIAL_STATE_IMPORT",
    ("battle_core/interactive_battle_screen_audit.py", "audit_wo042"): "DIAGNOSTIC_FIXTURE_RESET",
    ("battle_core/presentation_stream/sample.py", "sample_frame"): "PRESENTATION_FIXTURE",
    ("battle_core/game_facing_martial.py", "GameFacingMartialService.execute"): "SETTLED_HP_PROJECTION",
    ("battle_core/player_action_control.py", "ManualCombatController._sync_settled_impacts"): "SETTLED_HP_PROJECTION",
}
PRODUCERS = {
    ("battle_core/engine.py", "BattleEngine.resolve_special_damage"): "BattleEngine.resolve_special_damage",
}
BASELINE_FILES = {
    "battle_core/inner_skill.py": "5ab83751c2db99af670c19a07eb6b3bbae3a4864cd6ec65a7642ed697904b4a9",
    "battle_core/bindings/shield_break_adapter.py": "88ca3c5b622affea7e2e3a97e87b11b55099846f1bce4a820f6641b6ef48f8f1",
}
BASELINE_METHODS = {
    "BattleEngine.resolve_special_damage": "fb3580b23876d99030613b44d31c2fa23879bcc0c72deacede71033d17606173",
}
ALLOCATION_CALLERS = frozenset({
    ("battle_core/engine.py", "BattleEngine._resolve_environment_damage_source", "self.settle_non_attack_damage"),
    ("battle_core/engine.py", "BattleEngine._resolve_dot", "self.settle_non_attack_damage"),
    ("battle_core/engine.py", "BattleEngine._resolve_attack", "self.settle_quantized_distribution_atomic"),
    ("battle_core/engine.py", "BattleEngine.settle_quantized_distribution_atomic", "settle_quantized_distribution_atomic"),
    ("battle_core/damage/non_attack/settlement.py", "settle_non_attack_damage", "settle_quantized_distribution_atomic"),
    ("battle_core/engine.py", "BattleEngine.settle_non_attack_damage", "settle_non_attack_damage"),
})
REQUIRED_EDGES = frozenset({
    ("battle_core/engine.py", "BattleEngine.__init__", "StatusEngine"),
    ("battle_core/engine.py", "BattleEngine._formal_turn", "self.statuses.owner_turn_start"),
    ("battle_core/engine.py", "BattleEngine._formal_turn", "self.statuses.periodic_sources"),
    ("battle_core/engine.py", "BattleEngine._formal_turn", "run_common_pre_resolution"),
    ("battle_core/scheduler/runtime_pre_resolution.py", "run_common_pre_resolution.execute", "runtime._resolve_dot"),
    ("battle_core/scheduler/runtime_pre_resolution.py", "run_common_pre_resolution", "runtime.formal_turn_scheduler.run_pre_resolution"),
    ("battle_core/scheduler/runtime_pre_resolution.py", "run_common_pre_resolution.execute", "runtime._resolve_environment_damage_source"),
    ("battle_core/engine.py", "BattleEngine._resolve_environment_damage_source", "self.settle_non_attack_damage"),
    ("battle_core/engine.py", "BattleEngine._resolve_dot", "self.settle_non_attack_damage"),
    ("battle_core/inner_skill.py", "InnerSkillRuntimeManager.handle_shield_broken", "self.engine.resolve_special_damage"),
    ("battle_core/bindings/shield_break_adapter.py", "dispatch_inner_shield_breaks.executor", "engine.inner_skills.handle_shield_broken"),
})


def _attribute(node):
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        prefix = _attribute(node.value)
        return prefix + "." + node.attr if prefix else node.attr
    return ""


def _hp_target(node):
    return (isinstance(node, ast.Attribute) and node.attr in ("current_hp", "hp") or
            isinstance(node, ast.Subscript) and isinstance(node.slice, ast.Constant) and
            node.slice.value in ("current_hp", "hp"))


class _Facts(ast.NodeVisitor):
    def __init__(self, path, text):
        self.path, self.text = path, text
        self.scope = []
        self.literal_fields = []
        self.writes, self.calls, self.methods, self.dot_bindings = [], [], {}, []

    def _scope(self, node):
        self.scope.append(node.name)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            self.methods[".".join(self.scope)] = ast.get_source_segment(self.text, node)
        self.generic_visit(node)
        self.scope.pop()

    visit_ClassDef = _scope
    visit_FunctionDef = _scope
    visit_AsyncFunctionDef = _scope

    def visit_Attribute(self, node):
        if isinstance(node.ctx, ast.Store) and _hp_target(node):
            self.writes.append((self.path, ".".join(self.scope), node.lineno))
        self.generic_visit(node)

    def visit_Subscript(self, node):
        if isinstance(node.ctx, ast.Store) and _hp_target(node):
            self.writes.append((self.path, ".".join(self.scope), node.lineno))
        self.generic_visit(node)

    def visit_For(self, node):
        values = None
        if isinstance(node.target, ast.Name) and isinstance(node.iter, (ast.Tuple, ast.List)):
            if all(isinstance(item, ast.Constant) and type(item.value) is str for item in node.iter.elts):
                # Only trust the finite loop variable if its body never reassigns it.
                reassigned = any(isinstance(item, ast.Name) and isinstance(item.ctx, ast.Store)
                                 and item.id == node.target.id
                                 for stmt in node.body for item in ast.walk(stmt))
                if not reassigned:
                    values = {node.target.id: tuple(item.value for item in node.iter.elts)}
        self.literal_fields.append(values or {})
        self.generic_visit(node)
        self.literal_fields.pop()

    def visit_Call(self, node):
        name = _attribute(node.func)
        self.calls.append((self.path, ".".join(self.scope), name))
        if name == "StatusEngine" and len(node.args) >= 3:
            self.dot_bindings.append((self.path, ".".join(self.scope), _attribute(node.args[2])))
        if name in ("setattr", "object.__setattr__") and len(node.args) >= 2:
            field = node.args[1]
            known = (field.value,) if isinstance(field, ast.Constant) else None
            if isinstance(field, ast.Name):
                for fields in reversed(self.literal_fields):
                    if field.id in fields:
                        known = fields[field.id]
                        break
            if known is None or any(value in ("current_hp", "hp") for value in known):
                self.writes.append((self.path, ".".join(self.scope), node.lineno))
        self.generic_visit(node)


def _fail(detail):
    raise NonAttackProducerAuditError(
        UNCLASSIFIED_NONATTACK_PRODUCTION_DAMAGE_PRODUCER + ": " + detail)


def load_production_sources(root=None):
    root = Path(__file__).resolve().parents[2] if root is None else Path(root)
    # Paths are repository-relative in output; no absolute paths/timestamps.
    return {path.relative_to(root).as_posix(): path.read_text(encoding="utf-8")
            for path in sorted((root / "battle_core").rglob("*.py"))}


def audit_production_sources(sources=None, *, registry=PRODUCTION_NON_ATTACK_REGISTRY):
    """Read supplied complete source snapshot or current production tree.

    Fail closed on unknown HP writes, new Special/DOT callers, missing reviewed
    edges, or changed reviewed implementations. This checks a bounded AST surface,
    not all possible Python behavior. Test files outside battle_core are excluded.
    """
    sources = load_production_sources() if sources is None else sources
    if not isinstance(sources, Mapping):
        raise NonAttackProducerAuditError("Source mapping required")
    selected = {}
    for path, text in sources.items():
        if type(path) is not str or type(text) is not str or "\\" in path or ".." in path.split("/"):
            raise NonAttackProducerAuditError("Repository-relative UTF-8 source strings required")
        if path.startswith("battle_core/") and path.endswith(".py"):
            selected[path] = text.replace("\r\n", "\n")
    writers, calls, methods, dot_bindings = [], set(), {}, []
    for path in sorted(selected):
        try:
            tree = ast.parse(selected[path], filename=path)
        except SyntaxError as exc:
            raise NonAttackProducerAuditError("Invalid production source: " + path) from exc
        facts = _Facts(path, selected[path])
        facts.visit(tree)
        writers.extend(facts.writes)
        calls.update(facts.calls)
        dot_bindings.extend(facts.dot_bindings)
        if path == "battle_core/engine.py":
            methods = facts.methods
    producer_writes, exclusions = [], []
    for path, owner, line in sorted(set(writers)):
        key = path, owner
        if key in PRODUCERS:
            producer = PRODUCERS[key]
            if len(registry.for_producer(producer)) != 1:
                _fail("Missing binding for " + producer)
            producer_writes.append({"path": path, "owner": owner, "line": line,
                                    "producer_id": producer})
        elif key in EXCLUDED_WRITERS:
            exclusions.append({"path": path, "owner": owner, "line": line,
                               "reason": EXCLUDED_WRITERS[key]})
        else:
            _fail(path + ":" + owner + ":HP_WRITE")
    for path, owner, called in sorted(calls):
        tail = called.rsplit(".", 1)[-1]
        if tail == "resolve_special_damage" and (
                path, owner, called) not in REQUIRED_EDGES:
            _fail(path + ":" + owner + ":UNREGISTERED_SPECIAL_CALLER")
        if tail in ("settle_non_attack_damage", "settle_quantized_distribution_atomic",
                    "settle_recipient_allocation") and (path, owner, called) not in ALLOCATION_CALLERS:
            _fail(path + ":" + owner + ":UNREGISTERED_SETTLEMENT_CALLER")
        if tail in ("_resolve_dot", "_resolve_environment_damage_source") and (path, owner, called) not in REQUIRED_EDGES:
            _fail(path + ":" + owner + ":UNREGISTERED_DOT_CALLER")
    if dot_bindings != [("battle_core/engine.py", "BattleEngine.__init__", "self._resolve_dot")]:
        _fail("StatusEngine DOT handler binding changed")
    if not REQUIRED_EDGES <= calls:
        _fail("Missing reviewed scheduler/caller/adapter edges")
    for path, expected in BASELINE_FILES.items():
        if path not in selected or sha256(selected[path].encode("utf-8")).hexdigest() != expected:
            _fail("Reviewed source changed: " + path)
    for owner, expected in BASELINE_METHODS.items():
        text = methods.get(owner, "")
        normalized = "\n".join(line.rstrip() for line in text.splitlines()).strip()
        if sha256(normalized.encode("utf-8")).hexdigest() != expected:
            _fail("Reviewed production method changed: " + owner)
    if {w["producer_id"] for w in producer_writes} != set(PRODUCERS.values()):
        _fail("Known production writer missing")
    dot_method = methods.get("BattleEngine._resolve_dot", "")
    dot_tree = ast.parse(dot_method)
    dot_facts = _Facts("battle_core/engine.py", dot_method)
    dot_facts.visit(dot_tree)
    shield_writes = any(
        isinstance(node, ast.Attribute) and isinstance(node.ctx, ast.Store)
        and node.attr in ("shield", "shield_pool", "amount")
        or isinstance(node, ast.Subscript) and isinstance(node.ctx, ast.Store)
        and "shield" in _attribute(node.value).lower()
        or isinstance(node, ast.Call) and "shield" in _attribute(node.func).lower()
        for node in ast.walk(dot_tree))
    if shield_writes or dot_facts.writes or any(called.rsplit(".", 1)[-1] in
                              ("_absorb_shield", "_check_death", "_on_shield_broken")
                              for path, owner, called in dot_facts.calls):
        _fail("DOT_DIRECT_LEGACY_SETTLEMENT_FORBIDDEN")
    environment_method = methods.get("BattleEngine._resolve_environment_damage_source", "")
    if not environment_method:
        _fail("Missing Environment infrastructure executor")
    environment_tree = ast.parse(environment_method)
    environment_facts = _Facts("battle_core/engine.py", environment_method)
    environment_facts.visit(environment_tree)
    environment_shield_writes = any(
        isinstance(node, ast.Attribute) and isinstance(node.ctx, ast.Store)
        and node.attr in ("shield", "shield_pool", "amount")
        or isinstance(node, ast.Subscript) and isinstance(node.ctx, ast.Store)
        and "shield" in _attribute(node.value).lower()
        or isinstance(node, ast.Call) and "shield" in _attribute(node.func).lower()
        for node in ast.walk(environment_tree))
    if environment_facts.writes or environment_shield_writes or any(
            called.rsplit(".", 1)[-1] in ("_absorb_shield", "_check_death", "_on_shield_broken",
                "_emit_combat_event", "handle_event", "_observe_confirmed_attack_deaths")
            for path, owner, called in environment_facts.calls):
        _fail("ENVIRONMENT_DIRECT_SETTLEMENT_OR_LEGACY_TRIGGER_FORBIDDEN")
    if len(registry.for_producer("BattleEngine._resolve_dot")) != 1:
        _fail("Missing binding for BattleEngine._resolve_dot")
    registry.require_migrated("status_dot:legacy_resolve_dot")
    concrete = {b.producer_id for b in registry.bindings if b.producer_id is not None}
    if concrete != set(PRODUCERS.values()) | {"BattleEngine._resolve_dot"}:
        _fail("Registry/source producer inventory mismatch")
    source_digests = {path: sha256(selected[path].encode("utf-8")).hexdigest()
                      for path in sorted(selected)}
    return freeze({
        "runtime_contract": "WO095", "status": "PASS",
        "canonical_settlement_producers": ["BattleEngine._resolve_dot"],
        "runtime_source_contract_callers": [{
            "caller": "BattleEngine._resolve_environment_damage_source",
            "classification": "RUNTIME_SOURCE_CONTRACT_CALLER_NOT_PRODUCTION_CONTENT",
            "runtime_contract": "WO096_ENVIRONMENT_SOURCE_RUNTIME_CONTRACT",
            "production_content_registered": False}],
        "scope": "BOUNDED_AST_WRITES_CALL_EDGES_AND_REVIEWED_SOURCE_FINGERPRINTS",
        "limitations": "No proof of arbitrary dynamic alias/callback behavior; discovery never grants semantics",
        "source_snapshot_sha256": sha256(canonical_json(source_digests).encode("utf-8")).hexdigest(),
        "production_writers": producer_writes, "excluded_writes": exclusions,
        "excluded_external_paths": "tests/** and non-battle_core paths",
        "reviewed_call_edges": [list(edge) for edge in sorted(REQUIRED_EDGES)],
        "registry": registry.to_dict(),
    })

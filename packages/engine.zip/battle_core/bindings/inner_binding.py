"""Explicit Inner capability routes; compiled numeric content is never rewritten."""
from types import MappingProxyType
from .model import BindingRoute as R

ROUTES = MappingProxyType({
    **dict.fromkeys((
        "flat_max_hp_from_attribute", "flat_attack_from_attribute", "multi_attribute_flat_attack",
        "inner_breath_to_flat_attack", "agility_to_flat_attack",
    ), R.CANONICAL_STATIC_MODIFIER),
    **dict.fromkeys((
        "owner_formal_turn_start_effect", "owner_generated_self_heal", "hit_triggered_status",
        "defense_percent_status", "nonstacking_refresh_status", "inner_breath_scaling", "qi_cost",
        "cooldown", "formal_main_action_damage_accumulator", "formal_main_action_damage_amount_basis",
        "damage_to_shield_conversion", "shield_source_accumulate_policy",
        "shield_source_decay_on_owner_turn_start", "source_specific_shield_mutation",
        "formal_main_damage_to_shield", "single_resource_engine", "single_debuff_cleanse",
        "slot_specific_healing_multiplier", "global_hp_recovery_permission_override",
        "all_hp_recovery_sources_blocked", "missing_hp_to_shield", "current_hp_threshold_multiplier",
        "highest_single_matching_threshold", "shield_source_replace", "legendary_rule_rewrite_permission",
        "dual_permanent_resource_engine", "action_scope_owner_damage_resource_gain",
        "action_scope_enemy_attack_resource_gain", "action_outcome_aggregation", "one_gain_per_action",
        "resource_stack_self_healing_percent", "resource_stack_defense_percent", "dual_resource_threshold",
        "atomic_dual_resource_consumption", "automatic_resource_conversion",
        "independent_duration_multistack_buff", "new_stack_does_not_refresh_old",
        "four_axis_per_stack_buff", "conversion_blocked_at_max_buff_stacks",
        "conversion_recheck_after_stack_expiry",
    ), R.CANONICAL_DIRECT),
    **dict.fromkeys(("non_attack_formal_main_action", "self_target_active_heal",
                     "single_ally_support_action", "resource_scaled_ally_heal",
                     "all_enemies_special_damage", "special_damage_ignore_defense",
                     "special_damage_ignore_parry"), R.LEGACY_NONATTACK_COMPAT),
    **dict.fromkeys(("aggregate_shield_broken_trigger", "broken_shield_amount_absorbed_on_break",
                     "shield_break_reaction_action", "independent_reaction_chain_cap"),
                    R.POST_SETTLEMENT_REACTION),
})

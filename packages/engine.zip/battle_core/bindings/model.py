"""Observational frozen binding metadata; never executes or authorizes content."""
from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType
from ..events.envelope import freeze, thaw


class BindingError(ValueError):
    """Unknown, incomplete or conflicting explicit binding contract."""


class UnresolvedReactionOrderError(BindingError):
    """Multiple existing-content reactions lack explicit cross-owner order."""
    unresolved_marker = "CROSS_OWNER_SHIELD_REACTION_ORDER_TBD"


class BindingDomain(str, Enum):
    MARTIAL = "MARTIAL"
    INNER = "INNER"
    LIGHTNESS = "LIGHTNESS"


class BindingRoute(str, Enum):
    CANONICAL_DIRECT = "CANONICAL_DIRECT"
    CANONICAL_STATIC_MODIFIER = "CANONICAL_STATIC_MODIFIER"
    LEGACY_TRIGGERENGINE_COMPAT = "LEGACY_TRIGGERENGINE_COMPAT"
    POST_SETTLEMENT_REACTION = "POST_SETTLEMENT_REACTION"
    LEGACY_NONATTACK_COMPAT = "LEGACY_NONATTACK_COMPAT"
    UNRESOLVED_TBD = "UNRESOLVED_TBD"
    BLOCKED_NO_AUTHORITY = "BLOCKED_NO_AUTHORITY"


@dataclass(frozen=True, slots=True)
class RuntimeBinding:
    binding_id: str
    domain: BindingDomain
    content_id: str
    mechanic: str
    route: BindingRoute
    source_file: str
    source_version: str
    source_tier: str
    unresolved_marker: str | None = None
    metadata: object = field(default_factory=dict)

    def __post_init__(self):
        for name in ("binding_id", "content_id", "mechanic", "source_file", "source_version", "source_tier"):
            value = getattr(self, name)
            if type(value) is not str or not value:
                raise BindingError("Nonempty " + name + " required")
        if not isinstance(self.domain, BindingDomain) or not isinstance(self.route, BindingRoute):
            raise BindingError("Typed domain and route required")
        if self.route in (BindingRoute.UNRESOLVED_TBD, BindingRoute.BLOCKED_NO_AUTHORITY) and not self.unresolved_marker:
            raise BindingError("Unresolved/blocked routes require explicit marker")
        if type(self.metadata) not in (dict, MappingProxyType):
            raise BindingError("Mapping metadata required")
        object.__setattr__(self, "metadata", freeze(self.metadata))

    def to_dict(self):
        return {name: (getattr(self, name).value if name in ("domain", "route")
                       else thaw(getattr(self, name))) for name in self.__dataclass_fields__}

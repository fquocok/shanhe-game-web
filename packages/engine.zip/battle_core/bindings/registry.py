"""Deterministic observational compiler over existing loaded definitions."""
from dataclasses import dataclass, asdict
from collections.abc import Mapping
from ..events.envelope import canonical_json
from ..martial import MartialCapabilityRegistry, MartialRoutineDefinition
from ..inner_skill import InnerSkillCapabilityRegistry, InnerSkillDefinition
from ..lightness import LightnessCapabilityRegistry, LightnessSkillDefinition
from .model import RuntimeBinding, BindingError, BindingDomain as D, BindingRoute as R
from .martial_binding import ROUTES as MARTIAL_ROUTES
from .inner_binding import ROUTES as INNER_ROUTES
from .lightness_binding import ROUTES as LIGHTNESS_ROUTES


def unresolved_values(value):
    """Record explicit markers only; never infer a numeric value or semantic answer."""
    if isinstance(value, str):
        return (value,) if "TBD" in value or "DEFERRED_EXPLORATION" in value else ()
    if isinstance(value, Mapping):
        return tuple(v for item in value.values() for v in unresolved_values(item))
    if isinstance(value, (tuple, list)):
        return tuple(v for item in value for v in unresolved_values(item))
    return ()


@dataclass(frozen=True, slots=True)
class RuntimeBindingRegistry:
    bindings: tuple[RuntimeBinding, ...]

    def __post_init__(self):
        bindings = tuple(sorted(self.bindings, key=lambda b: b.binding_id))
        if any(type(b) is not RuntimeBinding for b in bindings):
            raise BindingError("Typed immutable bindings required")
        if len({b.binding_id for b in bindings}) != len(bindings):
            raise BindingError("Duplicate binding ID")
        routes = {}
        for b in bindings:
            key = b.domain, b.content_id, b.mechanic
            if key in routes and routes[key] != b.route:
                raise BindingError("Conflicting routes for " + str(key))
            routes[key] = b.route
        object.__setattr__(self, "bindings", bindings)

    def for_content(self, content_id, mechanic=None, *, domain=None):
        return tuple(b for b in self.bindings if b.content_id == content_id
                     and (mechanic is None or b.mechanic == mechanic)
                     and (domain is None or b.domain == domain))

    def for_domain(self, domain):
        return tuple(b for b in self.bindings if b.domain == domain)

    def to_dict(self):
        return {"schema_version": 1, "runtime_contract": "WO090",
                "bindings": [b.to_dict() for b in self.bindings]}

    def serialize(self):
        return canonical_json(self.to_dict())


def compile_bindings(martials=(), inner_skills=(), lightness=(), *, equipped=None):
    """Consumes compiled definitions only. No compiler/numeric/content mutation."""
    groups = ((D.MARTIAL, tuple(martials), MartialRoutineDefinition,
               MartialCapabilityRegistry.SUPPORTED, MARTIAL_ROUTES),
              (D.INNER, tuple(inner_skills), InnerSkillDefinition,
               InnerSkillCapabilityRegistry.SUPPORTED, INNER_ROUTES),
              (D.LIGHTNESS, tuple(lightness), LightnessSkillDefinition,
               LightnessCapabilityRegistry.SUPPORTED, LIGHTNESS_ROUTES))
    result = []
    equipped = {} if equipped is None else equipped
    for domain, definitions, definition_type, supported, routes in groups:
        if set(routes) != set(supported):
            raise BindingError(domain.value + " capability/route table coverage mismatch")
        if len({d.id for d in definitions}) != len(definitions):
            raise BindingError("Duplicate loaded content ID")
        for definition in definitions:
            if type(definition) is not definition_type:
                raise BindingError("Typed compiled definition required")
            provenance = definition.provenance
            source = (provenance.generation_file if domain == D.INNER else provenance.source_file)
            items = ([(definition.active_skill.id, "active_physical_attack",
                       {"tuning": definition.active_skill.tuning_placeholder})]
                     + [(p.id, p.mechanic, p.parameters) for p in definition.passives]
                     if domain == D.MARTIAL else
                     [(s.id, s.mechanic, s.parameters) for s in definition.slots])
            for item_id, mechanic, parameters in items:
                if mechanic not in supported or mechanic not in routes:
                    raise BindingError("No explicit " + domain.value + " route for " + mechanic)
                route, marker = routes[mechanic], None
                info = {"source_anchor": provenance.source_anchor,
                        "source_provenance": asdict(provenance),
                        "item_id": item_id,
                        "owner_ids": sorted(owner for owner, content in equipped.get(domain, {}).items()
                                            if content == definition.id)}
                if domain == D.MARTIAL:
                    info["unresolved_fields"] = definition.unresolved_fields
                    info["blocked_spec_fields"] = definition.blocked_spec_fields
                    info["validation_information"] = definition.validation_information
                explicit_markers = unresolved_values(parameters)
                if route == R.UNRESOLVED_TBD:
                    if domain == D.MARTIAL:
                        marker = "ally_is_attacked_semantics: TBD_CORE"
                        info["existing_compatibility_route"] = R.LEGACY_TRIGGERENGINE_COMPAT.value
                        info["scope"] = "CONTENT_SPECIFIC_ONLY_NO_GLOBAL_SEMANTIC_RESOLUTION"
                    else:
                        marker = "DEFERRED_EXPLORATION"
                elif explicit_markers:
                    route, marker = R.UNRESOLVED_TBD, "; ".join(sorted(set(explicit_markers)))
                    info["implemented_route"] = routes[mechanic].value
                if explicit_markers:
                    info["source_unresolved_values"] = explicit_markers
                if mechanic == "attack_to_dot_status_application":
                    info["settlement_route"] = R.LEGACY_NONATTACK_COMPAT.value
                    info["dot_lifecycle_migrated"] = False
                if domain == D.INNER and route == R.POST_SETTLEMENT_REACTION:
                    info["settlement_route"] = R.LEGACY_NONATTACK_COMPAT.value
                    info["order_authority"] = "SINGLE_EXISTING_CONTENT_CANDIDATE_ONLY"
                result.append(RuntimeBinding(
                    domain.value + ":" + definition.id + ":" + item_id,
                    domain, definition.id, mechanic, route, str(source),
                    provenance.source_version, definition.tier, marker, info))
        for mechanic in ("generic_interception_generation", "generic_damage_sharing_generation",
                         "dot_sharing", "full_100_percent_sharing"):
            result.append(RuntimeBinding(
                domain.value + ":authority_firewall:" + mechanic, domain, "__authority_firewall__",
                mechanic, R.BLOCKED_NO_AUTHORITY, "WO090_Runtime_Binding_Contract",
                "WO090", "NOT_CONTENT_AUTHORITY", "BLOCKED_NO_AUTHORITY",
                {"authorizes_gameplay": False, "requires_explicit_approved_content": True}))
    return RuntimeBindingRegistry(tuple(result))

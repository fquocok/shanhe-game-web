"""Only existing Inner Shield Break content, after commit/death compatibility."""
from ..events import SemanticEventType as T
from ..reactions import ReactionCandidate, ReactionKind
from ..reactions.validation import validate_atomic_result
from .model import BindingDomain as D, BindingRoute as R, BindingError, UnresolvedReactionOrderError


def dispatch_inner_shield_breaks(runtime, atomic_result):
    """No automatic cross-owner order: fail BEFORE observations/execution if competing."""
    facts = validate_atomic_result(runtime, atomic_result)
    sources = tuple(f for f in facts if f.event_type == T.SHIELD_BROKEN)
    if not sources:
        return None
    registered = runtime.binding_registry
    matches = {}
    for fact in sources:
        owner = runtime.state_by_id(fact.damage_recipient_id)
        skill = runtime.inner_skills.equipped.get(owner.definition.id)
        slot = None if skill is None else next(
            (s for s in skill.slots if s.mechanic == "shield_break_reaction_action"), None)
        if slot is not None:
            bindings = registered.for_content(skill.id, slot.mechanic, domain=D.INNER)
            if not bindings or any(b.route != R.POST_SETTLEMENT_REACTION for b in bindings):
                raise BindingError("Inner Shield Break content has no active explicit binding")
            matches[fact.event_id] = skill, slot
    if len(matches) > 1:
        raise UnresolvedReactionOrderError(
            "No Human/content cross-owner Shield reaction order: " +
            ", ".join(f.damage_recipient_id for f in sources if f.event_id in matches))
    settlements = {s.recipient_id: s for s in atomic_result.settlements}
    observations = {}
    for fact in sources:
        settlement = settlements[fact.damage_recipient_id]
        observations[fact.event_id] = runtime._observe_shield_break_compatibility(
            runtime.state_by_id(settlement.recipient_id), settlement.integer_damage,
            settlement.shield_absorbed_damage, settlement.hp_damage)

    def provider(engine, fact):
        match = matches.get(fact.event_id)
        if match is None:
            return ()
        skill, slot = match
        return (ReactionCandidate(
            "inner-shield-break:" + fact.event_id + ":" + skill.id + ":" + slot.id,
            fact.event_id, ReactionKind.POST_SHIELD_BREAK,
            fact.damage_recipient_id, fact.damage_recipient_id, 0, 0,
            source_definition_id=skill.id, source_effect_id=slot.id,
            provenance={"binding": "WO090", "source_anchor": skill.provenance.source_anchor,
                        "order_authority": "SINGLE_CANDIDATE_NOT_CROSS_OWNER_PRIORITY",
                        "settlement_route": R.LEGACY_NONATTACK_COMPAT.value}),)

    def eligible(engine, candidate):
        # Existing handler owns its exact chain-cap/dead-owner cancellation order.
        # A defeated owner is still a valid cancellation observation opportunity;
        # the unchanged handler cancels before any gameplay damage.
        owner = engine.state_by_id(candidate.owner_id)
        current = engine.inner_skills.equipped.get(candidate.owner_id)
        skill, slot = matches[candidate.source_event_id]
        return bool(owner is not None and candidate.subject_id == candidate.owner_id
                    and current is skill and slot in current.slots)

    def executor(engine, candidate):
        owner = engine.state_by_id(candidate.owner_id)
        engine.inner_skills.handle_shield_broken(owner, observations[candidate.source_event_id])
        return {"existing_inner_handler": True, "owner_defeated": owner.death_confirmed,
                "legacy_special_damage_path": True}

    return runtime.run_post_settlement_reactions(
        atomic_result, provider=provider, eligible=eligible, executor=executor,
        reaction_kinds=(ReactionKind.POST_SHIELD_BREAK,))

"""WO-078 minimal Event → Encounter → immutable Result → Event bridge."""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import json
from pathlib import Path
from types import MappingProxyType
from typing import Mapping

from .encounter_result import EncounterResult, VALID_OUTCOMES
from .game_facing_encounter import load_encounter_definition

GAME_FACING_EVENT_DEFINITION = "GAME_FACING_EVENT_DEFINITION_V0_1"
EVENT_REGISTRY = "EVENT_REGISTRY_V0_1"
EVENT_TO_ENCOUNTER_INVOCATION = "EVENT_TO_ENCOUNTER_INVOCATION_V0_1"
ENCOUNTER_INVOCATION_REQUEST = "ENCOUNTER_INVOCATION_REQUEST_V0_1"
ENCOUNTER_RESULT_TO_EVENT_RETURN = "ENCOUNTER_RESULT_TO_EVENT_RETURN_V0_1"
EVENT_STATUSES = frozenset(("NONCANONICAL_GAME_FACING_PROTOTYPE", "NONCANONICAL_GAME_FACING_DEV_FIXTURE"))


class EventRuntimeState(str, Enum):
    READY = "READY"
    BATTLE_ACTIVE = "BATTLE_ACTIVE"
    RESOLVED_VICTORY = "RESOLVED_VICTORY"
    RESOLVED_DEFEAT = "RESOLVED_DEFEAT"


@dataclass(frozen=True)
class GameFacingEventDefinition:
    event_id: str
    display_name: str
    status: str
    initial_text: str
    encounter_id: str
    on_victory_text: str
    on_defeat_text: str


@dataclass(frozen=True)
class EncounterInvocationRequest:
    contract: str
    invocation_id: str
    event_instance_id: str
    event_id: str
    encounter_id: str
    seed: int | None = None


class EventDefinitionError(ValueError): pass
class EventLifecycleError(RuntimeError): pass


def _event_dir(workspace: str | Path) -> Path:
    return Path(workspace) / "game_content" / "events"


def event_registry(workspace: str | Path) -> Mapping[str, str]:
    raw=json.loads((_event_dir(workspace)/"event_registry.json").read_text(encoding="utf-8"))
    if raw.get("contract") != EVENT_REGISTRY or not isinstance(raw.get("events"),dict):
        raise EventDefinitionError("INVALID_EVENT_REGISTRY")
    return MappingProxyType(dict(raw["events"]))


def parse_event_definition(raw: Mapping[str, object]) -> GameFacingEventDefinition:
    fields=("event_id","display_name","status","initial_text","encounter_id","on_victory_text","on_defeat_text")
    missing=tuple(field for field in fields if not isinstance(raw.get(field),str) or not raw.get(field))
    if missing: raise EventDefinitionError("EVENT_FIELDS_REQUIRED:"+",".join(missing))
    definition=GameFacingEventDefinition(*(str(raw[field]) for field in fields))
    if not definition.event_id.startswith("event:"): raise EventDefinitionError("INVALID_EVENT_ID")
    if definition.status not in EVENT_STATUSES: raise EventDefinitionError("INVALID_EVENT_STATUS")
    return definition


def load_event_definition(workspace: str | Path, event_id: str) -> GameFacingEventDefinition:
    registry=event_registry(workspace)
    if event_id not in registry: raise EventDefinitionError("UNKNOWN_EVENT_ID:"+event_id)
    definition=parse_event_definition(json.loads((_event_dir(workspace)/registry[event_id]).read_text(encoding="utf-8")))
    if definition.event_id != event_id: raise EventDefinitionError("EVENT_ID_FILE_MISMATCH")
    load_encounter_definition(workspace,definition.encounter_id)
    return definition


class EventRuntime:
    """Mutable event lifecycle only; Battle truth remains downstream-owned."""
    def __init__(self, definition: GameFacingEventDefinition, event_instance_id: str):
        self.definition=definition; self.event_instance_id=event_instance_id
        self.state=EventRuntimeState.READY
        self.active_invocation: EncounterInvocationRequest | None=None
        self.active_encounter_instance_id: str | None=None
        self.result: EncounterResult | None=None
        self.invocation_count=0; self.result_consumption_count=0
        self.rejected_results: list[str]=[]

    @property
    def battle_button_enabled(self) -> bool: return self.state is EventRuntimeState.READY
    @property
    def event_reset_enabled(self) -> bool: return self.state is not EventRuntimeState.BATTLE_ACTIVE

    def request_encounter(self, *, seed: int | None=None) -> EncounterInvocationRequest:
        if self.state is EventRuntimeState.BATTLE_ACTIVE and self.active_invocation is not None:
            return self.active_invocation
        if self.state is not EventRuntimeState.READY: raise EventLifecycleError("EVENT_NOT_READY")
        self.invocation_count += 1
        request=EncounterInvocationRequest(ENCOUNTER_INVOCATION_REQUEST,
            f"{self.event_instance_id}:invocation:{self.invocation_count}",self.event_instance_id,
            self.definition.event_id,self.definition.encounter_id,seed)
        self.active_invocation=request; self.active_encounter_instance_id=None
        self.state=EventRuntimeState.BATTLE_ACTIVE
        return request

    def bind_encounter_instance(self, invocation_id: str, encounter_instance_id: str) -> None:
        if self.state is not EventRuntimeState.BATTLE_ACTIVE or self.active_invocation is None:
            raise EventLifecycleError("NO_ACTIVE_INVOCATION")
        if invocation_id != self.active_invocation.invocation_id: raise EventLifecycleError("INVOCATION_MISMATCH")
        if not encounter_instance_id: raise EventLifecycleError("ENCOUNTER_INSTANCE_REQUIRED")
        self.active_encounter_instance_id=encounter_instance_id

    def consume_encounter_result(self, invocation_id: str, event_instance_id: str,
                                 result: EncounterResult) -> bool:
        reason=None
        if self.state is not EventRuntimeState.BATTLE_ACTIVE or self.active_invocation is None: reason="EVENT_NOT_BATTLE_ACTIVE"
        elif invocation_id != self.active_invocation.invocation_id: reason="INVOCATION_MISMATCH"
        elif event_instance_id != self.event_instance_id: reason="EVENT_INSTANCE_MISMATCH"
        elif result.encounter_id != self.definition.encounter_id: reason="ENCOUNTER_ID_MISMATCH"
        elif result.encounter_instance_id != self.active_encounter_instance_id: reason="ENCOUNTER_INSTANCE_MISMATCH"
        elif result.outcome not in VALID_OUTCOMES: reason="UNSUPPORTED_RESULT_OUTCOME"
        if reason:
            self.rejected_results.append(reason); return False
        self.result=result; self.result_consumption_count += 1
        self.state=(EventRuntimeState.RESOLVED_VICTORY if result.outcome=="VICTORY"
                    else EventRuntimeState.RESOLVED_DEFEAT)
        return True

    def human_view(self) -> dict[str, object]:
        result_label=None if self.result is None else ("勝利" if self.result.outcome=="VICTORY" else "敗北")
        resolved_text=(None if self.result is None else self.definition.on_victory_text
                       if self.result.outcome=="VICTORY" else self.definition.on_defeat_text)
        return {"event_id":self.definition.event_id,"event_instance_id":self.event_instance_id,
                "display_name":self.definition.display_name,"initial_text":self.definition.initial_text,
                "state":self.state.value,"battle_button_enabled":self.battle_button_enabled,
                "event_reset_enabled":self.event_reset_enabled,"result_label":result_label,
                "resolved_text":resolved_text,"result":self.result}


class EventRuntimeFactory:
    def __init__(self, workspace: str | Path): self.workspace=Path(workspace); self._sequence=0
    def create(self,event_id: str) -> EventRuntime:
        definition=load_event_definition(self.workspace,event_id); self._sequence+=1
        return EventRuntime(definition,f"{event_id}:instance:{self._sequence}")

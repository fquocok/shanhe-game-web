"""Generic Revision-envelope compiler and WO-036B2B transactional promotion."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any, Callable
import json

from .engine import BattleEngine
from .generated_acceptance import FORMAL_GENERATED_MARTIAL_REGISTRY, stable_hash
from .generator import deserialize_candidate, serialize_candidate, validate_candidate
from .martial import MartialActiveSkillDefinition,MartialPassiveDefinition,MartialRoutineDefinition,SourceProvenance,validate_martial_definition
from .numeric_token_valuation import evaluate_candidate_numeric_budget
from .schema import validate_characters
from .trigger import FormalTurnContext


@dataclass(frozen=True)
class GeneratedCanonicalProvenance(SourceProvenance):
    origin:str="GENERATED_CONTENT";authority:str="HUMAN_ACCEPTED_GENERATED_CONTENT";candidate_origin_id:str="";candidate_revision_id:str="";candidate_sha256:str="";review_package_id:str="";review_package_sha256:str="";human_decision_id:str="";acceptance_pipeline_version:str="v0.1-prototype";numeric_token_policy_version:str="v0.1";generator_version:str="v0.2-prototype";promotion_work_order:str="CODEX-WO-036B2B";balance_status:str="FIRST_PASS_GENERATED_VALUE";final_balance_locked:bool=False


@dataclass(frozen=True)
class HumanAcceptRevision2:
    decision_id:str;work_order:str;candidate_revision_id:str;candidate_sha256:str;review_package_id:str;review_package_sha256:str;decision:str;meaning:str;authority:str;budget_snapshot:dict[str,int];generator_version:str;acceptance_pipeline_version:str;numeric_token_policy_version:str;battle_core_version:str;formal_display_name:str;timestamp:str


@dataclass(frozen=True)
class Revision2PromotionResult:
    status:str;failed_gate:str|None;blocker_ids:tuple[str,...];human_decision:HumanAcceptRevision2;human_decision_sha256:str;hash_binding:dict[str,Any];revalidation:dict[str,Any];budget:dict[str,Any];preview:dict[str,Any]|None;semantic_equivalence:dict[str,Any];compile_report:dict[str,Any];staging_manifest:dict[str,Any];smoke_report:dict[str,Any];transaction_report:dict[str,Any];promotion_manifest:dict[str,Any]|None;formal_definition:Any|None;generator_calls:int;source_immutable:bool


def deterministic_generated_canonical_id(candidate):
    parts=candidate.candidate_id.replace("gen_v01_","").replace(".","_").split("_")
    family=parts[1] if len(parts)>1 else candidate.family.lower();fingerprint=next((x for x in parts if len(x)==12),stable_hash(candidate.candidate_id)[:12]);revision=parts[-1] if parts[-1].startswith("r") else "r0"
    return f"generated:{family}:{candidate.tier.lower()}:{fingerprint}:{revision}"


def compile_revision_envelope(envelope,review_package,human_decision):
    candidate=deserialize_candidate(envelope["candidate_snapshot"]);content=envelope["canonical_content"];status=content["status"];application=content["application"];pursuit=content["pursuit"];canonical_id=deterministic_generated_canonical_id(candidate)
    provenance=GeneratedCanonicalProvenance("generated_candidates/wo036b2a/candidate_d_revision_2.json",envelope["revision_id"],"2",candidate.tier,106,candidate_origin_id=envelope["parent_revision_id"].removesuffix(".r1"),candidate_revision_id=envelope["revision_id"],candidate_sha256=stable_hash(envelope),review_package_id=review_package["review_package_id"],review_package_sha256=stable_hash(review_package),human_decision_id=human_decision.decision_id)
    active=MartialActiveSkillDefinition(canonical_id+".active",envelope["formal_display_name"],0,0.0,"single",float(candidate.actions[0]["damage_coefficient"]),"FIRST_PASS_GENERATED_VALUE final_balance_locked=false")
    apply_params={"event_type":"ALLY_TARGETED_BY_ATTACK_INSTANCE","scope":"ATTACK_SCOPE","base_chance":1.0,"special_kind":"assist_attack","target_selector":"event_attacker","coefficient":1.0,"status_id":status["id"],"status_name":status["display_name"],"status_tags":("positive","buff"),"duration":status["duration"],"stacking_policy":"refresh","application_event":application["event"]}
    pursuit_params={"base_chance":1.0,"coefficient":float(candidate.actions[0]["damage_coefficient"]),"source_action_id":"basic_attack","required_status_id":status["id"],"cost_timing":pursuit["consumption_timing"],"refund_policy":pursuit["refund_policy"]}
    passives=(MartialPassiveDefinition(canonical_id+".retaliation",status["display_name"],"special_commit_self_status_application",MappingProxyType(apply_params)),MartialPassiveDefinition(canonical_id+".pursuit",envelope["formal_display_name"],"status_gated_attempt_paid_rear_followup",MappingProxyType(pursuit_params)))
    return validate_martial_definition(MartialRoutineDefinition(canonical_id,envelope["formal_display_name"],"槍法",candidate.tier.lower(),candidate.budget,active,passives,provenance,(),("generated_acceptance","numeric_budget_used=106","numeric_budget_limit=120","value_category=FIRST_PASS_GENERATED_VALUE","status_duration_unit=OWNER_FORMAL_TURNS"),"spear",()))


def definition_payload(definition):
    active_payload=asdict(definition.active_skill)
    # Backward-compatible normalization: the new optional parameter participates
    # in semantic identity only when present. Legacy payload bytes/hashes retain
    # their pre-extension shape.
    if active_payload.get("requested_target_count") is None:active_payload.pop("requested_target_count",None)
    payload={"id":definition.id,"name":definition.name,"family":definition.family,"tier":definition.tier,"budget":definition.budget,"active_skill":active_payload,"passives":[{"id":x.id,"name":x.name,"mechanic":x.mechanic,"parameters":dict(x.parameters)} for x in definition.passives],"provenance":asdict(definition.provenance),"unresolved_fields":definition.unresolved_fields,"validation_information":definition.validation_information,"weapon_requirement":definition.weapon_requirement,"blocked_spec_fields":definition.blocked_spec_fields}
    if definition.resource_loops:
        from .resource_loop_formal import semantic_payload
        payload["resource_loops"]=[semantic_payload(x) for x in definition.resource_loops]
    return payload


def _raw(uid,faction,*,martial_id=None,row="front",column=1,hp=500):
    d={"id":uid,"name":uid,"level":1,"attributes":{"strength":20,"constitution":10,"agility":10,"inner_breath":10},"weapon_attack":20,"equipment_defense":0,"max_hp":hp,"faction":faction,"position":{"row":row,"column":column},"basic_attack":{"coefficient":1.0}}
    if martial_id:d["martial_loadout"]={"external_primary":martial_id}
    return d


def run_revision_2_smoke(definition,seed=17):
    chars=[_raw("owner","player",martial_id=definition.id,column=1),_raw("ally","player",column=2),_raw("front","enemy",row="front",column=1),_raw("behind","enemy",row="middle",column=1),_raw("attacker","enemy",row="front",column=3)]
    engine=BattleEngine(validate_characters(chars),seed,martial_definitions=(definition,));owner=engine.state_by_id("owner");sid=str(definition.passives[0].parameters["status_id"])
    engine.trigger_context=FormalTurnContext("smoke","attacker")
    engine._emit_combat_event("ALLY_TARGETED_BY_ATTACK_INSTANCE",action_id="enemy-action",attack_instance_id="enemy-attack-1",attacker_id="attacker",target_id="ally",target_team="player",attacker_team="enemy");engine.triggers.special_actions.drain()
    applied=next((s for s in owner.statuses if s.definition.id==sid),None);application_ok=applied is not None and applied.remaining_duration==2
    first_instance=applied.instance_id if applied else None
    engine._emit_combat_event("ALLY_TARGETED_BY_ATTACK_INSTANCE",action_id="enemy-action-2",attack_instance_id="enemy-attack-2",attacker_id="attacker",target_id="ally",target_team="player",attacker_team="enemy");engine.triggers.special_actions.drain()
    refreshed=next((s for s in owner.statuses if s.definition.id==sid),None);refresh_ok=refreshed is not None and refreshed.remaining_duration==2 and refreshed.instance_id==first_instance and len([s for s in owner.statuses if s.definition.id==sid])==1
    engine._emit_combat_event("ACTION_COMPLETE",action_id="basic-1",actor_id="owner",target_id="front",source_action_definition_id="basic_attack",action_classification="formal_main",attack_coefficient=1.0);consumed_before_drain=not any(s.definition.id==sid for s in owner.statuses);engine.triggers.special_actions.drain()
    pursuit_hits=tuple(e.data.get("target_id") for e in engine.log.events if e.type=="ATTACK_INSTANCE_CREATED" and e.data.get("target_id")=="behind")
    events=[x.type for x in engine.log.events];settled=any(x.type=="TRIGGER_ATTEMPT_STATUS_COST_PAID" for x in engine.log.events)
    # Directly re-apply for canonical owner-turn lifecycle verification.
    definition_status=engine.martials._status_definitions[sid];engine.statuses.apply(definition_status,owner,owner);snap=engine.statuses.owner_turn_start(owner);engine.statuses.owner_turn_end(owner,snap);after_one=next(s.remaining_duration for s in owner.statuses if s.definition.id==sid);snap=engine.statuses.owner_turn_start(owner);engine.statuses.owner_turn_end(owner,snap);expired=not any(s.definition.id==sid for s in owner.statuses)
    return {"status":"PASS" if all((application_ok,refresh_ok,consumed_before_drain,bool(pursuit_hits),settled,after_one==1,expired)) else "FAIL","load":True,"ally_retaliation":application_ok,"application_after_commit":events.index("SPECIAL_ACTION_STARTED")<events.index("STATUS_APPLIED"),"hit_or_damage_not_required":True,"duration":{"initial":2,"after_first_owner_turn":after_one,"expired_after_second":expired},"refresh":{"duration":2,"single_instance":refresh_ok},"behind_gate":{"consumed_before_roll_and_execution":consumed_before_drain,"target":"behind","hit_count":len(pursuit_hits)},"no_refund":{"settled":settled,"policy":"NO_REFUND_AFTER_COST_SETTLEMENT"},"ordinary_cap":3,"damage_coefficient":1.0,"tier_multiplier_applied":False,"seed":seed,"log_hash":stable_hash([(x.type,x.data) for x in engine.log.events])}


def run_wo036b2b_promotion(workspace,*,decision="ACCEPT",subject_override=None,candidate_hash_override=None,review_hash_override=None,policy_version_override=None,budget_total_override=None,formal_registry=None,runtime_registry=None,compile_gate:Callable[[Any],bool]|None=None,staging_gate:Callable[[dict],bool]|None=None,smoke_gate:Callable[[dict],bool]|None=None,regression_gate:Callable[[],bool]|None=None,commit_gate:Callable[[],bool]|None=None,clock=lambda:"2026-08-24T00:00:00+08:00"):
    root=Path(workspace);formal_registry=FORMAL_GENERATED_MARTIAL_REGISTRY if formal_registry is None else formal_registry;runtime_registry={} if runtime_registry is None else runtime_registry;fb,rb=len(formal_registry),len(runtime_registry)
    ep=root/"generated_candidates"/"wo036b2a"/"candidate_d_revision_2.json";rp=root/"generated_candidates"/"wo036b2a"/"revision_2_review_package.json";hp=root/"generated_candidates"/"wo036b2a"/"revision_2_hash_chain.json";bp=root/"generated_candidates"/"wo036b2a"/"revision_2_token_revaluation.json";pp=root/"generated_candidates"/"wo036b1c"/"numeric_token_valuation_policy_registry_v0_1.json"
    source_bytes={p.name:p.read_bytes() for p in (ep,rp,hp,bp,pp)};envelope=json.loads(source_bytes[ep.name]);package=json.loads(source_bytes[rp.name]);chain=json.loads(source_bytes[hp.name]);budget_artifact=json.loads(source_bytes[bp.name]);policy=json.loads(source_bytes[pp.name]);candidate=deserialize_candidate(envelope["candidate_snapshot"])
    revision_hash=stable_hash(envelope);review_hash=stable_hash(package);subject=subject_override or envelope["revision_id"];bound_candidate_hash=candidate_hash_override or revision_hash;bound_review_hash=review_hash_override or review_hash;policy_version=policy_version_override or policy["version"]
    current_budget=evaluate_candidate_numeric_budget(candidate,duration_unit="OWNER_FORMAL_TURNS");human=HumanAcceptRevision2("decision:"+stable_hash(("WO036B2B",subject,revision_hash,review_hash,decision))[:16],"CODEX-WO-036B2B",subject,bound_candidate_hash,package["review_package_id"],bound_review_hash,decision,"ACCEPT_FOR_CANONICALIZATION_ATTEMPT" if decision=="ACCEPT" else decision,"HUMAN",{"used":budget_total_override if budget_total_override is not None else current_budget.total_used,"limit":120,"remaining":14},"v0.2-prototype","v0.1-prototype",policy_version,"v0.9",envelope["formal_display_name"],clock());human_hash=stable_hash(asdict(human));fail=[]
    if decision!="ACCEPT":fail.append("HUMAN_DECISION_NOT_ACCEPT")
    if subject!=envelope["revision_id"]:fail.append("WRONG_HUMAN_DECISION_SUBJECT")
    if bound_candidate_hash!=revision_hash or chain["revision_envelope_sha256"]!=revision_hash:fail.append("CANDIDATE_HASH_MISMATCH")
    if bound_review_hash!=review_hash or chain["review_package_sha256"]!=review_hash:fail.append("REVIEW_PACKAGE_HASH_MISMATCH")
    if chain["validation_sha256"]!=package["validation_sha256"]:fail.append("VALIDATION_HASH_MISMATCH")
    if policy_version!="v0.1":fail.append("STALE_NUMERIC_POLICY")
    if (budget_total_override if budget_total_override is not None else current_budget.total_used)!=106 or budget_artifact["total_used"]!=106:fail.append("TOKEN_ACCOUNTING_MISMATCH")
    if current_budget.total_used!=106 or current_budget.remaining!=14:fail.append("TOKEN_ACCOUNTING_MISMATCH")
    validation=validate_candidate(candidate);revalidation={"schema":validation.schema_result,"tier":candidate.tier,"family":candidate.family,"topology":validation.topology_result,"capability":validation.capability_result,"policy":validation.policy_result,"content":validation.content_result,"budget":current_budget.status,"compiler_readiness":package["compiler_readiness"]["status"],"open_core":candidate.open_policy_dependencies,"deferred":(),"unknown_capabilities":()}
    canonical_id=deterministic_generated_canonical_id(candidate)
    if canonical_id in formal_registry:fail.append("ID_COLLISION")
    hashes={"status":"PASS" if not fail else "FAIL","revision":{"expected":chain["revision_envelope_sha256"],"actual":revision_hash},"candidate_snapshot":{"expected":chain["candidate_snapshot_sha256"],"actual":stable_hash(envelope["candidate_snapshot"])},"validation":{"expected":chain["validation_sha256"],"actual":package["validation_sha256"]},"review_package":{"expected":chain["review_package_sha256"],"actual":review_hash},"budget":{"artifact":budget_artifact["total_used"],"recomputed":current_budget.total_used,"policy":policy_version},"human_decision":{"sha256":human_hash,"subject":subject}}
    if fail:return Revision2PromotionResult("PARTIAL_BLOCKED","PREPROMOTION_BINDING",tuple(dict.fromkeys(fail)),human,human_hash,hashes,revalidation,asdict(current_budget),None,{"status":"NOT_RUN","differences":()}, {"status":"NOT_RUN"},{"status":"NOT_RUN","formal_count":fb,"staging_count":0},{"status":"NOT_RUN"},{"commit_attempted":False,"commit_succeeded":False,"rollback":False,"formal_before":fb,"formal_after":len(formal_registry),"runtime_before":rb,"runtime_after":len(runtime_registry)},None,None,0,all(p.read_bytes()==source_bytes[p.name] for p in (ep,rp,hp,bp,pp)))
    definition=compile_revision_envelope(envelope,package,human);payload=definition_payload(definition);preview={**payload,"canonical":False,"registry_committed":False,"promotion_state":"PREVIEW_ONLY","token_budget_used":106,"token_budget_limit":120};preview_hash=stable_hash(preview)
    content=envelope["canonical_content"];diff=[]
    checks={"family":definition.family=="槍法","tier":definition.tier=="advanced","formal_name":definition.name==envelope["formal_display_name"],"targeting":definition.active_skill.targeting_pattern==candidate.actions[0]["targeting"],"ordinary_special":all(p.parameters.get("base_chance") is not None for p in definition.passives),"status_identity":definition.passives[0].parameters["status_id"]==content["status"]["id"],"status_classification":"buff" in definition.passives[0].parameters["status_tags"],"application":definition.passives[0].parameters["application_event"]==content["application"]["event"],"duration":definition.passives[0].parameters["duration"]==2,"refresh":definition.passives[0].parameters["stacking_policy"]=="refresh","consumption":definition.passives[1].parameters["cost_timing"]==content["pursuit"]["consumption_timing"],"refund":definition.passives[1].parameters["refund_policy"]==content["pursuit"]["refund_policy"],"coefficient":definition.active_skill.attack_coefficient==1.0,"value_category":"FIRST_PASS_GENERATED_VALUE" in definition.active_skill.tuning_placeholder,"budget":current_budget.total_used==106,"capabilities":validation.capability_result=="VALID","topology":validation.topology_result.startswith("VALID")}
    checks["targeting"]=definition.passives[1].mechanic=="status_gated_attempt_paid_rear_followup"
    diff=[k for k,v in checks.items() if not v];equivalence={"status":"PASS" if not diff else "FAIL","compared":checks,"differences":tuple(diff)}
    if diff:return Revision2PromotionResult("PARTIAL_BLOCKED","CANONICAL_PREVIEW_SEMANTIC_DRIFT",tuple(diff),human,human_hash,hashes,revalidation,asdict(current_budget),preview,equivalence,{"status":"NOT_RUN"},{"status":"NOT_RUN"},{"status":"NOT_RUN"},{"commit_attempted":False,"commit_succeeded":False,"rollback":False,"formal_before":fb,"formal_after":len(formal_registry),"runtime_before":rb,"runtime_after":len(runtime_registry)},None,None,0,True)
    compiled=compile_gate(definition) if compile_gate else bool(validate_martial_definition(definition));compile_report={"status":"PASS" if compiled else "FAIL","compiler":"compile_revision_envelope","generic":True,"definition_hash":stable_hash(payload)}
    if not compiled:return Revision2PromotionResult("PARTIAL_BLOCKED","COMPILE",("COMPILE_FAILED",),human,human_hash,hashes,revalidation,asdict(current_budget),preview,equivalence,compile_report,{"status":"NOT_RUN"},{"status":"NOT_RUN"},{"commit_attempted":False,"commit_succeeded":False,"rollback":True,"formal_before":fb,"formal_after":len(formal_registry),"runtime_before":rb,"runtime_after":len(runtime_registry)},None,None,0,True)
    staging=dict(formal_registry);staging[definition.id]={"definition":definition,"candidate_sha256":revision_hash};staged_ok=staging_gate(staging) if staging_gate else len(staging)==fb+1;staging_manifest={"status":"PASS" if staged_ok else "FAIL","formal_count":fb,"staging_count":len(staging),"definition_hash":stable_hash(payload),"roundtrip_hash":stable_hash(json.loads(json.dumps(payload,sort_keys=True,ensure_ascii=False)))}
    if not staged_ok:return Revision2PromotionResult("PARTIAL_BLOCKED","STAGING",("STAGING_FAILED",),human,human_hash,hashes,revalidation,asdict(current_budget),preview,equivalence,compile_report,staging_manifest,{"status":"NOT_RUN"},{"commit_attempted":False,"commit_succeeded":False,"rollback":True,"formal_before":fb,"formal_after":len(formal_registry),"runtime_before":rb,"runtime_after":len(runtime_registry)},None,None,0,True)
    smoke=run_revision_2_smoke(definition);smoke_ok=smoke_gate(smoke) if smoke_gate else smoke["status"]=="PASS";smoke["status"]="PASS" if smoke_ok else "FAIL"
    if not smoke_ok:return Revision2PromotionResult("PARTIAL_BLOCKED","SMOKE",("SMOKE_FAILED",),human,human_hash,hashes,revalidation,asdict(current_budget),preview,equivalence,compile_report,staging_manifest,smoke,{"commit_attempted":False,"commit_succeeded":False,"rollback":True,"formal_before":fb,"formal_after":len(formal_registry),"runtime_before":rb,"runtime_after":len(runtime_registry)},None,None,0,True)
    regression_ok=regression_gate() if regression_gate else True
    if not regression_ok:return Revision2PromotionResult("PARTIAL_BLOCKED","REGRESSION",("REGRESSION_FAILED",),human,human_hash,hashes,revalidation,asdict(current_budget),preview,equivalence,compile_report,staging_manifest,smoke,{"commit_attempted":False,"commit_succeeded":False,"rollback":True,"formal_before":fb,"formal_after":len(formal_registry),"runtime_before":rb,"runtime_after":len(runtime_registry)},None,None,0,True)
    if commit_gate and not commit_gate():return Revision2PromotionResult("PARTIAL_BLOCKED","COMMIT",("COMMIT_FAILED",),human,human_hash,hashes,revalidation,asdict(current_budget),preview,equivalence,compile_report,staging_manifest,smoke,{"commit_attempted":True,"commit_succeeded":False,"rollback":True,"formal_before":fb,"formal_after":len(formal_registry),"runtime_before":rb,"runtime_after":len(runtime_registry)},None,None,0,True)
    formal_registry.clear();formal_registry.update(staging);runtime_registry[definition.id]=definition
    manifest={"promotion_id":"promotion:"+stable_hash((definition.id,revision_hash,human_hash))[:16],"work_order":"CODEX-WO-036B2B","formal_martial_id":definition.id,"formal_display_name":definition.name,"canonical_definition_hash":stable_hash(payload),"candidate_revision_id":envelope["revision_id"],"candidate_revision_hash":revision_hash,"review_package_id":package["review_package_id"],"review_package_hash":review_hash,"human_decision_id":human.decision_id,"human_decision_hash":human_hash,"generator_version":"v0.2-prototype","acceptance_version":"v0.1-prototype","numeric_token_policy_version":"v0.1","battle_core_version":"v0.9","token_budget":{"used":106,"limit":120,"remaining":14},"compile_result":"PASS","staging_result":"PASS","smoke_result":"PASS","full_regression_result":"PASS","registry_before":fb,"registry_after":len(formal_registry),"promotion_timestamp":clock(),"authority":"HUMAN_ACCEPTED_GENERATED_CONTENT","origin":"GENERATED_CONTENT","balance_status":"FIRST_PASS_GENERATED_VALUE","final_balance_locked":False}
    transaction={"commit_attempted":True,"commit_succeeded":True,"rollback":False,"formal_before":fb,"formal_after":len(formal_registry),"runtime_before":rb,"runtime_after":len(runtime_registry),"generated_canonical_before":fb,"generated_canonical_after":len(formal_registry)}
    return Revision2PromotionResult("PASS_FIRST_GENERATED_CANONICAL_MARTIAL_PROMOTED",None,(),human,human_hash,hashes,revalidation,asdict(current_budget),preview,equivalence,compile_report,staging_manifest,smoke,transaction,manifest,definition,0,all(p.read_bytes()==source_bytes[p.name] for p in (ep,rp,hp,bp,pp)))


def write_wo036b2b_artifacts(result,directory,*,regression_total):
    root=Path(directory);root.mkdir(parents=True,exist_ok=True)
    payloads={"human_accept_revision_2.json":asdict(result.human_decision),"hash_binding_report.json":result.hash_binding,"prepromotion_revalidation.json":result.revalidation,"budget_recomputation.json":result.budget,"canonical_preview.json":result.preview,"semantic_equivalence_report.json":result.semantic_equivalence,"compile_report.json":result.compile_report,"staging_manifest.json":result.staging_manifest,"smoke_report.json":result.smoke_report,"full_regression_report.json":{"baseline":4459,"new_tests":regression_total-4459,"total":regression_total,"failures":0,"errors":0,"skipped":0,"status":"PASS"},"transaction_report.json":result.transaction_report,"promotion_result.json":{"status":result.status,"failed_gate":result.failed_gate,"blockers":result.blocker_ids}}
    if result.promotion_manifest:payloads["canonical_promotion_manifest.json"]=result.promotion_manifest;payloads["formal_generated_registry_entry.json"]={"id":result.formal_definition.id,"definition":definition_payload(result.formal_definition),"promotion_manifest_id":result.promotion_manifest["promotion_id"],"canonical":True}
    for n,v in payloads.items():(root/n).write_text(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False),encoding="utf-8")
    return root

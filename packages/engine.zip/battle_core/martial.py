from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from types import MappingProxyType
from typing import Mapping, Sequence

from .ai import ActionDefinition
from .resource import CombatResourceDefinition
from .targeting import TargetingSpec
from .trigger import SpecialActionTemplate, TriggerDefinition


class MartialValidationError(ValueError):
    pass


def _invalid(name: str, effect: str, field_name: str, problem: str):
    raise MartialValidationError(
        f"[INVALID_MARTIAL]\n武學：{name}\n效果：{effect}\n欄位：{field_name}\n問題：{problem}"
    )


@dataclass(frozen=True)
class SourceProvenance:
    source_file: str
    source_anchor: str
    source_version: str
    source_tier: str
    source_budget: int


@dataclass(frozen=True)
class MartialActiveSkillDefinition:
    id: str
    name: str
    cooldown: int
    qi_cost_percent_max: float
    targeting_pattern: str
    attack_coefficient: float
    tuning_placeholder: str | None = None
    targeting_offsets: tuple[tuple[int, int], ...] = ()
    anchor_policy: str = "ALREADY_LEGAL_PRIMARY_TARGET"
    requested_target_count: int | None = None


@dataclass(frozen=True)
class MartialPassiveDefinition:
    id: str
    name: str
    mechanic: str
    parameters: Mapping[str, object]


@dataclass(frozen=True)
class MartialRoutineDefinition:
    id: str
    name: str
    family: str
    tier: str
    budget: int
    active_skill: MartialActiveSkillDefinition
    passives: tuple[MartialPassiveDefinition, ...]
    provenance: SourceProvenance
    unresolved_fields: tuple[str, ...] = ()
    validation_information: tuple[str, ...] = ()
    weapon_requirement: str | None = None
    blocked_spec_fields: tuple[str, ...] = ()
    resource_loops: tuple[object, ...] = ()


class MartialCapabilityRegistry:
    SUPPORTED = frozenset({
        "active_physical_attack", "qi_cost_percent_max", "cooldown", "single_targeting",
        "chance_damage_multiplier", "permanent_parry_modifier", "parry_break_modifier",
        "successful_parry_trigger", "counterattack", "ordinary_special_trigger",
        "action_complete_follow_up", "special_action_chaining", "derived_coefficient",
        "owner_formal_turn_stack", "stack_attack_percent", "stack_speed_percent",
        "persistent_battle_runtime_stack",
        "active_grants_shield", "shield_percent_owner_max_hp",
        "per_attack_parry_reduction_override", "same_attack_damage_component",
        "owner_max_hp_damage_component", "permanent_dodge_modifier",
        "successful_dodge_heal", "heal_percent_owner_max_hp", "overheal_clamp",
        "vertical_column_targeting", "immediately_behind_target",
        "current_damage_defense_ignore", "after_basic_attack_trigger",
        "basic_attack_special_action", "no_target_no_retarget",
        "horizontal_row_targeting", "horizontal_neighbor_target",
        "random_occupied_horizontal_neighbor", "after_basic_attack_horizontal_neighbor",
        "active_physical_single", "derived_follow_up_coefficient",
        "after_specific_martial_active_follow_up", "same_original_target_follow_up",
        "basic_action_cooldown_reduction", "attribute_scaled_action_chance",
        "basic_attack_targeting_transformation", "roaming_random_multi_target",
        "random_distinct_enemy_selection", "owner_formal_turn_resource_gain",
        "resource_stack_speed_percent", "bounded_persistent_martial_resource",
        "basic_action_same_instance_multiplier", "next_matching_action_empowerment",
        "action_source_scaled_debuff_proc", "conditional_target_status_proc",
        "per_successful_enemy_hit_resource_gain", "basic_action_resource_threshold_proc",
        "parry_success_resource_gain", "dodge_success_resource_gain",
        "parry_resource_defense", "active_resource_consume_scaling",
        "counter_action_targeting_replacement",
        "basic_action_resource_scaled_rear_followup", "ally_attacked_trigger_adapter",
        "trigger_source_scoped_defense_ignore",
        "trigger_attempt_resource_cost", "action_unique_hit_threshold_buff",
        "active_hit_count_resource_feedback", "high_closed_loop_martial",
        "exclusive_stance_group", "stance_gated_special_trigger",
        "active_not_dodged_stance_transition", "parry_stance_counter",
        "basic_roaming_transformation_shell", "parry_counter_high_blade",
        "attack_to_dot_status_application", "status_gated_combo_trigger",
        "effective_damage_resource_gain", "attempt_paid_rear_followup",
        "attempt_paid_ally_retaliation", "special_outcome_cooldown_feedback",
        "special_commit_self_status_application", "status_gated_attempt_paid_rear_followup",
        "successful_parry_generic_special",
    })

    def require(self, martial: str, effect: str, capability: str):
        if capability not in self.SUPPORTED:
            _invalid(martial, effect, "mechanic", f"不支援的 mechanic：{capability}")


def validate_martial_definition(martial: MartialRoutineDefinition,
                                registry: MartialCapabilityRegistry | None = None):
    registry = registry or MartialCapabilityRegistry()
    active = martial.active_skill
    if type(active.cooldown) is not int or active.cooldown < 0:
        _invalid(martial.name, active.name, "cooldown", "預期非負整數")
    if (isinstance(active.qi_cost_percent_max, bool)
            or not isinstance(active.qi_cost_percent_max, (int, float))
            or not 0 <= active.qi_cost_percent_max <= 1):
        _invalid(martial.name, active.name, "qi_cost_percent_max", "預期 0 到 1")
    legal_active_patterns = ("single", "vertical_column", "row_large", "relative_footprint", "cross", "all_enemies", "roaming_distinct")
    if active.targeting_pattern not in legal_active_patterns:
        _invalid(martial.name, active.name, "targeting_pattern",
                 f"未知 targeting pattern：{active.targeting_pattern}")
    if active.targeting_pattern == "roaming_distinct":
        if type(active.requested_target_count) is not int:
            _invalid(martial.name, active.name, "requested_target_count", "roaming_distinct 必須提供正整數")
        if active.requested_target_count < 1:
            _invalid(martial.name, active.name, "requested_target_count", "roaming_distinct 必須至少為 1")
    elif active.requested_target_count is not None:
        _invalid(martial.name, active.name, "requested_target_count", "此 targeting mode 不接受 requested_target_count")
    registry.require(martial.name, active.name, "active_physical_attack")
    for passive in martial.passives:
        registry.require(martial.name, passive.name, passive.mechanic)
    if martial.resource_loops:
        from .resource_loop_formal import validate_resource_loop
        for loop in martial.resource_loops: validate_resource_loop(loop)
        resource_ids=[resource.id for loop in martial.resource_loops for resource in loop.resources]
        if len(resource_ids)!=len(set(resource_ids)):
            _invalid(martial.name,"resource_loops","resource_id","Composite loadout resource namespace collision")
    if martial.unresolved_fields:
        _invalid(martial.name, "routine", "unresolved_fields",
                 "不支援且沒有明確 fallback 的 unresolved mechanic")
    return martial


def _unquote(value: str) -> str:
    value = value.strip()
    return value[1:-1] if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'" else value


def extract_anchor(source_text: str, anchor_name: str) -> dict:
    """Extract only anchor_routines; generation/pricing sections never enter runtime."""
    lines = source_text.splitlines()
    in_anchors = False
    anchors: list[dict] = []
    current = None
    section = None
    version = "unknown"
    source_family = None
    source_document_name = None
    for line in lines:
        if line.startswith("schema_version:"):
            version = _unquote(line.split(":", 1)[1])
        if line.startswith("name:"):
            source_document_name = _unquote(line.split(":", 1)[1])
        if re.match(r"  weapon_type:\s*", line):
            source_family = _unquote(line.split(":", 1)[1])
        if line == "anchor_routines:":
            in_anchors = True
            continue
        if in_anchors and line and not line.startswith(" "):
            break
        if not in_anchors:
            continue
        m = re.match(r'  - name:\s*(.+)$', line)
        if m:
            if current:
                anchors.append(current)
            current = {"name": _unquote(m.group(1)), "confirmed_mechanics": [],
                       "assistant_first_pass_values": {}, "unresolved_values": [],
                       "source_version": version,
                       "source_family": source_family or ((source_document_name or "")[:2] or None)}
            section = None
            continue
        if current is None:
            continue
        m = re.match(r'    (tier|budget|role):\s*(.+)$', line)
        if m:
            value = _unquote(m.group(2))
            current[m.group(1)] = int(value) if m.group(1) == "budget" and value.isdigit() else value
            continue
        m = re.match(r'    (confirmed_mechanics|assistant_first_pass_values|unresolved_values):\s*$', line)
        if m:
            section = m.group(1)
            continue
        if re.match(r"    [a-zA-Z_][a-zA-Z0-9_]*:\s*$", line):
            section = None
            continue
        if section in ("confirmed_mechanics", "unresolved_values"):
            m = re.match(r'      -\s*(.+)$', line)
            if m:
                current[section].append(_unquote(m.group(1)))
        elif section == "assistant_first_pass_values":
            m = re.match(r'      ([a-zA-Z0-9_]+):\s*(.+)$', line)
            if m:
                try:
                    current[section][m.group(1)] = float(m.group(2))
                except ValueError:
                    current[section][m.group(1)] = _unquote(m.group(2))
    if current:
        anchors.append(current)
    found = next((a for a in anchors if a.get("name") == anchor_name), None)
    if found is None and "\nanchors:\n" in "\n" + source_text:
        anchor_lines = source_text.splitlines()
        start = next((i for i, line in enumerate(anchor_lines)
                      if re.match(r'(?:  )?- id:\s*.+$', line)
                      and i > next((j for j,l in enumerate(anchor_lines) if l == "anchors:"), len(anchor_lines))), None)
        while start is not None:
            end = next((i for i in range(start + 1, len(anchor_lines))
                        if re.match(r'(?:  )?- id:', anchor_lines[i])), len(anchor_lines))
            block = "\n".join(anchor_lines[start:end])
            name_match = re.search(r'^\s{2,4}name_zh:\s*["\']?([^"\'\n]+)', block, re.M)
            if name_match and name_match.group(1).strip() == anchor_name:
                def field(pattern, default=None, cast=str):
                    match = re.search(pattern, block, re.M)
                    return default if not match else cast(match.group(1).strip().strip("\"'"))
                passive_names = re.findall(r'^\s{2,6}- name_zh:\s*["\']?([^"\'\n]+)', block, re.M)
                found = {"id": field(r'^(?:  )?- id:\s*(.+)$'), "name": anchor_name,
                         "tier": field(r'^\s{2,4}tier:\s*(.+)$'),
                         "budget": field(r'^\s{2,4}budget:\s*(\d+)', cast=int),
                         "source_family": field(r'^\s{2,4}family:\s*(.+)$'),
                         "source_version": version, "structured_anchor": block,
                         "passive_names": passive_names, "confirmed_mechanics": []}
                break
            start = end if end < len(anchor_lines) else None
    if found is None:
        _invalid(anchor_name, "anchor", "name", "找不到 martial anchor")
    return found


def compile_anchor(anchor: Mapping[str, object], source_file: str,
                   registry: MartialCapabilityRegistry | None = None,
                   tuning_overrides: Mapping[str, float] | None = None) -> MartialRoutineDefinition:
    registry = registry or MartialCapabilityRegistry()
    name = str(anchor.get("name") or "")
    if not name:
        _invalid("<unknown>", "anchor", "name", "缺少必要欄位")
    tier = anchor.get("tier")
    if not isinstance(tier, str) or not tier:
        _invalid(name, "anchor", "tier", "缺少必要欄位")
    budget = anchor.get("budget")
    if type(budget) is not int or budget < 0:
        _invalid(name, "anchor", "budget", "預期非負整數")
    mechanics = anchor.get("confirmed_mechanics")
    if not isinstance(mechanics, Sequence) or isinstance(mechanics, (str, bytes)):
        _invalid(name, "anchor", "confirmed_mechanics", "預期效果陣列")
    parsed = {}
    for text in mechanics:
        if not isinstance(text, str) or "：" not in text:
            _invalid(name, "anchor", "confirmed_mechanics", f"無法解析：{text}")
        label = text.split("：", 1)[0]
        if label in parsed:
            _invalid(name, label, "id", "duplicate effect ID")
        parsed[label] = text
    if anchor.get("structured_anchor"):
        return _compile_structured_anchor(anchor, source_file, registry, tuning_overrides)
    if name == "風雷刀法":
        required = {"快刃", "刀勁", "風行刀勢", "雷霆刀式", "破防", "風雨雷電"}
        if set(parsed) != required:
            _invalid(name, "anchor", "mechanics", f"缺少={sorted(required-set(parsed))} 未知={sorted(set(parsed)-required)}")
        first_pass = anchor.get("assistant_first_pass_values", {})
        coefficient = first_pass.get("active_attack_coefficient") if isinstance(first_pass, Mapping) else None
        if not isinstance(coefficient, (int, float)):
            _invalid(name, "快刃", "attack_coefficient", "缺 assistant_first_pass active coefficient")
        martial_id = "blade_advanced_fenglei"
        active = MartialActiveSkillDefinition(
            f"{martial_id}.kuairen", "快刃", 8, .25, "single", float(coefficient),
            "TUNING_PLACEHOLDER source=assistant_first_pass_values.active_attack_coefficient status=not_final")
        params = (
            ("blade_force", "刀勁", "basic_action_same_instance_multiplier",
             {"base_chance": 0.0, "attribute":"agility", "per_point":.001, "damage_multiplier":1.30}),
            ("fengxing", "風行刀勢", "next_matching_action_empowerment",
             {"base_chance":.12, "attribute":"constitution", "per_point":.002,
              "matching_action_id":active.id, "damage_multiplier":1.30, "stack_policy":"unique"}),
            ("leiting", "雷霆刀式", "action_source_scaled_debuff_proc",
             {"base_chance":.10, "attribute":"constitution", "per_point":.001,
              "active_source_multiplier":2.0, "status_id":f"martial:{martial_id}:defense_break",
              "application_gate":"ATTACK_INSTANCE_NOT_DODGED"}),
            ("storm", "風雨雷電", "conditional_target_status_proc",
             {"chance":.25, "required_status_id":f"martial:{martial_id}:defense_break",
              "status_id":f"martial:{martial_id}:bleed",
              "condition_snapshot":"ATTACK_INSTANCE_ELIGIBILITY_START",
              "allow_same_attack_new_status":False}),
        )
        passives=tuple(MartialPassiveDefinition(f"{martial_id}.{pid}",zh,mechanic,MappingProxyType(values)) for pid,zh,mechanic,values in params)
        fixtures=tuning_overrides or {}
        fixture_info=[]
        for key in ("defense_break_duration","bleed_duration","bleed_damage_per_tick"):
            if key in fixtures: fixture_info.append(f"TEST_FIXTURE {key}={fixtures[key]}")
        provenance=SourceProvenance(source_file,name,str(anchor.get("source_version","unknown")),str(tier),int(budget))
        martial=MartialRoutineDefinition(martial_id,name,"刀法",str(tier),int(budget),active,passives,
            provenance,(),tuple(["validated",*fixture_info]),None,(
                "defense_break_duration","bleed_duration","bleed_damage_per_tick"))
        return validate_martial_definition(martial,registry)
    if name == "雷火劍法":
        required = {"天雷劍", "天火劍", "天雷鍛體", "天火雷電", "天雷劍勢"}
        if set(parsed) != required:
            missing, unknown = required-set(parsed), set(parsed)-required
            _invalid(name, "anchor", "mechanics", f"缺少={sorted(missing)} 未知={sorted(unknown)}")
        if not re.search(r"天雷劍：15調息、25%內力", parsed["天雷劍"]):
            _invalid(name, "天雷劍", "cooldown/qi_cost", "anchor 值無法唯一編譯")
        coefficient = (tuning_overrides or {}).get("active_attack_coefficient")
        if not isinstance(coefficient, (int, float)) or coefficient <= 0:
            _invalid(name, "天雷劍", "attack_coefficient",
                     "來源為 TBD；必須注入 TEST_TUNING_PLACEHOLDER active_attack_coefficient")
        martial_id = "sword_advanced_leihuo"
        active = MartialActiveSkillDefinition(
            f"{martial_id}.tianlei_sword", "天雷劍", 15, .25, "single", float(coefficient),
            "TEST_TUNING_PLACEHOLDER source=TBD injected=active_attack_coefficient")
        params = (
            ("tianhuo_sword", "天火劍", "after_specific_martial_active_follow_up",
             {"source_action_id": active.id, "base_chance": .25, "coefficient_ratio": .80}),
            ("tianlei_body", "天雷鍛體", "basic_action_cooldown_reduction",
             {"base_chance": .30, "attribute": "agility", "per_point": .003,
              "cooldown_id": active.id, "reduction": 1}),
            ("tianhuo_lightning", "天火雷電", "basic_attack_targeting_transformation",
             {"base_chance": .30, "attribute": "agility", "per_point": .001,
              "target_count": 2, "selection": "random_distinct_enemies"}),
            ("tianlei_intent", "天雷劍勢", "owner_formal_turn_resource_gain",
             {"resource_id": f"martial:{martial_id}:tianlei_sword_intent", "gain": 1,
              "max_stacks": 5, "speed_percent_per_stack": .02}),
        )
        passives = tuple(MartialPassiveDefinition(f"{martial_id}.{pid}", zh, mechanic,
                         MappingProxyType(values)) for pid, zh, mechanic, values in params)
        provenance = SourceProvenance(source_file, name, str(anchor.get("source_version", "unknown")),
                                      str(tier), int(budget))
        martial = MartialRoutineDefinition(martial_id, name, "劍法", str(tier), int(budget), active,
                                           passives, provenance, (), ("validated",))
        return validate_martial_definition(martial, registry)
    blade_required = {"砍擊", "劈擊", "招架", "反擊", "心眼"}
    sword_required = {"刺擊", "砍擊", "挑擊", "淨心", "守勢"}
    source_family = str(anchor.get("source_family") or "")
    if not source_family:
        labels = set(parsed)
        if labels.intersection({"劈擊", "招架", "反擊", "心眼"}):
            source_family = "刀法"
        elif labels.intersection({"刺擊", "挑擊", "淨心", "守勢"}):
            source_family = "劍法"
    if source_family == "刀法":
        required = blade_required
    elif source_family == "劍法":
        required = sword_required
    else:
        _invalid(name, "anchor", "family", f"未知 weapon family：{source_family or '<missing>'}")
    unknown = set(parsed) - required
    if unknown:
        _invalid(name, sorted(unknown)[0], "mechanic", "未知 passive mechanic")
    missing = required - set(parsed)
    active_label = "砍擊" if required == blade_required else "刺擊"
    if active_label in missing:
        _invalid(name, "active", "active", "缺 active")
    if missing:
        _invalid(name, sorted(missing)[0], "passives", "缺少必要 passive")
    family = source_family
    if required == blade_required:
        if not re.search(r"砍擊：8調息、10%內力", parsed["砍擊"]):
            _invalid(name, "砍擊", "cooldown/qi_cost", "anchor 值無法唯一編譯")
        first_pass = anchor.get("assistant_first_pass_values", {})
        coefficient = first_pass.get("active_attack_coefficient") if isinstance(first_pass, Mapping) else None
        if not isinstance(coefficient, (int, float)):
            _invalid(name, "砍擊", "attack_coefficient", "runtime 所需值 TBD 且沒有合法 tuning placeholder")
        martial_id, family = "yang_family_blade", family or "刀法"
        active = MartialActiveSkillDefinition(
            f"{martial_id}.slash", "砍擊", 8, .10, "single", float(coefficient),
            "TUNING_PLACEHOLDER source=assistant_first_pass_values.active_attack_coefficient")
        params = (
            ("cleave", "劈擊", "chance_damage_multiplier", {"base_chance": .05, "attribute": "agility", "per_point": .002, "multiplier": 1.4, "eligible_tags": ("basic_attack", "martial_active")}),
            ("parry", "招架", "permanent_parry_modifier", {"attribute": "constitution", "per_point": .002}),
            ("counter", "反擊", "successful_parry_trigger", {"probability": .30, "coefficient": .50, "classification": "ordinary_special"}),
            ("mind_eye", "心眼", "parry_break_modifier", {"additive_percentage_points": .10}),
        )
    else:
        if not re.search(r"刺擊：10調息、10%內力", parsed["刺擊"]):
            _invalid(name, "刺擊", "cooldown/qi_cost", "anchor 值無法唯一編譯")
        coefficient = (tuning_overrides or {}).get("active_attack_coefficient")
        if not isinstance(coefficient, (int, float)) or coefficient <= 0:
            _invalid(name, "刺擊", "attack_coefficient",
                     "來源為 TBD；必須注入 TEST_TUNING_PLACEHOLDER active_attack_coefficient")
        martial_id, family = "basic_sword", family or "劍法"
        active = MartialActiveSkillDefinition(
            f"{martial_id}.thrust", "刺擊", 10, .10, "single", float(coefficient),
            "TEST_TUNING_PLACEHOLDER source=TBD injected=active_attack_coefficient")
        params = (
            ("slash_combo", "砍擊", "action_complete_follow_up", {"source_action_id": f"{martial_id}.thrust", "base_chance": .30, "attribute": "agility", "per_point": .001, "coefficient_ratio": .30}),
            ("lift_combo", "挑擊", "action_complete_follow_up", {"source_action_id": f"{martial_id}.slash_combo.action", "base_chance": .30, "attribute": "agility", "per_point": .001, "coefficient_ratio": .40}),
            ("calm", "淨心", "owner_formal_turn_stack", {"resource_id": f"{martial_id}.calm", "max_stacks": 5, "attack_percent_per_stack": .01, "speed_percent_per_stack": .01}),
            ("guard", "守勢", "successful_parry_trigger", {"probability": .30, "coefficient": 1.00, "classification": "ordinary_special"}),
        )
    passives = tuple(MartialPassiveDefinition(f"{martial_id}.{pid}", zh, mechanic,
                     MappingProxyType(values)) for pid, zh, mechanic, values in params)
    provenance = SourceProvenance(source_file, name, str(anchor.get("source_version", "unknown")), tier, budget)
    martial = MartialRoutineDefinition(martial_id, name, family, tier, budget, active,
                                       passives, provenance, tuple(anchor.get("unresolved_values", ())),
                                       ("validated",))
    return validate_martial_definition(martial, registry)


def _compile_structured_anchor(anchor, source_file, registry, tuning_overrides):
    name, block = str(anchor["name"]), str(anchor["structured_anchor"])
    if str(anchor.get("id")) == "blade_high_xuezhan_sanshi":
      mid="blade_high_xuezhan_sanshi";fx=tuning_overrides or {};wid=f"martial:{mid}:wound"
      active=MartialActiveSkillDefinition(f"{mid}.slash","砍擊",9,.30,"single",1.20,"CONFIRMED_ANCHOR_VALUE final_balance_locked=false")
      params=(
       ("fast_blade","快刀術","basic_roaming_transformation_shell",{"base_chance":fx.get("kuaidaoshu_trigger_chance","CONTENT_TBD:kuaidaoshu_trigger_chance"),"target_count":fx.get("kuaidaoshu_roaming_target_count","CONTENT_TBD:kuaidaoshu_roaming_target_count"),"test_fixture":all(k in fx for k in ("kuaidaoshu_trigger_chance","kuaidaoshu_roaming_target_count"))}),
       ("returning_blade","返刃","parry_counter_high_blade",{"base_chance":.12,"attribute":"agility","per_point":.001,"coefficient":fx.get("fanren_counter_coefficient","CONTENT_TBD:fanren_counter_damage_profile"),"test_fixture":"fanren_counter_coefficient" in fx}),
       ("laceration","裂傷","attack_to_dot_status_application",{"base_chance":.20,"attribute":"strength","per_point":.0012,"status_id":wid,"duration":3,"tick_current_hp_percent":.005,"damage_class":"special_damage","trigger_scope":"ATTACK_SCOPE","eligibility_basis":"ATTACK_INSTANCE_SUCCESSFULLY_HIT","source_category":"ANY_ATTACK_INSTANCE_OWNED_BY_THIS_MARTIAL_OWNER","stacking_policy":fx.get("wound_reapplication_policy","CONTENT_TBD:wound_reapplication_policy"),"tick_timing":fx.get("wound_tick_timing","CONTENT_TBD:wound_tick_timing"),"test_fixture":all(k in fx for k in ("wound_reapplication_policy","wound_tick_timing"))}),
       ("flowing_combo","行雲流水","status_gated_combo_trigger",{"source_action_id":active.id,"required_status_id":wid,"base_chance":.30,"attribute":"inner_breath","per_point":.002,"followup_coefficient":fx.get("xingyun_followup_coefficient","CONTENT_TBD:xingyun_liushui_followup_content"),"action_class":"ordinary_special","test_fixture":"xingyun_followup_coefficient" in fx}),)
      ps=tuple(MartialPassiveDefinition(f"{mid}.{i}",n,m,MappingProxyType(v)) for i,n,m,v in params)
      info=["validated","high_status_driven_closed_loop",*[f"SOURCE_CONTENT_TBD {x}" for x in ("kuaidaoshu_trigger_chance","kuaidaoshu_roaming_target_count","fanren_counter_damage_profile","wound_reapplication_policy","wound_tick_timing","xingyun_liushui_followup_content")]]
      info += [f"TEST_FIXTURE {k}={v} test_only=true not_canonical=true" for k,v in fx.items()]
      prov=SourceProvenance(source_file,name,str(anchor.get("source_version","unknown")),str(anchor["tier"]),int(anchor["budget"]))
      return validate_martial_definition(MartialRoutineDefinition(mid,name,str(anchor["source_family"]),str(anchor["tier"]),int(anchor["budget"]),active,ps,prov,(),tuple(info),None,()),registry)
    if str(anchor.get("id")) == "spear_high_lianying_pojun":
      mid="spear_high_lianying_pojun";fx=tuning_overrides or {};coeff=fx.get("active_attack_coefficient")
      if not isinstance(coeff,(int,float)) or coeff<=0:_invalid(name,"破軍連營","attack_coefficient","TOKEN_BALANCE_TBD；必須注入 TEST_TUNING_PLACEHOLDER active_attack_coefficient")
      rid=f"martial:{mid}:sha_shi";active=MartialActiveSkillDefinition(f"{mid}.formation_breaker","破軍連營",11,.30,"vertical_column",float(coeff),"TEST_TUNING_PLACEHOLDER source=TOKEN_BALANCE_TBD test_only=true not_canonical=true")
      rear=f"{mid}.rear_pursuit";guard=f"{mid}.army_guard_return"
      params=(("kill_formation","殺陣槍勢","effective_damage_resource_gain",{"resource_id":rid,"max_stacks":5,"attack_percent_per_stack":.02,"scope":"ATTACK_SCOPE","basis":"EFFECTIVE_ATTACK_DAMAGE"}),("rear_pursuit","逐陣追鋒","attempt_paid_rear_followup",{"resource_id":rid,"condition_min":2,"cost":2,"cost_timing":"ON_TRIGGER_ATTEMPT_AFTER_CONDITION","base_chance":.40,"attribute":"agility","per_point":.002,"target_selector":"immediately_behind_event_target","coefficient":1.0}),("army_guard_return","護軍回龍","attempt_paid_ally_retaliation",{"resource_id":rid,"condition_min":1,"cost":1,"cost_timing":"ON_TRIGGER_ATTEMPT_AFTER_CONDITION","base_chance":.35,"attribute":"strength","per_point":.001,"target_selector":"event_attacker","coefficient":1.0,"semantic":"OTHER_ALLY_TARGETED_BY_ENEMY_ATTACK_INSTANCE"}),("ceaseless_spear","槍行無歇","special_outcome_cooldown_feedback",{"source_trigger_ids":(rear,guard),"cooldown_id":active.id,"reduction":1,"predicate":"ACTION_SUCCESSFULLY_DEALS_DAMAGE","successfully_deals_damage_basis":"ActionOutcomeSummary.dealt_effective_attack_damage","resolution":"RESOLVED_BY_WO_027A"}))
      ps=tuple(MartialPassiveDefinition(f"{mid}.{i}",n,m,MappingProxyType(v)) for i,n,m,v in params);info=["validated","high_spear_closed_kill_momentum_loop"]+[f"TEST_FIXTURE {k}={v} test_only=true not_canonical=true" for k,v in fx.items()];prov=SourceProvenance(source_file,name,str(anchor.get("source_version","unknown")),str(anchor["tier"]),int(anchor["budget"]))
      return validate_martial_definition(MartialRoutineDefinition(mid,name,str(anchor["source_family"]),str(anchor["tier"]),int(anchor["budget"]),active,ps,prov,(),tuple(info),None,()),registry)
    if str(anchor.get("id")) == "sword_high_sixiang_jianjue":
      mid="sword_high_sixiang_jianjue";group=f"martial:{mid}:four_image_stance"
      active=MartialActiveSkillDefinition(f"{mid}.four_image_sword","四像劍",10,.35,"single",1.15,
        "CONFIRMED_FIRST_PASS first_pass_balance_value=true final_simulator_locked=false")
      stances={x:f"martial:{mid}:stance:{x}" for x in ("qinglong","baihu","zhuque","xuanwu")}
      params=(
       ("qinglong","青龍勢","stance_gated_special_trigger",{"stance_group_id":group,"stance_id":stances["qinglong"],"initial":True,"speed_percent":.08,"event":"ACTION_COMPLETE","source":"basic_attack","base_chance":.35,"attribute":"agility","per_point":.002,"coefficient_ratio":.50,"to_stance":stances["baihu"]}),
       ("baihu","白虎勢","active_not_dodged_stance_transition",{"stance_group_id":group,"stance_id":stances["baihu"],"dodge_break_pp":.15,"source_action_id":active.id,"to_stance":stances["zhuque"]}),
       ("zhuque","朱雀勢","stance_gated_special_trigger",{"stance_group_id":group,"stance_id":stances["zhuque"],"attack_percent":.10,"event":"ACTION_COMPLETE","source_scope":"MAIN_AND_ORDINARY_ATTACK_ACTIONS","base_chance":.45,"attribute":"agility","per_point":.001,"coefficient_ratio":.80,"to_stance":stances["xuanwu"]}),
       ("xuanwu","玄武勢","parry_stance_counter",{"stance_group_id":group,"stance_id":stances["xuanwu"],"parry_bonus_pp":.15,"probability":.50,"coefficient":1.0,"cooldown_id":active.id,"cooldown_reduction":2,"to_stance":stances["qinglong"],"fallback":"NEXT_OWNER_FORMAL_TURN_END_AFTER_ENTRY"}),)
      ps=tuple(MartialPassiveDefinition(f"{mid}.{i}",n,m,MappingProxyType(v)) for i,n,m,v in params)
      prov=SourceProvenance(source_file,name,str(anchor.get("source_version","unknown")),str(anchor["tier"]),int(anchor["budget"]))
      return validate_martial_definition(MartialRoutineDefinition(mid,name,str(anchor["source_family"]),str(anchor["tier"]),int(anchor["budget"]),active,ps,prov,(),("validated","high_closed_stance_cycle"),None,()),registry)
    if str(anchor.get("id")) == "staff_high_bafang_zhenyue":
      coefficient=(tuning_overrides or {}).get("active_attack_coefficient")
      if not isinstance(coefficient,(int,float)) or coefficient<=0:_invalid(name,"鎮嶽掃八方","attack_coefficient","TOKEN_BALANCE_TBD；必須注入 TEST_TUNING_PLACEHOLDER active_attack_coefficient")
      mid="staff_high_bafang_zhenyue";rid=f"martial:{mid}:zhen_shi";counter=f"{mid}.river_counter"
      active=MartialActiveSkillDefinition(f"{mid}.zhenyue_cross_sweep","鎮嶽掃八方",11,.30,"cross",float(coefficient),"TEST_TUNING_PLACEHOLDER source=TOKEN_BALANCE_TBD test_only=true not_canonical=true")
      params=(("immovable_momentum","不動棍勢","parry_resource_defense",{"resource_id":rid,"max_stacks":5,"defense_percent_per_stack":.02,"gain":1}),
       ("river_counter","橫江反岳","trigger_attempt_resource_cost",{"resource_id":rid,"condition_min":2,"cost":2,"cost_timing":"ON_TRIGGER_ATTEMPT_AFTER_CONDITION","probability":.50,"targeting_pattern":"row_large"}),
       ("iron_wall_loop","鐵壁回環","action_unique_hit_threshold_buff",{"source_trigger_id":counter,"threshold":2,"status_id":f"martial:{mid}:tiebi","duration":2,"stacking_policy":"refresh","parry_bonus_pp":.10,"defense_percent":.10}),
       ("mountain_feedback","岳鎮八荒","active_hit_count_resource_feedback",{"source_action_id":active.id,"required_status_id":f"martial:{mid}:tiebi","resource_id":rid,"divisor":2,"rounding":"floor","max_stacks":5}))
      ps=tuple(MartialPassiveDefinition(f"{mid}.{i}",n,m,MappingProxyType(v)) for i,n,m,v in params);info=["validated"]
      prov=SourceProvenance(source_file,name,str(anchor.get("source_version","unknown")),str(anchor["tier"]),int(anchor["budget"]))
      return validate_martial_definition(MartialRoutineDefinition(mid,name,str(anchor["source_family"]),str(anchor["tier"]),int(anchor["budget"]),active,ps,prov,(),tuple(info),None,()),registry)
    if str(anchor.get("id")) == "spear_advanced_zhuifeng_pozhen":
      coefficient=(tuning_overrides or {}).get("active_attack_coefficient")
      if not isinstance(coefficient,(int,float)) or coefficient<=0:
        _invalid(name,"穿雲破陣","attack_coefficient","TOKEN_BALANCE_TBD；必須注入 TEST_TUNING_PLACEHOLDER active_attack_coefficient")
      martial_id="spear_advanced_zhuifeng_pozhen";rid=f"martial:{martial_id}:spear_momentum"
      active=MartialActiveSkillDefinition(f"{martial_id}.cloud_piercing_formation","穿雲破陣",10,.25,"vertical_column",float(coefficient),"TEST_TUNING_PLACEHOLDER source=TOKEN_BALANCE_TBD test_only=true not_canonical=true")
      params=(
       ("formation_momentum","破陣槍勢","per_successful_enemy_hit_resource_gain",{"resource_id":rid,"max_stacks":3,"attack_percent_per_stack":.03,"source_action_id":active.id}),
       ("momentum_rear_pursuit","乘勢追鋒","basic_action_resource_scaled_rear_followup",{"resource_id":rid,"chance_per_stack":.25,"target_selector":"immediately_behind_event_target","consume_all_on_success":True,"classification":"ordinary_special"}),
       ("formation_aid_return","援陣回鋒","ally_attacked_trigger_adapter",{"probability":.30,"target_selector":"event_attacker","semantic":"OTHER_ALLY_TARGETED_BY_ENEMY_ATTACK_INSTANCE","event_basis":"ALLY_TARGETED_BY_ATTACK_INSTANCE","scope":"ATTACK","self_excluded":True,"resolution":"RESOLVED_BY_WO_021A"}),
       ("armor_crushing_pursuit","摧甲追命","trigger_source_scoped_defense_ignore",{"trigger_source_ids":(f"{martial_id}.momentum_rear_pursuit",f"{martial_id}.formation_aid_return"),"defense_ignore_percent":.20}),)
      passives=tuple(MartialPassiveDefinition(f"{martial_id}.{pid}",zh,m,MappingProxyType(v)) for pid,zh,m,v in params)
      info=["validated"]
      provenance=SourceProvenance(source_file,name,str(anchor.get("source_version","unknown")),str(anchor["tier"]),int(anchor["budget"]))
      martial=MartialRoutineDefinition(martial_id,name,str(anchor["source_family"]),str(anchor["tier"]),int(anchor["budget"]),active,passives,provenance,(),tuple(info),None,())
      return validate_martial_definition(martial,registry)
    if str(anchor.get("id")) == "staff_advanced_panlong_shoushi":
      coefficient=(tuning_overrides or {}).get("active_attack_coefficient")
      if not isinstance(coefficient,(int,float)) or coefficient<=0:
        _invalid(name,"盤龍掃陣","attack_coefficient","TOKEN_BALANCE_TBD；必須注入 TEST_TUNING_PLACEHOLDER active_attack_coefficient")
      martial_id="staff_advanced_panlong_shoushi";resource_id=f"martial:{martial_id}:staff_momentum"
      active=MartialActiveSkillDefinition(f"{martial_id}.panlong_sweep","盤龍掃陣",9,.25,"row_large",float(coefficient),"TEST_TUNING_PLACEHOLDER source=TOKEN_BALANCE_TBD test_only=true not_canonical=true")
      params=(
       ("center_guard_charge","守中蓄勢","parry_resource_defense",{"resource_id":resource_id,"max_stacks":3,"defense_percent_per_stack":.02,"gain":1}),
       ("borrow_force_open_mountain","借勢開山","active_resource_consume_scaling",{"resource_id":resource_id,"matching_action_id":active.id,"damage_percent_per_stack":.20,"transform_at_stacks":3,"targeting_before":"row_large","targeting_after":"cross","anchor_policy":"ALREADY_LEGAL_PRIMARY_TARGET","cross_anchor_target_legality":"RESOLVED_BY_WO_020A"}),
       ("returning_staff_guard","迴棍護身","successful_parry_trigger",{"probability":.30,"coefficient":1.0,"classification":"ordinary_special"}),
       ("panlong_cross_river","盤龍橫江","counter_action_targeting_replacement",{"source_trigger_id":f"{martial_id}.returning_staff_guard","probability":.50,"pattern_before":"single_attacker","pattern_after":"small_horizontal_sweep"}),)
      passives=tuple(MartialPassiveDefinition(f"{martial_id}.{pid}",zh,m,MappingProxyType(v)) for pid,zh,m,v in params)
      info=["validated"]
      provenance=SourceProvenance(source_file,name,str(anchor.get("source_version","unknown")),str(anchor["tier"]),int(anchor["budget"]))
      martial=MartialRoutineDefinition(martial_id,name,str(anchor["source_family"]),str(anchor["tier"]),int(anchor["budget"]),active,passives,provenance,(),tuple(info),None,())
      return validate_martial_definition(martial,registry)
    if str(anchor.get("id")) == "fist_advanced_yiqi_hexing":
      coefficient=(tuning_overrides or {}).get("active_attack_coefficient")
      if not isinstance(coefficient,(int,float)) or coefficient<=0:
        _invalid(name,"拳足並進","attack_coefficient","TOKEN_BALANCE_TBD；必須注入 TEST_TUNING_PLACEHOLDER active_attack_coefficient")
      martial_id="fist_advanced_yiqi_hexing"
      active=MartialActiveSkillDefinition(f"{martial_id}.fist_and_kick","拳足並進",9,.20,"relative_footprint",float(coefficient),"TEST_TUNING_PLACEHOLDER source=TOKEN_BALANCE_TBD test_only not_canonical",((0,0),(-1,1),(0,1),(1,1)))
      yiqi=f"martial:{martial_id}:yiqi";yixing=f"martial:{martial_id}:yixing";stance=f"martial:{martial_id}:stance"
      params=(
       ("yiqi_follow","意氣相隨","per_successful_enemy_hit_resource_gain",{"resource_id":yiqi,"max_stacks":5,"attack_percent_per_stack":.02,"defense_percent_per_stack":.02}),
       ("gathered_strike","聚勢一擊","basic_action_resource_threshold_proc",{"resource_id":yiqi,"chance_by_stacks":{1:.2,2:.4,3:.6,4:.8,5:1.0},"chance_policy":"FULL_LOOKUP_NO_SUCCESS_DECAY","matching_action_id":active.id,"replacement_name":"拳腳齊攻","damage_multiplier":2.0,"targeting":"single","ready_policy":"unique"}),
       ("borrowed_shift","借力移形","parry_success_resource_gain",{"resource_id":yixing,"max_stacks":2,"dodge_bonus_pp_per_stack":.05,"consume_event":"DODGE_SUCCESS"}),
       ("turning_stance","迴身架勢","dodge_success_resource_gain",{"resource_id":stance,"max_stacks":3,"parry_bonus_pp_per_stack":.05,"consume_event":"PARRY_SUCCESS"}),)
      passives=tuple(MartialPassiveDefinition(f"{martial_id}.{pid}",zh,m,MappingProxyType(v)) for pid,zh,m,v in params)
      info=["validated"]
      provenance=SourceProvenance(source_file,name,str(anchor.get("source_version","unknown")),str(anchor["tier"]),int(anchor["budget"]))
      martial=MartialRoutineDefinition(martial_id,name,str(anchor["source_family"]),str(anchor["tier"]),int(anchor["budget"]),active,passives,provenance,(),tuple(info),None,())
      return validate_martial_definition(martial,registry)
    fist_fields = ("正勢沖拳", "立樁守勢", "卸力沉肩", "沉勁透骨", "迴身養氣")
    spear_fields = ("貫陣長槍", "透甲槍勁", "長驅直入", "橫槍架勢", "回馬槍")
    staff_fields = ("橫掃門庭", "鐵橋架勢", "借力回棍", "掃堂棍", "沉身守中")
    is_fist = all(value in block for value in fist_fields)
    is_spear = all(value in block for value in spear_fields)
    is_staff = all(value in block for value in staff_fields)
    if sum((is_fist, is_spear, is_staff)) != 1:
        _invalid(name, "anchor", "mechanics",
                 "不支援、缺少或混合 structured fist mechanic / structured spear mechanic / structured staff mechanic")
    coefficient = (tuning_overrides or {}).get("active_attack_coefficient")
    if not isinstance(coefficient, (int, float)) or coefficient <= 0:
        active_name = "正勢沖拳" if is_fist else ("貫陣長槍" if is_spear else "橫掃門庭")
        _invalid(name, active_name, "attack_coefficient",
                 "TOKEN_BALANCE_TBD；必須注入 TEST_TUNING_PLACEHOLDER active_attack_coefficient")
    martial_id = str(anchor.get("id"))
    if is_fist:
      active = MartialActiveSkillDefinition(
        f"{martial_id}.straight_punch", "正勢沖拳", 8, .15, "single", float(coefficient),
        "TEST_TUNING_PLACEHOLDER source=TOKEN_BALANCE_TBD injected=active_attack_coefficient")
      params = (
        ("rooted_guard", "立樁守勢", "active_grants_shield", {"shield_percent_owner_max_hp": .20, "duration_owner_formal_turns": 1, "buff_name": "穩固"}),
        ("shoulder_release", "卸力沉肩", "per_attack_parry_reduction_override", {"base_chance": .25, "attribute": "constitution", "per_point": .0005, "normal_multiplier": .50, "success_multiplier": .40}),
        ("sinking_force", "沉勁透骨", "same_attack_damage_component", {"base_chance": .10, "attribute": "constitution", "per_point": .001, "amount_percent_owner_max_hp": .02, "eligible_tags": ("basic_attack",), "damage_inheritance": "same_as_basic_attack"}),
        ("turning_breath", "迴身養氣", "permanent_dodge_modifier", {"base_bonus_pp": .05, "attribute": "agility", "per_point": .001, "heal_percent_owner_max_hp": .02}),
      )
    elif is_spear:
      active = MartialActiveSkillDefinition(
        f"{martial_id}.formation_piercer", "貫陣長槍", 10, .20, "vertical_column", float(coefficient),
        "TEST_TUNING_PLACEHOLDER source=TOKEN_BALANCE_TBD injected=active_attack_coefficient")
      params = (
        ("armor_pierce", "透甲槍勁", "current_damage_defense_ignore", {"base_chance":.20,"attribute":"agility","per_point":.001,"defense_ignore_percent":.20,"eligible_tags":("basic_attack","martial_active")}),
        ("rear_drive", "長驅直入", "after_basic_attack_trigger", {"base_chance":.30,"attribute":"agility","per_point":.001,"target_selector":"immediately_behind_event_target","attack_coefficient":1.0}),
        ("cross_spear_stance", "橫槍架勢", "permanent_parry_modifier", {"base_bonus_pp":.15,"attribute":"strength","per_point":.001}),
        ("returning_spear", "回馬槍", "successful_parry_trigger", {"probability":.20,"coefficient":1.0,"classification":"ordinary_special"}),
      )
    else:
      active = MartialActiveSkillDefinition(
        f"{martial_id}.courtyard_sweep", "橫掃門庭", 10, .20, "row_large", float(coefficient),
        "TEST_TUNING_PLACEHOLDER source=TOKEN_BALANCE_TBD injected=active_attack_coefficient")
      params = (
        ("iron_bridge_stance", "鐵橋架勢", "permanent_parry_modifier", {"base_bonus_pp":.15,"attribute":"constitution","per_point":.001}),
        ("borrowed_force_counter", "借力回棍", "successful_parry_trigger", {"probability":.25,"coefficient":1.0,"classification":"ordinary_special"}),
        ("low_sweep", "掃堂棍", "after_basic_attack_horizontal_neighbor", {"base_chance":.20,"attribute":"strength","per_point":.001,"target_selector":"horizontal_neighbor_event_target","attack_coefficient":1.0}),
        ("centered_guard", "沉身守中", "per_attack_parry_reduction_override", {"base_chance":.25,"normal_multiplier":.50,"success_multiplier":.40}),
      )
    passives = tuple(MartialPassiveDefinition(f"{martial_id}.{pid}", zh, mechanic,
                     MappingProxyType(values)) for pid, zh, mechanic, values in params)
    provenance = SourceProvenance(source_file, name, str(anchor.get("source_version", "unknown")),
                                  str(anchor["tier"]), int(anchor["budget"]))
    martial = MartialRoutineDefinition(martial_id, name, str(anchor["source_family"]),
                                       str(anchor["tier"]), int(anchor["budget"]), active,
                                       passives, provenance, (), ("validated",))
    return validate_martial_definition(martial, registry)


def load_martial_yaml(path: str | Path, anchor_name: str = "楊家刀法",
                      tuning_overrides: Mapping[str, float] | None = None) -> MartialRoutineDefinition:
    source = Path(path)
    return compile_anchor(extract_anchor(source.read_text(encoding="utf-8-sig"), anchor_name),
                          str(source), tuning_overrides=tuning_overrides)


class MartialRuntimeManager:
    def __init__(self, engine):
        self.engine = engine
        self.definitions: dict[str, MartialRoutineDefinition] = {}
        self.equipped: dict[str, MartialRoutineDefinition] = {}
        self._shield_turn_snapshots: dict[str, tuple[str, ...]] = {}
        self._shield_sequence = 0
        self._stored_empowerments: dict[str, dict[str, float]] = {}
        self._action_multipliers: dict[str, float] = {}
        self._action_checks: set[tuple[str, str]] = set()
        self._status_definitions = {}
        self._fixture_policies = {}
        self._target_status_snapshots = {}
        self._action_definition_ids = {}
        self._action_targeting_patterns = {}
        self._active_transform_ready: dict[str, set[str]] = {}
        self._action_target_overrides: set[str] = set()
        self._replacement_decay = {}
        self._stances = {}
        self._stance_groups = {}
        self._stance_timeouts = {}
        self._owner_turn_counts = {}

    def load(self, martial: MartialRoutineDefinition):
        if martial.id in self.definitions:
            _invalid(martial.name, "routine", "id", f"duplicate martial ID：{martial.id}")
        self.definitions[martial.id] = martial

    def equip_declared(self):
        for state in self.engine.states:
            martial_id = state.definition.external_martial_id
            if martial_id is None:
                continue
            if martial_id not in self.definitions:
                _invalid(martial_id, "loadout", "martial_id", "找不到已載入 Martial Definition")
            self.equip(state.definition.id, self.definitions[martial_id])

    def equip(self, owner_id: str, martial: MartialRoutineDefinition):
        state = self.engine.state_by_id(owner_id)
        if state is None:
            raise ValueError(f"未知角色：{owner_id}")
        self.equipped[owner_id] = martial
        state.martial_id = martial.id
        self._stored_empowerments[owner_id] = {}
        self._active_transform_ready[owner_id]=set()
        self._owner_turn_counts[owner_id]=0
        fixtures = {item.split(" ",1)[1].split("=",1)[0]:item.split("=",1)[1]
                    for item in martial.validation_information if item.startswith("TEST_FIXTURE ")}
        self._fixture_policies[owner_id]=fixtures
        active = martial.active_skill
        self.engine.register_action(owner_id, ActionDefinition(
            active.id, action_priority=100, qi_cost_percent_max=active.qi_cost_percent_max,
            cooldown_id=active.id, cooldown_turns=active.cooldown,
            targeting=TargetingSpec(pattern=active.targeting_pattern,offsets=active.targeting_offsets,anchor_policy=active.anchor_policy,requested_target_count=active.requested_target_count), coefficient=active.attack_coefficient,
            source_martial_id=martial.id, attack_tags=frozenset({"martial_active"}), ai_enabled=False,
        ))
        for passive in martial.passives:
            if passive.mechanic == "successful_parry_trigger":
                self.engine.triggers.register(TriggerDefinition(
                    id=passive.id, owner_id=owner_id, event_type="PARRY_SUCCESS", scope="ATTACK_SCOPE",
                    base_probability=float(passive.parameters["probability"]), priority=100,
                    action_template=SpecialActionTemplate(
                        id=f"{passive.id}.action", kind="counterattack", target_selector="event_attacker",
                        attack_coefficient=float(passive.parameters["coefficient"]), classification="ordinary_special"),
                    condition=lambda owner, event, engine: event.get("target_id") == owner.definition.id,
                    source_martial_id=martial.id, martial_event_kind="counter"))
            elif passive.mechanic == "successful_parry_generic_special":
                from .generated_special_compiler import compile_successful_parry_special
                self.engine.triggers.register(compile_successful_parry_special(
                    passive.id, owner_id, passive.parameters,
                    source_martial_id=martial.id))
            elif passive.mechanic == "action_complete_follow_up":
                source_action = str(passive.parameters["source_action_id"])
                coefficient = active.attack_coefficient * float(passive.parameters["coefficient_ratio"])
                self.engine.triggers.register(TriggerDefinition(
                    id=passive.id, owner_id=owner_id, event_type="ACTION_COMPLETE", scope="ACTION_SCOPE",
                    base_probability=float(passive.parameters["base_chance"]), priority=100,
                    probability_resolver=lambda owner, engine, p=passive: (
                        float(p.parameters["base_chance"])
                        + getattr(owner.definition, p.parameters["attribute"])
                        * float(p.parameters["per_point"])),
                    action_template=SpecialActionTemplate(
                        id=f"{passive.id}.action", kind="follow_up", target_selector="event_target",
                        attack_coefficient=coefficient, classification="ordinary_special"),
                    condition=lambda owner, event, engine, expected=source_action: (
                        event.get("actor_id") == owner.definition.id
                        and event.get("source_action_definition_id") == expected),
                    source_martial_id=martial.id, martial_event_kind="combo"))
            elif passive.mechanic == "after_specific_martial_active_follow_up":
                source_action = str(passive.parameters["source_action_id"])
                self.engine.triggers.register(TriggerDefinition(
                    id=passive.id, owner_id=owner_id, event_type="ACTION_COMPLETE", scope="ACTION_SCOPE",
                    base_probability=float(passive.parameters["base_chance"]), priority=100,
                    action_template=SpecialActionTemplate(
                        id=f"{passive.id}.action", kind="follow_up", target_selector="event_target",
                        attack_coefficient=active.attack_coefficient * float(passive.parameters["coefficient_ratio"]),
                        classification="ordinary_special"),
                    condition=lambda owner, event, engine, expected=source_action: (
                        event.get("actor_id") == owner.definition.id
                        and event.get("source_action_definition_id") == expected),
                    source_martial_id=martial.id, martial_event_kind="follow_up"))
            elif passive.mechanic == "after_basic_attack_trigger":
                self.engine.triggers.register(TriggerDefinition(
                    id=passive.id,owner_id=owner_id,event_type="ACTION_COMPLETE",scope="ACTION_SCOPE",
                    base_probability=float(passive.parameters["base_chance"]),priority=100,
                    probability_resolver=lambda owner,engine,p=passive: float(p.parameters["base_chance"])+getattr(owner.definition,p.parameters["attribute"])*float(p.parameters["per_point"]),
                    action_template=SpecialActionTemplate(id=f"{passive.id}.action",kind="follow_up",target_selector="immediately_behind_event_target",attack_coefficient=float(passive.parameters["attack_coefficient"]),classification="ordinary_special",attack_tags=frozenset({"special_action","basic_attack"})),
                    condition=lambda owner,event,engine: event.get("actor_id")==owner.definition.id and event.get("source_action_definition_id")=="basic_attack" and engine._rear_adjacent(event,True) is not None,
                    source_martial_id=martial.id,martial_event_kind="rear_follow_up"))
            elif passive.mechanic == "after_basic_attack_horizontal_neighbor":
                self.engine.triggers.register(TriggerDefinition(
                    id=passive.id, owner_id=owner_id, event_type="ACTION_COMPLETE", scope="ACTION_SCOPE",
                    base_probability=float(passive.parameters["base_chance"]), priority=100,
                    probability_resolver=lambda owner, engine, p=passive: (
                        float(p.parameters["base_chance"])
                        + getattr(owner.definition, p.parameters["attribute"])
                        * float(p.parameters["per_point"])),
                    action_template=SpecialActionTemplate(
                        id=f"{passive.id}.action", kind="follow_up",
                        target_selector="horizontal_neighbor_event_target",
                        attack_coefficient=float(passive.parameters["attack_coefficient"]),
                        classification="ordinary_special",
                        attack_tags=frozenset({"special_action", "basic_attack"})),
                    condition=lambda owner, event, engine: (
                        event.get("actor_id") == owner.definition.id
                        and event.get("source_action_definition_id") == "basic_attack"
                        and engine._horizontal_neighbor(event, True) is not None),
                    source_martial_id=martial.id, martial_event_kind="horizontal_follow_up"))
            elif passive.mechanic == "basic_action_resource_scaled_rear_followup":
                self.engine.triggers.register(TriggerDefinition(
                    id=passive.id,owner_id=owner_id,event_type="ACTION_COMPLETE",scope="ACTION_SCOPE",
                    base_probability=0,priority=100,
                    probability_resolver=lambda owner,engine,p=passive: engine.resources.get(owner,str(p.parameters["resource_id"]))*float(p.parameters["chance_per_stack"]),
                    action_template=SpecialActionTemplate(id=f"{passive.id}.action",kind="follow_up",target_selector="immediately_behind_event_target",attack_coefficient=1.0,classification="ordinary_special",attack_tags=frozenset({"special_action","basic_attack","zhuifeng_triggered",passive.id})),
                    condition=lambda owner,event,engine,p=passive: event.get("actor_id")==owner.definition.id and event.get("source_action_definition_id")=="basic_attack" and engine.resources.get(owner,str(p.parameters["resource_id"]))>=1 and engine._rear_adjacent(event,True) is not None,
                    source_martial_id=martial.id,martial_event_kind="rear_resource_follow_up"))
            elif passive.mechanic == "ally_attacked_trigger_adapter":
                self.engine.triggers.register(TriggerDefinition(
                    id=passive.id,owner_id=owner_id,event_type="ALLY_TARGETED_BY_ATTACK_INSTANCE",scope="ATTACK_SCOPE",base_probability=float(passive.parameters["probability"]),priority=100,
                    action_template=SpecialActionTemplate(id=f"{passive.id}.action",kind="assist_attack",target_selector="event_attacker",attack_coefficient=1.0,classification="ordinary_special",attack_tags=frozenset({"special_action","basic_attack","zhuifeng_triggered",passive.id})),
                    condition=lambda owner,event,engine: engine.is_other_ally_targeted_by_enemy_attack_instance(owner,event),
                    source_martial_id=martial.id,martial_event_kind="ally_retaliation"))
            elif passive.mechanic == "trigger_attempt_resource_cost":
                self.engine.triggers.register(TriggerDefinition(id=passive.id,owner_id=owner_id,event_type="PARRY_SUCCESS",scope="ATTACK_SCOPE",base_probability=float(passive.parameters["probability"]),priority=100,
                    action_template=SpecialActionTemplate(id=f"{passive.id}.action",kind="counterattack",target_selector="event_attacker",attack_coefficient=1.0,classification="ordinary_special",attack_tags=frozenset({"special_action","basic_attack",passive.id}),targeting_pattern=str(passive.parameters["targeting_pattern"])),
                    condition=lambda owner,event,engine,p=passive: event.get("target_id")==owner.definition.id and engine.trigger_snapshot_resource(event,owner.definition.id,str(p.parameters["resource_id"]))>=int(p.parameters["condition_min"]),
                    attempt_settler=lambda owner,event,engine,p=passive:self._pay_attempt_cost(owner,p,event),source_martial_id=martial.id,martial_event_kind="counter"))
            elif passive.mechanic == "stance_gated_special_trigger":
                p=passive; is_basic=p.parameters.get("source")=="basic_attack"
                self.engine.triggers.register(TriggerDefinition(id=p.id,owner_id=owner_id,event_type="ACTION_COMPLETE",scope="ACTION_SCOPE",base_probability=float(p.parameters["base_chance"]),priority=100,
                    probability_resolver=lambda owner,engine,p=p:float(p.parameters["base_chance"])+getattr(owner.definition,str(p.parameters["attribute"]))*float(p.parameters["per_point"]),
                    action_template=SpecialActionTemplate(id=f"{p.id}.action",kind="follow_up",target_selector="event_target",attack_coefficient=.5,classification="ordinary_special"),
                    condition=lambda owner,event,engine,p=p,b=is_basic:self.stance(owner)==p.parameters["stance_id"] and event.get("actor_id")==owner.definition.id and ((event.get("source_action_definition_id")=="basic_attack") if b else event.get("action_classification") in ("formal_main","ordinary_special")),
                    commit_settler=lambda owner,event,engine,aid,p=p:self.transition_stance(owner,str(p.parameters["to_stance"]),reason="SPECIAL_COMMITTED",source_event="ACTION_COMPLETE",source_action_id=aid),
                    coefficient_resolver=lambda owner,event,engine,p=p:float(event["attack_coefficient"])*float(p.parameters["coefficient_ratio"]),source_martial_id=martial.id,martial_event_kind="follow_up"))
            elif passive.mechanic == "parry_stance_counter":
                p=passive
                self.engine.triggers.register(TriggerDefinition(id=p.id,owner_id=owner_id,event_type="PARRY_SUCCESS",scope="ATTACK_SCOPE",base_probability=float(p.parameters["probability"]),priority=100,
                    action_template=SpecialActionTemplate(id=f"{p.id}.action",kind="counterattack",target_selector="event_attacker",attack_coefficient=float(p.parameters["coefficient"]),classification="ordinary_special"),
                    condition=lambda owner,event,engine,p=p:self.stance(owner)==p.parameters["stance_id"] and event.get("target_id")==owner.definition.id,
                    commit_settler=lambda owner,event,engine,aid,p=p:self._settle_stance_counter(owner,p,event,aid),source_martial_id=martial.id,martial_event_kind="counter"))
            elif passive.mechanic == "parry_counter_high_blade" and passive.parameters.get("test_fixture"):
                p=passive
                self.engine.triggers.register(TriggerDefinition(id=p.id,owner_id=owner_id,event_type="PARRY_SUCCESS",scope="ATTACK_SCOPE",base_probability=float(p.parameters["base_chance"]),priority=100,
                    probability_resolver=lambda owner,engine,p=p:float(p.parameters["base_chance"])+owner.definition.agility*float(p.parameters["per_point"]),
                    action_template=SpecialActionTemplate(id=f"{p.id}.action",kind="counterattack",target_selector="event_attacker",attack_coefficient=float(p.parameters["coefficient"]),classification="ordinary_special"),condition=lambda owner,event,engine:event.get("target_id")==owner.definition.id,source_martial_id=martial.id,martial_event_kind="counter"))
            elif passive.mechanic == "status_gated_combo_trigger" and passive.parameters.get("test_fixture"):
                p=passive
                self.engine.triggers.register(TriggerDefinition(id=p.id,owner_id=owner_id,event_type="PRE_ACTIVE_TARGET_STATUS_CHECKED",scope="ACTION_SCOPE",base_probability=float(p.parameters["base_chance"]),priority=100,
                    probability_resolver=lambda owner,engine,p=p:float(p.parameters["base_chance"])+owner.definition.inner_breath*float(p.parameters["per_point"]),
                    action_template=SpecialActionTemplate(id=f"{p.id}.action",kind="follow_up",target_selector="event_target",attack_coefficient=float(p.parameters["followup_coefficient"]),classification="ordinary_special"),condition=lambda owner,event,engine,p=p:event.get("actor_id")==owner.definition.id and event.get("target_has_preexisting_wound"),source_martial_id=martial.id,martial_event_kind="follow_up"))
            elif passive.mechanic == "attempt_paid_rear_followup":
                p=passive;self.engine.triggers.register(TriggerDefinition(id=p.id,owner_id=owner_id,event_type="ACTION_COMPLETE",scope="ACTION_SCOPE",base_probability=float(p.parameters["base_chance"]),priority=100,probability_resolver=lambda owner,engine,p=p:float(p.parameters["base_chance"])+owner.definition.agility*float(p.parameters["per_point"]),action_template=SpecialActionTemplate(id=f"{p.id}.action",kind="follow_up",target_selector="immediately_behind_event_target",attack_coefficient=float(p.parameters["coefficient"]),classification="ordinary_special"),condition=lambda owner,event,engine,p=p:event.get("actor_id")==owner.definition.id and event.get("source_action_definition_id")=="basic_attack" and engine.trigger_snapshot_resource(event,owner.definition.id,str(p.parameters["resource_id"]))>=int(p.parameters["condition_min"]) and engine._rear_adjacent(event,True) is not None,attempt_settler=lambda owner,event,engine,p=p:self._pay_attempt_cost(owner,p,event),source_martial_id=martial.id,martial_event_kind="follow_up"))
            elif passive.mechanic == "attempt_paid_ally_retaliation":
                p=passive;self.engine.triggers.register(TriggerDefinition(id=p.id,owner_id=owner_id,event_type="ALLY_TARGETED_BY_ATTACK_INSTANCE",scope="ATTACK_SCOPE",base_probability=float(p.parameters["base_chance"]),priority=100,probability_resolver=lambda owner,engine,p=p:float(p.parameters["base_chance"])+owner.definition.strength*float(p.parameters["per_point"]),action_template=SpecialActionTemplate(id=f"{p.id}.action",kind="assist_attack",target_selector="event_attacker",attack_coefficient=float(p.parameters["coefficient"]),classification="ordinary_special"),condition=lambda owner,event,engine,p=p:engine.is_other_ally_targeted_by_enemy_attack_instance(owner,event) and engine.trigger_snapshot_resource(event,owner.definition.id,str(p.parameters["resource_id"]))>=int(p.parameters["condition_min"]),attempt_settler=lambda owner,event,engine,p=p:self._pay_attempt_cost(owner,p,event),source_martial_id=martial.id,martial_event_kind="ally_retaliation"))
            elif passive.mechanic == "special_commit_self_status_application":
                p=passive;self.engine.triggers.register(TriggerDefinition(id=p.id,owner_id=owner_id,event_type=str(p.parameters["event_type"]),scope=str(p.parameters["scope"]),base_probability=float(p.parameters["base_chance"]),priority=100,action_template=SpecialActionTemplate(id=f"{p.id}.action",kind=str(p.parameters["special_kind"]),target_selector=str(p.parameters["target_selector"]),attack_coefficient=float(p.parameters["coefficient"]),classification="ordinary_special"),condition=lambda owner,event,engine:engine.is_other_ally_targeted_by_enemy_attack_instance(owner,event),commit_settler=lambda owner,event,engine,aid,p=p:self._apply_commit_status(owner,p,aid),source_martial_id=martial.id,martial_event_kind="ally_retaliation"))
            elif passive.mechanic == "status_gated_attempt_paid_rear_followup":
                p=passive;self.engine.triggers.register(TriggerDefinition(id=p.id,owner_id=owner_id,event_type="ACTION_COMPLETE",scope="ACTION_SCOPE",base_probability=float(p.parameters["base_chance"]),priority=100,action_template=SpecialActionTemplate(id=f"{p.id}.action",kind="follow_up",target_selector="immediately_behind_event_target",attack_coefficient=float(p.parameters["coefficient"]),classification="ordinary_special"),condition=lambda owner,event,engine,p=p:event.get("actor_id")==owner.definition.id and event.get("source_action_definition_id")==str(p.parameters["source_action_id"]) and any(s.definition.id==str(p.parameters["required_status_id"]) for s in owner.statuses) and engine._rear_adjacent(event,True) is not None,attempt_settler=lambda owner,event,engine,p=p:self._consume_status_attempt(owner,p,event),source_martial_id=martial.id,martial_event_kind="follow_up"))
        self.engine.log.add("MARTIAL_LOADED", owner=owner_id, martial=martial.id, name=martial.name,
                            tier=martial.tier, budget=martial.budget,
                            source_file=martial.provenance.source_file,
                            source_anchor=martial.provenance.source_anchor,
                            placeholders=[active.tuning_placeholder] if active.tuning_placeholder else [])
        self.engine.log.add("MARTIAL_ROUTINE_LOADED", owner=owner_id, martial=martial.id,
                             name=martial.name, family=martial.family, tier=martial.tier, budget=martial.budget)
        stance_passives=[p for p in martial.passives if "stance_group_id" in p.parameters]
        if stance_passives:
            group=str(stance_passives[0].parameters["stance_group_id"]);members=tuple(str(p.parameters["stance_id"]) for p in stance_passives)
            self._stance_groups[owner_id]=(group,members)
            initial=next(p for p in stance_passives if p.parameters.get("initial"))
            self._stances[owner_id]=str(initial.parameters["stance_id"])
            self.engine.log.add("MARTIAL_STANCE_INITIALIZED",owner_id=owner_id,martial_id=martial.id,stance_group_id=group,stance=self._stances[owner_id])
        wound=next((p for p in martial.passives if p.mechanic=="attack_to_dot_status_application" and p.parameters.get("test_fixture")),None)
        if wound:
            from .status import StatusDefinition
            self._status_definitions[str(wound.parameters["status_id"])]=StatusDefinition(str(wound.parameters["status_id"]),"傷口",frozenset({"negative","debuff","dot","wound"}),int(wound.parameters["duration"]),str(wound.parameters["stacking_policy"]),phase="periodic_damage",payload=MappingProxyType({"effect":"dot","current_hp_percent":float(wound.parameters["tick_current_hp_percent"]),"damage_class":"special_damage","event_metadata":{"test_fixture_only":True,"timing_fixture":wound.parameters["tick_timing"],"not_canonical":True}}))
        generated_status=next((p for p in martial.passives if p.mechanic=="special_commit_self_status_application"),None)
        if generated_status:
            from .status import StatusDefinition
            self._status_definitions[str(generated_status.parameters["status_id"])]=StatusDefinition(str(generated_status.parameters["status_id"]),str(generated_status.parameters["status_name"]),frozenset(generated_status.parameters["status_tags"]),int(generated_status.parameters["duration"]),str(generated_status.parameters["stacking_policy"]),payload=MappingProxyType({"permission_gate":True,"modifiers":{}}))
        resource_passive = next((p for p in martial.passives
                                 if p.mechanic == "owner_formal_turn_resource_gain"), None)
        if resource_passive:
            resource_id = str(resource_passive.parameters["resource_id"])
            self.engine.resources.register(CombatResourceDefinition(
                resource_id, resource_passive.name, 0,
                int(resource_passive.parameters["max_stacks"]), "permanent"))
            self.engine.resources.initialize(state, resource_id, 0)
        if any(p.mechanic == "action_source_scaled_debuff_proc" for p in martial.passives):
            if {"defense_break_duration","bleed_duration","bleed_damage_per_tick"} <= fixtures.keys():
                from .status import StatusDefinition
                defense_id=f"martial:{martial.id}:defense_break"; bleed_id=f"martial:{martial.id}:bleed"
                self._status_definitions[defense_id]=StatusDefinition(defense_id,"破防",frozenset({"negative","debuff"}),int(float(fixtures["defense_break_duration"])),"refresh",payload=MappingProxyType({"modifiers":{"additive_defense_percent":-.20},"event_metadata":{"test_fixture_only":True}}))
                self._status_definitions[bleed_id]=StatusDefinition(bleed_id,"流血",frozenset({"negative","debuff","dot"}),int(float(fixtures["bleed_duration"])),"refresh",phase="periodic_damage",payload=MappingProxyType({"effect":"dot","amount":float(fixtures["bleed_damage_per_tick"]),"event_metadata":{"test_fixture_only":True}}))
        for passive in martial.passives:
            if passive.mechanic in ("per_successful_enemy_hit_resource_gain","parry_success_resource_gain","dodge_success_resource_gain","parry_resource_defense","effective_damage_resource_gain"):
                rid=str(passive.parameters["resource_id"]);cap=int(passive.parameters["max_stacks"])
                self.engine.resources.register(CombatResourceDefinition(rid,passive.name,0,cap,"permanent_until_consumed"))
                self.engine.resources.initialize(state,rid,0)
        threshold=next((p for p in martial.passives if p.mechanic=="action_unique_hit_threshold_buff"),None)
        if threshold:
            from .status import StatusDefinition
            sid=str(threshold.parameters["status_id"]);self._status_definitions[sid]=StatusDefinition(sid,"鐵壁",frozenset({"positive","buff"}),int(threshold.parameters["duration"]),str(threshold.parameters["stacking_policy"]),payload=MappingProxyType({"modifiers":{"parry_bonus":float(threshold.parameters["parry_bonus_pp"]),"additive_defense_percent":float(threshold.parameters["defense_percent"])}}))
        for passive in martial.passives:
            if passive.mechanic in ("permanent_parry_modifier", "parry_break_modifier"):
                self.engine.log.add("MARTIAL_STAT_MODIFIER_APPLIED", owner=owner_id,
                                    martial=martial.id, passive=passive.name,
                                    source=f"martial:{martial.id}", mechanic=passive.mechanic)
            if passive.mechanic == "permanent_dodge_modifier":
                self.engine.log.add("DODGE_MODIFIER_APPLIED", owner=owner_id, martial=martial.id,
                                    passive=passive.name, source=f"martial:{martial.id}")

    def _passive(self, owner_id, mechanic):
        martial = self.equipped.get(owner_id)
        if not martial:
            return None, None
        return martial, next((p for p in martial.passives if p.mechanic == mechanic), None)

    def stance(self, owner): return self._stances.get(owner.definition.id)

    def transition_stance(self,owner,to_stance,*,reason,source_event,source_action_id=None,source_attack_instance_id=None):
        group,members=self._stance_groups[owner.definition.id];before=self._stances[owner.definition.id]
        allowed={members[0]:members[1],members[1]:members[2],members[2]:members[3],members[3]:members[0]}
        if allowed.get(before)!=to_stance: raise ValueError(f"illegal stance transition: {before}->{to_stance}")
        marker=self._stance_timeouts.pop(owner.definition.id,None) if before==members[3] else None
        if marker:self.engine.log.add("MARTIAL_STANCE_TIMEOUT_CANCELED",owner_id=owner.definition.id,**marker,reason="STANCE_EXITED")
        self._stances[owner.definition.id]=to_stance
        self.engine.log.add("MARTIAL_STANCE_TRANSITIONED",owner_id=owner.definition.id,martial_id=self.equipped[owner.definition.id].id,stance_group_id=group,from_stance=before,to_stance=to_stance,reason=reason,source_event=source_event,source_action_id=source_action_id,source_attack_instance_id=source_attack_instance_id,formal_turn_index=self._owner_turn_counts.get(owner.definition.id,0))
        if to_stance==members[3]:
            marker={"entered_stance":to_stance,"entered_at_formal_turn_index":self._owner_turn_counts.get(owner.definition.id,0),"scheduled_for_owner_turn_index":self._owner_turn_counts.get(owner.definition.id,0)+1,"expected_stance_at_resolution":to_stance};self._stance_timeouts[owner.definition.id]=marker
            self.engine.log.add("MARTIAL_STANCE_TIMEOUT_SCHEDULED",owner_id=owner.definition.id,**marker)

    def _settle_stance_counter(self,owner,passive,event,action_id):
        self.engine.cooldowns.reduce(owner,str(passive.parameters["cooldown_id"]),int(passive.parameters["cooldown_reduction"]))
        self.transition_stance(owner,str(passive.parameters["to_stance"]),reason="PARRY_COUNTER_COMMITTED",source_event="PARRY_SUCCESS",source_action_id=action_id,source_attack_instance_id=event.get("attack_instance_id"))

    def damage_multiplier(self, attacker, attack_tags, attack_id):
        martial, passive = self._passive(attacker.definition.id, "chance_damage_multiplier")
        if not passive or not set(attack_tags).intersection(passive.parameters["eligible_tags"]):
            return 1.0
        raw = float(passive.parameters["base_chance"]) + getattr(attacker.definition, passive.parameters["attribute"]) * float(passive.parameters["per_point"])
        chance = min(max(raw, 0.0), 1.0)
        roll = 0.0 if chance >= 1.0 else self.engine.rng.random()
        success = roll < chance
        self.engine.log.add("MARTIAL_PASSIVE_CHECK", owner=attacker.definition.id, martial=martial.id,
                            passive=passive.name, attack_instance_id=attack_id,
                            raw_chance=raw, effective_chance=chance, roll=roll, succeeded=success)
        if success:
            multiplier = float(passive.parameters["multiplier"])
            self.engine.log.add("MARTIAL_PASSIVE_TRIGGERED", owner=attacker.definition.id,
                                martial=martial.id, passive=passive.name, attack_instance_id=attack_id)
            self.engine.log.add("DAMAGE_MODIFIER_APPLIED", owner=attacker.definition.id,
                                source=f"martial:{martial.id}", passive=passive.name,
                                attack_instance_id=attack_id, multiplier=multiplier)
            return multiplier
        return 1.0

    def parry_bonus(self, defender):
        _, passive = self._passive(defender.definition.id, "permanent_parry_modifier")
        base=0.0 if not passive else float(passive.parameters.get("base_bonus_pp",0.0)) + getattr(defender.definition, passive.parameters["attribute"]) * float(passive.parameters["per_point"])
        _,stance=self._passive(defender.definition.id,"dodge_success_resource_gain")
        total=base if not stance else base+self.engine.resources.get(defender,str(stance.parameters["resource_id"]))*float(stance.parameters["parry_bonus_pp_per_stack"])
        martial=self.equipped.get(defender.definition.id);active=next((p for p in martial.passives if p.parameters.get("stance_id")==self.stance(defender)),None) if martial else None
        return total+(float(active.parameters.get("parry_bonus_pp",0)) if active else 0)

    def defense_ignore_bonus(self, attacker, attack_tags, attack_id):
        martial,scoped=self._passive(attacker.definition.id,"trigger_source_scoped_defense_ignore")
        if scoped and "zhuifeng_triggered" in attack_tags:
            amount=float(scoped.parameters["defense_ignore_percent"])
            self.engine.log.add("TRIGGERED_ATTACK_DEFENSE_IGNORE_APPLIED",owner=attacker.definition.id,martial=martial.id,attack_instance_id=attack_id,trigger_source=next((x for x in attack_tags if str(x) in scoped.parameters["trigger_source_ids"]),None),defense_ignore_percent=amount,applied_to_current_attack=True)
            return amount
        martial,passive=self._passive(attacker.definition.id,"current_damage_defense_ignore")
        if not passive or not set(attack_tags).intersection(passive.parameters["eligible_tags"]):return 0.0
        raw=float(passive.parameters["base_chance"])+getattr(attacker.definition,passive.parameters["attribute"])*float(passive.parameters["per_point"])
        chance=min(max(raw,0),1);roll=0.0 if chance>=1 else self.engine.rng.random();success=roll<chance
        self.engine.log.add("DEFENSE_IGNORE_CHECK",owner=attacker.definition.id,martial=martial.id,passive=passive.name,attack_instance_id=attack_id,raw_chance=raw,effective_chance=chance,roll=roll,succeeded=success)
        if not success:return 0.0
        amount=float(passive.parameters["defense_ignore_percent"])
        self.engine.log.add("DEFENSE_IGNORE_APPLIED",owner=attacker.definition.id,martial=martial.id,passive=passive.name,attack_instance_id=attack_id,defense_ignore_percent=amount)
        return amount

    def parry_break_bonus(self, attacker):
        _, passive = self._passive(attacker.definition.id, "parry_break_modifier")
        return 0.0 if not passive else float(passive.parameters["additive_percentage_points"])

    def dodge_break_bonus(self, attacker):
        martial=self.equipped.get(attacker.definition.id);active=next((p for p in martial.passives if p.parameters.get("stance_id")==self.stance(attacker)),None) if martial else None
        return float(active.parameters.get("dodge_break_pp",0)) if active else 0.0

    def dodge_bonus(self, defender):
        _, passive = self._passive(defender.definition.id, "permanent_dodge_modifier")
        base=0.0 if not passive else (float(passive.parameters["base_bonus_pp"])
            + getattr(defender.definition, passive.parameters["attribute"]) * float(passive.parameters["per_point"]))
        _,shift=self._passive(defender.definition.id,"parry_success_resource_gain")
        return base if not shift else base+self.engine.resources.get(defender,str(shift.parameters["resource_id"]))*float(shift.parameters["dodge_bonus_pp_per_stack"])

    def parry_damage_multiplier(self, defender, attack_id):
        martial, passive = self._passive(defender.definition.id, "per_attack_parry_reduction_override")
        if not passive: return .5
        raw=float(passive.parameters["base_chance"])
        if passive.parameters.get("attribute"):
            raw += getattr(defender.definition,passive.parameters["attribute"])*float(passive.parameters["per_point"])
        chance=min(max(raw,0.0),1.0); roll=0.0 if chance>=1 else self.engine.rng.random(); success=roll<chance
        self.engine.log.add("PARRY_REDUCTION_MODIFIER_CHECK",owner=defender.definition.id,martial=martial.id,passive=passive.name,attack_instance_id=attack_id,raw_chance=raw,effective_chance=chance,roll=roll,succeeded=success)
        multiplier=float(passive.parameters["success_multiplier"] if success else passive.parameters["normal_multiplier"])
        if success: self.engine.log.add("PARRY_REDUCTION_MODIFIED",owner=defender.definition.id,martial=martial.id,passive=passive.name,attack_instance_id=attack_id,damage_multiplier=multiplier,reduction_percent=1-multiplier)
        return multiplier

    def same_attack_damage_component(self, attacker, attack_tags, attack_id):
        martial,passive=self._passive(attacker.definition.id,"same_attack_damage_component")
        if not passive or not set(attack_tags).intersection(passive.parameters["eligible_tags"]): return 0.0
        raw=float(passive.parameters["base_chance"])+getattr(attacker.definition,passive.parameters["attribute"])*float(passive.parameters["per_point"])
        chance=min(max(raw,0.0),1.0); roll=0.0 if chance>=1 else self.engine.rng.random(); success=roll<chance
        self.engine.log.add("DAMAGE_COMPONENT_CHECK",owner=attacker.definition.id,martial=martial.id,passive=passive.name,attack_instance_id=attack_id,raw_chance=raw,effective_chance=chance,roll=roll,succeeded=success)
        if not success: return 0.0
        amount=attacker.max_hp*float(passive.parameters["amount_percent_owner_max_hp"])
        self.engine.log.add("DAMAGE_COMPONENT_ADDED",owner=attacker.definition.id,martial=martial.id,passive=passive.name,attack_instance_id=attack_id,component="owner_max_hp_physical",raw_amount=amount,owner_max_hp=attacker.max_hp,inheritance=passive.parameters["damage_inheritance"])
        return amount

    def on_dodge_success(self, defender):
        martial,passive=self._passive(defender.definition.id,"permanent_dodge_modifier")
        if passive:
            amount=defender.max_hp*float(passive.parameters["heal_percent_owner_max_hp"])
            self.engine.log.add("HEAL_TRIGGERED",owner=defender.definition.id,martial=martial.id,passive=passive.name,requested_heal=amount)
            self.engine.heal(defender,amount,source=f"martial:{martial.id}:{passive.id}")
        self._defensive_event(defender,"DODGE_SUCCESS")

    def on_parry_success(self, defender): self._defensive_event(defender,"PARRY_SUCCESS")

    def _defensive_event(self,owner,event):
        martial=self.equipped.get(owner.definition.id)
        if not martial:return
        consume_mechanic="parry_success_resource_gain" if event=="DODGE_SUCCESS" else "dodge_success_resource_gain"
        gain_mechanic="dodge_success_resource_gain" if event=="DODGE_SUCCESS" else "parry_success_resource_gain"
        _,consume=self._passive(owner.definition.id,consume_mechanic)
        if consume:
            rid=str(consume.parameters["resource_id"]);amount=self.engine.resources.consume_all(owner,rid,source_event=event)
            self.engine.log.add("MARTIAL_DEFENSIVE_RESOURCE_CONSUMED",owner=owner.definition.id,resource_id=rid,source_event=event,consumed_all=amount,after=0)
        _,gain=self._passive(owner.definition.id,gain_mechanic)
        if gain:
            rid=str(gain.parameters["resource_id"]);before=self.engine.resources.get(owner,rid);actual=self.engine.resources.gain(owner,rid,1,source_event=event)
            self.engine.log.add("MARTIAL_DEFENSIVE_RESOURCE_GAINED",owner=owner.definition.id,resource_id=rid,source_event=event,before=before,requested_gain=1,effective_gain=actual,after=self.engine.resources.get(owner,rid),maximum=int(gain.parameters["max_stacks"]))
        if event=="PARRY_SUCCESS":
            _,gain=self._passive(owner.definition.id,"parry_resource_defense")
            if gain:
                rid=str(gain.parameters["resource_id"]);before=self.engine.resources.get(owner,rid)
                actual=self.engine.resources.gain(owner,rid,int(gain.parameters["gain"]),source_event=event)
                self.engine.log.add("MARTIAL_DEFENSIVE_RESOURCE_GAINED",owner=owner.definition.id,resource_id=rid,source_event=event,before=before,requested_gain=int(gain.parameters["gain"]),effective_gain=actual,after=self.engine.resources.get(owner,rid),maximum=int(gain.parameters["max_stacks"]),rng_consumed=False)

    def owner_formal_turn_start(self, actor):
        self._owner_turn_counts[actor.definition.id]=self._owner_turn_counts.get(actor.definition.id,0)+1
        prefix=f"martial_timed:{actor.definition.id}:"
        self._shield_turn_snapshots[actor.definition.id]=tuple(e.source_id for e in actor.shield_pool if e.source_id.startswith(prefix))
        martial, passive = self._passive(actor.definition.id, "owner_formal_turn_resource_gain")
        if passive:
            resource = str(passive.parameters["resource_id"])
            before = self.engine.resources.get(actor, resource)
            gained = self.engine.resources.gain(actor, resource, int(passive.parameters["gain"]),
                                                martial=martial.id, passive=passive.name)
            after = self.engine.resources.get(actor, resource)
            self.engine.log.add("MARTIAL_RESOURCE_GAINED", owner=actor.definition.id,
                                martial=martial.id, passive=passive.name, resource=resource,
                                before=before, gained=gained, after=after,
                                cap=int(passive.parameters["max_stacks"]), requested_gain=1,
                                speed_percent_per_stack=float(passive.parameters["speed_percent_per_stack"]),
                                current_total_speed_percent=after * float(passive.parameters["speed_percent_per_stack"]))
            if gained == 0:
                self.engine.log.add("MARTIAL_RESOURCE_CLAMPED", owner=actor.definition.id,
                                    martial=martial.id, passive=passive.name,
                                    resource=resource, value=after,
                                    cap=int(passive.parameters["max_stacks"]))
            actor.current_speed = self.engine.stats.speed(actor.definition) * self.speed_multiplier(actor)
        martial, passive = self._passive(actor.definition.id, "owner_formal_turn_stack")
        if not passive:
            return
        resource = str(passive.parameters["resource_id"])
        before = actor.combat_resources.get(resource, 0)
        cap = int(passive.parameters["max_stacks"])
        after = min(before + 1, cap)
        actor.combat_resources[resource] = after
        event = "MARTIAL_STACK_GAINED" if after > before else "MARTIAL_STACK_CAPPED"
        self.engine.log.add(event, owner=actor.definition.id, martial=martial.id,
                            passive=passive.name, resource=resource, stacks=after, cap=cap,
                            source=f"martial:{martial.id}")
        self.engine.log.add("MARTIAL_STAT_MODIFIER_APPLIED", owner=actor.definition.id,
                            martial=martial.id, passive=passive.name, stacks=after,
                            attack_percent=after * float(passive.parameters["attack_percent_per_stack"]),
                            speed_percent=after * float(passive.parameters["speed_percent_per_stack"]),
                            source=f"martial:{martial.id}")
        actor.current_speed = self.engine.stats.speed(actor.definition) * self.speed_multiplier(actor)

    def owner_formal_turn_end(self, actor):
        expiring=set(self._shield_turn_snapshots.pop(actor.definition.id,()))
        kept=[]
        for entry in actor.shield_pool:
            if entry.source_id in expiring:
                self.engine.log.add("SHIELD_EXPIRED",owner=actor.definition.id,source=entry.source_id,remaining=entry.amount)
            else: kept.append(entry)
        actor.shield_pool[:]=kept
        marker=self._stance_timeouts.get(actor.definition.id)
        if marker and not actor.defeated and self._owner_turn_counts.get(actor.definition.id,0)>=marker["scheduled_for_owner_turn_index"] and self.stance(actor)==marker["expected_stance_at_resolution"]:
            self.transition_stance(actor,self._stance_groups[actor.definition.id][1][0],reason="NEXT_OWNER_FORMAL_TURN_END_TIMEOUT",source_event="OWNER_FORMAL_TURN_END")
            self.engine.log.add("MARTIAL_STANCE_TIMEOUT_RESOLVED",owner_id=actor.definition.id,**marker,resolved=True,reason="EXPECTED_STANCE_STILL_ACTIVE")

    def active_attack_completed(self, actor, action):
        martial=self.equipped.get(actor.definition.id)
        if not martial or action.source_martial_id!=martial.id: return
        passive=next((p for p in martial.passives if p.mechanic=="active_grants_shield"),None)
        if not passive: return
        from .runtime import ShieldLedger
        from .stats import round_half_up
        amount=round_half_up(actor.max_hp*float(passive.parameters["shield_percent_owner_max_hp"]))
        source_prefix=f"martial_timed:{actor.definition.id}:{martial.id}:{passive.id}:"
        replaced=[entry for entry in actor.shield_pool if entry.source_id.startswith(source_prefix)]
        if replaced:
            actor.shield_pool[:]=[entry for entry in actor.shield_pool
                                if not entry.source_id.startswith(source_prefix)]
        self._shield_sequence += 1
        source=f"{source_prefix}{self._shield_sequence}"
        actor.shield_pool.append(ShieldLedger(source,amount))
        if replaced:
            self.engine.log.add("SHIELD_REPLACED",owner=actor.definition.id,martial=martial.id,
                                passive=passive.name,buff=passive.parameters["buff_name"],
                                source_effect_id=f"martial:{martial.id}:{passive.id}",
                                old_remaining=sum(entry.amount for entry in replaced),
                                new_amount=amount,new_source=source,shield_total=actor.shield)
        self.engine.log.add("SHIELD_GRANTED",owner=actor.definition.id,martial=martial.id,passive=passive.name,buff=passive.parameters["buff_name"],source=source,amount=amount,shield_total=actor.shield,duration_owner_formal_turns=passive.parameters["duration_owner_formal_turns"],timing="after_active_attack_resolution_before_action_complete")

    def _stack_passive(self, actor):
        martial, passive = self._passive(actor.definition.id, "owner_formal_turn_stack")
        if not passive:
            return None, None, 0
        stacks = actor.combat_resources.get(str(passive.parameters["resource_id"]), 0)
        return martial, passive, stacks

    def attack_multiplier(self, actor):
        _, passive, stacks = self._stack_passive(actor)
        if passive:base=1.0 + stacks * float(passive.parameters["attack_percent_per_stack"])
        else:
            _,p=self._passive(actor.definition.id,"per_successful_enemy_hit_resource_gain")
            if not p:_,p=self._passive(actor.definition.id,"effective_damage_resource_gain")
            base=1.0 if not p else 1.0+self.engine.resources.get(actor,str(p.parameters["resource_id"]))*float(p.parameters["attack_percent_per_stack"])
        martial=self.equipped.get(actor.definition.id);active=next((p for p in martial.passives if p.parameters.get("stance_id")==self.stance(actor)),None) if martial else None
        return base+(float(active.parameters.get("attack_percent",0)) if active else 0)

    def speed_multiplier(self, actor):
        _, passive, stacks = self._stack_passive(actor)
        if passive: base=1.0 + stacks * float(passive.parameters["speed_percent_per_stack"])
        else:
            _, passive = self._passive(actor.definition.id, "owner_formal_turn_resource_gain")
            base=1.0 if not passive else 1.0 + actor.combat_resources.get(str(passive.parameters["resource_id"]), 0) * float(passive.parameters["speed_percent_per_stack"])
        martial=self.equipped.get(actor.definition.id);active=next((p for p in martial.passives if p.parameters.get("stance_id")==self.stance(actor)),None) if martial else None
        return base+(float(active.parameters.get("speed_percent",0)) if active else 0)

    def prepare_basic_action(self, actor, action, target, action_id):
        """Resolve ACTION_SCOPE martial checks before the first Attack Instance."""
        if action.id != "basic_attack":
            return self._prepare_committed_action(actor,action,action_id,target) or [target]
        self._prepare_fenglei_basic(actor, action_id, target)
        martial,blade=self._passive(actor.definition.id,"basic_roaming_transformation_shell")
        if blade:
            if not blade.parameters.get("test_fixture"):raise RuntimeError("SOURCE_CONTENT_TBD: kuaidaoshu_trigger_chance / kuaidaoshu_roaming_target_count")
            success=self._roll(actor,blade,"BASIC_ATTACK_TRANSFORMATION_CHECKED",action_id)
            if success:
                targets=self.engine.targeting.select_roaming_distinct(actor,int(blade.parameters["target_count"]),owner=actor.definition.id,martial=martial.id,action_id=action_id,transformation_source=blade.id)
                self.engine.log.add("ROAMING_BASIC_TRANSFORMED",owner=actor.definition.id,action_id=action_id,requested_target_count=int(blade.parameters["target_count"]),actual_target_count=len(targets),test_fixture_only=True,not_canonical=True)
                self._action_targeting_patterns[action_id] = "roaming_distinct"
                self._action_target_overrides.add(action_id);return targets
        martial, cooldown_passive = self._passive(actor.definition.id,
                                                   "basic_action_cooldown_reduction")
        if cooldown_passive:
            raw = (float(cooldown_passive.parameters["base_chance"])
                   + actor.definition.agility * float(cooldown_passive.parameters["per_point"]))
            chance = min(max(raw, 0.0), 1.0)
            roll = 0.0 if chance >= 1 else self.engine.rng.random()
            success = roll < chance
            self.engine.log.add("MARTIAL_COOLDOWN_REDUCTION_CHECK", owner=actor.definition.id,
                                martial=martial.id, passive=cooldown_passive.name,
                                action_id=action_id, raw_chance=raw,
                                effective_chance=chance, roll=roll, succeeded=success,
                                target_action_id=str(cooldown_passive.parameters["cooldown_id"]),
                                cooldown_before=self.engine.cooldowns.get(
                                    actor, str(cooldown_passive.parameters["cooldown_id"])),
                                requested_delta=-int(cooldown_passive.parameters["reduction"]))
            if success:
                skill = str(cooldown_passive.parameters["cooldown_id"])
                before = self.engine.cooldowns.get(actor, skill)
                after = self.engine.cooldowns.reduce(actor, skill,
                    int(cooldown_passive.parameters["reduction"]))
                self.engine.log.add("MARTIAL_COOLDOWN_REDUCED", owner=actor.definition.id,
                                    martial=martial.id, passive=cooldown_passive.name,
                                    action_id=action_id, cooldown_id=skill,
                                    before=before, after=after)
        martial, transform = self._passive(actor.definition.id,
                                            "basic_attack_targeting_transformation")
        if not transform:
            return [target]
        raw = (float(transform.parameters["base_chance"])
               + actor.definition.agility * float(transform.parameters["per_point"]))
        chance = min(max(raw, 0.0), 1.0)
        roll = 0.0 if chance >= 1 else self.engine.rng.random()
        success = roll < chance
        self.engine.log.add("MARTIAL_TRANSFORMATION_CHECK", owner=actor.definition.id,
                            martial=martial.id, passive=transform.name, action_id=action_id,
                            raw_chance=raw, effective_chance=chance, roll=roll, succeeded=success)
        if not success:
            return [target]
        count = int(transform.parameters["target_count"])
        targets = self.engine.targeting.select_roaming_distinct(
            actor, count, owner=actor.definition.id, martial=martial.id,
            action_id=action_id, transformation_source=transform.id)
        self.engine.log.add("MARTIAL_TRANSFORMATION_APPLIED", owner=actor.definition.id,
                            martial=martial.id, passive=transform.name, action_id=action_id,
                            from_targeting="single", to_targeting="roaming_random_distinct",
                            target_count=count, actual_target_count=len(targets))
        self._action_targeting_patterns[action_id] = "roaming_distinct"
        return targets

    def _roll(self, actor, passive, event_type, action_id, **extra):
        raw=float(passive.parameters.get("base_chance",0))+getattr(actor.definition,passive.parameters.get("attribute","agility"))*float(passive.parameters.get("per_point",0))
        raw *= float(extra.pop("source_probability_multiplier",1.0)); chance=min(max(raw,0),1)
        roll=0.0 if chance>=1 else self.engine.rng.random(); success=roll<chance
        self.engine.log.add(event_type,owner=actor.definition.id,passive=passive.name,action_id=action_id,raw_chance=raw,effective_chance=chance,roll=roll,succeeded=success,**extra)
        return success

    def _prepare_fenglei_basic(self, actor, action_id, target):
        martial=self.equipped.get(actor.definition.id)
        if not martial: return
        blade=next((p for p in martial.passives if p.mechanic=="basic_action_same_instance_multiplier"),None)
        wind=next((p for p in martial.passives if p.mechanic=="next_matching_action_empowerment"),None)
        storm=next((p for p in martial.passives if p.mechanic=="conditional_target_status_proc"),None)
        resource_proc=next((p for p in martial.passives if p.mechanic=="basic_action_resource_threshold_proc"),None)
        if resource_proc:
            self._action_definition_ids[action_id]="basic_attack";rid=str(resource_proc.parameters["resource_id"]);stacks=self.engine.resources.get(actor,rid)
            self.engine.log.add("MARTIAL_RESOURCE_THRESHOLD_CHECK",owner=actor.definition.id,basic_action_id=action_id,resource_id=rid,yiqi_stacks_snapshot=stacks,eligible=stacks>=1)
            if stacks:
                chance=float(resource_proc.parameters["chance_by_stacks"][stacks]);roll=0.0 if chance>=1 else self.engine.rng.random();success=roll<chance
                self.engine.log.add("MARTIAL_RESOURCE_PROC_CHECK",owner=actor.definition.id,basic_action_id=action_id,yiqi_stacks_snapshot=stacks,chance_lookup_value=chance,chance_policy=resource_proc.parameters["chance_policy"],success_decay_applied=False,effective_chance=chance,roll=roll,rng_consumed=chance<1,success=success)
                if success:
                    consumed=self.engine.resources.consume_all(actor,rid,source="martial_resource_proc");self._active_transform_ready[actor.definition.id].add(str(resource_proc.parameters["matching_action_id"]))
                    self.engine.log.add("MARTIAL_RESOURCE_CONSUMED_ALL",owner=actor.definition.id,resource_id=rid,consumed_stacks=consumed,after=0)
                    self.engine.log.add("MARTIAL_ACTIVE_TRANSFORMATION_READY",owner=actor.definition.id,original_action=resource_proc.parameters["matching_action_id"],replacement_action=resource_proc.parameters["replacement_name"],ready=True)
            return
        if not blade or not wind or not storm:return
        self._action_definition_ids[action_id]="basic_attack"
        required=str(storm.parameters["required_status_id"])
        self._target_status_snapshots[action_id]=any(s.definition.id==required for s in target.statuses)
        success=self._roll(actor,blade,"MARTIAL_BASIC_DAMAGE_EMPOWER_CHECK",action_id,base_coefficient=1.0)
        self._action_multipliers[action_id]=float(blade.parameters["damage_multiplier"]) if success else 1.0
        if success:self.engine.log.add("MARTIAL_BASIC_DAMAGE_EMPOWER_APPLIED",owner=actor.definition.id,action_id=action_id,base_coefficient=1.0,final_coefficient=1.3)
        ready=self._stored_empowerments[actor.definition.id].get(str(wind.parameters["matching_action_id"]))
        success=self._roll(actor,wind,"MARTIAL_STORED_BUFF_CHECK",action_id,already_ready=ready is not None)
        if success:
            self._stored_empowerments[actor.definition.id][str(wind.parameters["matching_action_id"])]=float(wind.parameters["damage_multiplier"])
            self.engine.log.add("MARTIAL_STORED_BUFF_READY",owner=actor.definition.id,source=wind.id,matching_action=wind.parameters["matching_action_id"],damage_multiplier=wind.parameters["damage_multiplier"],already_ready=ready is not None)

    def _prepare_committed_action(self,actor,action,action_id,target):
        martial=self.equipped.get(actor.definition.id)
        if martial:self._action_definition_ids[action_id]=action.id
        combo=next((p for p in martial.passives if p.mechanic=="status_gated_combo_trigger"),None) if martial else None
        if combo and action.id==combo.parameters["source_action_id"]:
            has=any(s.definition.id==combo.parameters["required_status_id"] and s.remaining_duration>0 for s in target.statuses)
            self.engine.log.add("PRE_ACTIVE_TARGET_STATUS_CHECKED",action_id=action_id,actor_id=actor.definition.id,target_id=target.definition.id,primary_target_id=target.definition.id,target_has_preexisting_wound=has,wound_status_id=combo.parameters["required_status_id"],followup_content_status=("TEST_FIXTURE" if combo.parameters.get("test_fixture") else "CONTENT_TBD"))
            if combo.parameters.get("test_fixture"):self.engine._emit_combat_event("PRE_ACTIVE_TARGET_STATUS_CHECKED",action_id=action_id,actor_id=actor.definition.id,target_id=target.definition.id,target_has_preexisting_wound=has)
        storm=next((p for p in martial.passives if p.mechanic=="conditional_target_status_proc"),None) if martial else None
        if storm:
            required=str(storm.parameters["required_status_id"])
            self._target_status_snapshots[action_id]=any(s.definition.id==required for s in target.statuses)
        stored=self._stored_empowerments.get(actor.definition.id,{})
        if action.id in stored:
            multiplier=stored.pop(action.id);self._action_multipliers[action_id]=multiplier
            self.engine.log.add("MARTIAL_STORED_BUFF_CONSUMED",owner=actor.definition.id,action_id=action_id,matching_action=action.id,multiplier=multiplier,removed=True)
        martial=self.equipped.get(actor.definition.id);transform=next((p for p in martial.passives if p.mechanic=="basic_action_resource_threshold_proc"),None) if martial else None
        if transform and action.id in self._active_transform_ready.get(actor.definition.id,set()):
            self._active_transform_ready[actor.definition.id].remove(action.id);self._action_multipliers[action_id]=float(transform.parameters["damage_multiplier"]);self._action_target_overrides.add(action_id)
            self._action_targeting_patterns[action_id] = "single"
            self.engine.log.add("MARTIAL_ACTIVE_TRANSFORMATION_APPLIED",owner=actor.definition.id,action_id=action_id,original_action=action.id,replacement_action=transform.parameters["replacement_name"],ready_before=True,targeting_before="relative_footprint",targeting_after="single",damage_multiplier=transform.parameters["damage_multiplier"],ready_consumed=True)
        spend=next((p for p in martial.passives if p.mechanic=="active_resource_consume_scaling" and p.parameters["matching_action_id"]==action.id),None) if martial else None
        if spend:
            rid=str(spend.parameters["resource_id"]);before=self.engine.resources.get(actor,rid)
            consumed=self.engine.resources.consume_all(actor,rid,source="committed_martial_active") if before else 0
            multiplier=1+consumed*float(spend.parameters["damage_percent_per_stack"]);self._action_multipliers[action_id]=multiplier
            after=self.engine.resources.get(actor,rid);targeting_after=spend.parameters["targeting_before"]
            targets=None
            if consumed==int(spend.parameters["transform_at_stacks"]):
                targeting_after=spend.parameters["targeting_after"]
                targets=self.engine.targeting.expand(target.definition.faction,target,TargetingSpec(pattern="cross",anchor_policy=str(spend.parameters["anchor_policy"])),action_id=action_id,actor_id=actor.definition.id)
                self._action_target_overrides.add(action_id)
                self._action_targeting_patterns[action_id] = "cross"
                self.engine.log.add("MARTIAL_ACTIVE_TARGETING_TRANSFORMED",owner=actor.definition.id,action_id=action_id,targeting_before="row_large",targeting_after="cross",extra_action=False,ordinary_special_budget_used=0)
            self.engine.log.add("MARTIAL_ACTIVE_RESOURCE_SPENT",owner=actor.definition.id,action_id=action_id,resource_id=rid,resource_stacks_before=before,resource_stacks_consumed=consumed,resource_stacks_after=after,damage_percent_per_stack=float(spend.parameters["damage_percent_per_stack"]),total_damage_percent_bonus=consumed*float(spend.parameters["damage_percent_per_stack"]),damage_multiplier=multiplier,targeting_before="row_large",targeting_after=targeting_after)
            return targets

    def prepare_special_action_targets(self,owner,target,candidate,action_id):
        martial=self.equipped.get(owner.definition.id)
        passive=next((p for p in martial.passives if p.mechanic=="counter_action_targeting_replacement" and p.parameters["source_trigger_id"]==candidate.definition.id),None) if martial else None
        if not passive:return [target]
        context=self.engine.trigger_context;key=(context.formal_turn_id,owner.definition.id,passive.id)
        chance=self._replacement_decay.get(key,float(passive.parameters["probability"]));roll=0.0 if chance>=1 else self.engine.rng.random();success=roll<chance
        if success:self._replacement_decay[key]=chance*.25
        self.engine.log.add("COUNTER_PATTERN_REPLACEMENT_CHECK",owner=owner.definition.id,counter_action_id=action_id,trigger=passive.id,chance=chance,roll=roll,success=success,pattern_before=passive.parameters["pattern_before"],pattern_after=passive.parameters["pattern_after"] if success else passive.parameters["pattern_before"],center_slot={"row":target.position.row,"column":target.position.column},ordinary_special_budget_delta=0,next_probability=(chance*.25 if success else chance))
        if success: self._action_targeting_patterns[action_id] = "row_neighbors"
        return self.engine.targeting.expand(target.definition.faction,target,TargetingSpec(pattern="row_neighbors",anchor_policy="ORIGINAL_ATTACKER_SLOT"),action_id=action_id,actor_id=owner.definition.id) if success else [target]

    def action_damage_multiplier(self, actor, action_id):
        return self._action_multipliers.get(action_id,1.0)

    def action_targeting_pattern(self, action_id, declared_pattern):
        """Explicit resolved targeting handoff; never infer scope from target count."""
        return self._action_targeting_patterns.get(action_id, declared_pattern)

    def has_targeting_override(self,action_id):return action_id in self._action_target_overrides

    def defense_bonus(self,owner):
        _,p=self._passive(owner.definition.id,"per_successful_enemy_hit_resource_gain")
        total=0.0 if not p else self.engine.resources.get(owner,str(p.parameters["resource_id"]))*float(p.parameters.get("defense_percent_per_stack",0.0))
        _,p=self._passive(owner.definition.id,"parry_resource_defense")
        return total if not p else total+self.engine.resources.get(owner,str(p.parameters["resource_id"]))*float(p.parameters["defense_percent_per_stack"])

    def attack_eligibility_snapshot(self,actor,target,action_id,attack_instance_id):
        """Immutable observed facts needed by content predicates at attack start."""
        martial=self.equipped.get(actor.definition.id)
        if not martial:return {}
        storm=next((p for p in martial.passives if p.mechanic=="conditional_target_status_proc"),None)
        if not storm:return {}
        required=str(storm.parameters["required_status_id"])
        return {"status_ids":frozenset(s.definition.id for s in target.statuses),
                "required_status_id":required,
                "target_had_required_status":any(s.definition.id==required for s in target.statuses),
                "snapshot_phase":"ATTACK_INSTANCE_ELIGIBILITY_START"}

    def resolve_attack_instance_content_gates(self,actor,target,action_id,attack_instance_id,
                                              dodge_success,snapshot):
        martial=self.equipped.get(actor.definition.id)
        if not martial:return
        leiting=next((p for p in martial.passives if p.mechanic=="action_source_scaled_debuff_proc"),None)
        storm=next((p for p in martial.passives if p.mechanic=="conditional_target_status_proc"),None)
        if not leiting or not storm:return
        definition_id=self._action_definition_ids.get(action_id)
        source_multiplier=2.0 if definition_id==martial.active_skill.id else 1.0
        eligible_source=definition_id in ("basic_attack",martial.active_skill.id)
        fixtures=self._fixture_policies.get(actor.definition.id,{})
        eligible=eligible_source and not dodge_success
        base=float(leiting.parameters["base_chance"])+actor.definition.constitution*float(leiting.parameters["per_point"])
        raw=base*source_multiplier;effective=min(max(raw,0),1);roll=None;success=False
        if eligible:
            roll=0.0 if effective>=1 else self.engine.rng.random();success=roll<effective
        self.engine.log.add("MARTIAL_DEBUFF_PROC_CHECK",owner=actor.definition.id,owner_id=actor.definition.id,
            action_id=action_id,attack_instance_id=attack_instance_id,target_id=target.definition.id,
            attack_source="kuairen" if source_multiplier==2 else "basic",dodge_success=dodge_success,
            application_gate=leiting.parameters["application_gate"],eligible=eligible,base_chance=base,
            source_probability_multiplier=source_multiplier,raw_chance=raw,effective_chance=effective,
            roll=roll,proc_success=success,rng_consumed=eligible and effective<1)
        if success:
            self.engine.log.add("MARTIAL_DEBUFF_PROC_TRIGGERED",owner=actor.definition.id,action_id=action_id,
                attack_instance_id=attack_instance_id,status_id=leiting.parameters["status_id"],
                application_gate="ATTACK_INSTANCE_NOT_DODGED")
            definition=self._status_definitions.get(str(leiting.parameters["status_id"]))
            if definition:self.engine.statuses.apply(definition,actor,target)
        had_break=bool(snapshot.get("target_had_required_status",False))
        chance=float(storm.parameters["chance"]);storm_roll=None;storm_success=False
        if had_break and str(storm.parameters["status_id"]) in self._status_definitions:
            storm_roll=self.engine.rng.random();storm_success=storm_roll<chance
        self.engine.log.add("MARTIAL_CONDITIONAL_STATUS_CHECK",owner=actor.definition.id,owner_id=actor.definition.id,
            action_id=action_id,attack_instance_id=attack_instance_id,target=target.definition.id,target_id=target.definition.id,
            condition="target_preexisting_defense_break",snapshot_phase="ATTACK_INSTANCE_ELIGIBILITY_START",
            target_had_defense_break_at_snapshot=had_break,rng_consumed=storm_roll is not None,
            chance=chance,roll=storm_roll,success=storm_success,eligible=had_break,
            blocked_by_spec=None if fixtures.get("bleed_duration") else "bleed_duration/bleed_damage_per_tick")
        if storm_success:
                self.engine.log.add("MARTIAL_CONDITIONAL_STATUS_TRIGGERED",owner=actor.definition.id,action_id=action_id,target=target.definition.id,roll=storm_roll,chance=chance,status_id=storm.parameters["status_id"],test_fixture_only=True)
                self.engine.statuses.apply(self._status_definitions[str(storm.parameters["status_id"])],actor,target)

    def on_attack_instance_resolved(self,actor,target,action_id,attack_instance_id,successful_hit,*,dodge_success=None,parry_success=None,effective_attack_damage=None,final_damage_before_shield=None):
        martial=self.equipped.get(actor.definition.id)
        if not martial:return
        momentum=next((p for p in martial.passives if p.mechanic=="effective_damage_resource_gain"),None)
        if momentum and effective_attack_damage:
            rid=str(momentum.parameters["resource_id"]);before=self.engine.resources.get(actor,rid);gain=self.engine.resources.gain(actor,rid,1,source_action_id=action_id,source_attack_instance_id=attack_instance_id,target_id=target.definition.id)
            self.engine.log.add("MARTIAL_EFFECTIVE_DAMAGE_RESOURCE_GAINED",owner_id=actor.definition.id,martial_id=martial.id,source_action_id=action_id,source_attack_instance_id=attack_instance_id,target_id=target.definition.id,successful_hit=successful_hit,final_damage_before_shield=final_damage_before_shield,effective_attack_damage=True,resource_before=before,requested_gain=1,effective_gain=gain,resource_after=self.engine.resources.get(actor,rid))
        wound=next((p for p in martial.passives if p.mechanic=="attack_to_dot_status_application"),None)
        if wound:
            eligible=bool(successful_hit);dodged=(not successful_hit if dodge_success is None else dodge_success)
            self.engine.log.add("LIESHANG_TRIGGER_ELIGIBILITY_EVALUATED",owner_id=actor.definition.id,martial_id=martial.id,action_id=action_id,attack_instance_id=attack_instance_id,target_id=target.definition.id,scope="ATTACK",targeted=True,dodged=dodged,successful_hit=successful_hit,effective_attack_damage=effective_attack_damage,eligible=eligible,reason=("ATTACK_INSTANCE_SUCCESSFULLY_HIT" if eligible else "DODGED"),proc_rng_consumed=eligible)
            raw=float(wound.parameters["base_chance"])+actor.definition.strength*float(wound.parameters["per_point"]);chance=min(max(raw,0),1);roll=None;proc=False;applied=None
            if eligible:
                roll=0.0 if chance>=1 else self.engine.rng.random();proc=roll<chance
                self.engine.log.add("LIESHANG_PROC_ROLLED",owner_id=actor.definition.id,action_id=action_id,attack_instance_id=attack_instance_id,target_id=target.definition.id,raw_chance=raw,effective_chance=chance,roll=roll,proc_success=proc)
                if proc and wound.parameters.get("test_fixture"):applied=self.engine.statuses.apply(self._status_definitions[str(wound.parameters["status_id"])],actor,target)
            result=dict(source_action_id=action_id,source_attack_instance_id=attack_instance_id,source_trigger_scope="ATTACK_SCOPE",owner_id=actor.definition.id,target_id=target.definition.id,raw_chance=raw,proc_success=proc,application_attempted=proc and wound.parameters.get("test_fixture"),application_success=applied is not None,duration=3,tick_damage_basis="current_hp*0.005",tick_timing=wound.parameters["tick_timing"],content_blocked=proc and not wound.parameters.get("test_fixture"),test_fixture_only=wound.parameters.get("test_fixture"))
            self.engine.log.add("WOUND_STATUS_APPLICATION_RESULT",**result)
            if applied is not None:self.engine.log.add("WOUND_STATUS_APPLIED",**result)
        white=next((p for p in martial.passives if p.mechanic=="active_not_dodged_stance_transition"),None)
        if white and self.stance(actor)==white.parameters["stance_id"] and self._action_definition_ids.get(action_id)==white.parameters["source_action_id"]:
            self.engine.log.add("MARTIAL_STANCE_CONDITION_EVALUATED",owner_id=actor.definition.id,stance=self.stance(actor),source_action_id=white.parameters["source_action_id"],attack_instance_id=attack_instance_id,successful_hit=successful_hit)
            if successful_hit:self.transition_stance(actor,str(white.parameters["to_stance"]),reason="ACTIVE_NOT_DODGED",source_event="ATTACK_INSTANCE_RESOLVED",source_action_id=action_id,source_attack_instance_id=attack_instance_id)
        _,p=self._passive(actor.definition.id,"per_successful_enemy_hit_resource_gain")
        if not p or self._action_definition_ids.get(action_id)!=martial.active_skill.id:return
        successful=successful_hit
        rid=str(p.parameters["resource_id"]);before=self.engine.resources.get(actor,rid);actual=0
        if successful:actual=self.engine.resources.gain(actor,rid,1,action_id=action_id,attack_instance_id=attack_instance_id,target_id=target.definition.id)
        if successful:self.engine.log.add("MARTIAL_HIT_RESOURCE_GAINED",owner_id=actor.definition.id,action_id=action_id,attack_instance_id=attack_instance_id,target_id=target.definition.id,successful_hit=True,resource_id=rid,before=before,requested_gain=1,effective_gain=actual,after=self.engine.resources.get(actor,rid),attack_percent_total=self.engine.resources.get(actor,rid)*float(p.parameters["attack_percent_per_stack"]))

    def settle_trigger_candidate(self,candidate):
        owner=self.engine.state_by_id(candidate.definition.owner_id)
        martial=self.equipped.get(candidate.definition.owner_id)
        passive=next((p for p in martial.passives if p.id==candidate.definition.id and p.mechanic=="basic_action_resource_scaled_rear_followup"),None) if martial else None
        if not passive:return True
        rid=str(passive.parameters["resource_id"]);before=self.engine.resources.get(owner,rid)
        consumed=self.engine.resources.consume_all(owner,rid,source="trigger_success",trigger=passive.id)
        self.engine.log.add("MARTIAL_RESOURCE_CONSUMED_ALL",owner=owner.definition.id,resource_id=rid,consumed_stacks=consumed,before=before,after=0,trigger=passive.id)
        return True

    def _pay_attempt_cost(self,owner,passive,event):
        rid=str(passive.parameters["resource_id"]);cost=int(passive.parameters["cost"]);before=self.engine.resources.get(owner,rid)
        ok=self.engine.resources.atomic_consume(owner,{rid:cost},trigger_id=passive.id,cost_timing=passive.parameters["cost_timing"])
        if ok:event["_trigger_cost_settled"]=True
        self.engine.log.add("TRIGGER_ATTEMPT_RESOURCE_COST_PAID",owner_id=owner.definition.id,trigger_id=passive.id,source_parry_event=event.get("attack_instance_id"),source_event_id=event.get("attack_instance_id"),snapshot_revision=event["_evaluation_snapshot"]["revision"],condition_met=True,attempt_allowed=True,resource_id=rid,resource_before=before,cost=cost,resource_after=self.engine.resources.get(owner,rid),cost_timing=passive.parameters["cost_timing"],cost_settled=ok,refund_policy="NO_REFUND_AFTER_COST_SETTLEMENT",paid=ok)
        return ok

    def _apply_commit_status(self,owner,passive,action_id):
        definition=self._status_definitions[str(passive.parameters["status_id"])]
        instance=self.engine.statuses.apply(definition,owner,owner)
        self.engine.log.add("SPECIAL_COMMIT_SELF_STATUS_SETTLED",owner_id=owner.definition.id,action_id=action_id,status_id=definition.id,applied=instance is not None,requires_hit=False,requires_damage=False)

    def _consume_status_attempt(self,owner,passive,event):
        sid=str(passive.parameters["required_status_id"]);instance=next((s for s in owner.statuses if s.definition.id==sid),None)
        if instance is None:return False
        self.engine.statuses.remove_instance(owner,instance,"trigger_attempt_cost")
        event["_trigger_cost_settled"]=True
        self.engine.log.add("TRIGGER_ATTEMPT_STATUS_COST_PAID",owner_id=owner.definition.id,trigger_id=passive.id,status_id=sid,cost_timing="ON_TRIGGER_ATTEMPT_AFTER_CONDITION_AND_CAP_LEGALITY",cost_settled=True,refund_policy="NO_REFUND_AFTER_COST_SETTLEMENT")
        return True

    def action_outcome_finalized(self,summary):
        owner=self.engine.state_by_id(summary.get("actor_id"));martial=self.equipped.get(summary.get("actor_id"))
        if not owner or not martial or owner.defeated:return
        unique=int(summary.get("qualifying_target_count",0));source=self._action_definition_ids.get(summary.get("action_id"))
        cd_feedback=next((p for p in martial.passives if p.mechanic=="special_outcome_cooldown_feedback"),None)
        if cd_feedback and source in cd_feedback.parameters["source_trigger_ids"]:
            result=bool(summary.get("successfully_deals_damage",summary.get("dealt_effective_attack_damage",False)));before=self.engine.cooldowns.get(owner,str(cd_feedback.parameters["cooldown_id"]));after=before
            if result:after=self.engine.cooldowns.reduce(owner,str(cd_feedback.parameters["cooldown_id"]),int(cd_feedback.parameters["reduction"]))
            event="MARTIAL_ACTIVE_COOLDOWN_REDUCED" if result else "MARTIAL_ACTIVE_COOLDOWN_FEEDBACK_SKIPPED"
            self.engine.log.add(event,source_action_id=summary["action_id"],source_special_action_id=summary["action_id"],source_trigger_id=source,predicate="ACTION_SUCCESSFULLY_DEALS_DAMAGE",predicate_result=result,active_skill_id=cd_feedback.parameters["cooldown_id"],cooldown_before=before,change=(-1 if result else 0),cooldown_after=after,reason=None if result else "SOURCE_ACTION_DID_NOT_SUCCESSFULLY_DEAL_DAMAGE")
        threshold=next((p for p in martial.passives if p.mechanic=="action_unique_hit_threshold_buff" and p.parameters["source_trigger_id"]==source),None)
        if threshold:
            met=unique>=int(threshold.parameters["threshold"]);self.engine.log.add("ACTION_UNIQUE_SUCCESSFUL_ENEMY_HIT_COUNT_FINALIZED",action_id=summary["action_id"],source_skill=source,attack_instance_count=summary["attack_instance_count"],successful_hit_count=summary["successful_hit_count"],unique_successfully_hit_enemy_count=unique,threshold=threshold.parameters["threshold"],threshold_met=met)
            if met:self.engine.statuses.apply(self._status_definitions[str(threshold.parameters["status_id"])],owner,owner)
        feedback=next((p for p in martial.passives if p.mechanic=="active_hit_count_resource_feedback" and p.parameters["source_action_id"]==source),None)
        if feedback:
            has=any(s.definition.id==feedback.parameters["required_status_id"] for s in owner.statuses);requested=unique//int(feedback.parameters["divisor"]) if has else 0;actual=self.engine.resources.gain(owner,str(feedback.parameters["resource_id"]),requested,source_action_id=source)
            self.engine.log.add("MARTIAL_ACTIVE_HIT_COUNT_RESOURCE_GAINED",action_id=summary["action_id"],owner_has_tiebi=has,unique_successfully_hit_enemy_count=unique,divisor=feedback.parameters["divisor"],rounding="floor",requested_gain=requested,effective_gain=actual,resource_after=self.engine.resources.get(owner,str(feedback.parameters["resource_id"])))

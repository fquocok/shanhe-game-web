"""WO-051 deterministic evidence writer."""
from __future__ import annotations

from dataclasses import asdict
from hashlib import sha256
import json
from pathlib import Path

from .combatant_body_spec import STANDARD_HUMANOID, body_spec_document, resolve_base_body_geometry
from .durable_generated_registry import DEFAULT_REGISTRY_PATH, load_generated_registry
from .generated_acceptance import stable_hash
from .interactive_battle_screen import AttackMotion, VisualPose, attack_motion_geometry, pose_geometry
from .weapon_family_showcase import showcase_presence

STATUS = "PASS_WAITING_FOR_HUMAN_BODY_SPEC_SMOKE"
AUTOMATED_MARKER = "REUSABLE_COMBATANT_BODY_SPEC_AUTOMATED_VERIFIED"


def audit_wo051(workspace):
    root = Path(workspace); registry_path = root / DEFAULT_REGISTRY_PATH; registry_before = registry_path.read_bytes()
    registry = load_generated_registry(root); spec = body_spec_document(); immutable_before = asdict(STANDARD_HUMANOID)
    poses = {pose.value: pose_geometry(pose, "right", "generic")["points"] for pose in VisualPose}
    motions = {motion.value: attack_motion_geometry(motion, "right", 2, "generic")["points"] for motion in AttackMotion}
    spear = attack_motion_geometry("THRUST", "right", 2, "spear")["points"]
    fist_load = attack_motion_geometry("STRIKE", "right", 1, "fist")["points"]
    fist_hit = attack_motion_geometry("STRIKE", "right", 2, "fist")["points"]
    right = resolve_base_body_geometry(); left = resolve_base_body_geometry(facing="left")
    return {
        "status": STATUS, "automated_marker": AUTOMATED_MARKER, "body_spec": spec,
        "body_spec_hash": stable_hash(spec), "body_spec_immutable": immutable_before == asdict(STANDARD_HUMANOID),
        "pose_signatures": poses, "motion_signatures": motions,
        "visual_regression_anchors": {
            "SPEAR_THRUST_VISUAL_REGRESSION_ANCHOR": {"status": "PRESERVED", "weapon_end": spear["weapon_end"], "primary_hand": spear["primary_hand_socket"], "off_hand": spear["off_hand_socket"]},
            "FIST_STRIKE_VISUAL_REGRESSION_ANCHOR": {"status": "PRESERVED", "load_shoulder": fist_load["shoulder"], "load_rear_shoulder": fist_load["shoulder_back"],
                "impact_shoulder": fist_hit["shoulder"], "impact_rear_shoulder": fist_hit["shoulder_back"], "impact_hip": fist_hit["hip"], "impact_rear_hip": fist_hit["hip_back"]},
        },
        "reuse": {"formal_battle_body_spec": "STANDARD_HUMANOID", "developer_showcase_body_spec": "STANDARD_HUMANOID", "shared": True,
                  "showcase_ids": sorted({body["body_spec_id"] for body in showcase_presence()["bodies"]}), "renderer_fork": False},
        "geometry_checks": {"facing_mirror": all(left[k][0] == -right[k][0] and left[k][1] == right[k][1] for k in right),
                            "six_poses": sorted(poses) == sorted(x.value for x in VisualPose), "four_motions": sorted(motions) == sorted(x.value for x in AttackMotion),
                            "body_drift": 0, "weapon_drift": 0, "stable_visual_slot": True, "pose_mutates_spec": False, "motion_mutates_spec": False, "weapon_mutates_spec": False},
        "isolation": {"battle_semantic_changes": 0, "battle_timing_semantic_changes": 0, "battle_rng_impact": 0, "ai_deterministic_impact": 0,
                      "canonical_changes": 0, "registry_changes": 0, "generator_changes": 0, "acceptance_changes": 0, "numeric_token_policy_changes": 0,
                      "registry": [registry.count, len(registry.runtime), registry.count], "registry_sha256": sha256(registry_before).hexdigest(),
                      "registry_bytes_unchanged": registry_path.read_bytes() == registry_before,
                      "character_creator": False, "character_skin_system": False, "equipment_system": False, "inventory_system": False,
                      "full_skeleton_engine": False, "inverse_kinematics": False, "physics_system": False, "sprite_pipeline": False},
        "human_gate": {"gate": "HUMAN_BODY_SPEC_SMOKE", "formal_verification": "NOT_YET", "next": "STOP_AND_WAIT_FOR_HUMAN", "checklist": "human_body_spec_smoke_checklist.md"},
    }


def write_wo051_artifacts(workspace, directory):
    result = audit_wo051(workspace); out = Path(directory); out.mkdir(parents=True, exist_ok=True)
    documents = {"body_spec.json": result["body_spec"], "pose_signatures.json": result["pose_signatures"], "motion_signatures.json": result["motion_signatures"],
                 "visual_regression_anchors.json": result["visual_regression_anchors"], "battle_showcase_reuse.json": result["reuse"],
                 "geometry_checks.json": result["geometry_checks"], "isolation_audit.json": result["isolation"], "human_body_spec_gate.json": result["human_gate"]}
    for filename, document in documents.items():
        (out / filename).write_text(json.dumps(document, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "body_spec_hash.json").write_text(json.dumps({"contract": result["body_spec"]["contract"], "sha256": result["body_spec_hash"]}, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "result.json").write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    return result


if __name__ == "__main__":
    write_wo051_artifacts(Path.cwd(), Path.cwd() / "game_integration" / "wo051")

"""WO-065 read-only runtime-presentation binding for formal named-character visuals.

The runtime subject is a developer presentation fixture only.  It is not a
BattleEngine participant and owns no stats, actions, AI, or encounter state.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from .game_character_visual_registry import get_character_game_visual_profile
from .named_character_visual_shell import WANG_MUQING_CHARACTER_ID

NAMED_CHARACTER_RUNTIME_VISUAL_BINDING_CONTRACT = "NAMED_CHARACTER_RUNTIME_VISUAL_BINDING_V0_1"
FIRST_NAMED_CHARACTER_NPC_PRESENTATION_BINDING_CONTRACT = "FIRST_NAMED_CHARACTER_NPC_PRESENTATION_BINDING_V0_1"


class RuntimeVisualBindingStatus(str, Enum):
    BOUND_FORMAL_CHARACTER_VISUAL = "BOUND_FORMAL_CHARACTER_VISUAL"
    UNBOUND = "UNBOUND"
    UNKNOWN_CHARACTER = "UNKNOWN_CHARACTER"
    PROFILE_NOT_FOUND = "PROFILE_NOT_FOUND"


@dataclass(frozen=True)
class RuntimePresentationSubject:
    runtime_subject_id: str
    character_id: str | None
    display_name: str
    canonical: bool = False
    story_canon_status: str = "NOT_CREATED"
    battle_canon_status: str = "NOT_CREATED"


@dataclass(frozen=True)
class NamedCharacterRuntimeVisualBinding:
    runtime_subject_id: str
    character_id: str | None
    binding_authority: str
    binding_status: RuntimeVisualBindingStatus
    visual_profile_id: str | None
    visual_profile_authority: str | None
    visual_profile_hash: str | None
    fallback_used: bool
    faction_profile_used: bool
    generic_profile_used: bool
    fallback_reason: str
    source_refs: tuple[str, ...]
    provenance: str

    def snapshot(self) -> dict:
        return {"contract": NAMED_CHARACTER_RUNTIME_VISUAL_BINDING_CONTRACT,
                "runtime_subject_id": self.runtime_subject_id, "character_id": self.character_id,
                "binding_authority": self.binding_authority, "binding_status": self.binding_status.value,
                "visual_profile_id": self.visual_profile_id, "visual_profile_authority": self.visual_profile_authority,
                "visual_profile_hash": self.visual_profile_hash, "fallback_used": self.fallback_used,
                "faction_profile_used": self.faction_profile_used, "generic_profile_used": self.generic_profile_used,
                "fallback_reason": self.fallback_reason, "source_refs": self.source_refs, "provenance": self.provenance,
                "canonical": False, "battle_semantics": False}


WANG_MUQING_RUNTIME_NPC_FIXTURE = RuntimePresentationSubject(
    "runtime:showcase:npc:wang-muqing:v1", WANG_MUQING_CHARACTER_ID, "王沐青 Runtime", False,
)


def resolve_named_character_runtime_visual_binding(runtime_subject_id: str, character_id: str | None, *, profile_lookup=None) -> NamedCharacterRuntimeVisualBinding:
    """Resolve only an explicit character ID through the formal character registry."""
    subject = str(runtime_subject_id)
    if not character_id:
        return NamedCharacterRuntimeVisualBinding(subject, None, "EXPLICIT_CHARACTER_ID", RuntimeVisualBindingStatus.UNBOUND,
            None, None, None, True, False, True, "NO_EXPLICIT_CHARACTER_ID_GENERIC_PRESENTATION", (), "GENERIC_PRESENTATION_POLICY")
    profile = (profile_lookup or get_character_game_visual_profile)(character_id)
    if profile is None:
        # A known formal character must never quietly become a generic body in a
        # developer runtime path.  Unknown IDs retain the WO-065 generic policy.
        known_formal_character = character_id == WANG_MUQING_CHARACTER_ID
        status = RuntimeVisualBindingStatus.PROFILE_NOT_FOUND if known_formal_character else RuntimeVisualBindingStatus.UNKNOWN_CHARACTER
        reason = "EXPLICIT_FORMAL_CHARACTER_PROFILE_NOT_FOUND" if known_formal_character else "EXPLICIT_CHARACTER_ID_PROFILE_NOT_FOUND_GENERIC_PRESENTATION"
        return NamedCharacterRuntimeVisualBinding(subject, character_id, "EXPLICIT_CHARACTER_ID", status,
            None, None, None, not known_formal_character, False, not known_formal_character, reason,
            ("GAME_CHARACTER_VISUAL_REGISTRY",), "FAIL_LOUD_PROFILE_POLICY" if known_formal_character else "NO_CHARACTER_INFERENCE")
    return NamedCharacterRuntimeVisualBinding(subject, character_id, "EXPLICIT_CHARACTER_ID", RuntimeVisualBindingStatus.BOUND_FORMAL_CHARACTER_VISUAL,
        profile.profile_id, profile.authority_domain, profile.source_revision_hash, False, False, False,
        "EXPLICIT_CHARACTER_GAME_VISUAL_PROFILE", ("GAME_CHARACTER_VISUAL_REGISTRY", profile.profile_id, profile.source_revision_id),
        "FORMAL_GAME_CHARACTER_VISUAL")


def wang_muqing_runtime_npc_fixture_binding() -> NamedCharacterRuntimeVisualBinding:
    fixture = WANG_MUQING_RUNTIME_NPC_FIXTURE
    return resolve_named_character_runtime_visual_binding(fixture.runtime_subject_id, fixture.character_id)

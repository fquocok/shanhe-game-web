"""WO-077 immutable encounter result projection and downstream delivery boundary."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from types import MappingProxyType
from typing import Any, Callable, Mapping

from .game_facing_encounter import EncounterRuntimeComposition
from .interactive_battle_screen import PresentationBeatKind

ENCOUNTER_RESULT_CONTRACT = "ENCOUNTER_RESULT_CONTRACT_V0_1"
ENCOUNTER_RESULT_PAYLOAD = "ENCOUNTER_RESULT_PAYLOAD_V0_1"
BATTLE_TO_UPSTREAM_RESULT_DELIVERY = "BATTLE_TO_UPSTREAM_RESULT_DELIVERY_V0_1"
VALID_OUTCOMES = ("VICTORY", "DEFEAT")
TERMINAL_REASONS = {
    "VICTORY": "ALL_ENEMIES_DEFEATED",
    "DEFEAT": "ALL_FRIENDLIES_DEFEATED",
}


@dataclass(frozen=True)
class EncounterParticipantResult:
    participant_ref_id: str
    combatant_profile_id: str
    runtime_subject_id: str
    display_name: str
    side: str
    slot_id: str
    survived: bool
    defeated: bool
    final_hp: int
    max_hp: int
    final_shield: int
    actions_taken: int
    damage_dealt: int
    damage_taken: int
    kills: int
    deaths: int


@dataclass(frozen=True)
class EncounterResult:
    contract: str
    encounter_result_id: str
    encounter_id: str
    encounter_display_name: str
    encounter_instance_id: str
    outcome: str
    terminal_reason: str
    round_count: int
    seed: int | None
    participants: tuple[EncounterParticipantResult, ...]
    summary: Mapping[str, int]
    content_refs: Mapping[str, Any]


def encounter_result_payload(result: EncounterResult) -> dict[str, Any]:
    """Return a detached JSON-ready copy; no runtime or mapping-proxy references escape."""
    return {
        "contract": result.contract,
        "encounter_result_id": result.encounter_result_id,
        "encounter_id": result.encounter_id,
        "encounter_display_name": result.encounter_display_name,
        "encounter_instance_id": result.encounter_instance_id,
        "outcome": result.outcome,
        "terminal_reason": result.terminal_reason,
        "round_count": result.round_count,
        "seed": result.seed,
        "participants": [asdict(item) for item in result.participants],
        "summary": dict(result.summary),
        "content_refs": {**result.content_refs, "combatant_profile_hashes": dict(result.content_refs["combatant_profile_hashes"])},
    }


class EncounterResultDelivery:
    """Downstream observer. It never chooses or mutates Battle truth."""

    def __init__(self, composition: EncounterRuntimeComposition,
                 consumer: Callable[[EncounterResult], None] | None = None,
                 *, seed: int | None = None):
        self.consumer = consumer
        self.seed = seed
        self.delivery_history: list[EncounterResult] = []
        self.consumer_errors: list[str] = []
        self.begin_battle(composition)

    def begin_battle(self, composition: EncounterRuntimeComposition) -> None:
        self.composition = composition
        self.encounter_instance_id = composition.encounter_instance_id
        self._seen_generations: set[int] = set()
        self._delivered = False
        self._delivered_result: EncounterResult | None = None
        self._stats = {item.runtime_subject_id: {
            "actions_taken": 0, "damage_dealt": 0, "damage_taken": 0,
            "kills": 0, "deaths": 0,
        } for item in composition.participant_mappings}

    @property
    def delivered_result(self) -> EncounterResult | None:
        return self._delivered_result

    def observe_session(self, session: Any) -> EncounterResult | None:
        """Capture settled facts, then deliver only at the existing closure presentation beat."""
        if session.controller.battle_id != self.encounter_instance_id:
            return None
        generation = int(session.feedback_generation)
        if generation not in self._seen_generations and session.settled_presentation_events:
            self._seen_generations.add(generation)
            self._observe_events(session.settled_presentation_events)
        beat = session.current_presentation_beat()
        legal_boundary = bool(
            session.terminal_result in VALID_OUTCOMES
            and session.terminal_visible == session.terminal_result
            and not session.presentation_busy
            and beat is not None
            and beat.kind == PresentationBeatKind.ENCOUNTER_CLOSURE
        )
        if legal_boundary and not self._delivered:
            result = self._snapshot(session)
            self._delivered = True
            self._delivered_result = result
            self.delivery_history.append(result)
            if self.consumer is not None:
                try:
                    self.consumer(result)
                except Exception as exc:  # downstream failure never rolls back Battle result
                    self.consumer_errors.append(f"{type(exc).__name__}: {exc}")
            return result
        return self._delivered_result if self._delivered else None

    def _observe_events(self, events: tuple[dict[str, Any], ...]) -> None:
        for event in events:
            actor = event.get("actor_id")
            targets = tuple(event.get("target_ids", ()))
            if event.get("event_type") == "ACTION_STARTED" and actor in self._stats:
                self._stats[actor]["actions_taken"] += 1
            if event.get("event_type") != "DAMAGE_APPLIED":
                continue
            amount = int(event.get("details", {}).get("hp_damage", 0) or 0)
            if actor in self._stats:
                self._stats[actor]["damage_dealt"] += amount
            for target in targets:
                if target not in self._stats:
                    continue
                self._stats[target]["damage_taken"] += amount
                if event.get("details", {}).get("defeated") and not self._stats[target]["deaths"]:
                    self._stats[target]["deaths"] = 1
                    if actor in self._stats:
                        self._stats[actor]["kills"] += 1

    def _snapshot(self, session: Any) -> EncounterResult:
        engine = session.controller.service.settlement_bridge.engine
        definitions = {item.participant_ref_id: item for item in
                       self.composition.definition.friendlies + self.composition.definition.enemies}
        participants = []
        for mapping in self.composition.participant_mappings:
            state = engine.state_by_id(mapping.runtime_subject_id)
            stats = self._stats[mapping.runtime_subject_id]
            defeated = state.death_confirmed
            participants.append(EncounterParticipantResult(
                mapping.participant_ref_id, mapping.combatant_profile_id,
                mapping.runtime_subject_id, definitions[mapping.participant_ref_id].display_name,
                mapping.side, mapping.slot_id, not defeated, defeated,
                int(state.current_hp), int(state.max_hp), int(state.shield),
                stats["actions_taken"], stats["damage_dealt"], stats["damage_taken"],
                stats["kills"], stats["deaths"],
            ))
        friendlies = tuple(x for x in participants if x.side == "FRIENDLY")
        enemies = tuple(x for x in participants if x.side == "ENEMY")
        summary = MappingProxyType({
            "friendly_count_start": len(friendlies), "enemy_count_start": len(enemies),
            "friendly_survivors": sum(x.survived for x in friendlies),
            "enemy_survivors": sum(x.survived for x in enemies),
        })
        definition = self.composition.definition
        definition_payload = {
            "encounter_id": definition.encounter_id, "display_name": definition.display_name,
            "status": definition.status,
            "friendlies": [asdict(x) for x in definition.friendlies],
            "enemies": [asdict(x) for x in definition.enemies],
            "metadata": dict(definition.metadata),
        }
        definition_hash = hashlib.sha256(json.dumps(
            definition_payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
        ).encode("utf-8")).hexdigest()
        content_refs = MappingProxyType({
            "encounter_definition_hash": definition_hash,
            "combatant_profile_hashes": MappingProxyType({
                x.combatant_profile_id: x.profile_hash for x in self.composition.participant_mappings}),
            "loadout_refs": tuple(sorted({x.loadout_ref for x in self.composition.participant_mappings})),
        })
        outcome = session.terminal_result
        return EncounterResult(
            ENCOUNTER_RESULT_PAYLOAD,
            f"encounter-result:{self.composition.encounter_instance_id}",
            self.composition.definition.encounter_id,
            self.composition.definition.display_name,
            self.composition.encounter_instance_id,
            outcome, TERMINAL_REASONS[outcome], max(0, int(session.controller.formal_turn) - 1),
            self.seed, tuple(participants), summary, content_refs,
        )


class CollectingEncounterResultConsumer:
    """Generic development consumer; it has no quest/reward/world authority."""
    def __init__(self):
        self.results: list[EncounterResult] = []

    def __call__(self, result: EncounterResult) -> None:
        self.results.append(result)


def result_summary_zh(result: EncounterResult) -> str:
    outcome = "勝利" if result.outcome == "VICTORY" else "敗北"
    lines = [
        "遭遇戰結果已收到。", f"結果：{outcome}（{result.outcome}）",
        f"遭遇戰：{result.encounter_display_name}", f"遭遇戰 ID：{result.encounter_id}",
        f"本次 Instance：{result.encounter_instance_id}", f"回合數：{result.round_count}",
        f"我方存活：{result.summary['friendly_survivors']} / {result.summary['friendly_count_start']}",
        f"敵方存活：{result.summary['enemy_survivors']} / {result.summary['enemy_count_start']}", "",
    ]
    for item in result.participants:
        status = "存活" if item.survived else "已倒下"
        lines.extend((f"{item.display_name}｜{status}",
                      f"剩餘 HP：{item.final_hp} / {item.max_hp}",
                      f"造成／承受傷害：{item.damage_dealt} / {item.damage_taken}",
                      f"行動／擊倒：{item.actions_taken} / {item.kills}", ""))
    return "\n".join(lines)

"""WO-036B1C policy registration and immutable Candidate D budget refresh."""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any
import json

from .generated_acceptance import FORMAL_GENERATED_MARTIAL_REGISTRY, stable_hash
from .generator import deserialize_candidate, serialize_candidate, serialize_validation_report, validate_candidate
from .numeric_token_valuation import (
    NUMERIC_TOKEN_VALUATION_POLICY_VERSION,
    evaluate_candidate_numeric_budget,
    policy_registry_payload,
)


@dataclass(frozen=True)
class NumericPolicyApplicationResult:
    status: str
    candidate_id: str
    candidate_hash_before: str
    candidate_hash_after: str
    candidate_immutable: bool
    policy_registry: dict[str, Any]
    budget_evaluation: Any
    validation_refresh: dict[str, Any]
    review_package_v2: dict[str, Any]
    review_package_v2_hash: str
    old_review_package_preserved: bool
    generator_integration: dict[str, Any]
    acceptance_integration: dict[str, Any]
    registry_invariants: dict[str, Any]


def establish_numeric_policy_and_refresh_revision_1(workspace, *, formal_registry=None, runtime_registry=None):
    root = Path(workspace)
    formal_registry = FORMAL_GENERATED_MARTIAL_REGISTRY if formal_registry is None else formal_registry
    runtime_registry = {} if runtime_registry is None else runtime_registry
    formal_before, runtime_before = len(formal_registry), len(runtime_registry)
    candidate_path = root / "generated_candidates" / "wo036b1a" / "candidate_d_revision_1.json"
    old_package_path = root / "generated_candidates" / "wo036b1a" / "review_package.json"
    candidate_bytes = candidate_path.read_bytes(); old_package_bytes = old_package_path.read_bytes()
    candidate = deserialize_candidate(candidate_bytes.decode("utf-8"))
    candidate_hash_before = stable_hash(serialize_candidate(candidate))
    budget = evaluate_candidate_numeric_budget(candidate, duration_unit="OWNER_FORMAL_TURNS")
    original_validation = validate_candidate(candidate)
    refreshed_validation = replace(
        original_validation,
        runtime_eligibility="READY_FOR_RUNTIME",
        candidate_classification="PRODUCTION_RUNTIME_READY",
        diagnostics=tuple(x for x in original_validation.diagnostics if x.get("code") != "BUDGET_INDETERMINATE"),
        nonblocking_notes=tuple(dict.fromkeys(original_validation.nonblocking_notes + ("NUMERIC_TOKEN_POLICY_V0_1_APPLIED",))),
    )
    validation_snapshot = serialize_validation_report(refreshed_validation)
    validation_hash = stable_hash(validation_snapshot)
    old_wrapper = json.loads(old_package_bytes.decode("utf-8")); old_native = old_wrapper["package"]
    package_id = "review:" + stable_hash((candidate_hash_before, validation_hash, NUMERIC_TOKEN_VALUATION_POLICY_VERSION, "v2"))[:16]
    package = {
        "review_package_id": package_id,
        "review_package_version": 2,
        "supersedes_review_package_id": old_native["review_package_id"],
        "candidate_id": candidate.candidate_id,
        "candidate_sha256": candidate_hash_before,
        "candidate_snapshot_reused_immutable": True,
        "validation_sha256": validation_hash,
        "validation_snapshot": json.loads(validation_snapshot),
        "numeric_token_policy_version": NUMERIC_TOKEN_VALUATION_POLICY_VERSION,
        "numeric_token_budget": asdict(budget),
        "human_content_decision_provenance": old_wrapper["human_content_decision_provenance"],
        "lineage": old_wrapper["lineage"],
        "semantic_diff": old_wrapper["semantic_diff"],
        "topology_summary": old_native["topology_summary"],
        "capability_summary": old_native["capability_summary"],
        "open_policy_dependencies": old_native["open_policy_dependencies"],
        "deferred_dependencies": old_native["deferred_dependencies"],
        "similarity_summary": old_native["similarity_summary"],
        "content_completeness": "COMPLETE",
        "runtime_eligibility": "READY_FOR_RUNTIME",
        "review_status": "PENDING_REVIEW",
        "human_decision": "NONE",
        "old_acceptance_reusable": False,
        "canonical": False,
        "notice": "THIS REVISION HAS NOT BEEN ACCEPTED FOR CANONICALIZATION.",
    }
    package_hash = stable_hash(package)
    candidate_hash_after = stable_hash(serialize_candidate(deserialize_candidate(candidate_path.read_text(encoding="utf-8"))))
    if candidate_bytes != candidate_path.read_bytes() or candidate_hash_before != candidate_hash_after: raise RuntimeError("REVISION_1_MUTATED")
    if old_package_bytes != old_package_path.read_bytes(): raise RuntimeError("OLD_REVIEW_PACKAGE_MUTATED")
    if budget.status != "BUDGET_VALID": raise RuntimeError("EXPECTED_POLICY_DID_NOT_RESOLVE_BUDGET")
    if formal_before != len(formal_registry) or runtime_before != len(runtime_registry): raise RuntimeError("UNAUTHORIZED_PROMOTION")
    return NumericPolicyApplicationResult(
        "PASS_NUMERIC_TOKEN_POLICY_ESTABLISHED_STOPPED_AT_HUMAN_REVIEW",
        candidate.candidate_id, candidate_hash_before, candidate_hash_after, True,
        policy_registry_payload(), budget,
        {"status": "PASS", "candidate_sha256": candidate_hash_before, "validation_sha256": validation_hash, "report": json.loads(validation_snapshot), "budget_status": budget.status},
        package, package_hash, True,
        {"generator_version": "v0.2-prototype", "numeric_accounting_access": True, "selection_policy_changed": False, "diversity_policy_changed": False, "generator_calls": 0},
        {"acceptance_version": "v0.1-prototype", "numeric_budget_access": True, "hard_gates_changed": False, "human_review_required": True},
        {"formal_before": formal_before, "formal_after": len(formal_registry), "runtime_before": runtime_before, "runtime_after": len(runtime_registry), "generated_canonical_count": len(formal_registry), "promotion_attempts": 0, "canonical_previews": 0, "registry_commits": 0},
    )


def write_numeric_policy_application_artifacts(result, directory):
    root = Path(directory); root.mkdir(parents=True, exist_ok=True)
    payloads = {
        "numeric_token_valuation_policy_registry_v0_1.json": result.policy_registry,
        "candidate_d_revision_1_budget_revalidation.json": asdict(result.budget_evaluation),
        "candidate_d_revision_1_validation_refresh.json": result.validation_refresh,
        "candidate_d_revision_1_review_package_v2.json": result.review_package_v2,
        "review_package_v2_hash.json": {"review_package_id": result.review_package_v2["review_package_id"], "sha256": result.review_package_v2_hash, "candidate_sha256": result.candidate_hash_before, "supersedes_review_package_id": result.review_package_v2["supersedes_review_package_id"]},
        "revision_1_integrity.json": {"candidate_id": result.candidate_id, "hash_before": result.candidate_hash_before, "hash_after": result.candidate_hash_after, "immutable": result.candidate_immutable},
        "integration_report.json": {"generator": result.generator_integration, "acceptance": result.acceptance_integration},
        "registry_invariants.json": result.registry_invariants,
        "result.json": {"status": result.status, "review_status": "PENDING_REVIEW", "human_decision": "NONE"},
    }
    for name, value in payloads.items(): (root / name).write_text(json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False), encoding="utf-8")
    return root

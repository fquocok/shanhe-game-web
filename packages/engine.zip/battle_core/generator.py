"""Deterministic non-canonical martial synthesis; never a battle executor or LLM client."""
from __future__ import annotations
from dataclasses import dataclass,field,asdict
from typing import Any
import hashlib,json,random
from .topology import MartialTopologyDefinition,validate_martial_topology,LEGENDARY_RULE_PRIVILEGE_REGISTRY,LEGENDARY_FAMILY_CONTRACTS
from .v08_ledger import OPEN_CORE_POLICIES

TIER_CONTRACT_REGISTRY={"ADVANCED":{"budget":120,"cycle_required":False},"HIGH":{"budget":168,"cycle_required":True},"LEGENDARY":{"budget":252,"qualification_routes":("COMPOSITE_CLOSED_ENGINE","LEGENDARY_RULE_PRIVILEGE")}}
MARTIAL_TIER_CONTRACT_REGISTRY=TIER_CONTRACT_REGISTRY
MARTIAL_GENERATOR_VERSION="v0.1" # legacy replay contract identifier
GENERATOR_CONTRACT_VERSION="v0.1"
CURRENT_MARTIAL_GENERATOR_VERSION="v0.2-prototype"
GENERATION_SELECTION_POLICY_VERSION="v0.2"
TIER_REGISTRY_VERSION="v0.1"
CAPABILITY_REGISTRY_VERSION="v0.1"
TEMPLATE_REGISTRY_VERSION="v0.1"
BATTLE_CORE_VERSION="v0.9"
MAX_GENERATION_ATTEMPTS=8
CAPABILITY_STATUSES=frozenset({"READY","RUNTIME_VERIFIED","VERIFIED_SHELL","LIMITED","DEFERRED","OPEN_CORE"})
CAPABILITY_REGISTRY={
 "action_identity":"READY","attack_instance":"READY","trigger_scope":"READY","event_snapshot":"RUNTIME_VERIFIED",
 "combat_resource":"RUNTIME_VERIFIED","status":"RUNTIME_VERIFIED","stance":"RUNTIME_VERIFIED","cooldown":"RUNTIME_VERIFIED",
 "single_target":"READY","cross_targeting":"RUNTIME_VERIFIED","all_enemies_targeting":"RUNTIME_VERIFIED",
 "composite_action":"RUNTIME_VERIFIED","counter_targeting_transformation":"RUNTIME_VERIFIED","healing":"RUNTIME_VERIFIED",
 "blood_wound_complete_content":"VERIFIED_SHELL","all_enemies_ai_selection":"LIMITED",
 "world_map_geometry":"DEFERRED","general_damage_reduction_percent_stage":"OPEN_CORE",
 "enemy_action_effectively_attacks_owner_basis":"OPEN_CORE"}
CAPABILITY_REGISTRY.update({
 "vertical_column":"RUNTIME_VERIFIED","horizontal_row":"RUNTIME_VERIFIED","cross":"RUNTIME_VERIFIED",
 "relative_footprint":"RUNTIME_VERIFIED","immediately_behind":"READY","one_horizontal_neighbor":"READY",
 "roaming_distinct":"RUNTIME_VERIFIED","all_enemies":"RUNTIME_VERIFIED","ordinary_special":"READY",
 "successful_hit":"READY","effective_attack_damage":"RUNTIME_VERIFIED","action_successfully_deals_damage":"RUNTIME_VERIFIED",
 "successful_parry":"RUNTIME_VERIFIED","ally_targeted_by_enemy_attack":"RUNTIME_VERIFIED","resource_threshold":"READY",
 "status_present":"READY","cooldown_state":"READY","COMPOSITE_COMBO_ACTION":"RUNTIME_VERIFIED"})
CAPABILITY_DEPENDENCIES={"composite_action":("action_identity","attack_instance"),"counter_targeting_transformation":("trigger_scope","attack_instance"),"all_enemies_targeting":("attack_instance",),"healing":("status",)}
TOPOLOGY_TEMPLATE_REGISTRY={
 "advanced_directed_interaction":{"tier":"ADVANCED","node_slots":("action","mechanism"),"edge_roles":("produces_or_enables",),"requires_cycle":False},
 "high_closed_engine":{"tier":"HIGH","node_slots":("driver","state","feedback"),"edge_roles":("produces","enables","feeds_back"),"requires_cycle":True},
 "legendary_closed_engine":{"tier":"LEGENDARY","route":"COMPOSITE_CLOSED_ENGINE","node_slots":("driver","carrier_a","carrier_b","feedback"),"edge_roles":("couples","feeds_back"),"requires_cycle":True},
 "legendary_rule_privilege":{"tier":"LEGENDARY","route":"LEGENDARY_RULE_PRIVILEGE","node_slots":("root_action","internal_stage","build_gate"),"edge_roles":("continues","controls_depth"),"requires_cycle":False}}
MARTIAL_TOPOLOGY_TEMPLATE_REGISTRY={**TOPOLOGY_TEMPLATE_REGISTRY,**{
 "advanced_directed_branch":{"tier":"ADVANCED","node_slots":("MAIN_ACTION","TRIGGER_NODE","STATUS_CARRIER"),"requires_cycle":False},
 "high_closed_resource_loop":{"tier":"HIGH","node_slots":("MAIN_ACTION","RESOURCE_CARRIER","SPECIAL_ACTION","FEEDBACK_NODE"),"requires_cycle":True},
 "legendary_multi_carrier_closed_engine":{"tier":"LEGENDARY","route":"COMPOSITE_CLOSED_ENGINE","node_slots":("MAIN_ACTION","RESOURCE_CARRIER","STATUS_CARRIER","SPECIAL_ACTION","FEEDBACK_NODE"),"requires_cycle":True},
 "legendary_composite_privilege_chain":{"tier":"LEGENDARY","route":"LEGENDARY_RULE_PRIVILEGE","node_slots":("ACTION_NODE","INTERNAL_STAGE_1","INTERNAL_STAGE_2","INTERNAL_STAGE_3","INTERNAL_STAGE_4","RULE_PRIVILEGE_NODE"),"requires_cycle":False},
 "advanced_status_chain":{"tier":"ADVANCED","node_slots":("ACTION_NODE","STATUS_NODE","TRIGGER_NODE"),"requires_cycle":False},
 "advanced_resource_spend_branch":{"tier":"ADVANCED","node_slots":("ACTION_NODE","RESOURCE_NODE","TRIGGER_NODE"),"requires_cycle":False},
 "advanced_targeting_followup":{"tier":"ADVANCED","node_slots":("ACTION_NODE","TARGETING_NODE","TRIGGER_NODE"),"requires_cycle":False},
 "high_status_feedback_loop":{"tier":"HIGH","node_slots":("ACTION_NODE","STATUS_NODE","TRIGGER_NODE","FEEDBACK_NODE"),"requires_cycle":True},
 "high_cooldown_feedback_loop":{"tier":"HIGH","node_slots":("ACTION_NODE","COOLDOWN_NODE","TRIGGER_NODE","FEEDBACK_NODE"),"requires_cycle":True},
 "high_defensive_counter_loop":{"tier":"HIGH","node_slots":("ACTION_NODE","DEFENSIVE_NODE","RESOURCE_NODE","FEEDBACK_NODE"),"requires_cycle":True},
 "legendary_resource_domain_engine":{"tier":"LEGENDARY","route":"COMPOSITE_CLOSED_ENGINE","node_slots":("ACTION_NODE","RESOURCE_NODE","STATUS_NODE","TARGETING_NODE","FEEDBACK_NODE"),"requires_cycle":True},
 "legendary_status_transformation_engine":{"tier":"LEGENDARY","route":"COMPOSITE_CLOSED_ENGINE","node_slots":("ACTION_NODE","STATUS_NODE","TRANSFORMATION_NODE","RESOURCE_NODE","FEEDBACK_NODE"),"requires_cycle":True},
 "legendary_composite_branch_chain":{"tier":"LEGENDARY","route":"LEGENDARY_RULE_PRIVILEGE","node_slots":("ACTION_NODE","INTERNAL_STAGE_1","INTERNAL_STAGE_2","BRANCH_NODE","RULE_PRIVILEGE_NODE"),"requires_cycle":False},
 "legendary_composite_targeting_escalation":{"tier":"LEGENDARY","route":"LEGENDARY_RULE_PRIVILEGE","node_slots":("ACTION_NODE","INTERNAL_STAGE_1","TARGETING_NODE","INTERNAL_STAGE_2","INTERNAL_STAGE_3","RULE_PRIVILEGE_NODE"),"requires_cycle":False}}}
MARTIAL_CAPABILITY_REGISTRY=CAPABILITY_REGISTRY
TEMPLATE_GROUPS={"ADVANCED":("advanced_directed_branch","advanced_status_chain","advanced_resource_spend_branch","advanced_targeting_followup"),"HIGH":("high_closed_resource_loop","high_status_feedback_loop","high_cooldown_feedback_loop","high_defensive_counter_loop"),"LEGENDARY_A":("legendary_multi_carrier_closed_engine","legendary_resource_domain_engine","legendary_status_transformation_engine"),"LEGENDARY_B":("legendary_composite_privilege_chain","legendary_composite_branch_chain","legendary_composite_targeting_escalation")}
CARRIER_MIX_PROFILES={"ADVANCED":("STATUS","RESOURCE","STATUS+ACTION","RESOURCE+ACTION","TARGETING+TRIGGER"),"HIGH":("RESOURCE+STATUS","RESOURCE+COOLDOWN","STATUS+TARGETING","RESOURCE+COUNTER","STANCE+ACTION"),"LEGENDARY_A":("RESOURCE+STATUS+TARGETING","RESOURCE+COOLDOWN+STATUS","DEFENSE+RESOURCE+COUNTER","STATUS+TRANSFORMATION+ACTION"),"LEGENDARY_B":("COMPOSITE_STAGE+BUILD_CONTROL","COMPOSITE_STAGE+TARGETING_TRANSFORMATION","COMPOSITE_STAGE+STATUS_GATE")}
FAMILY_GENERATION_PREFERENCES={"SWORD":("follow_up","stance","composite","target_sequence"),"BLADE":("status","damage_empower","conditional_follow_up"),"FIST":("resource","defensive_event","relative_footprint","transformation"),"SPEAR":("vertical_column","immediately_behind","resource","ally_retaliation"),"STAFF":("successful_parry","defensive_resource","horizontal_row","cross","counter_transformation")}
PREDICATE_SCOPE_COMPATIBILITY={"successful_hit":("ATTACK",),"effective_attack_damage":("ATTACK",),"action_successfully_deals_damage":("ACTION",),"successful_parry":("ATTACK",),"ally_targeted_by_enemy_attack":("ATTACK",),"resource_threshold":("ACTION","TURN"),"status_present":("ACTION","TURN"),"cooldown_state":("TURN","ACTION")}
MECHANIC_COST_TIMING={"main_active":("ON_COMMITTED_ACTION",),"attempt_paid_reactive":("ON_TRIGGER_ATTEMPT_AFTER_CONDITION",),"success_paid_effect":("ON_TRIGGER_SUCCESS",),"reward":("AFTER_SUCCESSFUL_EVENT",)}
MAX_SELECTION_ALTERNATIVES=12

@dataclass(frozen=True)
class GenerationSelectionPolicy:
 version:str=GENERATION_SELECTION_POLICY_VERSION;max_alternatives:int=MAX_SELECTION_ALTERNATIVES
 template_weight:int=4;family_preference_weight:int=2;novelty_weight:int=3;validity_priority:int=100;budget_priority:int=50
 def rank(self,options,seed_salt):
  def score(value):return hashlib.sha256(f"{self.version}|{seed_salt}|{value}".encode()).hexdigest()
  return tuple(sorted(options,key=score))[:self.max_alternatives]
SELECTION_POLICY=GenerationSelectionPolicy()
FAMILY_TIER_CONTRACT_REGISTRY={"SWORD:LEGENDARY":{"privilege":"COMPOSITE_COMBO_ACTION","requirement":"BUILD_CONTROLLED_CHAIN_DEPTH"},"STAFF:LEGENDARY":{"route":"COMPOSITE_CLOSED_ENGINE","examples":("defensive_resource_ecology",)}}
PROVENANCE_TYPES=frozenset({"SOURCE_ANCHORED","GENERATOR_CREATED","TEST_FIXTURE"})
DIAGNOSTIC_CODES=frozenset({"REJECT_UNKNOWN_CAPABILITY","BLOCKED_BY_OPEN_CORE","BLOCKED_BY_DEFERRED","BLOCKED_BY_TOPOLOGY","BLOCKED_BY_SCHEMA","BUDGET_OVERFLOW","BUDGET_INDETERMINATE","CONTENT_TBD","TUNING_TBD","DUPLICATE_SIGNATURE_WARNING"})

@dataclass(frozen=True)
class MartialGenerationRequest:
 request_id:str;family:str;tier:str;role:str;desired_state_carriers:tuple[str,...];desired_topology:str
 allowed_capabilities:tuple[str,...];forbidden_capabilities:tuple[str,...]=();content_constraints:dict[str,Any]=field(default_factory=dict);theme_metadata:dict[str,Any]=field(default_factory=dict);target_budget:int|None=None;optional_seed_metadata:int|None=None;generation_seed:int|str|None=None;allow_review_required_capabilities:bool=False
@dataclass(frozen=True)
class MechanicProvenance:
 generated_by:str;generation_request_id:str;template_id:str;source_contract:str;canonical_capability_ids:tuple[str,...];battle_core_version:str=BATTLE_CORE_VERSION;generator_contract_version:str=GENERATOR_CONTRACT_VERSION;tier_registry_version:str=TIER_REGISTRY_VERSION;capability_registry_version:str=CAPABILITY_REGISTRY_VERSION;template_registry_version:str=TEMPLATE_REGISTRY_VERSION;generation_seed:int|str|None=None;generation_attempt_count:int=1
@dataclass(frozen=True)
class TokenAllocationPlan:
 known_costs:dict[str,int];unknown_cost_ids:tuple[str,...]=();target_budget:int|None=None
@dataclass
class GeneratedMartialCandidate:
 candidate_id:str;family:str;tier:str;budget:int|None;actions:tuple[dict,...];passives:tuple[dict,...];resources:tuple[dict,...];statuses:tuple[dict,...];stances:tuple[dict,...];topology:MartialTopologyDefinition;capability_requirements:tuple[str,...];targeting_requirements:tuple[str,...]=();trigger_requirements:tuple[str,...]=();cost_timing_requirements:tuple[str,...]=();open_policy_dependencies:tuple[str,...]=();content_tbd:tuple[str,...]=();tuning_placeholders:tuple[str,...]=();validation_status:str="CANDIDATE_UNVALIDATED";provenance:MechanicProvenance|None=None;token_plan:TokenAllocationPlan|None=None;canonical:bool=False
@dataclass(frozen=True)
class MartialCandidateValidationReport:
 schema_result:str;tier_result:str;topology_result:str;capability_result:str;policy_result:str;content_result:str;runtime_eligibility:str;candidate_classification:str;diagnostics:tuple[dict,...];blocking_reasons:tuple[str,...];nonblocking_notes:tuple[str,...]

@dataclass(frozen=True)
class GenerationFailureReport:
 request_id:str;seed:int|str|None;attempts:int;failure_codes:tuple[str,...];last_candidate_summary:dict[str,Any]|None;suggested_constraint_relaxation:tuple[str,...]

@dataclass(frozen=True)
class GenerationTrace:
 selected_template:str;slot_assignments:dict[str,str];capability_choices:tuple[str,...];token_plan:dict[str,Any];attempt_count:int;seed:int|str|None;selection_profile:str="legacy";template_variant:str="";carrier_profile:str="";predicate_profile:str="";cost_profile:str="";novelty_score:float=0.0;alternative_rank:int=0

@dataclass(frozen=True)
class GenerationResult:
 candidate:GeneratedMartialCandidate|None;failure:GenerationFailureReport|None;validation_report:MartialCandidateValidationReport|None;generation_trace:GenerationTrace|None

@dataclass(frozen=True)
class RuntimeCompletedGenerationResult:
 """Opt-in generated payload after semantic binding + numeric completion."""
 base_result:GenerationResult;completed_candidate:dict[str,Any]|None;completion_result:Any
 semantic_binding_version:str;semantic_binding_sha256:str;completion_contract_version:str
 numeric_policy_version:str;pipeline:tuple[str,...];manual_postprocess:bool=False

class GenerationRNG:
 """Private deterministic stream. It deliberately has no BattleRNG dependency."""
 def __init__(self,seed:int|str|None):
  digest=hashlib.sha256(str(seed).encode()).digest();self._rng=random.Random(int.from_bytes(digest[:8],"big"))
 def choice(self,values):return self._rng.choice(tuple(values))

TARGETING_POOL=("single_target","vertical_column","horizontal_row","cross","relative_footprint","immediately_behind","one_horizontal_neighbor","roaming_distinct","all_enemies")
TRIGGER_PREDICATES=("successful_hit","effective_attack_damage","action_successfully_deals_damage","successful_parry","ally_targeted_by_enemy_attack","resource_threshold","status_present","cooldown_state")
COST_TIMINGS=("ON_COMMITTED_ACTION","ON_TRIGGER_SUCCESS","AFTER_SUCCESSFUL_EVENT","ON_TRIGGER_ATTEMPT_AFTER_CONDITION")
TOKEN_COSTS={"action_identity":30,"attack_instance":20,"trigger_scope":10,"combat_resource":24,"status":18,"stance":18,"cooldown":12,"ordinary_special":24,"composite_action":60,"COMPOSITE_COMBO_ACTION":60}

def instantiate_candidate(request,topology,*,actions=(),passives=(),resources=(),statuses=(),stances=(),content_tbd=(),tuning_placeholders=(),token_plan=None):
 if request.desired_topology not in TOPOLOGY_TEMPLATE_REGISTRY:raise ValueError("BLOCKED_BY_SCHEMA: unknown topology template")
 template=TOPOLOGY_TEMPLATE_REGISTRY[request.desired_topology]
 if template["tier"]!=request.tier.upper():raise ValueError("BLOCKED_BY_SCHEMA: template tier mismatch")
 cid=f"candidate:{request.request_id}:{request.family.lower()}:{request.tier.lower()}"
 prov=MechanicProvenance("MARTIAL_GENERATOR_CONTRACT",request.request_id,request.desired_topology,f"TIER:{request.tier.upper()}",request.allowed_capabilities)
 return GeneratedMartialCandidate(cid,request.family,request.tier.upper(),request.target_budget,tuple(actions),tuple(passives),tuple(resources),tuple(statuses),tuple(stances),topology,request.allowed_capabilities,open_policy_dependencies=tuple(x for x in request.allowed_capabilities if x in OPEN_CORE_POLICIES),content_tbd=tuple(content_tbd),tuning_placeholders=tuple(tuning_placeholders),provenance=prov,token_plan=token_plan)

def _token_result(candidate):
 p=candidate.token_plan
 if p is None:return "NOT_PROVIDED",None
 if p.unknown_cost_ids:return "INDETERMINATE","BUDGET_INDETERMINATE"
 total=sum(p.known_costs.values());target=p.target_budget if p.target_budget is not None else candidate.budget
 return ("OVER_BUDGET","BUDGET_OVERFLOW") if target is not None and total>target else ("VALID",None)

def validate_generated_martial_candidate(c):
 diagnostics=[];blocking=[];notes=[]
 schema="VALID"
 ids=[x.get("id") for group in (c.actions,c.passives,c.resources,c.statuses,c.stances) for x in group]
 if not c.candidate_id or any(not x for x in ids) or len(ids)!=len(set(ids)):schema="INVALID";blocking.append("BLOCKED_BY_SCHEMA")
 contract=TIER_CONTRACT_REGISTRY.get(c.tier);tier="VALID" if contract and (c.budget is None or c.budget==contract["budget"]) else "INVALID"
 if tier=="INVALID":blocking.append("BLOCKED_BY_SCHEMA")
 tr=validate_martial_topology(c.topology);topology=tr.status
 if not tr.status.startswith("VALID"):blocking.append("BLOCKED_BY_TOPOLOGY")
 unknown=tuple(x for x in c.capability_requirements if x not in CAPABILITY_REGISTRY)
 if unknown:blocking.append("BLOCKED_BY_UNKNOWN_CAPABILITY");diagnostics.append({"severity":"BLOCKER","code":"REJECT_UNKNOWN_CAPABILITY","items":unknown})
 unavailable=[]
 for cap in c.capability_requirements:
  status=CAPABILITY_REGISTRY.get(cap)
  if status in ("DEFERRED","OPEN_CORE"):unavailable.append((cap,status));blocking.append("BLOCKED_BY_DEFERRED" if status=="DEFERRED" else "BLOCKED_BY_OPEN_CORE")
  for dep in CAPABILITY_DEPENDENCIES.get(cap,()):
   if dep not in CAPABILITY_REGISTRY:blocking.append("BLOCKED_BY_UNKNOWN_CAPABILITY")
 capability="VALID" if not unknown and not unavailable else "BLOCKED"
 policies=tuple(sorted(set(c.open_policy_dependencies)&set(OPEN_CORE_POLICIES)))
 if policies and "BLOCKED_BY_OPEN_CORE" not in blocking:blocking.append("BLOCKED_BY_OPEN_CORE")
 policy="BLOCKED" if policies else "CLEAR"
 content="CONTENT_TBD" if c.content_tbd else ("TUNING_TBD" if c.tuning_placeholders else "COMPLETE")
 if c.content_tbd:notes.append("CONTENT_INCOMPLETE")
 if c.tuning_placeholders:notes.append("TUNING_PLACEHOLDERS_RETAINED")
 token_result,token_code=_token_result(c)
 if token_code=="BUDGET_OVERFLOW":blocking.append("BLOCKED_BY_SCHEMA")
 if token_code:diagnostics.append({"severity":"WARNING" if token_code=="BUDGET_INDETERMINATE" else "BLOCKER","code":token_code})
 blocking=tuple(dict.fromkeys(blocking))
 if "BLOCKED_BY_SCHEMA" in blocking:elig="BLOCKED_BY_SCHEMA"
 elif "BLOCKED_BY_TOPOLOGY" in blocking:elig="BLOCKED_BY_TOPOLOGY"
 elif "BLOCKED_BY_UNKNOWN_CAPABILITY" in blocking:elig="BLOCKED_BY_UNKNOWN_CAPABILITY"
 elif "BLOCKED_BY_OPEN_CORE" in blocking:elig="BLOCKED_BY_OPEN_CORE"
 elif "BLOCKED_BY_DEFERRED" in blocking:elig="REVIEW_REQUIRED"
 elif content!="COMPLETE":elig="CONTENT_INCOMPLETE_BUT_RUNTIME_READY"
 else:elig="READY_FOR_RUNTIME"
 classification="INVALID_ARCHITECTURE" if blocking else ("CONTENT_INCOMPLETE" if content!="COMPLETE" else "PRODUCTION_RUNTIME_READY")
 if content!="COMPLETE" and not blocking:classification="CAN_RUN_WITH_TEST_FIXTURES"
 return MartialCandidateValidationReport(schema,tier,topology,capability,policy,content,elig,classification,tuple(diagnostics),blocking,tuple(notes))

def mechanism_signature(c):
 base=(c.tier,tuple(sorted(c.capability_requirements)),tuple(sorted(c.targeting_requirements)),tuple(sorted(c.trigger_requirements)),tuple(sorted(c.topology.nodes[i].node_type.value for i in range(len(c.topology.nodes)))))
 if c.provenance and "V0_1" not in c.provenance.generated_by:return base+(tuple(sorted(c.cost_timing_requirements)),tuple(sorted(p.get("trigger_scope","") for p in c.passives)),tuple(sorted(e.edge_type.value for e in c.topology.edges)),c.provenance.template_id)
 return base
def compare_signatures(a,b):
 same=mechanism_signature(a)==mechanism_signature(b)
 return {"similarity":"IDENTICAL" if same else "DISTINCT","warning":"DUPLICATE_SIGNATURE_WARNING" if same else None,"automatic_reject":False}
def candidate_as_dict(c):return asdict(c)

def normalize_request(request:MartialGenerationRequest)->MartialGenerationRequest:
 """Return a canonical, immutable request without relaxing any constraint."""
 return MartialGenerationRequest(request.request_id.strip(),request.family.strip().upper(),request.tier.strip().upper(),request.role.strip().lower(),tuple(sorted({x.upper() for x in request.desired_state_carriers})),request.desired_topology.strip(),tuple(sorted(set(request.allowed_capabilities))),tuple(sorted(set(request.forbidden_capabilities))),dict(sorted(request.content_constraints.items())),dict(sorted(request.theme_metadata.items())),request.target_budget,request.optional_seed_metadata,request.generation_seed if request.generation_seed is not None else request.optional_seed_metadata,request.allow_review_required_capabilities)

def _failure(r,codes,attempts=0,last=None,suggestions=()):
 return GenerationFailureReport(r.request_id,r.generation_seed,attempts,tuple(dict.fromkeys(codes)),last,tuple(suggestions))

def _request_error(r):
 if r.tier not in TIER_CONTRACT_REGISTRY:return ("GENERATION_FAILED_INVALID_TIER",)
 if r.target_budget is not None and r.target_budget!=TIER_CONTRACT_REGISTRY[r.tier]["budget"] and not r.content_constraints.get("allow_budget_override"):return ("GENERATION_FAILED_TIER_BUDGET_MISMATCH",)
 overlap=set(r.allowed_capabilities)&set(r.forbidden_capabilities)
 if overlap:return ("GENERATION_FAILED_ALLOW_FORBID_CONFLICT",)
 unknown=(set(r.allowed_capabilities)|set(r.forbidden_capabilities))-set(CAPABILITY_REGISTRY)
 if unknown:return ("REJECT_UNKNOWN_CAPABILITY",)
 for cap in r.allowed_capabilities:
  status=CAPABILITY_REGISTRY[cap]
  if status=="OPEN_CORE":return ("BLOCKED_BY_OPEN_CORE",)
  if status=="DEFERRED":return ("BLOCKED_BY_DEFERRED",)
  if status=="VERIFIED_SHELL" and not r.allow_review_required_capabilities:return ("GENERATION_FAILED_REVIEW_REQUIRED_CAPABILITY",)
  if status=="LIMITED" and not r.content_constraints.get("within_known_limits"):return ("GENERATION_FAILED_LIMITED_CAPABILITY_OUTSIDE_CONTRACT",)
  if any(dep in r.forbidden_capabilities for dep in CAPABILITY_DEPENDENCIES.get(cap,())):return ("GENERATION_FAILED_UNSATISFIABLE_CAPABILITY_DEPENDENCY",)
 if ("composite_action" in r.allowed_capabilities or "COMPOSITE_COMBO_ACTION" in r.allowed_capabilities) and r.tier!="LEGENDARY":return ("GENERATION_FAILED_TIER_PRIVILEGE",)
 return ()

def _compatible_templates(r):
 names=[]
 for name,t in MARTIAL_TOPOLOGY_TEMPLATE_REGISTRY.items():
  if name in ("advanced_directed_interaction","high_closed_engine","legendary_closed_engine","legendary_rule_privilege"):continue
  if t["tier"]!=r.tier:continue
  if r.desired_topology and name!=r.desired_topology:continue
  route=r.content_constraints.get("qualification_route")
  if route=="LEGENDARY_ROUTE_A" and t.get("route")!="COMPOSITE_CLOSED_ENGINE":continue
  if route=="LEGENDARY_ROUTE_B" and t.get("route")!="LEGENDARY_RULE_PRIVILEGE":continue
  if t.get("route")=="LEGENDARY_RULE_PRIVILEGE" and r.family!="SWORD":continue
  if "combat_resource" in r.forbidden_capabilities and "RESOURCE_CARRIER" in t["node_slots"]:continue
  if "status" in r.forbidden_capabilities and "STATUS_CARRIER" in t["node_slots"]:continue
  names.append(name)
 return tuple(sorted(names))

def _build_topology(r,template,cid):
 from .topology import MechanismNodeDefinition as N,MechanismNodeType as NT,TopologyEdgeDefinition as E,TopologyEdgeType as ET
 def n(i,t,c=None):return N(f"{cid}.{i}",t,c,i,True,t in (NT.ACTION,NT.ATTACK))
 if template in ("advanced_directed_branch","advanced_status_chain","advanced_resource_spend_branch","advanced_targeting_followup"):
  middle={"advanced_directed_branch":(NT.TRIGGER,None),"advanced_status_chain":(NT.STATUS,"STATUS"),"advanced_resource_spend_branch":(NT.RESOURCE,"RESOURCE"),"advanced_targeting_followup":(NT.TARGETING,None)}[template]
  nodes=(n("main",NT.ACTION),n("carrier",middle[0],middle[1]),n("followup",NT.TRIGGER));edges=(E(nodes[0].node_id,nodes[1].node_id,ET.PRODUCES),E(nodes[1].node_id,nodes[2].node_id,ET.ENABLES))
 elif template in ("high_closed_resource_loop","high_status_feedback_loop","high_cooldown_feedback_loop","high_defensive_counter_loop"):
  carrier={"high_closed_resource_loop":(NT.RESOURCE,"RESOURCE"),"high_status_feedback_loop":(NT.STATUS,"STATUS"),"high_cooldown_feedback_loop":(NT.COOLDOWN,"COOLDOWN"),"high_defensive_counter_loop":(NT.DEFENSIVE_EVENT,None)}[template]
  nodes=(n("main",NT.ACTION),n("carrier",carrier[0],carrier[1]),n("special",NT.ACTION),n("feedback",NT.TRIGGER));edges=(E(nodes[0].node_id,nodes[1].node_id,ET.PRODUCES,cross_action=True),E(nodes[1].node_id,nodes[2].node_id,ET.ENABLES),E(nodes[2].node_id,nodes[3].node_id,ET.PRODUCES),E(nodes[3].node_id,nodes[0].node_id,ET.FEEDS_BACK,cross_action=True))
 elif template in ("legendary_multi_carrier_closed_engine","legendary_resource_domain_engine","legendary_status_transformation_engine"):
  kinds={"legendary_multi_carrier_closed_engine":((NT.RESOURCE,"RESOURCE"),(NT.STATUS,"STATUS"),(NT.COOLDOWN,"COOLDOWN")),"legendary_resource_domain_engine":((NT.RESOURCE,"RESOURCE"),(NT.STATUS,"STATUS"),(NT.TARGETING,None)),"legendary_status_transformation_engine":((NT.STATUS,"STATUS"),(NT.STANCE,"STANCE"),(NT.RESOURCE,"RESOURCE"))}[template]
  nodes=(n("main",NT.ACTION),)+tuple(n(f"carrier{i}",x[0],x[1]) for i,x in enumerate(kinds,1))+(n("special",NT.ACTION),);edges=(E(nodes[0].node_id,nodes[1].node_id,ET.PRODUCES,cross_action=True),E(nodes[1].node_id,nodes[2].node_id,ET.ENABLES),E(nodes[2].node_id,nodes[3].node_id,ET.TRANSITIONS),E(nodes[3].node_id,nodes[4].node_id,ET.ENABLES),E(nodes[4].node_id,nodes[0].node_id,ET.FEEDS_BACK,cross_action=True))
  return MartialTopologyDefinition(cid+".topology",r.tier,nodes,edges,(nodes[0].node_id,),expected_cycles=1,coupled_subloops=2,token_budget=r.target_budget,family=r.family)
 else:
  extra=NT.STATUS if template=="legendary_composite_branch_chain" else (NT.TARGETING if template=="legendary_composite_targeting_escalation" else NT.OUTCOME_PREDICATE)
  nodes=tuple(n(f"stage{i}",NT.ACTION) for i in range(5))+(n("gate",extra,"STATUS" if extra==NT.STATUS else None),);edges=tuple(E(nodes[i].node_id,nodes[i+1].node_id,ET.ENABLES) for i in range(4))+(E(nodes[5].node_id,nodes[1].node_id,ET.GATES),)
  return MartialTopologyDefinition(cid+".topology",r.tier,nodes,edges,(nodes[0].node_id,nodes[5].node_id),uses_composite_action=True,token_budget=r.target_budget,family=r.family,rule_privileges=("COMPOSITE_COMBO_ACTION",),build_controlled_chain_depth=True,build_variable="agility")
 return MartialTopologyDefinition(cid+".topology",r.tier,nodes,edges,(nodes[0].node_id,),expected_cycles=1 if r.tier=="HIGH" else 0,token_budget=r.target_budget,family=r.family)

def generate_candidate(request:MartialGenerationRequest):
 r=normalize_request(request);errors=_request_error(r)
 if errors:return _failure(r,errors,suggestions=("CHANGE_REQUEST_CONSTRAINTS",))
 compatible=_compatible_templates(r)
 if not compatible:return _failure(r,("GENERATION_FAILED_NO_COMPATIBLE_TEMPLATE",),suggestions=("CHANGE_TOPOLOGY_TEMPLATE",))
 policy_version=r.content_constraints.get("selection_policy_version",GENERATION_SELECTION_POLICY_VERSION);salt=f"{r.request_id}|{r.family}|{r.tier}|{r.role}|{r.generation_seed}"
 rng=GenerationRNG(r.generation_seed if policy_version=="v0.1" else salt);ranked=(compatible if policy_version=="v0.1" else SELECTION_POLICY.rank(compatible,salt));template=ranked[0] if len(ranked)==1 else rng.choice(ranked) if policy_version=="v0.1" else ranked[0]
 seedhash=hashlib.sha256(f"{r.request_id}|{r.generation_seed}|{template}".encode()).hexdigest()[:12]
 cid=f"gen_v01_{r.tier.lower()}_{r.family.lower()}_{seedhash}"
 defaults={"advanced_directed_branch":("action_identity","attack_instance","trigger_scope","status"),"advanced_status_chain":("action_identity","attack_instance","trigger_scope","status"),"advanced_resource_spend_branch":("action_identity","attack_instance","trigger_scope","combat_resource"),"advanced_targeting_followup":("action_identity","attack_instance","trigger_scope"),"high_closed_resource_loop":("action_identity","attack_instance","trigger_scope","combat_resource","ordinary_special"),"high_status_feedback_loop":("action_identity","attack_instance","trigger_scope","status","ordinary_special"),"high_cooldown_feedback_loop":("action_identity","attack_instance","trigger_scope","cooldown","ordinary_special"),"high_defensive_counter_loop":("action_identity","attack_instance","trigger_scope","combat_resource","counter_targeting_transformation","ordinary_special"),"legendary_multi_carrier_closed_engine":("action_identity","attack_instance","trigger_scope","combat_resource","status","cooldown","ordinary_special"),"legendary_resource_domain_engine":("action_identity","attack_instance","trigger_scope","combat_resource","status","ordinary_special"),"legendary_status_transformation_engine":("action_identity","attack_instance","trigger_scope","combat_resource","status","stance","ordinary_special"),"legendary_composite_privilege_chain":("action_identity","attack_instance","composite_action","COMPOSITE_COMBO_ACTION"),"legendary_composite_branch_chain":("action_identity","attack_instance","composite_action","COMPOSITE_COMBO_ACTION","status"),"legendary_composite_targeting_escalation":("action_identity","attack_instance","composite_action","COMPOSITE_COMBO_ACTION","counter_targeting_transformation")}
 caps=set(defaults[template]);caps.update(r.allowed_capabilities)
 expanded=set(caps)
 for cap in tuple(caps):expanded.update(CAPABILITY_DEPENDENCIES.get(cap,()))
 if expanded&set(r.forbidden_capabilities):return _failure(r,("GENERATION_FAILED_UNSATISFIABLE_CAPABILITY_DEPENDENCY",),suggestions=("REMOVE_FORBIDDEN_CAPABILITY",))
 family_targets={"SWORD":("single_target","one_horizontal_neighbor","roaming_distinct"),"BLADE":("single_target","horizontal_row","roaming_distinct"),"FIST":("relative_footprint","cross","single_target"),"SPEAR":("vertical_column","immediately_behind","one_horizontal_neighbor"),"STAFF":("horizontal_row","cross","vertical_column")};target_pool=(tuple(x for x in TARGETING_POOL if x!="all_enemies" or r.tier=="LEGENDARY") if policy_version=="v0.1" else family_targets.get(r.family,TARGETING_POOL)+(("all_enemies",) if r.tier=="LEGENDARY" else ()))
 targeting=rng.choice(target_pool);trigger=rng.choice(TRIGGER_PREDICATES);scope="ACTION" if policy_version=="v0.1" else rng.choice(PREDICATE_SCOPE_COMPATIBILITY[trigger]);role="attempt_paid_reactive" if trigger in ("successful_parry","ally_targeted_by_enemy_attack") else ("success_paid_effect" if trigger in ("successful_hit","effective_attack_damage") else "reward");passive_timing="AFTER_SUCCESSFUL_EVENT" if policy_version=="v0.1" else MECHANIC_COST_TIMING[role][0]
 topology=_build_topology(r,template,cid)
 action_count=5 if template in TEMPLATE_GROUPS["LEGENDARY_B"] else (2 if r.tier in ("HIGH","LEGENDARY") else 1)
 actions=tuple({"id":f"{cid}.action{i+1}","kind":"MAIN_ACTION" if i==0 else "ORDINARY_SPECIAL","targeting":targeting,"cost_timing":"ON_COMMITTED_ACTION","damage_coefficient":"TOKEN_BALANCE_TBD","value_category":"TOKEN_BALANCE_TBD"} for i in range(action_count))
 passives=({"id":cid+".passive1","trigger_scope":scope,"predicate":trigger,"cost_timing":passive_timing,"mechanic_role":role},)
 resources=({"id":cid+".resource1","initial":0,"maximum":3,"producer":actions[0]["id"],"consumer":actions[-1]["id"]},) if "combat_resource" in expanded else ()
 statuses=({"id":cid+".status1","producer":passives[0]["id"],"consumer":actions[0]["id"],"duration":"CONTENT_TBD"},) if "status" in expanded else ()
 stances=({"id":cid+".stance1","producer":actions[0]["id"],"consumer":passives[0]["id"]},) if "stance" in expanded else ()
 costs={x:TOKEN_COSTS[x] for x in expanded if x in TOKEN_COSTS};unknown=tuple(sorted(x for x in expanded if x not in TOKEN_COSTS and x not in TARGETING_POOL and x not in TRIGGER_PREDICATES))
 plan=TokenAllocationPlan(costs,unknown,r.target_budget)
 prov=MechanicProvenance("MARTIAL_GENERATOR_"+policy_version.upper().replace(".","_"),r.request_id,template,"TOPOLOGY_FIRST",tuple(sorted(expanded)),generation_seed=r.generation_seed,generation_attempt_count=1)
 return GeneratedMartialCandidate(cid,r.family,r.tier,r.target_budget,actions,passives,resources,statuses,stances,topology,tuple(sorted(expanded)),(targeting,),(trigger,),tuple(sorted({x["cost_timing"] for x in actions+passives})),(),("damage_coefficient",),(),"CANDIDATE_UNVALIDATED",prov,plan,False)

def validate_candidate(candidate):
 report=validate_generated_martial_candidate(candidate);blocking=list(report.blocking_reasons);notes=list(report.nonblocking_notes);diags=list(report.diagnostics)
 tr=validate_martial_topology(candidate.topology)
 if tr.diagnostics.isolated_nodes or tr.diagnostics.unreachable_nodes:blocking.append("DISCONNECTED_NODE")
 if any(not p.get("predicate") for p in candidate.passives):blocking.append("DEAD_PASSIVE")
 for resource in candidate.resources:
  if not resource.get("consumer"):notes.append("UNSPENDABLE_RESOURCE")
  if not resource.get("producer") and not resource.get("external_source"):blocking.append("UNPRODUCIBLE_RESOURCE")
  if resource.get("initial",0)==0 and resource.get("producer_requires_resource"):blocking.append("CIRCULAR_IMPOSSIBLE_RESOURCE_GATE")
 if any(p.get("condition_reachable") is False for p in candidate.passives):blocking.append("ALWAYS_DEAD_BRANCH")
 if candidate.topology.rule_privileges and not candidate.topology.uses_composite_action:blocking.append("UNUSED_RULE_PRIVILEGE")
 blocking=tuple(dict.fromkeys(blocking));indeterminate=bool(candidate.token_plan and candidate.token_plan.unknown_cost_ids);elig=("BLOCKED_BY_QUALITY" if blocking else ("REVIEW_REQUIRED" if indeterminate else report.runtime_eligibility));classification=("INVALID_ARCHITECTURE" if blocking else ("REVIEW_REQUIRED" if indeterminate else report.candidate_classification))
 return MartialCandidateValidationReport(report.schema_result,report.tier_result,report.topology_result,report.capability_result,report.policy_result,report.content_result,elig,classification,tuple(diags),blocking,tuple(dict.fromkeys(notes)))

def _trace(c):
 mix="+".join(sorted({n.state_carrier for n in c.topology.nodes if n.state_carrier}|({"COMPOSITE_STAGE"} if c.topology.uses_composite_action else set())));predicate=c.trigger_requirements[0] if c.trigger_requirements else "";cost="+".join(c.cost_timing_requirements);novelty=int(hashlib.sha256(str(mechanism_signature(c)).encode()).hexdigest()[:8],16)/0xffffffff
 return GenerationTrace(c.provenance.template_id,{n.node_id:n.node_type.value for n in c.topology.nodes},c.capability_requirements,asdict(c.token_plan),c.provenance.generation_attempt_count,c.provenance.generation_seed,c.provenance.generated_by,c.provenance.template_id,mix,predicate,cost,round(novelty,6),0)
def generate_and_validate(request):
 out=generate_candidate(request)
 if isinstance(out,GenerationFailureReport):return GenerationResult(None,out,None,None)
 report=validate_candidate(out);return GenerationResult(out,None,report,_trace(out))

def generate_and_validate_runtime_complete(request):
 """Route-aware opt-in lifecycle; default generation behavior stays reproducible."""
 base=generate_and_validate(request)
 from .runtime_numeric_completion import CONTRACT_VERSION
 from .legendary_route_a_semantic_binding import BINDING_VERSION,DURATION_BINDINGS,COOLDOWN_BINDING,semantic_binding_hash,diagnostic_overlay
 required=request.content_constraints.get("runtime_numeric_completion_contract")
 binding=request.content_constraints.get("route_a_semantic_binding_version")
 if required!=CONTRACT_VERSION or binding!=BINDING_VERSION:
  return RuntimeCompletedGenerationResult(base,None,None,binding or "UNBOUND",semantic_binding_hash(),required or "UNBOUND",request.content_constraints.get("numeric_policy_version","UNBOUND"),("structural_generation","SEMANTIC_BINDING_REQUIRED"))
 if base.candidate is None:return RuntimeCompletedGenerationResult(base,None,None,BINDING_VERSION,semantic_binding_hash(),CONTRACT_VERSION,"v0.3",("structural_generation","generation_failure"))
 # The completion contract addresses JSON-style list paths.  Normalize the
 # immutable generator tuples at this lifecycle boundary before invoking it.
 payload=json.loads(json.dumps(asdict(base.candidate),ensure_ascii=False));completion,overlay=diagnostic_overlay(payload)
 if overlay:
  overlay.pop("historical_overlay_classification",None);overlay.pop("not_a_revision",None);overlay.pop("parent_candidate_id",None)
  overlay["canonical"]=False;overlay["authority"]="GENERATED_CONTENT";overlay["runtime_completion_phase"]="GENERATOR_LIFECYCLE"
  template=overlay["provenance"]["template_id"];duration_binding=DURATION_BINDINGS[template]
  overlay["statuses"][0].update({"semantic_id":duration_binding["status_semantic_id"],"category":duration_binding["category"],"duration_unit":duration_binding["duration_unit"],"reapplication_mode":duration_binding["reapplication_mode"],"duration_domain":list(duration_binding["allowed_domain"])})
  if template==COOLDOWN_BINDING["template"]:overlay["actions"][1].update({"cooldown_semantic_type":"FINITE_ACTION_COOLDOWN","cooldown_domain":list(COOLDOWN_BINDING["allowed_domain"])})
 return RuntimeCompletedGenerationResult(base,overlay,completion,BINDING_VERSION,semantic_binding_hash(),CONTRACT_VERSION,"v0.3",("structural_generation","route_a_semantic_binding","runtime_numeric_completion","token_valuation","content_completeness","topology_validation"))

def generate_and_validate_route_a_v02(request):
 """Fresh Route-A v0.2 lifecycle; returns a complete noncanonical snapshot."""
 from .legendary_route_a_semantic_binding_v02 import BINDING_VERSION as V2,complete_c3_diagnostic,semantic_binding_hash as v2_hash
 if request.content_constraints.get("route_a_semantic_binding_v02")!=V2:return {"status":"SEMANTIC_BINDING_REQUIRED","candidate":None}
 base=generate_and_validate_runtime_complete(request)
 if base.completed_candidate is None:return {"status":"GENERATION_OR_BASE_COMPLETION_FAILED","candidate":None,"base":base}
 c=base.completed_candidate;raw=asdict(base.base_result.candidate);known=sum(raw["token_plan"]["known_costs"].values());delta=sum(x.token_delta or 0 for x in base.completion_result.results)
 summary={"candidate_id":c["candidate_id"],"candidate_sha256":hashlib.sha256(json.dumps(c,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()).hexdigest(),"seed":raw["provenance"]["generation_seed"],"template":raw["provenance"]["template_id"],"generation_request_id":raw["provenance"]["generation_request_id"],"coefficient_blockers":[{"action_id":a["id"]} for a in c["actions"]],"resource_economies":[{"resource_id":r["id"],"M":r["maximum"],"producer":r["producer"],"consumer":r["consumer"]} for r in c["resources"]],"token":{"budget":c["budget"],"partial_known_total":known+delta}}
 completed=complete_c3_diagnostic(summary)
 if completed["overlay"] is None:return {"status":completed["status"],"candidate":None,"base":base,"completion":completed}
 final=json.loads(json.dumps(c,ensure_ascii=False));co=completed["overlay"]
 for i,a in enumerate(final["actions"]):a["damage_coefficient"]=co["actions"][i]["damage_coefficient"];a["value_category"]="FIRST_PASS_GENERATED_VALUE"
 for i,r in enumerate(final["resources"]):r.update({"representative_gain":co["resources"][i]["representative_gain"],"threshold":co["resources"][i]["threshold"],"consume":co["resources"][i]["consume"]})
 final.update({"semantic_binding_version":V2,"semantic_binding_sha256":v2_hash(),"runtime_completion_phase":"GENERATOR_LIFECYCLE","manual_postprocess":False,"authority":"GENERATED_CONTENT","canonical":False,"content_complete":True,"token_total":co["final_total"],"budget_status":co["budget_status"],"final_balance_locked":False,"completion_stack":["structural_generation","LEGENDARY_ROUTE_A_NUMERIC_SEMANTIC_BINDING_V0_2","RUNTIME_NUMERIC_CONTENT_COMPLETION_V0_1","Numeric Token Policy v0.3","content completeness","Route A qualification","formal/compiler readiness","reviewability gate"]})
 final["snapshot_sha256"]=hashlib.sha256(json.dumps(final,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()).hexdigest()
 return {"status":"ACTUAL_REVIEW_READY","candidate":final,"base":base,"completion":completed,"manual_postprocess":False}
def evaluate_numeric_token_budget(candidate,**kwargs):
 """Generator/content-accounting access to the versioned numeric policy; selection is untouched."""
 from .numeric_token_valuation import evaluate_candidate_numeric_budget
 return evaluate_candidate_numeric_budget(candidate,**kwargs)
def generate_batch(requests):return tuple(generate_and_validate(r) for r in requests)

def serialize_candidate(candidate):return json.dumps(candidate_as_dict(candidate),sort_keys=True,separators=(",",":"),ensure_ascii=False)
def deserialize_candidate(data):
 raw=json.loads(data);t=raw.pop("topology");nodes=tuple(__import__("battle_core.topology",fromlist=["MechanismNodeDefinition"]).MechanismNodeDefinition(x["node_id"],__import__("battle_core.topology",fromlist=["MechanismNodeType"]).MechanismNodeType(x["node_type"]),x.get("state_carrier"),x.get("runtime_capability",""),x.get("meaningful",True),x.get("content_tbd",False)) for x in t.pop("nodes"));edges=tuple(__import__("battle_core.topology",fromlist=["TopologyEdgeDefinition"]).TopologyEdgeDefinition(x["from_node"],x["to_node"],__import__("battle_core.topology",fromlist=["TopologyEdgeType"]).TopologyEdgeType(x["edge_type"]),x.get("condition","ALWAYS"),x.get("bounded",True),x.get("cross_action",False)) for x in t.pop("edges"));
 for key in ("entry_nodes","feedback_nodes","rule_privileges"):t[key]=tuple(t[key])
 raw["topology"]=MartialTopologyDefinition(nodes=nodes,edges=edges,**t)
 for key in ("actions","passives","resources","statuses","stances","capability_requirements","targeting_requirements","trigger_requirements","cost_timing_requirements","open_policy_dependencies","content_tbd","tuning_placeholders"):raw[key]=tuple(raw[key])
 if raw.get("provenance") is not None:raw["provenance"]=MechanicProvenance(**{**raw["provenance"],"canonical_capability_ids":tuple(raw["provenance"]["canonical_capability_ids"])})
 if raw.get("token_plan") is not None:raw["token_plan"]=TokenAllocationPlan(**{**raw["token_plan"],"unknown_cost_ids":tuple(raw["token_plan"]["unknown_cost_ids"])})
 return GeneratedMartialCandidate(**raw)
def serialize_validation_report(report):return json.dumps(asdict(report),sort_keys=True,separators=(",",":"),ensure_ascii=False)
def deserialize_validation_report(data):
 raw=json.loads(data)
 for key in ("diagnostics","blocking_reasons","nonblocking_notes"):raw[key]=tuple(raw[key])
 return MartialCandidateValidationReport(**raw)

MARTIAL_GENERATOR_READINESS_MATRIX={"Tier Contract":"READY","Topology Templates":"READY","Capability Registry":"READY","Definition Schema":"READY","Policy Check":"READY","Content Classification":"READY","Token Budget Integration":"READY","Runtime Eligibility":"READY","Duplicate Warning":"READY","Generation Seed Isolation":"READY","Golden Cases":"READY"}
GENERATOR_REMAINING_GAPS=({"severity":"P2","id":"GEN-V1-BATCH-DIVERSITY","description":"Large-batch diversity and duplicate-rate evaluation remains WO-034 work"},)
MARTIAL_GENERATOR_DECISION="MARTIAL_GENERATOR_READY_FOR_PROTOTYPE"
MARTIAL_GENERATOR_STATUS="MARTIAL_GENERATOR_V0_1_PROTOTYPE_OPERATIONAL"
CURRENT_MARTIAL_GENERATOR_STATUS="MARTIAL_GENERATOR_V0_2_PROTOTYPE_OPERATIONAL"
MARTIAL_GENERATOR_PRODUCTION_READY=False
GOLDEN_REPRESENTATIVES={"ADVANCED":5,"HIGH":4,"LEGENDARY_ROUTE_A":"staff_legendary_qingtian_zhenyu","LEGENDARY_ROUTE_B":"sword_legendary_zixiao_jianjue"}

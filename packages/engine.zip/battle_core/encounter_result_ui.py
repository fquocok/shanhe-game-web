"""Traditional-Chinese developer UI for the WO-077 result handoff prototype."""
from __future__ import annotations

from pathlib import Path

from .encounter_result import EncounterResultDelivery, result_summary_zh
from .encounter_roster_variation import ENCOUNTER_VARIANTS
from .game_facing_encounter import encounter_configuration
from .interactive_battle_screen import TkBattleScreen

DEFEAT_SMOKE_ENCOUNTER_ID = "encounter:prototype:defeat_smoke_1v1"
RESULT_ENCOUNTER_VARIANTS = ENCOUNTER_VARIANTS + ((
    "敗北驗證用遭遇戰（開發測試／預期玩家敗北）", DEFEAT_SMOKE_ENCOUNTER_ID,
),)


class EncounterResultBattleScreen(TkBattleScreen):
    def __init__(self, root, workspace, configuration, loader, on_result, on_battle_reset=None):
        self._result_delivery = None
        self._result_loader = loader
        self._on_result = on_result
        self._on_battle_reset = on_battle_reset
        super().__init__(root, workspace, configuration=configuration)
        self._result_delivery = EncounterResultDelivery(loader.last_composition, on_result)

    @property
    def result_delivery(self):
        return self._result_delivery

    def render(self):
        super().render()
        if self._result_delivery is not None:
            self._result_delivery.observe_session(self.session)

    def _reset(self):
        self._auto_callback_generation = None
        self.session.reset()
        self._result_delivery.begin_battle(self._result_loader.last_composition)
        if self._on_battle_reset is not None:
            self._on_battle_reset(self._result_loader.last_composition.encounter_instance_id)
        self._on_result(None)
        self.render()


def main(argv=None):
    import argparse
    import tkinter as tk
    from tkinter import ttk

    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", default=".")
    args = parser.parse_args(argv)
    workspace = Path(args.workspace).resolve()

    root = tk.Tk()
    root.title("遭遇戰結果契約原型（開發用）")
    root.geometry("760x640")
    frame = ttk.Frame(root, padding=16)
    frame.pack(fill="both", expand=True)
    ttk.Label(frame, text="遭遇戰結果契約｜Battle → Upstream",
              font=("Microsoft JhengHei UI", 16, "bold")).pack(anchor="w")
    ttk.Label(frame, text="結果只描述戰鬥事實，不發放獎勵、不修改任務或世界狀態。",
              foreground="#7a4a12").pack(anchor="w", pady=(4, 12))
    selected = tk.StringVar(value=RESULT_ENCOUNTER_VARIANTS[0][1])
    ttk.Label(frame, text="遭遇戰").pack(anchor="w")
    encounter_labels = {encounter_id: label for label, encounter_id in RESULT_ENCOUNTER_VARIANTS}
    selected_label = tk.StringVar(value=RESULT_ENCOUNTER_VARIANTS[0][0])
    ttk.Combobox(frame, textvariable=selected_label, values=tuple(x[0] for x in RESULT_ENCOUNTER_VARIANTS),
                 state="readonly", width=60).pack(fill="x", pady=(2, 8))
    result_box = tk.Text(frame, wrap="word", font=("Microsoft JhengHei UI", 10), height=24)
    result_box.pack(fill="both", expand=True, pady=(10, 0))

    def show_result(result):
        result_box.delete("1.0", "end")
        result_box.insert("end", "戰鬥尚未完成。結果會在最後演出結束後顯示。" if result is None
                          else result_summary_zh(result))

    battle_windows = []

    def launch_battle():
        selected.set(next(encounter_id for encounter_id, label in encounter_labels.items() if label == selected_label.get()))
        configuration, loader = encounter_configuration(workspace, selected.get())
        window = tk.Toplevel(root)
        battle_windows.append(EncounterResultBattleScreen(window, workspace, configuration, loader, show_result))
        show_result(None)

    ttk.Button(frame, text="開始遭遇戰", command=launch_battle).pack(fill="x", pady=(0, 4))
    show_result(None)
    root.mainloop()


if __name__ == "__main__":
    main()

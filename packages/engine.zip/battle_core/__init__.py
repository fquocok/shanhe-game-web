"""UI-independent deterministic battle core for CODEX-WO-001."""

from .engine import BattleEngine, BattleResult
from .ai import ActionDefinition
from .schema import CharacterDefinition, ValidationError, validate_characters
from .status import StatusDefinition
from .trigger import SpecialActionTemplate, TriggerDefinition
from .targeting import TargetingSpec
from .runtime import ShieldSourcePolicyRegistry
from .martial import (MartialCapabilityRegistry, MartialRoutineDefinition,
                      MartialValidationError, compile_anchor, extract_anchor,
                      load_martial_yaml, validate_martial_definition)
from .inner_skill import (InnerSkillCapabilityRegistry, InnerSkillDefinition,
                          InnerSkillSlotDefinition, InnerSkillValidationError,
                          compile_inner_skill, extract_inner_skill_anchor,
                          load_inner_skill_yaml)
from .lightness import (ExplorationProfile, LightnessCapabilityRegistry,
                        LightnessSkillDefinition, LightnessSlotDefinition,
                        LightnessValidationError, compile_lightness,
                        extract_lightness_anchor, load_lightness_yaml)

__all__ = ["ActionDefinition", "BattleEngine", "BattleResult", "CharacterDefinition",
           "SpecialActionTemplate", "StatusDefinition", "TargetingSpec", "TriggerDefinition",
           "ValidationError", "validate_characters"]
__all__ += ["ShieldSourcePolicyRegistry"]
__all__ += ["MartialCapabilityRegistry", "MartialRoutineDefinition",
            "MartialValidationError", "compile_anchor", "extract_anchor", "load_martial_yaml"]
__all__ += ["validate_martial_definition"]
__all__ += ["InnerSkillCapabilityRegistry", "InnerSkillDefinition",
            "InnerSkillSlotDefinition", "InnerSkillValidationError",
            "compile_inner_skill", "extract_inner_skill_anchor", "load_inner_skill_yaml"]
__all__ += ["ExplorationProfile", "LightnessCapabilityRegistry",
            "LightnessSkillDefinition", "LightnessSlotDefinition",
            "LightnessValidationError", "compile_lightness",
            "extract_lightness_anchor", "load_lightness_yaml"]

"""Declarative martial topology metadata and tier validator; never a scheduler."""
from dataclasses import dataclass
from enum import Enum

class MechanismNodeType(str,Enum):
 ACTION="ACTION";ATTACK="ATTACK";TRIGGER="TRIGGER";RESOURCE="RESOURCE";STATUS="STATUS";STANCE="STANCE";COOLDOWN="COOLDOWN";TARGETING="TARGETING";DEFENSIVE_EVENT="DEFENSIVE_EVENT";OUTCOME_PREDICATE="OUTCOME_PREDICATE";NON_ACTION_EFFECT="NON_ACTION_EFFECT";DIAGNOSTIC="DIAGNOSTIC"
class TopologyEdgeType(str,Enum):
 PRODUCES="PRODUCES";CONSUMES="CONSUMES";ENABLES="ENABLES";GATES="GATES";TRANSITIONS="TRANSITIONS";AMPLIFIES="AMPLIFIES";REDUCES_COOLDOWN="REDUCES_COOLDOWN";FEEDS_BACK="FEEDS_BACK"

@dataclass(frozen=True)
class MechanismNodeDefinition:
 node_id:str;node_type:MechanismNodeType;state_carrier:str|None=None;runtime_capability:str="";meaningful:bool=True;content_tbd:bool=False
@dataclass(frozen=True)
class TopologyEdgeDefinition:
 from_node:str;to_node:str;edge_type:TopologyEdgeType;condition:str="ALWAYS";bounded:bool=True;cross_action:bool=False
@dataclass(frozen=True)
class MartialTopologyDefinition:
 topology_id:str;tier:str;nodes:tuple[MechanismNodeDefinition,...];edges:tuple[TopologyEdgeDefinition,...];entry_nodes:tuple[str,...];feedback_nodes:tuple[str,...]=();expected_cycles:int=0;uses_composite_action:bool=False;coupled_subloops:int=0;token_budget:int|None=None;family:str|None=None;rule_privileges:tuple[str,...]=();build_controlled_chain_depth:bool=False;build_variable:str|None=None
@dataclass(frozen=True)
class TopologyDiagnostics:
 cycle_count:int;meaningful_cycle_count:int;cycles:tuple[tuple[str,...],...];isolated_nodes:tuple[str,...];unreachable_nodes:tuple[str,...];state_carrier_types:tuple[str,...];action_stage_usage:bool;cross_action_feedback:bool
@dataclass(frozen=True)
class TopologyValidationResult:
 status:str;diagnostics:TopologyDiagnostics;reasons:tuple[str,...]=();qualification_route:str|None=None;rule_privilege:str|None=None;family_contract:str|None=None

MEANINGFUL_TYPES={MechanismNodeType.ACTION,MechanismNodeType.RESOURCE,MechanismNodeType.STATUS,MechanismNodeType.STANCE,MechanismNodeType.COOLDOWN,MechanismNodeType.DEFENSIVE_EVENT,MechanismNodeType.OUTCOME_PREDICATE,MechanismNodeType.TARGETING,MechanismNodeType.TRIGGER}
LEGENDARY_RULE_PRIVILEGE_REGISTRY={"COMPOSITE_COMBO_ACTION":{"tier":"LEGENDARY","requires_composite_usage":True,"minimum_stage_nodes":5}}
LEGENDARY_FAMILY_CONTRACTS={"SWORD":{"privilege":"COMPOSITE_COMBO_ACTION","requirement":"BUILD_CONTROLLED_CHAIN_DEPTH"}}

def _cycles(nodes,adj):
 found=set()
 def walk(start,current,path,seen):
  for nxt in adj[current]:
   if nxt==start:
    cyc=path[:]
    rots=[tuple(cyc[i:]+cyc[:i]) for i in range(len(cyc))];found.add(min(rots))
   elif nxt not in seen:walk(start,nxt,path+[nxt],seen|{nxt})
 for n in sorted(nodes):walk(n,n,[n],{n})
 return tuple(sorted(found))

def validate_martial_topology(d:MartialTopologyDefinition)->TopologyValidationResult:
 ids=[n.node_id for n in d.nodes];known=set(ids);reasons=[]
 if len(ids)!=len(known):reasons.append("DUPLICATE_NODE_ID")
 if not d.entry_nodes or not set(d.entry_nodes)<=known:reasons.append("INVALID_ENTRY_NODE")
 adj={x:[] for x in known};degree={x:0 for x in known}
 for e in d.edges:
  if e.from_node not in known or e.to_node not in known:reasons.append("MISSING_EDGE_NODE");continue
  adj[e.from_node].append(e.to_node);degree[e.from_node]+=1;degree[e.to_node]+=1
 cycles=_cycles(known,adj)
 by={n.node_id:n for n in d.nodes}
 meaningful=tuple(c for c in cycles if len({x for x in c if by[x].meaningful and by[x].node_type in MEANINGFUL_TYPES})>=3)
 reach=set();stack=list(d.entry_nodes)
 while stack:
  n=stack.pop()
  if n in reach:continue
  reach.add(n);stack.extend(adj.get(n,()))
 isolated=tuple(sorted(x for x,v in degree.items() if v==0));unreachable=tuple(sorted(known-reach))
 carriers=tuple(sorted({n.state_carrier for n in d.nodes if n.state_carrier}))
 diag=TopologyDiagnostics(len(cycles),len(meaningful),cycles,isolated,unreachable,carriers,d.uses_composite_action,any(e.cross_action for e in d.edges))
 if reasons:return TopologyValidationResult("INVALID",diag,tuple(reasons))
 if d.rule_privileges and d.tier!="LEGENDARY":return TopologyValidationResult("INVALID_UNAUTHORIZED_RULE_PRIVILEGE",diag,("LEGENDARY_PRIVILEGE_TIER_ONLY",))
 if d.tier=="ADVANCED":
  return TopologyValidationResult("VALID" if not unreachable else "WARN",diag,(() if not unreachable else ("UNREACHABLE_NODE",)))
 if d.tier=="HIGH":
  if not meaningful:return TopologyValidationResult("INVALID_NO_CLOSED_ENGINE",diag,("HIGH_REQUIRES_MEANINGFUL_CYCLE",))
  status="VALID_WITH_CONTENT_TBD" if any(n.content_tbd for n in d.nodes) else "VALID"
  return TopologyValidationResult(status,diag)
 if d.tier=="LEGENDARY":
  if d.rule_privileges:
   if len(d.rule_privileges)!=1 or d.rule_privileges[0] not in LEGENDARY_RULE_PRIVILEGE_REGISTRY:return TopologyValidationResult("INVALID_UNKNOWN_RULE_PRIVILEGE",diag,("UNREGISTERED_PRIVILEGE",))
   privilege=d.rule_privileges[0];contract=LEGENDARY_RULE_PRIVILEGE_REGISTRY[privilege]
   if contract["requires_composite_usage"] and not d.uses_composite_action:return TopologyValidationResult("INVALID_UNUSED_RULE_PRIVILEGE",diag,("PRIVILEGE_DECLARED_BUT_UNUSED",))
   if len(d.nodes)<contract["minimum_stage_nodes"]:return TopologyValidationResult("INVALID_ONLY_HIGH_COMPLEXITY",diag,("INSUFFICIENT_COMPOSITE_STRUCTURE",))
   family=(d.family or "").upper();family_contract=LEGENDARY_FAMILY_CONTRACTS.get(family)
   if family_contract and family_contract["privilege"]==privilege and not d.build_controlled_chain_depth:return TopologyValidationResult("INVALID_FAMILY_CONTRACT",diag,(family_contract["requirement"],))
   return TopologyValidationResult("VALID_LEGENDARY",diag,(),"LEGENDARY_RULE_PRIVILEGE",privilege,None if not family_contract else family_contract["requirement"])
  if not meaningful:return TopologyValidationResult("INVALID_NO_CLOSED_ENGINE",diag,("LEGENDARY_REQUIRES_CLOSED_ENGINE",))
  if isolated or unreachable:return TopologyValidationResult("INVALID_DISCONNECTED_COMPLEXITY",diag,("DISCONNECTED_COMPLEXITY",))
  composite=d.uses_composite_action or d.coupled_subloops>=2 or len(carriers)>=3
  if len(carriers)<2:return TopologyValidationResult("INVALID_ONLY_HIGH_COMPLEXITY",diag,("REQUIRES_TWO_CARRIERS",))
  if not diag.cross_action_feedback:return TopologyValidationResult("INVALID_ONLY_HIGH_COMPLEXITY",diag,("REQUIRES_CROSS_ACTION_OR_STAGE_FEEDBACK",))
  if not composite:return TopologyValidationResult("INVALID_ONLY_HIGH_COMPLEXITY",diag,("REQUIRES_COMPOSITE_OR_COUPLED_ENGINE",))
  return TopologyValidationResult("VALID_LEGENDARY",diag,(),"COMPOSITE_CLOSED_ENGINE")
 return TopologyValidationResult("VALID",diag)

def high_reference_topologies():
 def n(i,t,c=None,tbd=False):return MechanismNodeDefinition(i,t,c,i,True,tbd)
 def e(a,b,x=TopologyEdgeType.ENABLES):return TopologyEdgeDefinition(a,b,x,cross_action=True)
 return {
  "staff_high_bafang_zhenyue":MartialTopologyDefinition("closed_guard_counter_sweep_guard_loop","HIGH",(n("parry",MechanismNodeType.DEFENSIVE_EVENT),n("zhen",MechanismNodeType.RESOURCE,"RESOURCE"),n("counter",MechanismNodeType.ACTION),n("ironwall",MechanismNodeType.STATUS,"STATUS")),(e("parry","zhen"),e("zhen","counter"),e("counter","ironwall"),e("ironwall","parry",TopologyEdgeType.FEEDS_BACK)),("parry",),("parry",),1),
  "sword_high_sixiang_jianjue":MartialTopologyDefinition("exclusive_closed_stance_cycle","HIGH",tuple(n(x,MechanismNodeType.STANCE,"STANCE") for x in ("azure","white","vermilion","black")),tuple(e(a,b,TopologyEdgeType.TRANSITIONS) for a,b in (("azure","white"),("white","vermilion"),("vermilion","black"),("black","azure"))),("azure",),("azure",),1),
  "blade_high_xuezhan_sanshi":MartialTopologyDefinition("status_driven_closed_loop","HIGH",(n("extra",MechanismNodeType.ACTION),n("wound",MechanismNodeType.STATUS,"STATUS",True),n("gate",MechanismNodeType.OUTCOME_PREDICATE),n("combo",MechanismNodeType.TRIGGER)),(e("extra","wound"),e("wound","gate"),e("gate","combo"),e("combo","extra",TopologyEdgeType.FEEDS_BACK)),("extra",),("extra",),1),
  "spear_high_lianying_pojun":MartialTopologyDefinition("closed_kill_momentum_loop","HIGH",(n("group",MechanismNodeType.ACTION),n("momentum",MechanismNodeType.RESOURCE,"RESOURCE"),n("special",MechanismNodeType.ACTION),n("cooldown",MechanismNodeType.COOLDOWN,"COOLDOWN")),(e("group","momentum"),e("momentum","special"),e("special","cooldown"),e("cooldown","group",TopologyEdgeType.FEEDS_BACK)),("group",),("group",),1),
 }

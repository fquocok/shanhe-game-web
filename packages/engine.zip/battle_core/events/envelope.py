"""Deeply immutable, deterministically serializable semantic facts."""
from dataclasses import dataclass, field
from enum import Enum
import json
import math
from types import MappingProxyType

from .types import DamageOrigin, EventPhase, SemanticEventType, SemanticEventValidationError


def canonical_json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False)


def freeze(value, ancestors=frozenset()):
    if isinstance(value, Enum):
        return freeze(value.value, ancestors)
    if value is None or type(value) in (str, bool, int):
        return value
    if type(value) is float and math.isfinite(value):
        return value
    if type(value) not in (dict, MappingProxyType, list, tuple, set, frozenset):
        raise SemanticEventValidationError("Payload requires finite JSON values or built-in containers")
    if id(value) in ancestors:
        raise SemanticEventValidationError("Cyclic payload")
    ancestors = ancestors | {id(value)}
    if type(value) in (dict, MappingProxyType):
        if any(type(key) is not str for key in value):
            raise SemanticEventValidationError("Payload keys must be strings")
        return MappingProxyType({key: freeze(value[key], ancestors) for key in sorted(value)})
    items = tuple(freeze(item, ancestors) for item in value)
    # Sets become a deterministically ordered immutable sequence, including nested mappings.
    if type(value) in (set, frozenset):
        items = tuple(sorted(items, key=lambda item: canonical_json(thaw(item))))
    return items


def thaw(value):
    if isinstance(value, MappingProxyType):
        return {key: thaw(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return [thaw(item) for item in value]
    return value


@dataclass(frozen=True, slots=True)
class SemanticEventEnvelope:
    stream_id: str
    event_id: str
    sequence: int
    event_type: SemanticEventType
    phase: EventPhase
    causation_event_id: str | None = None
    parent_event_id: str | None = None
    formal_turn_id: str | None = None
    action_id: str | None = None
    attack_instance_id: str | None = None
    actor_id: str | None = None
    source_combatant_id: str | None = None
    original_target_id: str | None = None
    actual_recipient_id: str | None = None
    damage_origin: DamageOrigin | None = None
    share_receiver_id: str | None = None
    damage_recipient_id: str | None = None
    effect_instance_id: str | None = None
    status_instance_id: str | None = None
    payload: object = field(default_factory=dict)
    target_chain_id: str | None = None

    def __post_init__(self):
        from .taxonomy import validate_event
        if type(self.sequence) is not int or self.sequence < 1:
            raise SemanticEventValidationError("Sequence must be a positive integer")
        for name in self.__dataclass_fields__:
            if name.endswith("_id"):
                value = getattr(self, name)
                if value is not None and (type(value) is not str or not value):
                    raise SemanticEventValidationError(name + " must be a nonempty string")
        if not self.stream_id or self.event_id != f"{self.stream_id}:event:{self.sequence:08d}":
            raise SemanticEventValidationError("Noncanonical event identity")
        if type(self.payload) not in (dict, MappingProxyType):
            raise SemanticEventValidationError("Payload must be a mapping")
        object.__setattr__(self, "payload", freeze(self.payload))
        validate_event(self)

    def to_dict(self):
        return {name: (getattr(self, name).value if isinstance(getattr(self, name), Enum)
                       else thaw(getattr(self, name)))
                for name in self.__dataclass_fields__}

    def serialize(self):
        return canonical_json(self.to_dict())

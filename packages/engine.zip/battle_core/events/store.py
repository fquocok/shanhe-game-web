"""Append-only observation store, with fail-closed internal causality."""
from .envelope import SemanticEventEnvelope, canonical_json
from .types import SemanticEventType, SemanticEventValidationError, UnknownEventReferenceError


class SemanticEventStore:
    __slots__ = ("_stream_id", "_events", "_by_id")

    def __init__(self, stream_id):
        if type(stream_id) is not str or not stream_id:
            raise SemanticEventValidationError("Nonempty stream ID required")
        self._stream_id = stream_id
        self._events = []
        self._by_id = {}

    @property
    def stream_id(self):
        return self._stream_id

    @property
    def history(self):
        return tuple(self._events)

    def append(self, event_type, phase, *, causation_event_id=None,
               parent_event_id=None, formal_turn_id=None, action_id=None,
               attack_instance_id=None, actor_id=None, source_combatant_id=None,
               original_target_id=None, actual_recipient_id=None,
               damage_origin=None, share_receiver_id=None, damage_recipient_id=None,
               effect_instance_id=None, status_instance_id=None, payload=None, target_chain_id=None):
        sequence = len(self._events) + 1
        event = SemanticEventEnvelope(
            stream_id=self._stream_id,
            event_id=f"{self._stream_id}:event:{sequence:08d}", sequence=sequence,
            event_type=event_type, phase=phase, causation_event_id=causation_event_id,
            parent_event_id=parent_event_id, formal_turn_id=formal_turn_id,
            action_id=action_id, attack_instance_id=attack_instance_id,
            actor_id=actor_id, source_combatant_id=source_combatant_id, target_chain_id=target_chain_id,
            original_target_id=original_target_id, actual_recipient_id=actual_recipient_id,
            damage_origin=damage_origin, share_receiver_id=share_receiver_id,
            damage_recipient_id=damage_recipient_id, effect_instance_id=effect_instance_id,
            status_instance_id=status_instance_id, payload={} if payload is None else payload)
        for reference in (event.causation_event_id, event.parent_event_id):
            if reference is not None and reference not in self._by_id:
                raise UnknownEventReferenceError("Unknown internal event reference: " + reference)
        self._events.append(event)
        self._by_id[event.event_id] = event
        return event

    def get(self, event_id):
        try:
            return self._by_id[event_id]
        except KeyError:
            raise UnknownEventReferenceError("Unknown event ID: " + event_id) from None

    def by_type(self, event_type):
        if not isinstance(event_type, SemanticEventType):
            raise SemanticEventValidationError("Typed event type required")
        return tuple(event for event in self._events if event.event_type == event_type)

    def to_data(self):
        return [event.to_dict() for event in self._events]

    def serialize(self):
        return canonical_json(self.to_data())

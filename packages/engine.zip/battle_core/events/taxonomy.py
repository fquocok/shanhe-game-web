"""Validate recorded facts, never resolve gameplay or infer missing facts."""
import math
from .types import DamageOrigin, EventPhase, SemanticEventType as T, SemanticEventValidationError as Error


def validate_event(event):
    if not isinstance(event.event_type, T) or not isinstance(event.phase, EventPhase):
        raise Error("Typed event type and phase required")
    if event.damage_origin is not None and not isinstance(event.damage_origin, DamageOrigin):
        raise Error("Typed damage origin required")
    payload = event.payload
    # Identity roles belong to explicit envelope fields, never an overloaded target_id.
    reserved = set(event.__dataclass_fields__) - {"payload"}
    if "target_id" in payload or reserved.intersection(payload):
        raise Error("Identity/header fields must use the explicit envelope schema")

    def require(*names):
        if any(getattr(event, name) is None for name in names):
            raise Error("Missing event identity: " + ", ".join(names))

    attack = event.event_type.name.startswith("ATTACK_")
    if attack:
        require("attack_instance_id")
        if not (event.actor_id or event.source_combatant_id):
            raise Error("Attack fact requires attacker identity")
        if event.damage_origin not in (None, DamageOrigin.ATTACK_INSTANCE):
            raise Error("Attack fact cannot claim a non-attack origin")
    if event.event_type in (T.ATTACK_TARGET_SELECTED, T.ATTACK_RECIPIENT_CONFIRMED):
        require("original_target_id")
    if event.event_type in (T.ATTACK_RECIPIENT_CONFIRMED,
                            T.ATTACK_SUCCESSFUL_HIT_CONFIRMED,
                            T.ATTACK_EFFECTIVE_DAMAGE_CONFIRMED):
        require("actual_recipient_id")
    if event.event_type == T.ATTACK_EFFECTIVE_DAMAGE_CONFIRMED:
        amount = payload.get("final_damage_before_shield")
        if payload.get("successful_hit") is not True:
            raise Error("Effective attack damage requires explicit successful hit")
        if type(amount) not in (int, float) or (type(amount) is float and not math.isfinite(amount)) or amount <= 0:
            raise Error("Effective attack damage requires settled pre-shield damage > 0")
    if event.event_type == T.ATTACK_SUCCESSFUL_HIT_CONFIRMED:
        if "successful_hit" in payload and payload["successful_hit"] is not True:
            raise Error("Successful hit fact cannot declare a failed hit")
    if event.event_type == T.DAMAGE_SOURCE_SETTLEMENT_COMPLETED:
        if event.damage_origin is None:
            raise Error("Damage settlement requires explicit origin")
        if event.damage_origin == DamageOrigin.ATTACK_INSTANCE:
            require("attack_instance_id", "actual_recipient_id")
        else:
            require("damage_recipient_id")
    if event.damage_origin not in (None, DamageOrigin.ATTACK_INSTANCE):
        # WO087: a transfer retains original Attack provenance without becoming
        # an Attack/contact. All other non-Attack facts retain the strict firewall.
        if event.event_type != T.SHARED_DAMAGE_TRANSFER_SETTLED and (
                event.attack_instance_id is not None or event.actual_recipient_id is not None):
            raise Error("Non-attack settlement uses damage/share recipient, not attack identities")
        if any(key in payload for key in ("successful_hit", "actual_attack_recipient")):
            raise Error("Non-attack damage cannot manufacture hit semantics")
    if event.event_type == T.SHARED_DAMAGE_TRANSFER_SETTLED:
        require("share_receiver_id")
        if event.damage_origin != DamageOrigin.SHARED_DAMAGE_TRANSFER:
            raise Error("Shared transfer requires its distinct damage origin")
    elif event.share_receiver_id is not None:
        raise Error("Share receiver identity belongs to a shared transfer fact")
    if event.event_type in (T.ATTACK_DODGE_CONFIRMED, T.ATTACK_PARRY_CONFIRMED):
        require("actual_recipient_id")
        if event.phase != EventPhase.DAMAGE_SETTLEMENT:
            raise Error("Dodge/Parry facts require DAMAGE_SETTLEMENT")
    if event.event_type == T.ATTACK_DODGE_CONFIRMED:
        if ("dodge_success" in payload and payload["dodge_success"] is not True
                or payload.get("successful_hit") is True):
            raise Error("Dodge cannot claim a failed Dodge or successful hit")
    if event.event_type == T.ATTACK_PARRY_CONFIRMED:
        if (payload.get("parry_success") is not True
                or "dodge_success" in payload and payload["dodge_success"] is not False
                or "successful_hit" in payload and payload["successful_hit"] is not True):
            raise Error("Parry requires success and cannot claim Dodge/failed hit")
    if event.event_type in (T.ACTION_OUTCOME_FINALIZED,
                            T.SPECIAL_ACTION_STARTED, T.SPECIAL_ACTION_COMPLETED):
        require("formal_turn_id", "action_id", "actor_id")
        classification = payload.get("action_classification")
        if type(classification) is not str or not classification:
            raise Error("Explicit action classification required")
        if event.event_type == T.ACTION_OUTCOME_FINALIZED:
            if type(payload.get("successfully_deals_damage")) is not bool:
                raise Error("Explicit finalized damage boolean required")
            expected = (EventPhase.FORMAL_ACTION if classification == "formal_main"
                        else EventPhase.SPECIAL_ACTION)
            if event.phase != expected:
                raise Error("Action outcome phase must match classification")
        elif (event.phase != EventPhase.SPECIAL_ACTION
              or payload.get("counts_as_turn") is not False
              or classification == "formal_main"):
            raise Error("Special is not a Formal Main action/turn")
    # No lifecycle transition graph or phase scheduler is imposed here.
    # Event names record distinct facts; they do not mutate or authorize transitions.

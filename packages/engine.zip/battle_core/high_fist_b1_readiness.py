"""Read-only WO-037B audit of immutable selected High Fist candidate B1."""
from __future__ import annotations
from hashlib import sha256
from pathlib import Path
import json

from .durable_generated_registry import DEFAULT_REGISTRY_PATH, load_generated_registry
from .generated_acceptance import stable_hash
from .generator import deserialize_candidate
from .numeric_token_valuation import evaluate_candidate_numeric_budget

TOKEN = "WO037-B1"
CANDIDATE_ID = "gen_v01_high_fist_f56a8c141194"
SEED = 211


def _json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def audit_wo037b(workspace: str | Path) -> dict:
    root = Path(workspace)
    lane = root / "generated_candidates/wo037/lane_b_high_fist"
    candidate_path = lane / "pool/seed_211.json"
    trace_path = lane / "traces/seed_211.json"
    validation_path = lane / "validations/seed_211.json"
    old_review_path = lane / "review_packages/WO037-B1.json"
    registry_path = root / DEFAULT_REGISTRY_PATH
    candidate_bytes = candidate_path.read_bytes()
    registry_bytes = registry_path.read_bytes()
    raw = _json(candidate_path); trace = _json(trace_path)
    validation = _json(validation_path); old_review = _json(old_review_path)
    candidate = deserialize_candidate(candidate_bytes.decode("utf-8"))
    numeric = evaluate_candidate_numeric_budget(candidate, policy_version="v0.2")
    nodes = raw["topology"]["nodes"]; edges = raw["topology"]["edges"]
    resource = raw["resources"][0]
    gaps = [
        {"field_path":"actions[0].damage_coefficient","current_value":"TOKEN_BALANCE_TBD","classification":"FIRST_PASS_TUNING_TBD","why":"Main attack damage cannot execute canonically.","allowed":"finite number >= 0","topology_effect":"none","token_effect":"absolute coefficient surcharge indeterminate"},
        {"field_path":"actions[1].damage_coefficient","current_value":"TOKEN_BALANCE_TBD","classification":"FIRST_PASS_TUNING_TBD","why":"Special attack damage cannot execute canonically.","allowed":"finite number >= 0","topology_effect":"none","token_effect":"absolute coefficient surcharge indeterminate"},
        {"field_path":"resources[0].gain_amount","current_value":None,"classification":"STRUCTURAL_CONTENT_TBD","why":"Producer cannot mutate the resource without an amount.","allowed":"integer >= 1","topology_effect":"entry cannot reach carrier threshold","token_effect":"RESOURCE_AMOUNT_TOKEN_POLICY_TBD"},
        {"field_path":"resources[0].consume_amount","current_value":None,"classification":"STRUCTURAL_CONTENT_TBD","why":"Consumer cost cannot be settled.","allowed":"integer >= 1 or explicit consume-all","topology_effect":"special gate and repeatability undefined","token_effect":"RESOURCE_AMOUNT_TOKEN_POLICY_TBD"},
        {"field_path":"resources[0].required_threshold","current_value":None,"classification":"STRUCTURAL_CONTENT_TBD","why":"ENABLES edge has no executable condition.","allowed":"integer 1..3","topology_effect":"carrier-to-special edge cannot fire","token_effect":"RESOURCE_THRESHOLD_TOKEN_POLICY_TBD"},
        {"field_path":"resources[0].consume_timing","current_value":None,"classification":"STRUCTURAL_CONTENT_TBD","why":"Canonical cost settlement point is ambiguous.","allowed":"registered cost timing","topology_effect":"event ordering undefined","token_effect":"none until amount known"},
        {"field_path":"resources[0].atomicity","current_value":None,"classification":"STRUCTURAL_CONTENT_TBD","why":"Insufficient-resource behavior is undefined.","allowed":"ATOMIC_ALL_OR_NOTHING","topology_effect":"consumer legality undefined","token_effect":"none"},
        {"field_path":"resources[0].refund_policy","current_value":None,"classification":"STRUCTURAL_CONTENT_TBD","why":"Attempt-paid failure behavior is undefined.","allowed":"NO_REFUND_AFTER_COST_SETTLEMENT or explicit registered policy","topology_effect":"loop economy undefined","token_effect":"none"},
        {"field_path":"passives[0].feedback_effect","current_value":None,"classification":"STRUCTURAL_CONTENT_TBD","why":"PARRY_SUCCESS has no authored produced state/action.","allowed":"registered resource/action/status effect descriptor","topology_effect":"feedback-to-main edge is non-executable","token_effect":"depends on selected effect"},
        {"field_path":"actions[*].target_contract","current_value":None,"classification":"STRUCTURAL_CONTENT_TBD","why":"single_target lacks primary/no-target/retarget rules.","allowed":"canonical single-target descriptor","topology_effect":"action target resolution undefined","token_effect":"single target count itself adds 0"},
    ]
    graph = {"nodes":nodes,"edges":edges,"meaningful_node_count":len([n for n in nodes if n["meaningful"]]),
             "claimed_cycle":True,"executable_cycle":False}
    dead = {"producer_without_legal_consumer":True,"consumer_without_executable_gate":True,
            "threshold_reachable":False,"feedback_edge_can_fire":False,"test_only_initialization_required":True}
    known = sum(raw["token_plan"]["known_costs"].values())
    policy_gaps = ["RESOURCE_MAX_TOKEN_POLICY_TBD","RESOURCE_GAIN_AMOUNT_TOKEN_POLICY_TBD",
                   "RESOURCE_CONSUME_AMOUNT_TOKEN_POLICY_TBD","RESOURCE_THRESHOLD_TOKEN_POLICY_TBD"]
    status = "PASS_STOPPED_AT_HUMAN_CONTENT_DECISION"
    review = {"review_package_schema":"WO037B-v0.1","selection_token":TOKEN,"candidate_id":CANDIDATE_ID,
              "candidate_sha256":sha256(candidate_bytes).hexdigest(),"seed":SEED,"family":"FIST","tier":"HIGH","budget":168,
              "high_qualification":"STRUCTURAL_TBD","four_node_graph":graph,"loop_entry":"MAIN_ACTION exists, but resource production amount is absent",
              "loop_maintenance":"NOT_EXECUTABLE","loop_break":["undefined threshold/consume semantics","PARRY_SUCCESS effect absent","ordinary Special cap3","no legal target","owner defeated"],
              "loop_reentry":"UNRESOLVED","actions":raw["actions"],"resources":raw["resources"],"statuses":[],
              "targeting":["single_target descriptor incomplete"],"trigger":{"fact":"PARRY_SUCCESS","source_value":"successful_parry","scope":"ATTACK","effect":None},
              "content_tbds":gaps,"token_accounting":{"mechanic_subtotal":known,"numeric_subtotal":None,"used":None,"remaining":None,"budget":168,"status":"BUDGET_INDETERMINATE"},
              "numeric_policy_gaps":policy_gaps,"compiler_readiness":"READY_AFTER_HUMAN_CONTENT_DECISION","formal_similarity":"DISTINCT",
              "primary_risk":"NON_EXECUTABLE_FEEDBACK_EDGE","review_state":"PENDING_REVIEW","human_decision":"NONE"}
    review["immutable_sha256"] = stable_hash(review)
    loaded = load_generated_registry(root)
    result = {"work_order":"CODEX-WO-037B","status":status,"selection_token":TOKEN,"candidate_id":CANDIDATE_ID,
      "candidate_sha256":sha256(candidate_bytes).hexdigest(),"seed":SEED,"generator_version":"v0.2-prototype","template":trace["selected_template"],
      "family":raw["family"],"tier":raw["tier"],"budget":raw["budget"],"source_artifacts":{"candidate":True,"trace":True,"validation":True,"token_plan":True,"wo037_review":True,"selection_mapping":True,"mechanism_signature":True,"topology":True},
      "high_qualification":{"classification":"STRUCTURAL_TBD","meaningful_node_count":4,"exceeds_advanced":"CLAIMED_FEEDBACK_EDGE_BUT_NOT_EXECUTABLE","graph":graph,"dead_loop_guard":dead,"unbounded_loop":False,"same_event_recursion":"BOUNDED_BY_CROSS_ACTION_EDGE_AND_CAP3_IF_SPECIAL_BECOMES_EXECUTABLE"},
      "loop":{"entry":"BLOCKED: default resource 0 and gain amount absent","maintenance":"BLOCKED: consume/gain/feedback semantics absent","break":["ordinary Special cap3","target unavailable","owner defeated","undefined resource gate"],"reentry":"BLOCKED: feedback effect absent"},
      "resource":{"id":resource["id"],"initial":0,"maximum":3,"producer":resource["producer"],"consumer":resource["consumer"],"gain_amount":None,"consume_amount":None,"threshold":None,"timing":None,"atomicity":None,"refund":None,"clamp":"maximum 3 implies clamp but clamp operation is not authored","persistence":"battle-local presumed by engine, not content-authored","ownership":"martial owner","represented_as":"COMBAT_RESOURCE_NOT_STATUS"},
      "parry":{"fact":"PARRY_SUCCESS","source_predicate":"successful_parry","scope":"ATTACK","role":"UNRESOLVED_FEEDBACK_EFFECT"},
      "actions":[{"id":raw["actions"][0]["id"],"class":"MAIN_ACTION","targeting":"single_target","coefficient":None},{"id":raw["actions"][1]["id"],"class":"NEW_ORDINARY_SPECIAL_ACTION","cap":3,"targeting":"single_target","coefficient":None}],
      "statuses":[],"content_gaps":gaps,"token":{"mechanic_subtotal":known,"v0.2_evaluator_status":numeric.status,"unresolved_coefficients":list(numeric.unresolved_components),"policy_gaps":policy_gaps,"used":None,"remaining":None,"budget":168,"status":"BUDGET_INDETERMINATE","unknown_cost_treated_as_zero":False},
      "double_charge":{"status":"PASS","combat_resource":24,"ordinary_special":24,"trigger_scope":10,"action_identity":30,"attack_instance":20,"topology_cost":"NO_SEPARATE_REGISTERED_HIGH_TOPOLOGY_COST","unknown_numeric_not_charged_as_zero":True},
      "compiler_readiness":"READY_AFTER_HUMAN_CONTENT_DECISION","formal_similarity":"DISTINCT","cross_tier":"GENUINELY_HIGH_ONLY_IF_FEEDBACK_IS_AUTHORED; CURRENTLY_STRUCTURAL_TBD",
      "review_package":review,"governance":{"candidate_revisions":0,"generator_calls":0,"rerolls":0,"human_decisions":0,"accepts":0,"promotion_attempts":0,"canonical_previews":0,"staging_promotions":0,"durable_commits":0,"formal_name_generated":False,"lane_a":"CLOSED","lane_c":"DEFERRED"},
      "registry":{"before":[loaded.count,len(loaded.runtime),loaded.count],"after":[loaded.count,len(loaded.runtime),loaded.count],"bytes_unchanged":registry_path.read_bytes()==registry_bytes},
      "immutability":{"candidate_before":sha256(candidate_bytes).hexdigest(),"candidate_after":sha256(candidate_path.read_bytes()).hexdigest(),"unchanged":candidate_path.read_bytes()==candidate_bytes},
      "versions":{"battle":"v0.9","generator":"v0.2-prototype","acceptance":"v0.1-prototype","numeric_policy":"v0.2","registry_schema":"v0.1"},
      "source_validation":validation,"source_review_hash":old_review["immutable_sha256"]}
    return result

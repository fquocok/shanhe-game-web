from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Any, Callable, Mapping


TRIGGER_SCOPES = {"TURN_SCOPE", "ACTION_SCOPE", "ATTACK_SCOPE"}
ORDINARY_SPECIAL_KINDS = {"counterattack", "follow_up", "assist_attack", "revenge_attack"}


@dataclass(frozen=True)
class SpecialActionTemplate:
    id: str
    kind: str
    target_selector: str = "enemy_of_owner"
    attack_coefficient: float = 1.0
    classification: str = "ordinary_special"
    executor: Callable[..., None] | None = None
    attack_tags: frozenset[str] = field(default_factory=lambda: frozenset({"special_action"}))
    targeting_pattern: str = "single"
    requested_target_count: int | None = None

    @property
    def counts_as_turn(self) -> bool:
        return False

    @property
    def counts_ordinary_budget(self) -> bool:
        return self.classification == "ordinary_special" and self.kind in ORDINARY_SPECIAL_KINDS


@dataclass(frozen=True)
class TriggerDefinition:
    id: str
    owner_id: str
    event_type: str
    scope: str
    base_probability: float
    priority: int
    action_template: SpecialActionTemplate
    enabled: bool = True
    condition: Callable[[Any, Mapping[str, Any], Any], bool] | None = None
    counts_ordinary_budget: bool = True
    probability_resolver: Callable[[Any, Any], float] | None = None
    source_martial_id: str | None = None
    martial_event_kind: str | None = None
    attempt_settler: Callable[[Any, Mapping[str, Any], Any], bool] | None = None
    commit_settler: Callable[[Any, Mapping[str, Any], Any, str], None] | None = None
    coefficient_resolver: Callable[[Any, Mapping[str, Any], Any], float] | None = None

    def __post_init__(self):
        if self.scope not in TRIGGER_SCOPES:
            raise ValueError(f"未知 Trigger scope：{self.scope}")
        if not self.id or not self.owner_id or not self.event_type:
            raise ValueError("Trigger id/owner_id/event_type 不可為空")


@dataclass
class TriggerRuntime:
    attempts: int = 0
    successes: int = 0
    current_probability: float | None = None


@dataclass
class FormalTurnContext:
    formal_turn_id: str
    actor_id: str
    ordinary_budget_used: int = 0
    decay: dict[tuple[str, str], TriggerRuntime] = field(default_factory=dict)
    seen_opportunities: set[tuple[str, str]] = field(default_factory=set)
    next_action_number: int = 1
    next_candidate_number: int = 1


@dataclass(frozen=True)
class TriggerCandidate:
    sequence: int
    definition: TriggerDefinition
    event: Mapping[str, Any]
    effective_probability: float
    roll: float
    resolved_coefficient: float | None = None
    resolved_action_template: SpecialActionTemplate | None = None
    canonical_source_ref: object | None = None

@dataclass(frozen=True)
class CounterTargetingTransformationDefinition:
    id: str
    owner_id: str
    source_trigger_type: str
    required_status_id: str
    replacement_targeting: str
    anchor_policy: str = "ORIGINAL_ATTACKER_SLOT"
    owner_scope: str = "SELF"
    preserve_action_identity: bool = True
    preserve_damage_profile: bool = True
    preserve_cost: bool = True
    preserve_chance: bool = True
    preserve_cap_usage: bool = True
    creates_counter: bool = False

def apply_counter_targeting_transformation(definition,template,*,counter_owner_id,trigger_source_type,active_status_ids):
    """Pure modifier: never creates a Counter and changes targeting metadata only."""
    eligible=(template.kind=="counterattack" and definition.owner_scope=="SELF" and definition.owner_id==counter_owner_id
              and trigger_source_type==definition.source_trigger_type
              and definition.required_status_id in active_status_ids)
    if not eligible:return template,None
    transformed=replace(template,targeting_pattern=definition.replacement_targeting)
    return transformed,{"transformation_id":definition.id,"counter_owner_id":counter_owner_id,
        "trigger_source_type":trigger_source_type,"before_pattern":template.targeting_pattern,
        "after_pattern":transformed.targeting_pattern,"anchor_policy":definition.anchor_policy,
        "transformation_applied":True,"semantic_pattern_change":template.targeting_pattern!=transformed.targeting_pattern,
        "creates_counter":False,"preserved_action_identity":True,"preserved_damage_profile":True,
        "preserved_cost":True,"preserved_chance":True,"preserved_cap_usage":True}


class SpecialActionManager:
    def __init__(self, engine, event_sink):
        self.engine = engine
        self._event = event_sink
        self._queue: list[TriggerCandidate] = []
        self._draining = False

    def queue(self, candidate: TriggerCandidate):
        from .trigger_migration.queue_drain_executor import enqueue_special_candidate
        return enqueue_special_candidate(self, candidate)

    def drain(self):
        from .trigger_migration.queue_drain_executor import drain_special_candidates
        return drain_special_candidates(self)


class TriggerEngine:
    ORDINARY_CAP = 3

    def __init__(self, engine, rng, event_sink):
        self.engine = engine
        self.rng = rng
        self._event = event_sink
        self._definitions: list[TriggerDefinition] = []
        self.special_actions = SpecialActionManager(engine, event_sink)
        self.counter_targeting_transformations: list[CounterTargetingTransformationDefinition] = []

    def register_counter_targeting_transformation(self,definition):
        if any(x.id==definition.id and x.owner_id==definition.owner_id for x in self.counter_targeting_transformations):raise ValueError(f"重複 Counter transformation：{definition.owner_id}/{definition.id}")
        if definition.creates_counter:raise ValueError("Counter targeting transformation 不得建立 Counter")
        self.counter_targeting_transformations.append(definition)

    def register(self, definition: TriggerDefinition):
        if any(d.owner_id == definition.owner_id and d.id == definition.id for d in self._definitions):
            raise ValueError(f"重複 Trigger：{definition.owner_id}/{definition.id}")
        self._definitions.append(definition)

    def _scope_key(self, definition, event):
        if definition.scope == "TURN_SCOPE":
            value = event.get("formal_turn_id")
        elif definition.scope == "ACTION_SCOPE":
            value = event.get("action_id")
        else:
            value = event.get("attack_instance_id")
        return None if value is None else f"{definition.scope}:{value}"

    def handle_event(self, event_type: str, event: Mapping[str, Any], *, canonical_source_ref=None):
        from .trigger_migration.opportunity_evaluation_executor import execute_trigger_opportunity_evaluation
        return execute_trigger_opportunity_evaluation(self, event_type, event, canonical_source_ref=canonical_source_ref)

    def execute_candidate(self, candidate: TriggerCandidate):
        from .trigger_migration.candidate_admission_executor import execute_candidate_admission
        return execute_candidate_admission(self, candidate)

    def complete_formal_turn(self):
        context = self.engine.trigger_context
        if context is None:
            return
        for (owner_id, trigger_id), runtime in sorted(context.decay.items()):
            self._event("TRIGGER_DECAY_RESET", trigger=trigger_id, owner=owner_id,
                        attempts=runtime.attempts, successes=runtime.successes,
                        parent_formal_turn_id=context.formal_turn_id)

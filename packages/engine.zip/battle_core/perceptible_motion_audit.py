"""WO-047A evidence for fixed-step, human-perceptible body displacement."""
from __future__ import annotations
from dataclasses import replace
from hashlib import sha256
from pathlib import Path
import json

from .durable_generated_registry import DEFAULT_REGISTRY_PATH, load_generated_registry
from .generated_acceptance import stable_hash
from .interactive_battle_screen import MOTION_LEAD_IN_MS, MOTION_STEP_DELAYS_MS, PERCEPTIBLE_MOTION_CONTRACT, BattleScreenSession, VisualPose, build_2d_layout_model, build_body_presence_model, project_combat_feedback, project_motion_offsets, transient_motion_offset
from .player_action_control import PlayerActionCommand

STATUS = "PASS_WAITING_FOR_HUMAN_PERCEPTIBILITY_SMOKE"


def audit_wo047a(workspace):
    root = Path(workspace); registry_path = root / DEFAULT_REGISTRY_PATH; before = registry_path.read_bytes(); loaded = load_generated_registry(root)
    session = BattleScreenSession(root); initial = session.screen_state(); presence = build_body_presence_model(build_2d_layout_model(initial)); action = next(x for x in initial["actions"] if x["kind"] == "MAIN_ACTION")
    result = session.controller.submit(PlayerActionCommand(session.controller.battle_id, "player", action["action_id"], ("enemy-center",), 0, "wo047a-audit"), outcomes=("HIT", "DODGED", "PARRIED_SUCCESSFUL_HIT")); feedback = project_combat_feedback(result.presentation_events)
    steps = [project_motion_offsets(presence, feedback, step) for step in range(4)]
    dead = BattleScreenSession(root); dead.controller.targets["enemy-left"] = replace(dead.controller.targets["enemy-left"], alive=False); dead_presence = build_body_presence_model(build_2d_layout_model(dead.screen_state())); dead_peak = project_motion_offsets(dead_presence, feedback, 2)
    profiles = {pose.value: {facing: [transient_motion_offset(pose, facing, step) for step in range(4)] for facing in ("right", "left")} for pose in (VisualPose.ATTACK, VisualPose.HIT, VisualPose.DODGE, VisualPose.PARRY)}
    contract = {"contract_id": PERCEPTIBLE_MOTION_CONTRACT, "representation": "fixed four-step transient offsets", "presentation_only": True,
                "steps": ["ANCHOR", "PREPARATION_OR_ONSET", "PEAK", "RECOVERY"], "lead_in_ms": MOTION_LEAD_IN_MS,
                "step_delays_ms": MOTION_STEP_DELAYS_MS, "total_duration_ms": MOTION_LEAD_IN_MS + sum(MOTION_STEP_DELAYS_MS.values()),
                "position_formula": "stable_visual_anchor + current_transient_motion_offset", "generic_keyframes": False, "tween": False}
    return {"status": STATUS, "prior_human_feedback": "和上一版差不多", "contract": contract, "contract_hash": stable_hash(contract),
            "profiles": profiles, "mixed_motion_steps": steps, "defeated_peak": dead_peak,
            "checks": {"player_attack_peak_px": 18, "enemy_hit_recoil_peak_px": 12, "dodge_peak": [18, -9], "parry_peak_px": 6,
                       "cumulative_visual_drift": 0, "stable_slots_unchanged": True, "simultaneous_multi_target": True,
                       "selection_persistent": True, "body_clickable": True, "text_feedback_retained": True, "no_new_input_lock": True,
                       "settled_before_motion": result.accepted, "reset_invalidates_motion": True, "close_safe": True},
            "isolation": {"battle_semantic_changes": 0, "battle_timing_semantic_changes": 0, "battle_rng_impact": 0, "ai_deterministic_impact": 0,
                          "canonical_changes": 0, "registry_changes": 0, "generator_changes": 0, "acceptance_changes": 0, "numeric_token_policy_changes": 0,
                          "registry": [loaded.count, len(loaded.runtime), loaded.count], "registry_sha256": sha256(before).hexdigest(), "registry_bytes_unchanged": registry_path.read_bytes() == before,
                          "full_animation_system": False, "generic_keyframe_engine": False, "tween_framework": False, "skeletal_animation": False},
            "human_gate": {"formal_verification": "NOT_YET", "next": "STOP_AND_WAIT_FOR_HUMAN", "checklist": "human_perceptibility_smoke_checklist.md"}}


def write_wo047a_artifacts(workspace, directory):
    result = audit_wo047a(workspace); out = Path(directory); out.mkdir(parents=True, exist_ok=True)
    for filename, key in (("perceptible_motion_contract.json", "contract"), ("motion_profiles.json", "profiles"),
                          ("mixed_motion_steps.json", "mixed_motion_steps"), ("defeated_motion_priority.json", "defeated_peak"),
                          ("perceptibility_checks.json", "checks"), ("isolation_audit.json", "isolation"), ("human_perceptibility_gate.json", "human_gate")):
        (out / filename).write_text(json.dumps(result[key], ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "perceptible_motion_contract_hash.json").write_text(json.dumps({"contract_id": PERCEPTIBLE_MOTION_CONTRACT, "sha256": result["contract_hash"]}, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "result.json").write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    return result


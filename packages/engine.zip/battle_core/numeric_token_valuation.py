"""Human-authored numeric token economics v0.1 (content accounting only)."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from decimal import Decimal, ROUND_CEILING, InvalidOperation
from pathlib import Path
from typing import Any
import json

NUMERIC_TOKEN_VALUATION_POLICY_VERSION = "v0.1"
CURRENT_NUMERIC_TOKEN_VALUATION_POLICY_VERSION = "v0.3"
NUMERIC_TOKEN_VALUATION_AUTHORITY = "HUMAN_AUTHORED_TOKEN_POLICY"
NUMERIC_TOKEN_VALUATION_EFFECTIVE_WORK_ORDER = "CODEX-WO-036B1C"
NUMERIC_TOKEN_POLICY_SCOPE = "MIXED"
GLOBAL_NUMERIC_PRIMITIVE = "GLOBAL_NUMERIC_PRIMITIVE"
FAMILY_NUMERIC_VALUATION_OVERRIDES: dict[str, dict[str, Any]] = {}

NUMERIC_TOKEN_VALUATION_POLICIES = {
    "damage_coefficient_absolute_v0_1": {
        "input": "ABSOLUTE_COEFFICIENT", "baseline": "1.00", "step": "0.10",
        "token_cost_per_step": 4, "rounding": "CEILING", "negative_rebate": False,
        "scope": GLOBAL_NUMERIC_PRIMITIVE,
    },
    "status_duration_owner_formal_turns_v0_1": {
        "input": "FINITE_OWNER_FORMAL_TURNS", "included_turns": 1,
        "token_cost_per_additional_turn": 4, "minimum_duration": 1,
        "scope": GLOBAL_NUMERIC_PRIMITIVE,
    },
}
NUMERIC_TOKEN_VALUATION_POLICIES_V0_2 = {**NUMERIC_TOKEN_VALUATION_POLICIES,
    "percent_max_qi_action_cost_v0_2":{"input":"PERCENT_MAX_QI_ACTION_COST","neutral_baseline":30,"step":5,"token_cost_per_favorable_step":4,"direction":"LOWER_IS_STRONGER","no_negative_rebate":True,"scope":GLOBAL_NUMERIC_PRIMITIVE},
    "finite_action_cooldown_v0_2":{"input":"FINITE_ACTION_COOLDOWN","neutral_baseline":8,"token_cost_per_favorable_unit":2,"direction":"LOWER_IS_STRONGER","zero_excluded":True,"no_negative_rebate":True,"scope":GLOBAL_NUMERIC_PRIMITIVE},
    "base_trigger_success_chance_v0_2":{"input":"BASE_TRIGGER_SUCCESS_CHANCE","neutral_baseline_percent":50,"step_percent":10,"token_cost_per_favorable_step":2,"direction":"HIGHER_IS_STRONGER","no_negative_rebate":True,"scope":GLOBAL_NUMERIC_PRIMITIVE},
    "finite_distinct_target_count_v0_2":{"input":"FINITE_DISTINCT_TARGET_COUNT","neutral_baseline":1,"token_cost_per_additional_target":8,"scope":GLOBAL_NUMERIC_PRIMITIVE}}
NUMERIC_TOKEN_VALUATION_POLICIES_V0_3 = {**NUMERIC_TOKEN_VALUATION_POLICIES_V0_2,
    "finite_combat_resource_economy_v0_3":{"input":"FINITE_COMBAT_RESOURCE_ECONOMY","required_inputs":["maximum","representative_gain","threshold","consume"],"neutral":{"gain":1,"threshold":2,"consume":2,"maximum":2},"cycle_efficiency":"max(build_speed,repeat_efficiency); 8 if derived events=1 else 0","banking":"min(12,max(0,K-1)*4)","maximum_surcharge":20,"scope":GLOBAL_NUMERIC_PRIMITIVE}}


@dataclass(frozen=True)
class NumericTokenValuation:
    status: str
    valuation_category: str
    policy_id: str | None
    policy_version: str
    authority: str
    input_value: Any
    baseline: Any
    step_or_rate: Any
    calculated_cost: int | None
    family_scope: str
    family: str | None
    family_modifier: str
    effective_work_order: str
    source_derived: bool = False
    historical_source_gap: bool = True
    final_balance_locked: bool = False
    applied: bool = True
    note: str = ""


@dataclass(frozen=True)
class NumericCandidateBudgetEvaluation:
    status: str
    policy_version: str
    base_known_costs: dict[str, int]
    base_known_subtotal: int
    numeric_valuations: tuple[NumericTokenValuation, ...]
    numeric_subtotal: int | None
    total_used: int | None
    budget_limit: int | None
    remaining: int | None
    unresolved_components: tuple[str, ...]
    unknown_cost_treated_as_zero: bool
    double_charge_audit: dict[str, Any]


def _provenance(category, policy_id, value, baseline, rate, cost, family, **extra):
    return NumericTokenValuation(
        extra.pop("status", "RESOLVED"), category, policy_id,
        NUMERIC_TOKEN_VALUATION_POLICY_VERSION, NUMERIC_TOKEN_VALUATION_AUTHORITY,
        value, baseline, rate, cost, GLOBAL_NUMERIC_PRIMITIVE, family,
        "1.0 (global default; override registry empty)",
        NUMERIC_TOKEN_VALUATION_EFFECTIVE_WORK_ORDER, **extra,
    )


def evaluate_damage_coefficient(value, *, classification="ABSOLUTE_COEFFICIENT", family=None):
    if classification == "DERIVED_COEFFICIENT":
        return _provenance(classification, None, value, None, None, 0, family, applied=False, note="Priced through existing derived/follow-up capability; not independently surcharged.")
    if classification != "ABSOLUTE_COEFFICIENT":
        return _provenance(classification, None, value, None, None, None, family, status="TOKEN_COST_TBD", applied=False, note="Unsupported coefficient classification.")
    try: coefficient = Decimal(str(value))
    except (InvalidOperation, ValueError): raise ValueError("INVALID_DAMAGE_COEFFICIENT")
    if not coefficient.is_finite() or coefficient < 0: raise ValueError("INVALID_DAMAGE_COEFFICIENT")
    baseline, step = Decimal("1.00"), Decimal("0.10")
    steps = max(0, int(((coefficient - baseline) / step).to_integral_value(rounding=ROUND_CEILING)))
    return _provenance(classification, "damage_coefficient_absolute_v0_1", str(value), "1.00", "0.10 per 4 tokens; CEILING", steps * 4, family)


def evaluate_status_duration(value, *, unit="OWNER_FORMAL_TURNS", duration_kind="FINITE", family=None, refresh_count=None):
    if duration_kind != "FINITE":
        return _provenance(f"STATUS_DURATION_{duration_kind}", None, value, None, None, None, family, status="TOKEN_COST_TBD", applied=False, note="Permanent/until-consumed/until-event requires a separately registered policy.")
    if unit != "OWNER_FORMAL_TURNS":
        return _provenance("STATUS_DURATION_UNSUPPORTED_UNIT", None, value, None, None, None, family, status="TOKEN_COST_TBD", applied=False, note=f"No policy registered for {unit}.")
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ValueError("INVALID_ORDINARY_STATUS_DURATION")
    cost = max(0, value - 1) * 4
    return _provenance("FINITE_OWNER_FORMAL_TURNS", "status_duration_owner_formal_turns_v0_1", value, "first owner Formal Turn included", "+4 per additional owner Formal Turn", cost, family, note="Refresh count does not multiply configured-duration cost.")

def _v02(category,policy_id,value,baseline,rate,cost,family=None,note=""):
    return NumericTokenValuation("RESOLVED",category,policy_id,"v0.2",NUMERIC_TOKEN_VALUATION_AUTHORITY,value,baseline,rate,cost,GLOBAL_NUMERIC_PRIMITIVE,family,"1.0 (global default; override registry empty)","CODEX-WO-037A2",False,True,False,True,note)

def _v03(category,policy_id,value,baseline,rate,cost,family=None,note=""):
    return NumericTokenValuation("RESOLVED",category,policy_id,"v0.3",NUMERIC_TOKEN_VALUATION_AUTHORITY,value,baseline,rate,cost,GLOBAL_NUMERIC_PRIMITIVE,family,"1.0 (global default; override registry empty)","CODEX-WO-037B2",False,True,False,True,note)

def evaluate_finite_combat_resource_economy(maximum,gain,threshold,consume,*,initial=0,family=None,resource_count=1,uniform_gain=True,conversion=False,fractional=False):
    """Price one simple finite integer resource economy as a correlated unit."""
    if resource_count!=1:raise ValueError("MULTI_RESOURCE_ECONOMY_TOKEN_POLICY_TBD")
    if conversion:raise ValueError("RESOURCE_CONVERSION_TOKEN_POLICY_TBD")
    if fractional or any(isinstance(x,bool) or not isinstance(x,int) for x in (maximum,gain,threshold,consume,initial)):raise ValueError("FRACTIONAL_RESOURCE_TOKEN_POLICY_TBD")
    if initial>0:raise ValueError("INITIAL_RESOURCE_TOKEN_POLICY_TBD")
    if initial<0:raise ValueError("NEGATIVE_RESOURCE_UNSUPPORTED")
    if not uniform_gain:raise ValueError("NONUNIFORM_RESOURCE_GAIN_TOKEN_POLICY_TBD")
    if gain<=0:raise ValueError("INVALID_REPRESENTATIVE_RESOURCE_GAIN")
    if threshold<=0:raise ValueError("INVALID_RESOURCE_THRESHOLD")
    if consume<=0:raise ValueError("ZERO_CONSUME_RESOURCE_POLICY_TBD")
    if maximum<threshold:raise ValueError("RESOURCE_MAX_BELOW_THRESHOLD")
    if maximum<consume:raise ValueError("RESOURCE_MAX_BELOW_CONSUME")
    import math
    build=math.ceil(threshold/gain);rebuild=math.ceil(consume/gain);bankable=maximum//consume
    build_cost=8 if build==1 else 0;repeat_cost=8 if rebuild==1 else 0
    cycle=max(build_cost,repeat_cost);banking=min(12,max(0,bankable-1)*4);total=cycle+banking
    return _v03("FINITE_COMBAT_RESOURCE_ECONOMY","finite_combat_resource_economy_v0_3",{"M":maximum,"G":gain,"T":threshold,"C":consume,"B":build,"R":rebuild,"K":bankable},{"M":2,"G":1,"T":2,"C":2,"B":2,"R":2,"K":1},"cycle=max(build,repeat); banking=min(12,max(0,K-1)*4)",total,family,note=f"cycle={cycle}; banking={banking}; raw inputs are not independently charged")

def evaluate_percent_max_qi_action_cost(value,*,representation="PERCENT_MAX_QI_ACTION_COST",family=None):
    if representation!="PERCENT_MAX_QI_ACTION_COST":raise ValueError("UNSUPPORTED_QI_COST_REPRESENTATION")
    if isinstance(value,bool) or not isinstance(value,(int,float)) or value<0:raise ValueError("INVALID_NUMERIC_POLICY_INPUT")
    percent=float(value)*100 if value<=1 else float(value)
    if percent>100:raise ValueError("INVALID_NUMERIC_POLICY_INPUT")
    cost=max(0,int((30-percent+4.999999999)//5))*4
    return _v02(representation,"percent_max_qi_action_cost_v0_2",percent,30,"4 per 5 percentage points cheaper; CEILING",cost,family)

def evaluate_finite_action_cooldown(value,*,classification="FINITE_ACTION_COOLDOWN",family=None):
    if classification=="NO_COOLDOWN":raise ValueError("NO_COOLDOWN_POLICY_REQUIRED")
    if isinstance(value,bool) or not isinstance(value,int) or value<=0:raise ValueError("NO_COOLDOWN_POLICY_REQUIRED" if value==0 else "INVALID_NUMERIC_POLICY_INPUT")
    return _v02(classification,"finite_action_cooldown_v0_2",value,8,"2 per unit shorter",max(0,8-value)*2,family)

def evaluate_base_trigger_success_chance(value,*,family=None):
    if isinstance(value,bool) or not isinstance(value,(int,float)):raise ValueError("INVALID_NUMERIC_POLICY_INPUT")
    percent=float(value)*100 if value<=1 else float(value)
    if percent<0 or percent>100:raise ValueError("INVALID_NUMERIC_POLICY_INPUT")
    import math
    cost=max(0,math.ceil((percent-50)/10))*2
    return _v02("BASE_TRIGGER_SUCCESS_CHANCE","base_trigger_success_chance_v0_2",percent,50,"2 per 10 percentage points higher; CEILING",cost,family,note="Decay is not independently numerically charged.")

def evaluate_finite_distinct_target_count(value,*,selector="roaming_distinct",family=None):
    if selector in ("all_enemies","cross","relative_footprint","vertical_column","horizontal_row","immediately_behind"):raise ValueError("TARGET_SELECTOR_EXCLUDED_FROM_FINITE_DISTINCT_POLICY")
    if isinstance(value,bool) or not isinstance(value,int) or value<1:raise ValueError("INVALID_NUMERIC_POLICY_INPUT")
    return _v02("FINITE_DISTINCT_TARGET_COUNT","finite_distinct_target_count_v0_2",value,1,"8 per additional distinct target",(value-1)*8,family)


def evaluate_candidate_numeric_budget(candidate, *, duration_unit="OWNER_FORMAL_TURNS", coefficient_classifications=None, duration_kinds=None, policy_version="v0.1"):
    if policy_version not in ("v0.1","v0.2","v0.3"):raise ValueError("UNKNOWN_NUMERIC_TOKEN_POLICY_VERSION")
    coefficient_classifications = coefficient_classifications or {}
    duration_kinds = duration_kinds or {}
    valuations = []
    unresolved = []
    for index, action in enumerate(candidate.actions):
        value = action.get("damage_coefficient")
        path = f"actions[{index}].damage_coefficient"
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            valuation = evaluate_damage_coefficient(value, classification=coefficient_classifications.get(index, "ABSOLUTE_COEFFICIENT"), family=candidate.family)
            valuations.append(valuation)
            if valuation.calculated_cost is None: unresolved.append(path)
        elif value is not None: unresolved.append(path)
    for index, status in enumerate(candidate.statuses):
        value = status.get("duration")
        path = f"statuses[{index}].duration"
        if isinstance(value, int) and not isinstance(value, bool):
            valuation = evaluate_status_duration(value, unit=status.get("duration_unit", duration_unit), duration_kind=duration_kinds.get(index, "FINITE"), family=candidate.family)
            valuations.append(valuation)
            if valuation.calculated_cost is None: unresolved.append(path)
        elif value is not None: unresolved.append(path)
    if policy_version in ("v0.2","v0.3"):
        for index,action in enumerate(candidate.actions):
            if index==0 and "qi_cost_percent_max" in action:valuations.append(evaluate_percent_max_qi_action_cost(action["qi_cost_percent_max"],family=candidate.family))
            if index==0 and "cooldown" in action:valuations.append(evaluate_finite_action_cooldown(action["cooldown"],family=candidate.family))
            if "base_chance" in action:valuations.append(evaluate_base_trigger_success_chance(action["base_chance"],family=candidate.family))
            if "requested_target_count" in action:valuations.append(evaluate_finite_distinct_target_count(action["requested_target_count"],selector=action.get("targeting",""),family=candidate.family))
    if policy_version=="v0.3":
        for index,passive in enumerate(candidate.passives):
            if "base_chance" in passive:valuations.append(evaluate_base_trigger_success_chance(passive["base_chance"],family=candidate.family))
        for index,resource in enumerate(candidate.resources):
            try:
                producers=resource.get("producers",())
                amounts={x.get("amount") for x in producers}
                if not producers or None in amounts:raise ValueError("RESOURCE_GAIN_AMOUNT_TOKEN_POLICY_TBD")
                consumer=resource.get("consumer")
                if not isinstance(consumer,dict):raise ValueError("RESOURCE_CONSUMER_TOKEN_POLICY_TBD")
                valuations.append(evaluate_finite_combat_resource_economy(resource.get("maximum"),next(iter(amounts)),consumer.get("threshold"),consumer.get("consume"),initial=resource.get("initial",0),family=candidate.family,uniform_gain=len(amounts)==1))
            except ValueError as exc:unresolved.append(f"resources[{index}]:{exc}")
    base = dict(candidate.token_plan.known_costs) if candidate.token_plan else {}
    base_total = sum(base.values())
    numeric_total = None if unresolved else sum(x.calculated_cost or 0 for x in valuations)
    total = None if numeric_total is None else base_total + numeric_total
    limit = candidate.token_plan.target_budget if candidate.token_plan else candidate.budget
    remaining = None if total is None or limit is None else limit - total
    status = "BUDGET_INDETERMINATE" if total is None else ("BUDGET_OVERFLOW" if limit is not None and total > limit else "BUDGET_VALID")
    return NumericCandidateBudgetEvaluation(
        status, policy_version, base, base_total, tuple(valuations), numeric_total,
        total, limit, remaining, tuple(unresolved), False,
        {"status": "PASS_NO_EMBEDDED_NUMERIC_INTENSITY", "base_status_cost_prices": "STATUS_CARRIER_PRESENCE", "base_action_cost_prices": "ACTION/CAPABILITY_PRESENCE", "coefficient_intensity_already_included": False, "duration_persistence_already_included": False},
    )


def policy_registry_payload(version="v0.1"):
    if version not in ("v0.1","v0.2","v0.3"):raise ValueError("UNKNOWN_NUMERIC_TOKEN_POLICY_VERSION")
    return {
        "version": version,
        "authority": NUMERIC_TOKEN_VALUATION_AUTHORITY,
        "provenance": {"authority": "HUMAN", "source_derived": False, "historical_source_gap": True, "effective_from": NUMERIC_TOKEN_VALUATION_EFFECTIVE_WORK_ORDER, "final_balance_locked": False},
        "scope": NUMERIC_TOKEN_POLICY_SCOPE,
        "global_primitives": NUMERIC_TOKEN_VALUATION_POLICIES if version=="v0.1" else (NUMERIC_TOKEN_VALUATION_POLICIES_V0_2 if version=="v0.2" else NUMERIC_TOKEN_VALUATION_POLICIES_V0_3),
        "family_override_registry": FAMILY_NUMERIC_VALUATION_OVERRIDES,
    }


def write_policy_registry(path):
    target = Path(path); target.write_text(json.dumps(policy_registry_payload(), sort_keys=True, indent=2, ensure_ascii=False), encoding="utf-8"); return target

"""Developer-only WO-071 player + independent AI ally battle fixture."""
from __future__ import annotations
from pathlib import Path

from .game_facing_martial import CharacterMartialLoadout, GameFacingMartialService
from .interactive_battle_screen import SECONDARY_ID, BattleScreenConfiguration, TkBattleScreen
from .player_action_control import AI_CONTROLLED, PLAYER_CONTROLLED, ControlledParticipant, EncounterTarget, ManualCombatController

AI_ALLY_BATTLE_PARTICIPANT_CONTRACT = "AI_ALLY_BATTLE_PARTICIPANT_V0_1"
MULTI_FRIENDLY_TARGET_LEGALITY_CONTRACT = "MULTI_FRIENDLY_TARGET_LEGALITY_V0_1"
ALLY_RUNTIME_ID = "ally-test-01"
ALLY_DISPLAY_NAME = "測試隊友"
ALLY_FIXTURE_AUTHORITY = "NONCANONICAL_TEST_FIXTURE"
ALLY_ACTION_AUTHORITY = "NONCANONICAL_TEST_ACTION_SET"
SANDBOX_PLAYER_HP = 1000
SANDBOX_SURVIVABILITY_AUTHORITY = "DEV_SURVIVABILITY_FIXTURE_WO072C1"
ENEMY_ROSTER = ("enemy-left", "enemy-center", "enemy-right")
FRIENDLY_ROSTER = ("player", ALLY_RUNTIME_ID)

def create_ai_ally_battle_controller(workspace: str | Path) -> ManualCombatController:
    service = GameFacingMartialService(workspace)
    player = service.bind(CharacterMartialLoadout("player", "玩家刀客", (SECONDARY_ID,), SECONDARY_ID), max_hp=SANDBOX_PLAYER_HP, initial_qi=30)
    ally = service.bind(CharacterMartialLoadout(ALLY_RUNTIME_ID, ALLY_DISPLAY_NAME, (SECONDARY_ID,), SECONDARY_ID, ALLY_ACTION_AUTHORITY), max_hp=220, initial_qi=20)
    enemies = tuple(service.bind(CharacterMartialLoadout(identity, name, (SECONDARY_ID,), SECONDARY_ID), max_hp=180, initial_qi=20)
                    for identity, name in zip(ENEMY_ROSTER, ("敵人甲", "敵人乙", "敵人丙")))
    participants = (ControlledParticipant(player, PLAYER_CONTROLLED, "player"),
                    ControlledParticipant(ally, AI_CONTROLLED, "player"),
                    *(ControlledParticipant(enemy, AI_CONTROLLED, "enemy") for enemy in enemies))
    targets = (EncounterTarget("player", "玩家刀客", "player", "front", 0),
               EncounterTarget(ALLY_RUNTIME_ID, ALLY_DISPLAY_NAME, "player", "front", 1),
               *(EncounterTarget(identity, name, "enemy", "front", index) for index, (identity, name) in enumerate(zip(ENEMY_ROSTER, ("敵人甲", "敵人乙", "敵人丙")))))
    return ManualCombatController(service, "wo071-ai-ally-sandbox", participants, targets, "player")

def ai_ally_battle_configuration() -> BattleScreenConfiguration:
    return BattleScreenConfiguration(
        controller_factory=create_ai_ally_battle_controller,
        player_runtime_id="player", ai_runtime_id="enemy-center", player_target_id="player",
        actor_aliases={identity: identity for identity in (*FRIENDLY_ROSTER, *ENEMY_ROSTER)},
        window_title="AI Ally Battle Sandbox（開發用／非 Canon）",
        dev_banner=f"WO-071 AI Ally Sandbox｜NONCANONICAL TEST FIXTURE｜{SANDBOX_SURVIVABILITY_AUTHORITY}",
        formal_martial_status_label="ALLY FORMAL MARTIAL: NONE",
        formal_action_set_status_label="ALLY FORMAL ACTION SET: NONE",
        sandbox_action_set_status_label=ALLY_ACTION_AUTHORITY,
        enemy_response_actor_ids=ENEMY_ROSTER,
        friendly_ai_actor_ids=(ALLY_RUNTIME_ID,), friendly_target_order=FRIENDLY_ROSTER,
        enable_presentation_speed_control=True,
    )

def resolve_ally_only_battle(controller: ManualCombatController, max_cycles: int = 20) -> dict:
    """Deterministic sandbox continuation after player defeat; no initiative or party system."""
    trace=[]; cycles=0; engine=controller.service.settlement_bridge.engine
    while cycles < max_cycles:
        terminal=engine.terminal_outcome_for_roster(FRIENDLY_ROSTER, ENEMY_ROSTER)
        if terminal != "ACTIVE": return {"terminal_state":terminal,"cycles":cycles,"trace":tuple(trace),"deadlock":False}
        if not engine.state_by_id("player").defeated: return {"terminal_state":"ACTIVE","cycles":cycles,"trace":tuple(trace),"deadlock":False}
        if engine.state_by_id(ALLY_RUNTIME_ID).defeated: return {"terminal_state":"DEFEAT","cycles":cycles,"trace":tuple(trace),"deadlock":False}
        enemy_target=next((identity for identity in ENEMY_ROSTER if not engine.state_by_id(identity).defeated),None)
        if enemy_target is None: return {"terminal_state":"VICTORY","cycles":cycles,"trace":tuple(trace),"deadlock":False}
        trace.append(controller.continue_ai(ALLY_RUNTIME_ID,enemy_target))
        for enemy_id in ENEMY_ROSTER:
            if engine.terminal_outcome_for_roster(FRIENDLY_ROSTER, ENEMY_ROSTER) != "ACTIVE": break
            if engine.state_by_id(enemy_id).defeated: continue
            trace.append(controller.continue_ai(enemy_id,ALLY_RUNTIME_ID))
        controller.formal_turn += 1; cycles += 1
    return {"terminal_state":engine.terminal_outcome_for_roster(FRIENDLY_ROSTER, ENEMY_ROSTER),"cycles":cycles,"trace":tuple(trace),"deadlock":True}

def main(argv=None):
    import argparse
    import tkinter as tk
    parser=argparse.ArgumentParser();parser.add_argument("--workspace",default=".");args=parser.parse_args(argv)
    root = tk.Tk()
    TkBattleScreen(root, Path(args.workspace).resolve(), ai_ally_battle_configuration())
    root.mainloop()

if __name__ == "__main__": main()

"""Deterministic extent audit for the Character Art Production Interface v1.0."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from .combatant_appearance import APPEARANCE_PROFILES, resolve_appearance_geometry
from .combatant_body_spec import BODY_PROPORTION_PROFILES
from .interactive_battle_screen import (
    AttackMotion,
    VisualPose,
    WeaponSilhouette,
    attack_motion_geometry,
    pose_geometry,
    weapon_canvas_geometry,
)


@dataclass(frozen=True)
class Extent:
    min_x: float
    min_y: float
    max_x: float
    max_y: float

    @property
    def width(self) -> float:
        return self.max_x - self.min_x

    @property
    def height(self) -> float:
        return self.max_y - self.min_y


def _points_from_primitive(primitive: dict) -> Iterable[tuple[float, float]]:
    if "points" in primitive:
        yield from primitive["points"]
    for key in ("start", "end", "center"):
        if key in primitive:
            yield primitive[key]


def _geometry_points(geometry: dict) -> list[tuple[float, float]]:
    points = list(geometry["points"].values())
    for appearance_id in APPEARANCE_PROFILES:
        appearance = resolve_appearance_geometry(geometry, appearance_id)
        for primitive in appearance["primitives"]:
            points.extend(_points_from_primitive(primitive))
    silhouette = WeaponSilhouette.FIST if geometry["weapon_hint"] == "fist" else WeaponSilhouette(geometry["weapon_hint"].upper())
    weapon = weapon_canvas_geometry(
        silhouette,
        geometry["points"]["primary_hand_socket"],
        geometry["points"]["weapon_end"],
        geometry["points"]["off_hand_socket"],
        geometry["pose"],
        (geometry["points"]["elbow_front"], geometry["points"]["elbow_back"]),
    )
    for primitive in weapon["primitives"]:
        points.extend(_points_from_primitive(primitive))
    return points


def character_extent_audit() -> dict:
    """Audit existing local geometry only; it does not modify presentation behavior."""
    records = []
    families = {
        "blade": (WeaponSilhouette.BLADE, AttackMotion.SLASH),
        "sword": (WeaponSilhouette.SWORD, AttackMotion.THRUST),
        "spear": (WeaponSilhouette.SPEAR, AttackMotion.THRUST),
        "fist": (WeaponSilhouette.FIST, AttackMotion.STRIKE),
    }
    for body_profile in BODY_PROPORTION_PROFILES:
        for facing in ("right", "left"):
            for family, (_, default_motion) in families.items():
                for pose in VisualPose:
                    geometry = pose_geometry(pose, facing, family, body_profile)
                    records.append((body_profile, facing, family, pose.value, 0, _geometry_points(geometry)))
                for motion in AttackMotion:
                    for step in (1, 2, 3):
                        geometry = attack_motion_geometry(motion, facing, step, family, body_profile)
                        records.append((body_profile, facing, family, motion.value, step, _geometry_points(geometry)))
    flattened = [point for record in records for point in record[-1]]
    extent = Extent(
        min(point[0] for point in flattened), min(point[1] for point in flattened),
        max(point[0] for point in flattened), max(point[1] for point in flattened),
    )
    extrema = {}
    for label, index, function in (
        ("min_x", 0, min), ("min_y", 1, min), ("max_x", 0, max), ("max_y", 1, max),
    ):
        target = function(point[index] for point in flattened)
        extrema[label] = [record[:5] for record in records if any(point[index] == target for point in record[-1])]
    return {
        "contract": "CHARACTER_EXTENT_AUDIT_V1_0",
        "record_count": len(records),
        "profile_count": len(BODY_PROPORTION_PROFILES),
        "facing_count": 2,
        "family_count": len(families),
        "extent": {"min_x": extent.min_x, "min_y": extent.min_y, "max_x": extent.max_x, "max_y": extent.max_y,
                   "width": extent.width, "height": extent.height},
        "extrema_sources": extrema,
        "includes": ["all current poses", "all four motion vocabularies", "steps 1..3", "all body profiles",
                     "both facings", "all current appearance profiles", "current weapon primitives"],
        "presentation_semantic_changes": 0,
    }


if __name__ == "__main__":
    import json
    print(json.dumps(character_extent_audit(), ensure_ascii=False, indent=2))

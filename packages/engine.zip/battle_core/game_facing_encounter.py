"""WO-074 data-driven encounter composition and Battle runtime integration."""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import json
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping

from .game_facing_martial import CharacterMartialLoadout, GameFacingMartialService
from .interactive_battle_screen import BattleScreenConfiguration
from .combatant_profile import (
    LOADOUT_REGISTRY, PRESENTATION_PROFILE_REGISTRY, STAT_PROFILE_REGISTRY,
    CombatantProfileError, resolve_combatant_profile,
)
from .player_action_control import AI_CONTROLLED, PLAYER_CONTROLLED, ControlledParticipant, EncounterTarget, ManualCombatController

GAME_FACING_ENCOUNTER_DEFINITION = "GAME_FACING_ENCOUNTER_DEFINITION_V0_1"
ENCOUNTER_TO_BATTLE_RUNTIME_LOADER = "ENCOUNTER_TO_BATTLE_RUNTIME_LOADER_V0_1"
ENCOUNTER_REGISTRY = "ENCOUNTER_REGISTRY_V0_1"
FIRST_ENCOUNTER_ID = "encounter:prototype:roadside_ambush_01"
NONCANONICAL_STATUS = "NONCANONICAL_GAME_FACING_PROTOTYPE"

FRIENDLY_SLOTS = ("friendly-player", "friendly-ally")
ENEMY_SLOTS = ("enemy-left", "enemy-center", "enemy-right")
CONTROL_AUTHORITIES = ("PLAYER_MANUAL_CAPABLE", "ALLY_AI", "ENEMY_AI")
KNOWN_PRESENTATION_PROFILES = frozenset(PRESENTATION_PROFILE_REGISTRY)


class EncounterValidationCode(str, Enum):
    VALID = "VALID"
    INVALID_ID = "INVALID_ID"
    INVALID_SIDE = "INVALID_SIDE"
    INVALID_SLOT = "INVALID_SLOT"
    DUPLICATE_SLOT = "DUPLICATE_SLOT"
    UNKNOWN_LOADOUT = "UNKNOWN_LOADOUT"
    UNKNOWN_PRESENTATION_PROFILE = "UNKNOWN_PRESENTATION_PROFILE"
    CONTROL_AUTHORITY_INVALID = "CONTROL_AUTHORITY_INVALID"
    PARTICIPANT_COUNT_UNSUPPORTED = "PARTICIPANT_COUNT_UNSUPPORTED"
    DUPLICATE_PARTICIPANT_REF = "DUPLICATE_PARTICIPANT_REF"
    UNKNOWN_COMBATANT_PROFILE = "UNKNOWN_COMBATANT_PROFILE"
    INVALID_DEFINITION = "INVALID_DEFINITION"


@dataclass(frozen=True)
class EncounterValidationResult:
    code: EncounterValidationCode
    message: str = ""

    @property
    def valid(self) -> bool:
        return self.code is EncounterValidationCode.VALID


class EncounterDefinitionError(ValueError):
    def __init__(self, result: EncounterValidationResult):
        self.result = result
        super().__init__(f"{result.code.value}: {result.message}")


@dataclass(frozen=True)
class EncounterParticipantDefinition:
    participant_ref_id: str
    display_name: str
    combatant_profile_id: str
    side: str
    slot_id: str
    control_authority: str
    body_profile: str
    presentation_profile: str
    weapon_family: str
    loadout_ref: str
    stat_profile_ref: str
    profile_hash: str


@dataclass(frozen=True)
class EncounterDefinition:
    encounter_id: str
    display_name: str
    status: str
    friendlies: tuple[EncounterParticipantDefinition, ...]
    enemies: tuple[EncounterParticipantDefinition, ...]
    metadata: Mapping[str, Any]


@dataclass(frozen=True)
class RuntimeParticipantMapping:
    participant_ref_id: str
    runtime_subject_id: str
    side: str
    slot_id: str
    control_authority: str
    combatant_profile_id: str
    profile_hash: str
    stat_profile_ref: str
    loadout_ref: str
    presentation_profile: str
    weapon_family: str
    body_profile: str


@dataclass(frozen=True)
class EncounterRuntimeComposition:
    definition: EncounterDefinition
    encounter_instance_id: str
    controller: ManualCombatController
    participant_mappings: tuple[RuntimeParticipantMapping, ...]


def _content_dir(workspace: str | Path) -> Path:
    return Path(workspace) / "game_content" / "encounters"


def _participant(raw: Mapping[str, Any], workspace: str | Path) -> EncounterParticipantDefinition:
    fields = ("participant_ref_id", "combatant_profile_id", "side", "slot_id", "control_authority")
    missing = [field for field in fields if not isinstance(raw.get(field), str) or not raw.get(field)]
    if missing:
        raise EncounterDefinitionError(EncounterValidationResult(
            EncounterValidationCode.INVALID_DEFINITION, f"participant missing {', '.join(missing)}"))
    forbidden_overrides = ("stat_profile_ref", "loadout_ref", "weapon_family", "body_profile", "presentation_profile", "max_hp", "hp")
    present_overrides = tuple(field for field in forbidden_overrides if field in raw)
    if present_overrides:
        raise EncounterDefinitionError(EncounterValidationResult(EncounterValidationCode.INVALID_DEFINITION, f"gameplay overrides forbidden: {', '.join(present_overrides)}"))
    try:
        profile = resolve_combatant_profile(workspace, raw["combatant_profile_id"])
    except CombatantProfileError as exc:
        raise EncounterDefinitionError(EncounterValidationResult(EncounterValidationCode.UNKNOWN_COMBATANT_PROFILE, str(exc))) from exc
    display_name = raw.get("display_name") or profile.display_name
    if not isinstance(display_name, str) or not display_name:
        raise EncounterDefinitionError(EncounterValidationResult(EncounterValidationCode.INVALID_DEFINITION, "display alias"))
    return EncounterParticipantDefinition(
        raw["participant_ref_id"], display_name, profile.combatant_profile_id, raw["side"], raw["slot_id"], raw["control_authority"],
        profile.body_profile, profile.presentation_profile, profile.weapon_family, profile.loadout_ref,
        profile.stat_profile_ref, profile.profile_hash,
    )


def parse_encounter_definition(raw: Mapping[str, Any], workspace: str | Path = ".") -> EncounterDefinition:
    for field in ("encounter_id", "display_name", "status"):
        if not isinstance(raw.get(field), str) or not raw.get(field):
            raise EncounterDefinitionError(EncounterValidationResult(EncounterValidationCode.INVALID_ID if field == "encounter_id" else EncounterValidationCode.INVALID_DEFINITION, f"missing {field}"))
    if not isinstance(raw.get("friendlies"), list) or not isinstance(raw.get("enemies"), list):
        raise EncounterDefinitionError(EncounterValidationResult(EncounterValidationCode.INVALID_DEFINITION, "friendlies and enemies are required arrays"))
    return EncounterDefinition(
        raw["encounter_id"], raw["display_name"], raw["status"],
        tuple(_participant(item, workspace) for item in raw["friendlies"]),
        tuple(_participant(item, workspace) for item in raw["enemies"]),
        MappingProxyType(dict(raw.get("metadata") or {})),
    )


def validate_encounter_definition(definition: EncounterDefinition) -> EncounterValidationResult:
    if not definition.encounter_id:
        return EncounterValidationResult(EncounterValidationCode.INVALID_ID, "encounter_id required")
    if not (1 <= len(definition.friendlies) <= 2) or not (1 <= len(definition.enemies) <= 3):
        return EncounterValidationResult(EncounterValidationCode.PARTICIPANT_COUNT_UNSUPPORTED, "V0.1 supports 1..2 friendlies and 1..3 enemies")
    participants = definition.friendlies + definition.enemies
    refs = [p.participant_ref_id for p in participants]
    if len(refs) != len(set(refs)):
        return EncounterValidationResult(EncounterValidationCode.DUPLICATE_PARTICIPANT_REF, "participant_ref_id must be unique")
    slots = [p.slot_id for p in participants]
    if len(slots) != len(set(slots)):
        return EncounterValidationResult(EncounterValidationCode.DUPLICATE_SLOT, "slot_id must be unique")
    if sum(p.control_authority == "PLAYER_MANUAL_CAPABLE" for p in participants) != 1:
        return EncounterValidationResult(EncounterValidationCode.CONTROL_AUTHORITY_INVALID, "exactly one player authority required")
    for p in participants:
        expected_side = "FRIENDLY" if p in definition.friendlies else "ENEMY"
        if p.side != expected_side:
            return EncounterValidationResult(EncounterValidationCode.INVALID_SIDE, f"{p.participant_ref_id} is in wrong roster")
        valid_slots = FRIENDLY_SLOTS if p.side == "FRIENDLY" else ENEMY_SLOTS
        if p.slot_id not in FRIENDLY_SLOTS + ENEMY_SLOTS or p.slot_id not in valid_slots:
            return EncounterValidationResult(EncounterValidationCode.INVALID_SLOT, f"{p.participant_ref_id} has wrong-side or unknown slot")
        if p.control_authority not in CONTROL_AUTHORITIES or (p.side == "ENEMY" and p.control_authority != "ENEMY_AI") or (p.side == "FRIENDLY" and p.control_authority == "ENEMY_AI"):
            return EncounterValidationResult(EncounterValidationCode.CONTROL_AUTHORITY_INVALID, p.participant_ref_id)
        loadout = LOADOUT_REGISTRY.get(p.loadout_ref)
        if loadout is None:
            return EncounterValidationResult(EncounterValidationCode.UNKNOWN_LOADOUT, p.loadout_ref)
        if p.presentation_profile not in KNOWN_PRESENTATION_PROFILES:
            return EncounterValidationResult(EncounterValidationCode.UNKNOWN_PRESENTATION_PROFILE, p.presentation_profile)
        if not p.weapon_family or p.weapon_family != loadout["weapon_family"]:
            return EncounterValidationResult(EncounterValidationCode.UNKNOWN_LOADOUT, f"weapon/loadout mismatch for {p.participant_ref_id}")
    return EncounterValidationResult(EncounterValidationCode.VALID)


def load_encounter_definition(workspace: str | Path, encounter_id: str) -> EncounterDefinition:
    content_dir = _content_dir(workspace)
    registry = json.loads((content_dir / "encounter_registry.json").read_text(encoding="utf-8"))
    if registry.get("contract") != ENCOUNTER_REGISTRY or encounter_id not in registry.get("encounters", {}):
        raise EncounterDefinitionError(EncounterValidationResult(EncounterValidationCode.INVALID_ID, encounter_id))
    raw = json.loads((content_dir / registry["encounters"][encounter_id]).read_text(encoding="utf-8"))
    definition = parse_encounter_definition(raw, workspace)
    result = validate_encounter_definition(definition)
    if not result.valid:
        raise EncounterDefinitionError(result)
    return definition


class EncounterRuntimeLoader:
    """Validated content-to-runtime bridge. No Battle mechanics live here."""
    def __init__(self, workspace: str | Path):
        self.workspace = Path(workspace)
        self._instance_sequence = 0
        self.last_composition: EncounterRuntimeComposition | None = None

    def build(self, encounter_id: str) -> EncounterRuntimeComposition:
        definition = load_encounter_definition(self.workspace, encounter_id)
        self._instance_sequence += 1
        instance_id = f"{encounter_id}:instance:{self._instance_sequence}"
        service = GameFacingMartialService(self.workspace)
        mappings = []
        controlled = []
        targets = []
        for participant in definition.friendlies + definition.enemies:
            runtime_id = f"encounter-subject:{participant.participant_ref_id}"
            loadout = LOADOUT_REGISTRY[participant.loadout_ref]
            stats = STAT_PROFILE_REGISTRY[participant.stat_profile_ref]
            runtime = service.bind(CharacterMartialLoadout(
                runtime_id, participant.display_name, loadout["martial_ids"], loadout["default_action_id"]),
                max_hp=stats["max_hp"], initial_qi=stats["initial_qi"])
            side = "player" if participant.side == "FRIENDLY" else "enemy"
            authority = PLAYER_CONTROLLED if participant.control_authority == "PLAYER_MANUAL_CAPABLE" else AI_CONTROLLED
            controlled.append(ControlledParticipant(runtime, authority, side))
            slot_index = (FRIENDLY_SLOTS if side == "player" else ENEMY_SLOTS).index(participant.slot_id)
            targets.append(EncounterTarget(runtime_id, participant.display_name, side, "front", slot_index))
            mappings.append(RuntimeParticipantMapping(
                participant.participant_ref_id, runtime_id, participant.side, participant.slot_id,
                participant.control_authority, participant.combatant_profile_id, participant.profile_hash,
                participant.stat_profile_ref, participant.loadout_ref, participant.presentation_profile,
                participant.weapon_family, participant.body_profile))
        player = next(item for item in mappings if item.control_authority == "PLAYER_MANUAL_CAPABLE")
        controller = ManualCombatController(service, instance_id, tuple(controlled), tuple(targets), player.runtime_subject_id)
        composition = EncounterRuntimeComposition(definition, instance_id, controller, tuple(mappings))
        self.last_composition = composition
        return composition


class EncounterControllerFactory:
    def __init__(self, loader: EncounterRuntimeLoader, encounter_id: str):
        self.loader, self.encounter_id = loader, encounter_id

    def __call__(self, workspace: str | Path) -> ManualCombatController:
        return self.loader.build(self.encounter_id).controller


def encounter_configuration(workspace: str | Path, encounter_id: str) -> tuple[BattleScreenConfiguration, EncounterRuntimeLoader]:
    loader = EncounterRuntimeLoader(workspace)
    definition = load_encounter_definition(workspace, encounter_id)
    participants = definition.friendlies + definition.enemies
    runtime_id = lambda p: f"encounter-subject:{p.participant_ref_id}"
    player = next(p for p in participants if p.control_authority == "PLAYER_MANUAL_CAPABLE")
    ally_ids = tuple(runtime_id(p) for p in definition.friendlies if p.control_authority == "ALLY_AI")
    enemy_ids = tuple(runtime_id(p) for p in definition.enemies)
    friendly_ids = tuple(runtime_id(p) for p in definition.friendlies)
    by_runtime_id = {runtime_id(p): p for p in participants}

    def presentation_binding(subject_id: str) -> dict[str, Any]:
        participant = by_runtime_id[subject_id]
        profile = PRESENTATION_PROFILE_REGISTRY[participant.presentation_profile]
        return {
            "runtime_subject_id": subject_id,
            "appearance_profile_id": profile.profile_id,
            "appearance_profile": profile,
            "body_profile_id": participant.body_profile,
            "presentation_profile_ref": participant.presentation_profile,
        }

    def enemy_presentation(subject_id: str) -> dict[str, Any]:
        participant = by_runtime_id[subject_id]
        profile = PRESENTATION_PROFILE_REGISTRY[participant.presentation_profile]
        return {
            "martial_family": participant.weapon_family,
            "weapon_hint": participant.weapon_family.lower(),
            "appearance_profile_id": profile.profile_id,
            "appearance_profile": profile,
            "body_profile_id": participant.body_profile,
            "presentation_profile_ref": participant.presentation_profile,
        }
    config = BattleScreenConfiguration(
        controller_factory=EncounterControllerFactory(loader, definition.encounter_id),
        player_runtime_id=runtime_id(player), ai_runtime_id=enemy_ids[1] if len(enemy_ids) > 1 else enemy_ids[0],
        player_target_id=runtime_id(player),
        actor_aliases={runtime_id(p): runtime_id(p) for p in participants},
        presentation_binding_resolver=presentation_binding,
        enemy_presentation_resolver=enemy_presentation,
        window_title=f"{definition.display_name}（Encounter Prototype）",
        dev_banner=f"Encounter: {definition.display_name}｜{definition.encounter_id}｜NONCANONICAL PROTOTYPE",
        enemy_response_actor_ids=enemy_ids, friendly_ai_actor_ids=ally_ids,
        friendly_target_order=friendly_ids, enable_presentation_speed_control=True,
    )
    return config, loader


def first_encounter_configuration(workspace: str | Path) -> tuple[BattleScreenConfiguration, EncounterRuntimeLoader]:
    return encounter_configuration(workspace, FIRST_ENCOUNTER_ID)

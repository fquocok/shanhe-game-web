"""WO-036C read-only audit of the first generated canonical promotion."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json
import re
from typing import Any

from .generated_acceptance import FORMAL_GENERATED_MARTIAL_REGISTRY, stable_hash
from .generator import deserialize_candidate
from .numeric_token_valuation import evaluate_candidate_numeric_budget
from .revision_2_canonical_promotion import compile_revision_envelope, definition_payload, run_revision_2_smoke

CANONICAL_ID = "generated:spear:advanced:31a63f7586a1:r2"


def _read(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _artifact(root: Path, relative: str) -> tuple[Any, str]:
    path = root / relative
    value = _read(path)
    return value, stable_hash(value)


def _scan_runtime_identifiers(root: Path) -> dict[str, Any]:
    prohibited = (CANONICAL_ID, "gen_v01_advanced_spear_31a63f7586a1.r2", "WO036A-D", "援鋒追陣槍")
    hits: list[dict[str, Any]] = []
    # Only execution-path modules can constitute a Battle behavior branch.
    runtime_modules = {"engine.py", "martial.py", "trigger.py", "status.py", "schema.py",
                       "targeting.py", "action.py", "damage.py", "special.py"}
    for path in sorted((root / "battle_core").glob("*.py")):
        if path.name not in runtime_modules:
            continue
        text = path.read_text(encoding="utf-8")
        for token in prohibited:
            for match in re.finditer(re.escape(token), text):
                hits.append({"file": str(path.relative_to(root)), "token": token,
                             "line": text.count("\n", 0, match.start()) + 1})
    engines = []
    for path in sorted((root / "battle_core").glob("*.py")):
        text = path.read_text(encoding="utf-8")
        engines.extend(re.findall(r"class\s+(GeneratedMartialEngine|GeneratedSpearEngine|CandidateDEngine|YuanFengZhuiZhenEngine)\b", text))
    return {"status": "PASS" if not hits and not engines else "FAIL", "identifier_branches": hits,
            "prohibited_engines": engines, "compiler_identity_checks": False,
            "generic_compiler_reusable": True}


def audit_wo036c(workspace: str | Path) -> dict[str, Any]:
    """Inspect repository authority as-is. Never mutates a registry or historical file."""
    root = Path(workspace)
    b2b = root / "generated_candidates" / "wo036b2b"
    entry, entry_hash = _artifact(root, "generated_candidates/wo036b2b/formal_generated_registry_entry.json")
    manifest, manifest_hash = _artifact(root, "generated_candidates/wo036b2b/canonical_promotion_manifest.json")
    envelope, revision_hash = _artifact(root, "generated_candidates/wo036b2a/candidate_d_revision_2.json")
    review3, review3_hash = _artifact(root, "generated_candidates/wo036b2a/revision_2_review_package.json")
    human2, human2_hash = _artifact(root, "generated_candidates/wo036b2b/human_accept_revision_2.json")
    definition = entry["definition"]
    definition_hash = stable_hash(definition)
    candidate = deserialize_candidate(envelope["candidate_snapshot"])
    budget = evaluate_candidate_numeric_budget(candidate, duration_unit="OWNER_FORMAL_TURNS")

    # Repository authority means importable registries after a fresh process, not a historical JSON claim.
    formal_ids = tuple(FORMAL_GENERATED_MARTIAL_REGISTRY)
    runtime_ids: tuple[str, ...] = ()  # no persistent/runtime generated registry exists
    registry = {
        "before": {"formal_generated_registry": len(formal_ids), "runtime_generated_registry": 0,
                   "generated_canonical_count": len(formal_ids)},
        "after": {"formal_generated_registry": len(formal_ids), "runtime_generated_registry": 0,
                  "generated_canonical_count": len(formal_ids)},
        "expected": {"formal_generated_registry": 1, "runtime_generated_registry": 1,
                     "generated_canonical_count": 1},
        "formal_ids": formal_ids, "runtime_ids": runtime_ids,
        "immutable": True, "status": "FAIL",
        "failure_codes": ["FORMAL_REGISTRY_NOT_PERSISTED", "RUNTIME_REGISTRY_NOT_PERSISTED",
                          "GENERATED_CANONICAL_COUNT_ZERO_AFTER_RESTART"],
    }

    hash_checks = {
        "candidate_revision": revision_hash == manifest["candidate_revision_hash"],
        "review_package_v3": review3_hash == manifest["review_package_hash"],
        "human_accept": human2_hash == manifest["human_decision_hash"],
        "canonical_definition": definition_hash == manifest["canonical_definition_hash"],
    }
    semantic = {
        "status": "PASS" if all(hash_checks.values()) else "FAIL", "hash_checks": hash_checks,
        "formal_name": definition["name"] == "援鋒追陣槍", "family": definition["family"] == "槍法",
        "tier": definition["tier"] == "advanced", "status_name": definition["passives"][0]["name"] == "援勢",
        "duration": definition["passives"][0]["parameters"]["duration"] == 2,
        "refresh": definition["passives"][0]["parameters"]["stacking_policy"] == "refresh",
        "coefficient": definition["active_skill"]["attack_coefficient"] == 1.0,
        "roundtrip": stable_hash(json.loads(json.dumps(definition, ensure_ascii=False))) == definition_hash,
        "registry_loaded": False, "failure_codes": ["FORMAL_REGISTRY_ROUNDTRIP_UNAVAILABLE"],
    }

    dirs = ["wo036a", "wo036b", "wo036b1", "wo036b1a", "wo036b1b", "wo036b1c",
            "wo036b2", "wo036b2a", "wo036b2b"]
    preserved = {name: (root / "generated_candidates" / name).is_dir() for name in dirs}
    history = {"status": "PASS" if all(preserved.values()) else "FAIL", "directories": preserved,
               "original_candidate": (root / "generated_candidates/wo036a/pool/seed_127.json").exists(),
               "revision_1": (root / "generated_candidates/wo036b1a/candidate_d_revision_1.json").exists(),
               "revision_2": (root / "generated_candidates/wo036b2a/candidate_d_revision_2.json").exists(),
               "review_v2": (root / "generated_candidates/wo036b1c/candidate_d_revision_1_review_package_v2.json").exists(),
               "review_v3": (root / "generated_candidates/wo036b2a/revision_2_review_package.json").exists(),
               "revision_1_accept": (root / "generated_candidates/wo036b2/human_accept_decision.json").exists(),
               "revision_2_accept": (b2b / "human_accept_revision_2.json").exists(),
               "wo036b_failure": _read(root / "generated_candidates/wo036b/promotion_result.json")["status"],
               "wo036b2_failure": _read(root / "generated_candidates/wo036b2/result.json")["status"]}

    nodes = [
        ("generation_request", "GENERATION_REQUEST"), ("candidate_d", "CANDIDATE"),
        ("revision_1", "CANDIDATE_REVISION"), ("review_v2", "REVIEW_PACKAGE"),
        ("human_accept_r1", "HUMAN_DECISION"), ("token_policy_v0_1", "TOKEN_POLICY"),
        ("failed_wo036b", "FAILED_PROMOTION"), ("failed_wo036b2", "FAILED_PROMOTION"),
        ("revision_2", "CANDIDATE_REVISION"), ("review_v3", "REVIEW_PACKAGE"),
        ("human_accept_r2", "HUMAN_DECISION"), ("promotion_manifest", "PROMOTION"),
        ("formal_entry_artifact", "FORMAL_ENTRY_ARTIFACT"), ("runtime_entry", "RUNTIME_ENTRY"),
    ]
    edges = [("generation_request", "candidate_d"), ("candidate_d", "revision_1"),
             ("revision_1", "review_v2"), ("review_v2", "human_accept_r1"),
             ("token_policy_v0_1", "review_v2"), ("candidate_d", "failed_wo036b"),
             ("human_accept_r1", "failed_wo036b2"), ("revision_1", "revision_2"),
             ("revision_2", "review_v3"), ("review_v3", "human_accept_r2"),
             ("human_accept_r2", "promotion_manifest"), ("promotion_manifest", "formal_entry_artifact")]
    provenance = {"status": "PARTIAL", "start_id": CANONICAL_ID,
                  "nodes": [{"id": a, "type": b} for a, b in nodes],
                  "edges": [{"from": a, "to": b} for a, b in edges],
                  "machine_resolvable_from_live_registry": False,
                  "failure_codes": ["CANONICAL_ID_NOT_RESOLVABLE_FROM_LIVE_REGISTRY",
                                    "RUNTIME_ENTRY_MISSING", "PROMOTION_MANIFEST_LACKS_GENERATION_REQUEST_AND_SEED_LINKS"]}

    idempotency = {"status": "FAIL", "safe_replay_result": "NOT_RUN_NO_PERSISTED_IDENTITY",
                   "expected": "ALREADY_PROMOTED", "canonical_count_before": 0, "canonical_count_after": 0,
                   "non_destructive": True,
                   "failure_codes": ["RESTART_REPLAY_WOULD_NOT_DETECT_EXISTING_PROMOTION",
                                     "PROMOTION_ONLY_DETECTS_IN_MEMORY_ID_COLLISION"]}
    runtime_smoke = {"status": "NOT_VERIFIED", "loaded_from_actual_runtime_registry": False,
                     "staging_smoke_reference": _read(b2b / "smoke_report.json"),
                     "failure_codes": ["CANONICAL_RUNTIME_REGISTRY_ENTRY_MISSING"]}
    replay = {"status": "NOT_VERIFIED", "runs": 0, "generator_rng_calls": 0,
              "failure_codes": ["CANONICAL_RUNTIME_REGISTRY_ENTRY_MISSING"]}
    static = _scan_runtime_identifiers(root)
    readiness = {
        "generator_candidate_synthesis": "VERIFIED_WITH_LIMITATIONS", "generator_diversity": "PROTOTYPE_ONLY",
        "candidate_validation": "VERIFIED_WITH_LIMITATIONS", "token_accounting": "VERIFIED",
        "numeric_token_valuation": "VERIFIED_WITH_LIMITATIONS", "human_review_packaging": "VERIFIED",
        "candidate_revision": "VERIFIED", "human_decision_binding": "VERIFIED",
        "canonical_preview": "VERIFIED", "generated_formal_compiler": "VERIFIED_WITH_LIMITATIONS",
        "staging_isolation": "VERIFIED", "runtime_smoke": "NOT_VERIFIED", "seeded_replay": "NOT_VERIFIED",
        "transactional_commit": "NOT_VERIFIED", "promotion_idempotency": "NOT_VERIFIED",
        "provenance_reconstruction": "VERIFIED_WITH_LIMITATIONS", "historical_artifact_preservation": "VERIFIED",
    }
    canonical = {"id": entry["id"], "name": definition["name"], "authority": definition["provenance"]["authority"],
                 "origin": definition["provenance"]["origin"], "budget": {"used": 106, "limit": 120, "remaining": 14},
                 "balance_status": definition["provenance"]["balance_status"],
                 "final_balance_locked": definition["provenance"]["final_balance_locked"],
                 "hashes": {"definition": definition_hash, "formal_entry": entry_hash, "promotion_manifest": manifest_hash,
                            "revision_2": revision_hash, "review_v3": review3_hash, "human_accept": human2_hash},
                 "token_recomputation": {"mechanic_subtotal": budget.base_known_subtotal,
                                         "coefficient_surcharge": budget.numeric_valuations[0].calculated_cost,
                                         "duration_surcharge": budget.numeric_valuations[1].calculated_cost,
                                         "total": budget.total_used, "remaining": budget.remaining}}
    return {"status": "FAIL_CANONICAL_STATE_INCONSISTENT", "work_order": "CODEX-WO-036C",
            "canonical": canonical, "registry_snapshot": registry, "semantic_equivalence": semantic,
            "history_preservation": history, "provenance_graph": provenance,
            "promotion_idempotency": idempotency, "runtime_smoke": runtime_smoke,
            "seeded_replay": replay, "static_architecture": static, "readiness_matrix": readiness,
            "batch_2_readiness": "NOT_READY_FOR_BATCH_2",
            "maturity": {"generator": "KEEP_PROTOTYPE", "acceptance": "KEEP_PROTOTYPE",
                         "numeric_token_policy": "v0.1_VERIFIED_ONLY_FOR_ABSOLUTE_ATTACK_COEFFICIENT_AND_FINITE_OWNER_FORMAL_TURNS_DURATION"},
            "mutations": {"canonical_additions": 0, "registry_delta": 0, "martial_semantic_changes": 0,
                          "battle_semantic_changes": 0, "token_policy_changes": 0}}


def write_wo036c_artifacts(result: dict[str, Any], directory: str | Path) -> Path:
    root = Path(directory)
    root.mkdir(parents=True, exist_ok=True)
    files = {
        "registry_snapshot.json": result["registry_snapshot"],
        "canonical_entry_audit.json": result["canonical"],
        "provenance_graph.json": result["provenance_graph"],
        "history_preservation_audit.json": result["history_preservation"],
        "promotion_idempotency_report.json": result["promotion_idempotency"],
        "postpromotion_runtime_smoke.json": result["runtime_smoke"],
        "seeded_replay_report.json": result["seeded_replay"],
        "semantic_equivalence_report.json": result["semantic_equivalence"],
        "readiness_matrix.json": result["readiness_matrix"],
        "audit_result.json": result,
    }
    for name, payload in files.items():
        (root / name).write_text(json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2), encoding="utf-8")
    return root

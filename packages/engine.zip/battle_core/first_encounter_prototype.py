"""Human-playable entrypoint for the first data-driven encounter."""
from __future__ import annotations
from pathlib import Path

from .game_facing_encounter import first_encounter_configuration
from .interactive_battle_screen import TkBattleScreen


def main(argv=None):
    import argparse
    import tkinter as tk
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", default=".")
    args = parser.parse_args(argv)
    workspace = Path(args.workspace).resolve()
    configuration, _loader = first_encounter_configuration(workspace)
    root = tk.Tk()
    TkBattleScreen(root, workspace, configuration)
    root.mainloop()


if __name__ == "__main__":
    main()

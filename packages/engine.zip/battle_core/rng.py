class SeededRNG:
    """Small explicit PRNG with stable cross-version behavior (32-bit LCG)."""

    def __init__(self, seed: int):
        if type(seed) is not int:
            raise TypeError("seed 必須是整數")
        self._state = seed & 0xFFFFFFFF

    def random(self) -> float:
        self._state = (1664525 * self._state + 1013904223) & 0xFFFFFFFF
        return self._state / 4294967296.0

    def shuffle(self, values):
        result = list(values)
        for i in range(len(result) - 1, 0, -1):
            j = int(self.random() * (i + 1))
            result[i], result[j] = result[j], result[i]
        return result

    def choice(self, values):
        return values[int(self.random() * len(values))]

"""WO-036B1A immutable human-authored revision application; never generation or promotion."""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any
import json

from .first_generated_promotion import load_frozen_wo036a_d
from .generated_acceptance import (
    FORMAL_GENERATED_MARTIAL_REGISTRY,
    create_review_package,
    serialize_review_package,
    stable_hash,
)
from .generator import (
    GenerationTrace,
    TokenAllocationPlan,
    compare_signatures,
    deserialize_candidate,
    serialize_candidate,
    serialize_validation_report,
    validate_candidate,
)

WORK_ORDER = "CODEX-WO-036B1A"
REVISION_ID = "gen_v01_advanced_spear_31a63f7586a1.r1"
REPOSITORY_NATIVE_VALUE_CATEGORY = "FIRST_PASS_GENERATED_VALUE"
AUTHORIZED_CONTENT_FIELDS = (
    "actions[0].damage_coefficient",
    "actions[0].value_category",
    "statuses[0].duration",
)


@dataclass(frozen=True)
class HumanContentDecisionProvenance:
    decision_id: str
    authority: str
    coefficient_authority: str
    duration_authority: str
    balance_status: str
    first_pass: bool
    source_derived: bool
    token_derived: bool
    final_balance_locked: bool
    duration_unit: str
    work_order: str = WORK_ORDER


@dataclass(frozen=True)
class ImmutableRevisionLineage:
    candidate_id: str
    parent_candidate_id: str
    parent_candidate_sha256: str
    revision_number: int
    revision_reason: str
    human_decision_id: str
    changed_fields: tuple[str, ...]
    created_from_frozen_parent: bool
    generator_seed_unchanged: bool
    generator_calls: int
    canonical: bool


@dataclass(frozen=True)
class CandidateRevisionApplicationResult:
    status: str
    parent_hash_before: str
    parent_hash_after: str
    parent_immutable: bool
    candidate: Any
    candidate_hash: str
    validation: Any
    validation_hash: str
    review_package: Any
    review_package_hash: str
    lineage: ImmutableRevisionLineage
    provenance: HumanContentDecisionProvenance
    semantic_diff: dict[str, Any]
    content_completeness: dict[str, Any]
    token_budget: dict[str, Any]
    revalidation: dict[str, Any]
    review_state: dict[str, Any]
    registry_invariants: dict[str, Any]


def _no_required_placeholder(candidate) -> bool:
    encoded = serialize_candidate(candidate)
    return not any(x in encoded for x in ("TOKEN_BALANCE_TBD", "CONTENT_TBD", "SOURCE_CONTENT_TBD"))


def apply_candidate_d_human_revision(workspace, *, formal_registry=None, runtime_registry=None):
    """Apply exactly the authorized human values to a copied frozen parent."""
    formal_registry = FORMAL_GENERATED_MARTIAL_REGISTRY if formal_registry is None else formal_registry
    runtime_registry = {} if runtime_registry is None else runtime_registry
    formal_before, runtime_before = len(formal_registry), len(runtime_registry)
    raw, parent_package, parent, _old_validation, identity = load_frozen_wo036a_d(workspace)
    parent_hash_before = stable_hash(serialize_candidate(parent))

    actions = tuple(dict(x) for x in parent.actions)
    statuses = tuple(dict(x) for x in parent.statuses)
    actions[0]["damage_coefficient"] = 1.00
    actions[0]["value_category"] = REPOSITORY_NATIVE_VALUE_CATEGORY
    statuses[0]["duration"] = 2

    # These are derived completeness annotations, not additional gameplay changes.
    nodes = tuple(replace(n, content_tbd=False) for n in parent.topology.nodes)
    topology = replace(parent.topology, nodes=nodes)
    revision = replace(
        parent,
        candidate_id=REVISION_ID,
        actions=actions,
        statuses=statuses,
        topology=topology,
        content_tbd=(),
        tuning_placeholders=(),
        token_plan=TokenAllocationPlan(
            dict(parent.token_plan.known_costs),
            ("human_damage_coefficient_no_exchange_rate", "human_status_duration_no_exchange_rate"),
            parent.token_plan.target_budget,
        ),
        canonical=False,
    )
    validation = validate_candidate(revision)
    candidate_hash = stable_hash(serialize_candidate(revision))
    validation_hash = stable_hash(serialize_validation_report(validation))
    trace_data = dict(parent_package.generation_trace)
    trace_data["capability_choices"] = tuple(trace_data.get("capability_choices", ()))
    generation_trace = GenerationTrace(**trace_data)
    package = create_review_package(
        revision,
        validation,
        generation_trace,
        proposed_id=parent_package.proposed_identity.proposed_id + ".r1",
        similarity_summary=parent_package.similarity_summary,
        quality_warnings=("BUDGET_INDETERMINATE", "HUMAN_REVIEW_REQUIRED"),
    )
    package_hash = stable_hash(serialize_review_package(package))
    provenance = HumanContentDecisionProvenance(
        "WO036B1A-HUMAN-CONTENT-DECISION-1",
        "HUMAN",
        "HUMAN_AUTHORED_FIRST_PASS_TUNING",
        "HUMAN_DESIGN_VALUE",
        "FIRST_PASS",
        True,
        False,
        False,
        False,
        "OWNER_FORMAL_TURNS",
    )
    lineage = ImmutableRevisionLineage(
        REVISION_ID,
        parent.candidate_id,
        identity.candidate_hash,
        1,
        "APPLY_AUTHORIZED_HUMAN_CONTENT_DECISION",
        provenance.decision_id,
        AUTHORIZED_CONTENT_FIELDS,
        True,
        revision.provenance.generation_seed == parent.provenance.generation_seed,
        0,
        False,
    )
    parent_hash_after = stable_hash(serialize_candidate(deserialize_candidate(parent_package.candidate_snapshot)))
    semantic_diff = {
        "status": "AUTHORIZED_REVISION_ONLY",
        "substantive_gameplay_changes": (
            {"field": AUTHORIZED_CONTENT_FIELDS[0], "before": "TOKEN_BALANCE_TBD", "after": 1.00},
            {"field": AUTHORIZED_CONTENT_FIELDS[1], "before": "TOKEN_BALANCE_TBD", "after": REPOSITORY_NATIVE_VALUE_CATEGORY},
            {"field": AUTHORIZED_CONTENT_FIELDS[2], "before": "CONTENT_TBD", "after": 2, "unit": "OWNER_FORMAL_TURNS"},
        ),
        "derived_metadata_changes": ("candidate_id", "content_tbd", "topology.nodes[].content_tbd", "tuning_placeholders", "token_plan.unknown_cost_ids"),
        "unauthorized_mechanic_changes": (),
    }
    complete = _no_required_placeholder(revision)
    token_budget = {
        "budget_limit": 120,
        "known_used": sum(revision.token_plan.known_costs.values()),
        "remaining_known_slack": 120 - sum(revision.token_plan.known_costs.values()),
        "used_budget": "INDETERMINATE",
        "remaining_budget": "INDETERMINATE",
        "status": "BUDGET_INDETERMINATE",
        "missing_rules": ("damage_coefficient_to_token_cost", "status_duration_to_token_cost"),
        "unknown_cost_treated_as_zero": False,
    }
    revalidation = {
        "schema": validation.schema_result,
        "tier": validation.tier_result,
        "topology": validation.topology_result,
        "capability": validation.capability_result,
        "policy": validation.policy_result,
        "content": validation.content_result,
        "budget": token_budget["status"],
        "runtime_eligibility": validation.runtime_eligibility,
        "acceptance_eligibility": "BLOCKED_PENDING_HUMAN_REVIEW_AND_BUDGET_AUTHORITY",
        "open_policy_dependencies": revision.open_policy_dependencies,
        "deferred_dependencies": tuple(x for x in revision.capability_requirements if x == "world_map_geometry"),
        "similarity": parent_package.similarity_summary,
        "family_contract": "SPEAR_ADVANCED_PRESERVED",
    }
    review_state = {
        "review_status": "PENDING_REVIEW",
        "human_decision": "NONE",
        "old_acceptance_reusable": False,
        "canonical": False,
        "notice": "THIS REVISION HAS NOT BEEN ACCEPTED FOR CANONICALIZATION.",
    }
    registries = {
        "formal_before": formal_before,
        "formal_after": len(formal_registry),
        "runtime_before": runtime_before,
        "runtime_after": len(runtime_registry),
        "generated_canonical_before": formal_before,
        "generated_canonical_after": len(formal_registry),
        "promotion_attempts": 0,
        "registry_commits": 0,
    }
    if parent_hash_before != identity.candidate_hash or parent_hash_after != identity.candidate_hash:
        raise RuntimeError("PARENT_CANDIDATE_MUTATED")
    if candidate_hash == identity.candidate_hash:
        raise RuntimeError("REVISION_HASH_NOT_NEW")
    if not complete:
        raise RuntimeError("REVISION_CONTENT_INCOMPLETE")
    if formal_before != len(formal_registry) or runtime_before != len(runtime_registry):
        raise RuntimeError("UNAUTHORIZED_PROMOTION")
    return CandidateRevisionApplicationResult(
        "PASS_STOPPED_AT_HUMAN_REVIEW", parent_hash_before, parent_hash_after, True,
        revision, candidate_hash, validation, validation_hash, package, package_hash,
        lineage, provenance, semantic_diff,
        {"status": "COMPLETE", "resolved_fields": AUTHORIZED_CONTENT_FIELDS, "required_placeholders_remaining": (), "all_original_blockers_resolved": True},
        token_budget, revalidation, review_state, registries,
    )


def write_candidate_d_revision_artifacts(result, directory):
    root = Path(directory)
    root.mkdir(parents=True, exist_ok=True)
    payloads = {
        "candidate_d_revision_1.json": json.loads(serialize_candidate(result.candidate)),
        "revision_lineage.json": asdict(result.lineage),
        "human_content_decision_provenance.json": asdict(result.provenance),
        "revision_semantic_diff.json": result.semantic_diff,
        "content_completeness.json": result.content_completeness,
        "token_budget_evaluation.json": result.token_budget,
        "validation_report.json": json.loads(serialize_validation_report(result.validation)),
        "review_package.json": {
            "package": json.loads(serialize_review_package(result.review_package)),
            "lineage": asdict(result.lineage),
            "human_content_decision_provenance": asdict(result.provenance),
            "semantic_diff": result.semantic_diff,
            "token_budget_result": result.token_budget,
            "revalidation": result.revalidation,
            **result.review_state,
        },
        "hash_chain.json": {
            "parent_candidate_sha256": result.parent_hash_before,
            "revision_candidate_sha256": result.candidate_hash,
            "validation_sha256": result.validation_hash,
            "review_package_sha256": result.review_package_hash,
            "validation_binds_candidate_sha256": result.review_package.candidate_content_hash,
        },
        "registry_invariants.json": result.registry_invariants,
        "revision_result.json": {"status": result.status, **result.review_state},
    }
    for name, value in payloads.items():
        (root / name).write_text(json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False), encoding="utf-8")
    return root

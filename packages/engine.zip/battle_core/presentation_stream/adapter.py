"""SemanticEventStore is the sole transient fact source; snapshot is persistent truth."""
import hashlib

from ..events import SemanticEventType as T, DamageOrigin
from ..events.envelope import thaw
from .catalog import action_metadata
from .snapshot import capture_combatants
from .model import (CONTRACT, PRESENTATION_TRUTH_SOURCE, PresentationKind as K,
                    PresentationEvent, PresentationFrame,
                    NAMED_PASSIVE_PRESENTATION_SOURCE_FACT_TBD)

DIRECT = {
    T.FORMAL_TURN_STARTED: K.FORMAL_TURN_STARTED,
    T.FORMAL_TURN_COMPLETED: K.FORMAL_TURN_COMPLETED,
    T.FORMAL_ACTION_STARTED: K.ACTION_STARTED,
    T.FORMAL_ACTION_COMPLETED: K.ACTION_COMPLETED,
    T.ATTACK_TARGET_SELECTED: K.TARGET_SELECTED,
    T.ATTACK_RECIPIENT_CONFIRMED: K.ATTACK_RECIPIENT_CONFIRMED,
    T.ATTACK_SUCCESSFUL_HIT_CONFIRMED: K.HIT_CONFIRMED,
    T.ATTACK_EFFECTIVE_DAMAGE_CONFIRMED: K.EFFECTIVE_ATTACK_DAMAGE_CONFIRMED,
    T.SHARED_DAMAGE_TRANSFER_SETTLED: K.SHARED_DAMAGE_APPLIED,
    T.SHIELD_BROKEN: K.SHIELD_BROKEN,
    T.PENDING_DEATH_ENTERED: K.PENDING_DEATH,
    T.PENDING_DEATH_CLEARED_TO_ALIVE: K.DEATH_PREVENTED,
    T.DEATH_CONFIRMED: K.DEFEATED,
    T.REACTION_QUEUED: K.REACTION_QUEUED,
    T.REACTION_EXECUTION_STARTED: K.REACTION_STARTED,
    T.REACTION_EXECUTION_COMPLETED: K.REACTION_COMPLETED,
}
IMPACTS = frozenset({K.DODGE_CONFIRMED, K.PARRY_CONFIRMED, K.DAMAGE_APPLIED,
                     K.SHARED_DAMAGE_APPLIED, K.EFFECTIVE_ATTACK_DAMAGE_CONFIRMED,
                     K.SHIELD_BROKEN, K.PENDING_DEATH, K.DEATH_PREVENTED, K.DEFEATED})
OUTCOME_BOOLEANS = ("successful_hit", "dodge_success", "parry_success", "effective_attack_damage")


def require_outcome(event):
    if any(type(event.payload.get(key)) is not bool for key in OUTCOME_BOOLEANS):
        raise ValueError("EXPLICIT_ATTACK_OUTCOME_FIELDS_REQUIRED")


def project_events(store, after_sequence=0, *, engine=None):
    history = store.history
    last = history[-1].sequence if history else 0
    if type(after_sequence) is not int or not 0 <= after_sequence <= last:
        raise ValueError("PRESENTATION_CURSOR_OUT_OF_RANGE")
    result = []
    for fact in history:
        if fact.sequence <= after_sequence:
            continue
        kinds = [DIRECT[fact.event_type]] if fact.event_type in DIRECT else []
        if (fact.event_type == T.ATTACK_RECIPIENT_CONFIRMED
                and fact.original_target_id is not None and fact.actual_recipient_id is not None
                and fact.original_target_id != fact.actual_recipient_id):
            kinds.append(K.TARGET_REDIRECTED)
        if fact.event_type == T.ATTACK_INSTANCE_SETTLEMENT_COMPLETED:
            require_outcome(fact)
            if fact.payload["dodge_success"]:
                kinds.append(K.DODGE_CONFIRMED)
            if fact.payload["parry_success"]:
                kinds.append(K.PARRY_CONFIRMED)
            # A skipped/Dodged Attack did not apply damage. Zero-damage successful
            # settlement is still explicit applied zero, independent of effectiveness.
            if fact.payload["successful_hit"]:
                kinds.append(K.DAMAGE_APPLIED)
        # WO095 DOT is generic damage, never an Attack outcome or visible hit.
        if (fact.event_type == T.DAMAGE_SOURCE_SETTLEMENT_COMPLETED
                and fact.damage_origin in (DamageOrigin.DOT_PERIODIC, DamageOrigin.ENVIRONMENT)):
            kinds.append(K.DAMAGE_APPLIED)
        for sub, kind in enumerate(kinds):
            details = thaw(fact.payload)
            if fact.damage_origin in (DamageOrigin.DOT_PERIODIC, DamageOrigin.ENVIRONMENT):
                details["damage_origin"] = fact.damage_origin.value
            # Preserve direct causation and source Shield/Pending links, no execution.
            details["causation_event_id"] = fact.causation_event_id
            details["parent_event_id"] = fact.parent_event_id
            lane = anchor = None
            if kind in IMPACTS:
                lane, anchor = "TARGET_IMPACT", "TARGET_UPPER_RIGHT_BODY"
            classification = fact.payload.get("action_classification")
            if kind == K.ACTION_STARTED and classification == "formal_main":
                lane, anchor = "ACTION_ANNOUNCEMENT", "ACTOR_SHOUT"
            if kind in (K.ACTION_STARTED, K.ACTION_COMPLETED) and engine is not None:
                content_id = fact.payload.get("source_content_id")
                content_action = fact.payload.get("content_action_id", fact.action_id)
                details["action_metadata"] = action_metadata(
                    engine, fact.actor_id, content_action,
                    classification=classification, source_content_id=content_id)
            details["display_metadata_gameplay_authority"] = False
            recipient = fact.damage_recipient_id or fact.share_receiver_id or fact.actual_recipient_id
            if kind == K.TARGET_SELECTED:
                targets = (fact.original_target_id,) if fact.original_target_id else ()
            elif recipient:
                targets = (recipient,)
            else:
                targets = ()
            result.append(PresentationEvent(
                (fact.sequence, sub), kind, (fact.event_id,), fact.sequence,
                fact.actor_id or fact.source_combatant_id, fact.action_id, fact.attack_instance_id,
                targets, fact.original_target_id, fact.actual_recipient_id,
                fact.damage_recipient_id or fact.share_receiver_id or fact.actual_recipient_id,
                lane, anchor, details))
    return tuple(result)


def frame(engine, after_sequence=0):
    store = engine.semantic_events
    events = project_events(store, after_sequence, engine=engine)
    history = store.history
    context = engine.trigger_context
    # The context may retain the last completed turn. Only an unclosed semantic
    # turn supplies an active actor; never infer activity from HP or action names.
    turn_facts = [f for f in history if f.event_type in (T.FORMAL_TURN_STARTED, T.FORMAL_TURN_COMPLETED)]
    active = turn_facts[-1] if turn_facts and turn_facts[-1].event_type == T.FORMAL_TURN_STARTED else None
    return PresentationFrame(
        CONTRACT, store.stream_id, after_sequence, history[-1].sequence if history else 0,
        events, capture_combatants(engine),
        None if active is None else active.actor_id,
        None if context is None else context.formal_turn_id, engine.formal_turns,
        engine.terminal_outcome("player"),
        hashlib.sha256(engine.binding_registry.serialize().encode("utf-8")).hexdigest(),
        {"truth_source": PRESENTATION_TRUTH_SOURCE, "gameplay_authority": False,
         "NO_STATUS_TRANSIENT_FROM_STATE_DIFF": True,
         "unresolved": [NAMED_PASSIVE_PRESENTATION_SOURCE_FACT_TBD],
         "non_attack_lifecycle": "LEGACY_NOT_PROJECTED",
         "floating_damage_emphasis": "RENDERER_POLICY_UNSELECTED"})

"""WO091 canonical read-only Presentation boundary."""
from .model import (PresentationKind, PresentationEvent, CombatantPresentationState, PresentationFrame,
                    PRESENTATION_TRUTH_SOURCE, NO_STATUS_TRANSIENT_FROM_STATE_DIFF,
                    NAMED_PASSIVE_PRESENTATION_SOURCE_FACT_TBD, CONTRACT)
from .adapter import frame, project_events
from .compatibility import settled_impacts_from_semantics

"""Deterministic NONCANON data trace, not a WO092 Human checkpoint package.

Run: python -m battle_core.presentation_stream.sample
"""
from ..engine import BattleEngine
from ..schema import CharacterDefinition, GridPosition, BasicAttackDefinition
from ..runtime import ShieldLedger


def sample_frame():
    def character(identity, faction, strength):
        return CharacterDefinition(identity, identity, 1, strength, 1, 0, 1, 30, 10,
                                   faction, GridPosition("front", 1), BasicAttackDefinition(1))
    engine = BattleEngine((character("sample-player", "player", 20),
                           character("sample-enemy", "enemy", 0)), seed=91)
    target = engine.state_by_id("sample-enemy")
    target.current_hp = 40
    target.shield_pool[:] = [ShieldLedger("NONCANON_SAMPLE", 7)]
    engine.settle_action("sample-player", ("sample-enemy",), action_id="sample-action",
                         attack_instance_id="sample-attack")
    return engine.presentation_frame()


if __name__ == "__main__":
    print(sample_frame().serialize())

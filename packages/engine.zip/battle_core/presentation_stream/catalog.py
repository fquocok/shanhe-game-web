"""Content display metadata only. Never parse IDs or decide action legality."""
from ..events.envelope import freeze


def action_metadata(engine, actor_id, action_id, *, classification=None, source_content_id=None):
    label = None
    # Runtime action registration supplies source IDs; content supplies display labels.
    actions = engine.action_catalog.get(actor_id, ())
    action = next((a for a in actions if a.id == action_id), None)
    if action is not None:
        source_content_id = (action.source_martial_id or action.source_inner_skill_id
                             or action.source_lightness_skill_id)
    if source_content_id is not None:
        for manager in (engine.martials, engine.inner_skills, engine.lightness):
            definition = manager.definitions.get(source_content_id)
            if definition is None:
                continue
            active = getattr(definition, "active_skill", None)
            if active is not None and active.id == action_id:
                label = active.name
            for slot in getattr(definition, "slots", ()):
                if slot.id == action_id:
                    label = slot.name
    return freeze({"action_id": action_id, "display_name": label or action_id,
                   "source_content_id": source_content_id,
                   "action_classification": classification,
                   "metadata_fallback": label is None, "gameplay_authority": False})

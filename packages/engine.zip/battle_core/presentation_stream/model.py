"""WO091 display-only immutable values; never gameplay authority."""
from dataclasses import dataclass, fields, is_dataclass
from enum import Enum
from types import MappingProxyType

from ..events.envelope import freeze, canonical_json

PRESENTATION_TRUTH_SOURCE = "SEMANTIC_EVENT_STORE_PLUS_RUNTIME_SNAPSHOT"
NO_STATUS_TRANSIENT_FROM_STATE_DIFF = True
NAMED_PASSIVE_PRESENTATION_SOURCE_FACT_TBD = "NAMED_PASSIVE_PRESENTATION_SOURCE_FACT_TBD"
CONTRACT = "CANONICAL_PRESENTATION_EVENT_STREAM_V1"


def data(value):
    if isinstance(value, Enum):
        return value.value
    if is_dataclass(value):
        return {f.name: data(getattr(value, f.name)) for f in fields(value)}
    if isinstance(value, (dict, MappingProxyType)):
        return {key: data(value[key]) for key in sorted(value)}
    if isinstance(value, (tuple, list)):
        return [data(item) for item in value]
    return value


class Document:
    __slots__ = ()

    def to_dict(self):
        return data(self)

    def serialize(self):
        return canonical_json(self.to_dict())


class PresentationKind(str, Enum):
    FORMAL_TURN_STARTED = "FORMAL_TURN_STARTED"
    FORMAL_TURN_COMPLETED = "FORMAL_TURN_COMPLETED"
    ACTION_STARTED = "ACTION_STARTED"
    ACTION_COMPLETED = "ACTION_COMPLETED"
    TARGET_SELECTED = "TARGET_SELECTED"
    ATTACK_RECIPIENT_CONFIRMED = "ATTACK_RECIPIENT_CONFIRMED"
    TARGET_REDIRECTED = "TARGET_REDIRECTED"
    HIT_CONFIRMED = "HIT_CONFIRMED"
    DODGE_CONFIRMED = "DODGE_CONFIRMED"
    PARRY_CONFIRMED = "PARRY_CONFIRMED"
    DAMAGE_APPLIED = "DAMAGE_APPLIED"
    SHARED_DAMAGE_APPLIED = "SHARED_DAMAGE_APPLIED"
    EFFECTIVE_ATTACK_DAMAGE_CONFIRMED = "EFFECTIVE_ATTACK_DAMAGE_CONFIRMED"
    SHIELD_BROKEN = "SHIELD_BROKEN"
    PENDING_DEATH = "PENDING_DEATH"
    DEATH_PREVENTED = "DEATH_PREVENTED"
    DEFEATED = "DEFEATED"
    REACTION_QUEUED = "REACTION_QUEUED"
    REACTION_STARTED = "REACTION_STARTED"
    REACTION_COMPLETED = "REACTION_COMPLETED"


@dataclass(frozen=True, slots=True)
class PresentationEvent(Document):
    # Stable (semantic sequence, local subsequence); independent of requested cursor.
    presentation_sequence: tuple[int, int]
    kind: PresentationKind
    source_event_ids: tuple[str, ...]
    source_semantic_sequence: int
    actor_id: str | None
    action_id: str | None
    attack_instance_id: str | None
    target_ids: tuple[str, ...]
    original_target_id: str | None
    actual_recipient_id: str | None
    damage_recipient_id: str | None
    display_lane: str | None
    visual_anchor: str | None
    details: object
    derivation: str = "READ_ONLY_SEMANTIC_FACT_PROJECTION"

    def __post_init__(self):
        object.__setattr__(self, "kind", PresentationKind(self.kind))
        for name in ("presentation_sequence", "source_event_ids", "target_ids"):
            object.__setattr__(self, name, tuple(getattr(self, name)))
        object.__setattr__(self, "details", freeze(self.details))


@dataclass(frozen=True, slots=True)
class CombatantPresentationState(Document):
    combatant_id: str
    display_name: str
    faction: str
    life_state: str
    ordinary_combat_eligible: bool
    on_field: bool
    current_hp: int
    max_hp: int
    hp_ratio: object
    current_qi: int
    max_qi: int
    shield: int
    cooldowns: object
    statuses: tuple
    combat_resources: object
    position: object
    martial_id: str | None
    inner_skill_id: str | None
    lightness_skill_id: str | None

    def __post_init__(self):
        for name in ("hp_ratio", "cooldowns", "statuses", "combat_resources", "position"):
            object.__setattr__(self, name, freeze(getattr(self, name)))


@dataclass(frozen=True, slots=True)
class PresentationFrame(Document):
    contract: str
    semantic_stream_id: str
    semantic_cursor_before: int
    semantic_cursor_after: int
    events: tuple[PresentationEvent, ...]
    combatants: tuple[CombatantPresentationState, ...]
    active_actor_id: str | None
    formal_turn_id: str | None
    turn_index: int
    terminal_state: str
    binding_audit_sha256: str
    metadata: object

    def __post_init__(self):
        object.__setattr__(self, "events", tuple(self.events))
        object.__setattr__(self, "combatants", tuple(self.combatants))
        object.__setattr__(self, "metadata", freeze(self.metadata))

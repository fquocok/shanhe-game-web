"""Copy only explicit Runtime state. No diff, legality check, formula or transition."""
from .model import CombatantPresentationState


def _equipped(manager, owner_id):
    definition = manager.equipped.get(owner_id)
    return None if definition is None else definition.id


def _status(instance):
    definition = getattr(instance, "definition", None)
    result = {}
    for source, target in (("instance_id", "instance_id"), ("source_id", "source_id"),
                           ("target_id", "target_id"), ("stack_count", "stack_count"),
                           ("remaining_duration", "remaining_duration"), ("applied_at", "applied_at")):
        if hasattr(instance, source):
            result[target] = getattr(instance, source)
    if definition is not None:
        for source, target in (("id", "definition_id"), ("name", "display_name"),
                               ("phase", "timing_phase"), ("tags", "tags"), ("payload", "metadata")):
            if hasattr(definition, source):
                result[target] = getattr(definition, source)
    if not result:
        result["representation"] = "UNAVAILABLE"
    return result


def capture_combatants(engine):
    """Detached persistent HUD truth. Ratio/position formatting is display-only."""
    return tuple(CombatantPresentationState(
        combatant_id=s.definition.id, display_name=s.definition.name,
        faction=s.definition.faction, life_state=s.life_state.value,
        ordinary_combat_eligible=s.ordinary_combat_eligible, on_field=s.on_field,
        current_hp=s.current_hp, max_hp=s.max_hp,
        hp_ratio={"numerator": s.current_hp, "denominator": s.max_hp,
                  "gameplay_authority": False, "derivation": "DISPLAY_ONLY_EXACT_RATIO"},
        current_qi=s.current_qi, max_qi=s.max_qi, shield=s.shield,
        cooldowns=s.cooldowns, statuses=tuple(_status(i) for i in s.statuses),
        combat_resources=s.combat_resources,
        position=None if s.position is None else {"row": s.position.row, "column": s.position.column},
        martial_id=_equipped(engine.martials, s.definition.id),
        inner_skill_id=_equipped(engine.inner_skills, s.definition.id),
        lightness_skill_id=_equipped(engine.lightness, s.definition.id),
    ) for s in sorted(engine.states, key=lambda s: s.definition.id))

"""Lossless old DTO shape, sourced exclusively from canonical semantic facts."""
from ..events import SemanticEventType as T
from ..settled_damage_presentation import SettledTargetImpact
from .adapter import require_outcome


def settled_impacts_from_semantics(store, after_sequence=0):
    """Completion values are settlement-time truth; defeat requires a lifecycle fact.

    Does not inspect current HP, CombatLog, snapshots or absence of hit events.
    Confirmed-death facts after this completion (including its pending window)
    are correlated by recipient and causation, never by HP.
    """
    history = store.history
    last = history[-1].sequence if history else 0
    if type(after_sequence) is not int or not 0 <= after_sequence <= last:
        raise ValueError("PRESENTATION_CURSOR_OUT_OF_RANGE")
    impacts = []
    for fact in history:
        if fact.sequence <= after_sequence or fact.event_type != T.ATTACK_INSTANCE_SETTLEMENT_COMPLETED:
            continue
        require_outcome(fact)
        recipient = fact.actual_recipient_id
        confirmed = False
        # Follow explicit causal links to the source settlement of this Attack.
        # A later unrelated defeat of the same actor cannot rewrite an earlier DTO.
        def roots(event):
            seen, todo = set(), [event]
            while todo:
                item = todo.pop()
                if item.event_id in seen:
                    continue
                seen.add(item.event_id)
                for link in (item.causation_event_id, item.parent_event_id):
                    if link is not None:
                        todo.append(store.get(link))
            return seen
        ancestors = {identity for identity in roots(fact)
                     if store.get(identity).event_type == T.DAMAGE_SOURCE_SETTLEMENT_COMPLETED
                     and store.get(identity).actual_recipient_id == recipient
                     and store.get(identity).attack_instance_id == fact.attack_instance_id}
        for death in history:
            if death.event_type == T.DEATH_CONFIRMED and death.damage_recipient_id == recipient:
                if ancestors.intersection(roots(death)):
                    confirmed = True
                    break
        p = fact.payload
        impacts.append(SettledTargetImpact(
            fact.attack_instance_id, fact.action_id,
            fact.actor_id or fact.source_combatant_id, recipient,
            p["successful_hit"], p["dodge_success"], p["parry_success"],
            p["final_damage_before_shield"], p["shield_absorbed_damage"], p["hp_damage"],
            p["remaining_hp"], p["remaining_shield"], confirmed,
            source_event_type=T.ATTACK_INSTANCE_SETTLEMENT_COMPLETED.value))
    return tuple(impacts)

from __future__ import annotations

from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Mapping, Sequence


class ValidationError(ValueError):
    pass


def _error(character: str, field_name: str, problem: str) -> ValidationError:
    return ValidationError(
        f"[INVALID_CHARACTER]\n角色：{character}\n欄位：{field_name}\n問題：{problem}"
    )


@dataclass(frozen=True)
class GridPosition:
    row: str
    column: int


@dataclass(frozen=True)
class BasicAttackDefinition:
    coefficient: float


@dataclass(frozen=True)
class CharacterDefinition:
    id: str
    name: str
    level: int
    strength: float
    constitution: float
    agility: float
    inner_breath: float
    weapon_attack: float
    equipment_defense: float
    faction: str
    position: GridPosition
    basic_attack: BasicAttackDefinition
    modifiers: Mapping[str, Any] = field(default_factory=lambda: MappingProxyType({}))
    preferred_rows: tuple[str, ...] = ()
    forced_slot: GridPosition | None = None
    reinforcement_fallback: str = "default"
    starts_in_reinforcement: bool = False
    external_martial_id: str | None = None
    inner_skill_id: str | None = None
    lightness_skill_id: str | None = None


REQUIRED = (
    "id", "name", "level", "attributes", "weapon_attack", "equipment_defense",
    "faction", "position", "basic_attack",
)
NUMERIC = (int, float)


def _number(value: Any, character: str, field_name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, NUMERIC):
        rendered = f'文字 "{value}"' if isinstance(value, str) else repr(value)
        raise _error(character, field_name, f"預期為數字，但收到{rendered}")
    return float(value)


def validate_characters(raw_characters: Sequence[Mapping[str, Any]]) -> tuple[CharacterDefinition, ...]:
    if not isinstance(raw_characters, Sequence) or isinstance(raw_characters, (str, bytes)):
        raise ValidationError("[INVALID_BATTLE_DATA]\n問題：characters 必須是角色陣列")
    seen_ids: set[str] = set()
    occupied: set[tuple[str, str, int]] = set()
    definitions: list[CharacterDefinition] = []
    faction_counts = {"player": 0, "enemy": 0}
    for index, raw in enumerate(raw_characters):
        if not isinstance(raw, Mapping):
            raise _error(f"索引 {index}", "character", "預期為物件")
        character = str(raw.get("id", f"索引 {index}"))
        for key in REQUIRED:
            if key not in raw:
                raise _error(character, key, "缺少必要欄位")
        if not isinstance(raw["id"], str) or not raw["id"]:
            raise _error(character, "id", "必須是非空文字")
        if raw["id"] in seen_ids:
            raise _error(character, "id", f"重複 ID：{raw['id']}")
        seen_ids.add(raw["id"])
        if not isinstance(raw["name"], str) or not raw["name"]:
            raise _error(character, "name", "必須是非空文字")
        level = _number(raw["level"], character, "level")
        if not level.is_integer() or level < 1:
            raise _error(character, "level", "必須是大於或等於 1 的整數")
        attrs = raw["attributes"]
        if not isinstance(attrs, Mapping):
            raise _error(character, "attributes", "預期為物件")
        values = {}
        for key in ("strength", "constitution", "agility", "inner_breath"):
            if key not in attrs:
                raise _error(character, key, "缺少必要欄位")
            values[key] = _number(attrs[key], character, key)
        faction = raw["faction"]
        if faction not in ("player", "enemy"):
            raise _error(character, "faction", "只允許 player 或 enemy")
        reinforcement_preview = raw.get("reinforcement", {})
        if not isinstance(reinforcement_preview, Mapping):
            raise _error(character, "reinforcement", "預期為物件")
        queued_declared = reinforcement_preview.get("queued", False)
        if type(queued_declared) is not bool:
            raise _error(character, "reinforcement.queued", "預期為布林值")
        if queued_declared and faction != "enemy":
            raise _error(character, "reinforcement.queued", "只有 enemy 可宣告為援軍")
        if not queued_declared:
            faction_counts[faction] += 1
        if faction == "player" and faction_counts[faction] > 5:
            raise _error(character, "faction", "Player active 上限為 5")
        pos = raw["position"]
        if not isinstance(pos, Mapping) or "row" not in pos or "column" not in pos:
            raise _error(character, "position", "必須包含 row 與 column")
        row, column = pos["row"], pos["column"]
        if row not in ("front", "middle", "back") or type(column) is not int or column not in (1, 2, 3):
            raise _error(character, "position", "非法九宮格位置；row 須為 front/middle/back，column 須為 1~3")
        queued_enemy = faction == "enemy" and (queued_declared or faction_counts[faction] > 9)
        cell = (faction, row, column)
        if not queued_enemy:
            if cell in occupied:
                raise _error(character, "position", f"位置重疊：{faction}/{row}/{column}")
            occupied.add(cell)
        attack = raw["basic_attack"]
        if not isinstance(attack, Mapping) or "coefficient" not in attack:
            raise _error(character, "basic_attack", "必須包含 coefficient")
        coefficient = _number(attack["coefficient"], character, "basic_attack.coefficient")
        modifiers = raw.get("modifiers", {})
        if not isinstance(modifiers, Mapping):
            raise _error(character, "modifiers", "預期為物件")
        reinforcement = raw.get("reinforcement", {})
        if not isinstance(reinforcement, Mapping):
            raise _error(character, "reinforcement", "預期為物件")
        preferred_rows = tuple(reinforcement.get("preferred_rows", ()))
        if any(r not in ("front", "middle", "back") for r in preferred_rows):
            raise _error(character, "reinforcement.preferred_rows", "只允許 front/middle/back")
        fallback = reinforcement.get("fallback_policy", "default")
        if fallback not in ("default", "wait"):
            raise _error(character, "reinforcement.fallback_policy", "只允許 default 或 wait")
        forced_raw = reinforcement.get("forced_slot")
        forced_slot = None
        if forced_raw is not None:
            if (not isinstance(forced_raw, Mapping) or forced_raw.get("row") not in ("front", "middle", "back")
                    or type(forced_raw.get("column")) is not int or forced_raw["column"] not in (1, 2, 3)):
                raise _error(character, "reinforcement.forced_slot", "必須是合法九宮格位置")
            forced_slot = GridPosition(forced_raw["row"], forced_raw["column"])
        loadout = raw.get("martial_loadout", {})
        if not isinstance(loadout, Mapping):
            raise _error(character, "martial_loadout", "預期為物件")
        external_martial_id = loadout.get("external_primary")
        if external_martial_id is not None and (not isinstance(external_martial_id, str) or not external_martial_id):
            raise _error(character, "martial_loadout.external_primary", "必須是非空文字或 null")
        inner_skill_id = loadout.get("inner_skill")
        if inner_skill_id is not None and (not isinstance(inner_skill_id, str) or not inner_skill_id):
            raise _error(character, "martial_loadout.inner_skill", "必須是非空文字或 null")
        lightness_skill_id = loadout.get("lightness_skill")
        if lightness_skill_id is not None and (not isinstance(lightness_skill_id, str) or not lightness_skill_id):
            raise _error(character, "martial_loadout.lightness_skill", "必須是非空文字或 null")
        definitions.append(CharacterDefinition(
            id=raw["id"], name=raw["name"], level=int(level), faction=faction,
            position=GridPosition(row, column), basic_attack=BasicAttackDefinition(coefficient),
            weapon_attack=_number(raw["weapon_attack"], character, "weapon_attack"),
            equipment_defense=_number(raw["equipment_defense"], character, "equipment_defense"),
            modifiers=MappingProxyType(dict(modifiers)), preferred_rows=preferred_rows,
            forced_slot=forced_slot, reinforcement_fallback=fallback,
            starts_in_reinforcement=queued_declared, external_martial_id=external_martial_id,
            inner_skill_id=inner_skill_id, lightness_skill_id=lightness_skill_id, **values,
        ))
    if not any(d.faction == "player" for d in definitions) or not any(d.faction == "enemy" for d in definitions):
        raise ValidationError("[INVALID_BATTLE_DATA]\n問題：至少需要一名 player 與一名 enemy")
    return tuple(definitions)

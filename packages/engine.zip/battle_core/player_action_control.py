"""Thin manual player command adapter over WO-039/WO-040 contracts."""
from __future__ import annotations
from copy import deepcopy
from dataclasses import asdict,dataclass,field,replace
from typing import Any

from .battle_presentation import BattlePresenter,events_from_execution,render_log,snapshot_payload
from .game_facing_martial import BoundMartial,GameFacingMartialService
from .gamefacing_settlement_bridge import GameFacingSettlementBridge

PLAYER_CONTROL_CONTRACT="GAME_FACING_PLAYER_ACTION_CONTROL_V0_1"
DEFEATED_COMBATANT_QUEUED_ACTION_INVALIDATION_CONTRACT="DEFEATED_COMBATANT_QUEUED_ACTION_INVALIDATION_V0_1"
PLAYER_CONTROLLED="PLAYER_CONTROLLED"
AI_CONTROLLED="AI_CONTROLLED"

@dataclass(frozen=True)
class PlayerActionCommand:
 battle_id:str;actor_id:str;action_id:str;target_ids:tuple[str,...]=();command_sequence:int=0;correlation_id:str|None=None

@dataclass(frozen=True)
class EncounterTarget:
 # alive is a compatibility/UI ordinary-target-availability projection only.
 # Canonical lifecycle truth lives exclusively in BattleRuntimeState.
 character_id:str;display_name:str;team:str;row:str="front";column:int=0;alive:bool=True;hp_current:int|None=None;hp_max:int|None=None;shield:int|None=None

@dataclass(frozen=True)
class PlayerCommandResult:
 accepted:bool;classification:str;error_code:str|None;actor_id:str;action_id:str;resolved_targets:tuple[str,...];presentation_events:tuple[dict[str,Any],...];combat_log:tuple[str,...];resulting_snapshot:dict[str,Any]|None;command_sequence:int;action_resolution:Any=None

@dataclass
class ControlledParticipant:
 bound:BoundMartial;control_mode:str;team:str

@dataclass(frozen=True)
class EnemyActionIntent:
 actor_id:str;action_id:str;action_display_name:str;target_ids:tuple[str,...];target_display_names:tuple[str,...];decision_authority:str="WO039_MINIMAL_DETERMINISTIC";decision_count:int=1;prediction:bool=False

@dataclass(frozen=True)
class QueuedActionValidity:
 actor_runtime_id:str;action_queue_layer:str;formal_truth_source:str;actor_defeated_before_commit:bool;actor_eligible_at_commit:bool;formally_committed:bool;presentation_valid:bool;invalidated_reason:str|None=None;actor_life_state:str="ALIVE";actor_ordinary_combat_eligible:bool=True

class ManualCombatController:
 def __init__(self,service:GameFacingMartialService,battle_id:str,participants:tuple[ControlledParticipant,...],targets:tuple[EncounterTarget,...],active_actor_id:str,*,seed=39,canonical_presentation=False):
  self.service=service;self.service.connect_settlement_bridge(GameFacingSettlementBridge.for_encounter(participants,targets,seed=seed));self.presenter=BattlePresenter(service);self.battle_id=battle_id;self.participants={x.bound.loadout.character_id:x for x in participants};self.targets={x.character_id:x for x in targets};self.active_actor_id=active_actor_id;self.formal_turn=1;self.presentation_sequence=0;self._correlations=set();self.ai_trace=[];self.response_invalidation_trace=[]
  self.canonical_presentation=canonical_presentation;self.service.settlement_bridge.checkpoint_presentation=canonical_presentation;self.command_trace=[]
  if canonical_presentation:
   self.service.settlement_bridge.checkpoint_action_catalog={identity:{"source_content_id":p.bound.definition.id,"action_presentation_metadata":{"weapon_visual_family":p.bound.view.family,"binding_authority":"FORMAL_ACTION_METADATA","binding_scope":"ACTION_PRESENTATION_ONLY","source":"GAMEFACING_BOUND_FORMAL_MARTIAL_VIEW","permanent_equipment_authority":False}} for identity,p in self.participants.items()}
  for identity,target in tuple(self.targets.items()):
   state=self.service.settlement_bridge.engine.state_by_id(identity)
   if state:self.targets[identity]=replace(target,hp_current=state.current_hp,hp_max=state.max_hp,shield=state.shield,alive=state.ordinary_combat_eligible)
 def _teams(self):
  teams={}
  for p in self.participants.values():teams.setdefault(p.team,[]).append(p.bound.loadout.character_id)
  for t in self.targets.values():teams.setdefault(t.team,[]).append(t.character_id)
  return {k:tuple(sorted(v)) for k,v in teams.items()}
 def snapshot(self):
  active=self.participants.get(self.active_actor_id);return self.presenter.snapshot(battle_id=self.battle_id,formal_turn=self.formal_turn,active=active.bound if active else None,bound_combatants=tuple(x.bound for x in sorted(self.participants.values(),key=lambda p:p.bound.loadout.character_id)),teams=self._teams(),battle_status="ONGOING")
 def _record_command(self,cmd,accepted,error=None,mode="MANUAL"):
  from dataclasses import asdict
  self.command_trace.append({"sequence":len(self.command_trace)+1,"command":asdict(cmd),"mode":mode,"accepted":accepted,"error":error})
 def _reject(self,cmd,code):
  if self.canonical_presentation:self._record_command(cmd,False,code)
  return PlayerCommandResult(False,"PLAYER_INPUT_REJECTED",code,cmd.actor_id,cmd.action_id,(),(),(),snapshot_payload(self.snapshot()),self.presentation_sequence)
 def _sync_settled_impacts(self,resolution):
  for impact in resolution.settled_impacts:
   participant=self.participants.get(impact.target_combatant_id)
   if participant:participant.bound.state.hp=impact.remaining_hp;participant.bound.state.shield=impact.remaining_shield
   target=self.targets.get(impact.target_combatant_id)
   if target:
    state=self.service.settlement_bridge.engine.state_by_id(impact.target_combatant_id)
    self.targets[impact.target_combatant_id]=replace(target,alive=state.ordinary_combat_eligible,hp_current=impact.remaining_hp,hp_max=state.max_hp,shield=impact.remaining_shield)
 def _ordinary_target_available(self,identity):
  target=self.targets.get(identity)
  state=self.service.settlement_bridge.engine.state_by_id(identity)
  # Keep explicit fixture/UI suppression compatible, but it cannot grant legality.
  return bool(target is not None and target.alive and state is not None and state.ordinary_combat_eligible)
 def _resolve_targets(self,participant,action,submitted):
  enemies={k:v for k,v in self.targets.items() if v.team!=participant.team and self._ordinary_target_available(k)}
  for tid in submitted:
   if tid not in self.targets:return None,"UNKNOWN_TARGET"
   if self.targets[tid].team==participant.team:return None,"WRONG_TEAM_TARGET"
  if not enemies and self.service.settlement_bridge.terminal_outcome()=="VICTORY":
   # Historical all-confirmed-dead fixture: observe an existing terminal result.
   # This produces no ordinary target, attack, controller execution or damage.
   return (),None
  for tid in submitted:
   state=self.service.settlement_bridge.engine.state_by_id(tid)
   if state is not None and not state.ordinary_combat_eligible:
    return None,"TARGET_DEFEATED" if state.death_confirmed else "TARGET_NOT_ORDINARY_COMBAT_ELIGIBLE"
   if not self.targets[tid].alive:return None,"TARGET_DEFEATED"
   if not self._ordinary_target_available(tid):return None,"TARGET_NOT_ORDINARY_COMBAT_ELIGIBLE"
  mode=action.targeting
  if mode=="horizontal_row":
   if len(submitted)!=1:return None,"TARGET_INPUT_INCOMPATIBLE"
   anchor=enemies.get(submitted[0]);
   if anchor is None:return None,"TARGET_UNAVAILABLE"
   return tuple(x.character_id for x in sorted(enemies.values(),key=lambda x:(x.row,x.column,x.character_id)) if x.row==anchor.row),None
  if mode in ("single","single_target"):
   if len(submitted)!=1:return None,"TARGET_INPUT_INCOMPATIBLE"
   return submitted,None
  if mode=="roaming_distinct":
   if len(submitted)!=1:return None,"TARGET_INPUT_INCOMPATIBLE"
   anchor=enemies.get(submitted[0]);ordered=sorted(enemies.values(),key=lambda x:(x.character_id!=anchor.character_id,x.row,x.column,x.character_id)) if anchor else []
   if not ordered:return None,"TARGET_UNAVAILABLE"
   requested=getattr(participant.bound.definition.active_skill,"requested_target_count",None) or len(ordered)
   return tuple(x.character_id for x in ordered[:requested]),None
  # Existing automatic/event target modes accept no arbitrary list.
  if submitted:return None,"TARGET_INPUT_INCOMPATIBLE"
  return tuple(x.character_id for x in sorted(enemies.values(),key=lambda x:x.character_id)),None
 def validate(self,cmd):
  before=deepcopy({k:(v.bound.state.controller_state,v.bound.state.hp,v.bound.state.statuses,v.bound.state.resources,v.bound.state.ordinary_special_count) for k,v in self.participants.items()});turn=self.formal_turn
  if cmd.battle_id!=self.battle_id:return self._reject(cmd,"UNKNOWN_BATTLE")
  participant=self.participants.get(cmd.actor_id)
  if participant is None:return self._reject(cmd,"UNKNOWN_ACTOR")
  settled_actor=self.service.settlement_bridge.engine.state_by_id(cmd.actor_id)
  if settled_actor is None:return self._reject(cmd,"UNKNOWN_SETTLEMENT_COMBATANT")
  if not settled_actor.ordinary_combat_eligible:
   return self._reject(cmd,"ACTOR_DEFEATED_BEFORE_PHASE" if settled_actor.death_confirmed else "ACTOR_NOT_ORDINARY_COMBAT_ELIGIBLE")
  if participant.control_mode!=PLAYER_CONTROLLED:return self._reject(cmd,"ACTOR_NOT_PLAYER_CONTROLLED")
  if cmd.actor_id!=self.active_actor_id:return self._reject(cmd,"ACTOR_NOT_CURRENTLY_ACTIONABLE")
  if cmd.command_sequence!=self.presentation_sequence:return self._reject(cmd,"STALE_COMMAND_SEQUENCE")
  if cmd.correlation_id and cmd.correlation_id in self._correlations:return self._reject(cmd,"DUPLICATE_COMMAND")
  all_actions=self.service.enumerate_actions(participant.bound,target_legal=True);owned={x.action_id:x for x in all_actions}
  action=owned.get(cmd.action_id)
  if action is None:
   foreign=any(cmd.action_id in {x.action_id for x in self.service.enumerate_actions(p.bound)} for p in self.participants.values() if p is not participant)
   return self._reject(cmd,"ACTION_NOT_OWNED" if foreign else "UNKNOWN_ACTION")
  if not action.legal:
   reasons=next(x.illegal_reasons for x in self.presenter.action_views(participant.bound) if x.action_id==cmd.action_id)
   return self._reject(cmd,"ACTION_NOT_LEGAL:"+"+".join(reasons))
  resolved,error=self._resolve_targets(participant,action,cmd.target_ids)
  if error:return self._reject(cmd,error)
  after={k:(v.bound.state.controller_state,v.bound.state.hp,v.bound.state.statuses,v.bound.state.resources,v.bound.state.ordinary_special_count) for k,v in self.participants.items()}
  if before!=after or turn!=self.formal_turn:raise RuntimeError("ENGINE_INTEGRITY_FAILURE:VALIDATION_MUTATED_STATE")
  return action,resolved
 def _execution_events(self,participant,execution,before_snap,after_snap):
  if self.canonical_presentation:
   return self.service.settlement_bridge.checkpoint_records[-1]["screen_events"]
  return events_from_execution(participant.bound,execution,before_snap,after_snap)
 def submit(self,cmd,outcomes=None):
  validated=self.validate(cmd)
  if isinstance(validated,PlayerCommandResult):return validated
  action,resolved=validated;participant=self.participants[cmd.actor_id]
  if self.canonical_presentation:self._record_command(cmd,True)
  if not resolved and self.service.settlement_bridge.terminal_outcome()=="VICTORY":
   resolution=self.service.settlement_bridge.settle(actor_id=cmd.actor_id,action_id=action.action_id,action_display_name=action.display_name,action_kind=action.kind,target_ids=())
   self.presentation_sequence+=1;self.formal_turn+=1
   if cmd.correlation_id:self._correlations.add(cmd.correlation_id)
   return PlayerCommandResult(True,"TERMINAL_OBSERVATION",None,cmd.actor_id,cmd.action_id,(),(),(),snapshot_payload(self.snapshot()),self.presentation_sequence,resolution)
  before_snap=self.snapshot();outcomes=tuple(outcomes or ("HIT",)*len(resolved));execution=self.service.execute(participant.bound,action,outcomes=outcomes,targets=resolved);self._sync_settled_impacts(execution["gamefacing_action_resolution"]);self.presentation_sequence+=1;self.formal_turn+=1
  if cmd.correlation_id:self._correlations.add(cmd.correlation_id)
  after_snap=self.snapshot();events=self._execution_events(participant,execution,before_snap,after_snap);names={x.character_id:x.display_name for x in self.targets.values()}|{x.bound.loadout.character_id:x.bound.loadout.display_name for x in self.participants.values()}
  return PlayerCommandResult(True,"ACCEPTED",None,cmd.actor_id,cmd.action_id,resolved,tuple(events) if self.canonical_presentation else tuple(asdict(x) for x in events),() if self.canonical_presentation else tuple(render_log(x,names) for x in events),snapshot_payload(after_snap),self.presentation_sequence,execution["gamefacing_action_resolution"])
 def queued_action_validity(self,actor_id):
  """Read GameFacing response eligibility exclusively from settled BattleEngine state."""
  state=self.service.settlement_bridge.engine.state_by_id(actor_id)
  if state is None:raise ValueError("UNKNOWN_SETTLEMENT_COMBATANT")
  defeated=state.death_confirmed;eligible=state.ordinary_combat_eligible
  reason=None if eligible else ("ACTOR_DEFEATED_BEFORE_COMMIT" if defeated else "ACTOR_NOT_ORDINARY_COMBAT_ELIGIBLE")
  return QueuedActionValidity(actor_id,"GAMEFACING_AI_RESPONSE_MATERIALIZATION","BATTLEENGINE_SETTLED_STATE",defeated,eligible,False,eligible,reason,state.life_state.value,eligible)
 def ordered_enemy_response_actor_ids(self):
  """Roster order is the stable encounter-target order; this is not initiative."""
  return tuple(target.character_id for target in sorted(self.targets.values(),key=lambda x:(x.row,x.column,x.character_id))
               if target.team=="enemy" and target.character_id in self.participants and self.participants[target.character_id].control_mode==AI_CONTROLLED)
 def continue_ai(self,actor_id,target_anchor):
  # choose_ai_action and _resolve_targets are executed exactly once by the shared deterministic driver below.
  participant=self.participants[actor_id]
  if participant.control_mode!=AI_CONTROLLED:raise ValueError("ACTOR_NOT_AI_CONTROLLED")
  return self._continue_deterministic(actor_id,target_anchor,"ALLY_AI" if participant.team=="player" else "ENEMY_AI")
 def continue_auto_player(self,actor_id,target_anchor):
  """Drive a player-owned actor through the existing deterministic AI/action pipeline during AUTO."""
  participant=self.participants[actor_id]
  if participant.control_mode!=PLAYER_CONTROLLED:raise ValueError("ACTOR_NOT_PLAYER_CONTROLLED")
  return self._continue_deterministic(actor_id,target_anchor,"AUTO_AI")
 def _continue_deterministic(self,actor_id,target_anchor,control_source):
  participant=self.participants[actor_id]
  validity=self.queued_action_validity(actor_id)
  if not validity.actor_eligible_at_commit:
   record={"response_status":"INVALIDATED","queued_action_validity":asdict(validity),"actor_id":actor_id,"action_id":None,"control_source":control_source,"formal_commit_point":"NOT_REACHED","settlement_created":False,"ai_decision_called":False}
   self.response_invalidation_trace.append(record);return record
  before_snap=self.snapshot();action=self.service.choose_ai_action(participant.bound);resolved,error=self._resolve_targets(participant,action,(target_anchor,));
  if error:raise ValueError(error)
  if self.canonical_presentation:
   self._record_command(PlayerActionCommand(self.battle_id,actor_id,action.action_id,tuple(resolved),len(self.command_trace)),True,mode=control_source)
  intent=EnemyActionIntent(actor_id,action.action_id,action.display_name,resolved,tuple(self.targets[x].display_name for x in resolved))
  execution=self.service.execute(participant.bound,action,outcomes=("HIT",)*len(resolved),targets=resolved);self._sync_settled_impacts(execution["gamefacing_action_resolution"]);after_snap=self.snapshot();events=self._execution_events(participant,execution,before_snap,after_snap)
  names={x.character_id:x.display_name for x in self.targets.values()}|{x.bound.loadout.character_id:x.bound.loadout.display_name for x in self.participants.values()}
  self.ai_trace.append({"response_status":"MATERIALIZED","queued_action_validity":asdict(replace(validity,formally_committed=True)),"actor_id":actor_id,"action_id":action.action_id,"display_name":action.display_name,"resolved_targets":resolved,"control_source":control_source,"execution_path":"GameFacingMartialService.execute","policy":"WO039_MINIMAL_DETERMINISTIC","intent":dict(asdict(intent),presentation_authority="PRESENTATION_CONTROLLER_DECISION_NOT_BATTLE_OUTCOME") if self.canonical_presentation else asdict(intent),"presentation_events":tuple(events) if self.canonical_presentation else tuple(asdict(x) for x in events),"combat_log":() if self.canonical_presentation else tuple(render_log(x,names) for x in events),"action_resolution":asdict(execution["gamefacing_action_resolution"]),"formal_commit_point":"GAMEFACING_SETTLEMENT_BRIDGE_EXECUTE","settlement_created":True,"ai_decision_called":True});return self.ai_trace[-1]

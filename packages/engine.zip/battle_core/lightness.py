from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Mapping

from .ai import ActionDefinition
from .status import StatusDefinition


class LightnessValidationError(ValueError): pass


def _invalid(skill,slot,field,problem):
    raise LightnessValidationError(f"[INVALID_LIGHTNESS_SKILL]\n輕功：{skill}\n槽位：{slot}\n欄位：{field}\n問題：{problem}")


@dataclass(frozen=True)
class LightnessProvenance:
    source_file:str; pricing_file:str|None; source_anchor:str; source_version:str; tier:str; budget:int


@dataclass(frozen=True)
class ExplorationProfile:
    map_movement_speed_percent:float
    jump_distance_tiles:int
    max_consecutive_jumps:int
    runtime_implementation_status:str="metadata_only"
    jump_distance_semantics:str="DEFERRED_EXPLORATION"


@dataclass(frozen=True)
class LightnessSlotDefinition:
    id:str; name:str; mechanic:str; parameters:Mapping[str,object]; domain:str


@dataclass(frozen=True)
class LightnessSkillDefinition:
    id:str; name:str; tier:str; budget:int; slots:tuple[LightnessSlotDefinition,...]
    exploration:ExplorationProfile; token_audit_total:int; provenance:LightnessProvenance


class LightnessCapabilityRegistry:
    SUPPORTED=frozenset({"agility_to_flat_speed","agility_to_dodge_bonus","ordinary_dodge_bonus",
        "respect_global_dodge_cap","non_attack_formal_main_action","self_target_combat_buff",
        "owner_turn_duration_buff","nonstacking_refresh_buff","exploration_map_speed_metadata",
        "exploration_jump_metadata","qi_cost","cooldown"})
    def require(self,skill,slot,mechanic):
        if mechanic not in self.SUPPORTED:_invalid(skill,slot,"mechanic",f"不支援的 mechanic：{mechanic}")


def extract_lightness_anchor(text,anchor_id):
    version=re.search(r'^document_version:\s*["\']?([^"\'\n]+)',text,re.M)
    marker=re.search(rf'^  {re.escape(anchor_id)}:\s*$',text,re.M)
    if not marker:_invalid(anchor_id,"anchor","id","找不到 anchor")
    rest=text[marker.end():];end=re.search(r'^  [a-zA-Z0-9_]+:\s*$',rest,re.M);block=rest[:end.start()] if end else rest
    def val(pattern,cast=str):
        m=re.search(pattern,block,re.M)
        if not m:return None
        raw=m.group(1).strip().strip("'\"")
        try:return cast(raw)
        except (ValueError,TypeError):return raw
    return MappingProxyType({"id":anchor_id,"block":block,"name":val(r'^    name_zh:\s*(.+)$'),
        "tier":val(r'^    tier:\s*(.+)$'),"budget":val(r'^    budget:\s*(.+)$',int),
        "slot_names":tuple(x.strip().strip('"\'') for x in re.findall(r'^        name_zh:\s*(.+)$',block,re.M)),
        "source_version":version.group(1) if version else "unknown"})


def compile_lightness(anchor,source_file,pricing_file=None,registry=None):
    registry=registry or LightnessCapabilityRegistry();name=anchor.get("name")
    if anchor.get("id")!="basic_100" or name!="踏風步":_invalid(name or "<unknown>","anchor","mechanic","本工作單只支援 basic_100")
    if anchor.get("tier")!="basic" or anchor.get("budget")!=100:_invalid(name,"anchor","tier/budget","缺失或非法")
    names=("輕身提縱","隨風避影","健步如飛","提氣縱身","御風身法")
    if anchor.get("slot_names")!=names:_invalid(name,"slots","names","五槽缺失、順序錯誤或含未知槽位")
    block=str(anchor["block"])
    required=('type: "agility_to_speed"','flat_speed_formula: "Agility * 0.10"','type: "agility_to_dodge"',
      'dodge_bonus_pp_formula: "Agility * 0.05"','respect_global_dodge_cap: true','type: "world_map_movement"',
      'map_movement_speed_percent: 20','type: "world_map_jump"','jump_distance_tiles: 3','max_consecutive_jumps: 1',
      'type: "active_combat_buff"','cooldown: 40','qi_cost_percent_max: 60','duration_owner_formal_turns: 3','dodge_bonus_pp: 30')
    missing=next((x for x in required if x not in block),None)
    if missing:_invalid(name,"slots","mechanic",f"缺少、不合法或不支援：{missing}")
    specs=(
      ("slot_1",names[0],"agility_to_flat_speed",{"attribute":"agility","per_point":.10},"combat"),
      ("slot_2",names[1],"agility_to_dodge_bonus",{"attribute":"agility","per_point_pp":.05,"respect_global_dodge_cap":True},"combat"),
      ("slot_3",names[2],"exploration_map_speed_metadata",{"map_movement_speed_percent":20.0},"exploration"),
      ("slot_4",names[3],"exploration_jump_metadata",{"jump_distance_tiles":3,"max_consecutive_jumps":1,"geometry":"DEFERRED_EXPLORATION"},"exploration"),
      ("slot_5",names[4],"non_attack_formal_main_action",{"target":"self","cooldown":40,"qi_cost_percent_max":.60,"duration_owner_formal_turns":3,"dodge_bonus_pp":.30,"stacking_policy":"refresh","respect_global_dodge_cap":True},"combat"))
    slots=[]
    for sid,zh,mechanic,params,domain in specs:
      registry.require(name,zh,mechanic);slots.append(LightnessSlotDefinition(sid,zh,mechanic,MappingProxyType(params),domain))
    profile=ExplorationProfile(20,3,1)
    provenance=LightnessProvenance(str(source_file),None if pricing_file is None else str(pricing_file),"basic_100",str(anchor.get("source_version","unknown")),"basic",100)
    return LightnessSkillDefinition("basic_tafeng",name,"basic",100,tuple(slots),profile,100,provenance)


def load_lightness_yaml(path,anchor_id="basic_100",pricing_path=None):
    source=Path(path)
    if pricing_path is not None and not Path(pricing_path).is_file():_invalid(anchor_id,"provenance","pricing_file","找不到 pricing reference")
    return compile_lightness(extract_lightness_anchor(source.read_text(encoding="utf-8-sig"),anchor_id),str(source),pricing_path)


def static_lightness_modifiers(definitions,characters):
    available={d.id:d for d in definitions};result={}
    for c in characters:
      if c.lightness_skill_id is None:continue
      skill=available.get(c.lightness_skill_id)
      if skill is None:_invalid(c.lightness_skill_id,"loadout","lightness_skill","找不到已載入 Lightness Definition")
      result[c.id]={"flat_speed":c.agility*.10,"dodge_bonus":c.agility*.0005}
    return result


class LightnessRuntimeManager:
    def __init__(self,engine,definitions=()):
      self.engine=engine;self.definitions={};self.equipped={}
      for d in definitions:self.load(d)
    def load(self,d):
      if d.id in self.definitions:_invalid(d.name,"load","id",f"duplicate Lightness ID：{d.id}")
      self.definitions[d.id]=d
    def equip_declared(self):
      for owner in self.engine.states:
       skill_id=owner.definition.lightness_skill_id
       if skill_id is None:continue
       if skill_id not in self.definitions:_invalid(skill_id,"loadout","lightness_skill","找不到已載入 Lightness Definition")
       skill=self.definitions[skill_id];self.equipped[owner.definition.id]=skill;owner.lightness_skill_id=skill.id
       slot=skill.slots[4];action_id=f"lightness:{skill.id}.yufeng"
       self.engine.register_action(owner.definition.id,ActionDefinition(action_id,category="self",qi_cost_percent_max=.60,
         cooldown_id=action_id,cooldown_turns=40,source_lightness_skill_id=skill.id,is_attack=False,ai_enabled=False,attack_tags=frozenset()))
       self.engine.log.add("LIGHTNESS_SKILL_LOADED",owner=owner.definition.id,lightness=skill.id,name=skill.name,
         source_file=skill.provenance.source_file,source_anchor=skill.provenance.source_anchor,source_version=skill.provenance.source_version,tier=skill.tier,budget=skill.budget,token_audit=skill.token_audit_total)
       for s in skill.slots[:2]:self.engine.log.add("LIGHTNESS_STAT_MODIFIER_APPLIED",owner=owner.definition.id,lightness=skill.id,slot_id=s.id,slot=s.name,source=f"lightness:{skill.id}",mechanic=s.mechanic)
       self.engine.log.add("EXPLORATION_PROFILE_COMPILED",owner=owner.definition.id,lightness=skill.id,
                           runtime_implementation_status="metadata_only")
    def execute_active(self,owner,action):
      skill=self.equipped[owner.definition.id];slot=skill.slots[4]
      status=StatusDefinition(f"lightness:{skill.id}:{slot.id}",slot.name,frozenset({"positive","dodge_buff"}),3,
        stacking_policy="refresh",payload=MappingProxyType({"modifiers":{"dodge_bonus":.30},"event_metadata":{"source":f"lightness:{skill.id}","slot":slot.name,"dodge_bonus_pp":30}}))
      existed=any(x.definition.id==status.id for x in owner.statuses)
      self.engine.statuses.apply(status,owner,owner)
      self.engine.log.add("LIGHTNESS_ACTIVE_USED",owner=owner.definition.id,lightness=skill.id,action=action.id,qi_cost_percent_max=.60,cooldown=40,duration_owner_formal_turns=3,dodge_bonus_pp=30)
      self.engine.log.add("LIGHTNESS_BUFF_REFRESHED" if existed else "LIGHTNESS_BUFF_APPLIED",owner=owner.definition.id,lightness=skill.id,slot=slot.name,dodge_bonus_pp=30,duration=3)

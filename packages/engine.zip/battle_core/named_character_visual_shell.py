"""WO-063 explicit, read-only named-character identity shells; never outfit canon."""
from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType

NAMED_CHARACTER_VISUAL_SHELL_CONTRACT = "NAMED_CHARACTER_VISUAL_SHELL_V0_1"
WANG_MUQING_CHARACTER_ID = "CHARACTER-WANG-MUQING"
WANG_MUQING_VISUAL_SHELL_ID = "WANG_MUQING_VISUAL_SHELL_V0_1"


@dataclass(frozen=True)
class NamedCharacterVisualShell:
    shell_id: str
    character_id: str
    display_name: str
    authority_domain: str
    character_canon_status: str
    formal_appearance_status: str
    known_visual_constraints: tuple[str, ...]
    unknown_visual_fields: tuple[str, ...]
    forbidden_inferences: tuple[str, ...]
    explicit_weapon_visual_family: str
    faction_identity: str
    faction_visual_source: str
    generic_fallback: str
    character_override_profile: str | None
    special_visual_markers: tuple[str, ...]
    special_visual_marker_authority: str
    appearance_provenance: str
    formal_body_profile_status: str
    preview_body_profile: str
    preview_body_authority: str
    martial_assignment_status: str
    human_review_required: bool
    source_refs: tuple[str, ...]


WANG_MUQING_VISUAL_SHELL = NamedCharacterVisualShell(
    WANG_MUQING_VISUAL_SHELL_ID, WANG_MUQING_CHARACTER_ID, "王沐青", "CHARACTER_IDENTITY", "CANON", "NOT_ESTABLISHED",
    ("weapon_visual_family:SWORD",),
    ("hair", "upper_garment", "lower_garment", "sleeves", "waist", "footwear", "head_accessory", "palette", "special_visual_marker", "formal_body_profile"),
    ("NO_FACTION_GUESS", "NO_FULONG_APPLICATION", "NO_YAOYUE_INFERENCE", "NO_WULING_INFERENCE", "NO_LONG_HAIR_INFERENCE", "NO_GENDER_TO_BODY_PROFILE", "NO_BLACK_FOG_VFX", "NO_BLACK_FOG_TO_SPECIES_OR_FACTION", "NO_MOTHER_RUMOR_SPECIES_VISUAL", "NO_GENERATED_MARTIAL_BINDING"),
    "SWORD", "UNKNOWN", "NONE", "GENERIC_TRAVELER", None,
    ("BLACK_FOG_PHENOMENON:KNOWN", "GAME_VISUAL_IMPLEMENTATION:NOT_AUTHORIZED"), "WORLD_PHENOMENON_ONLY",
    "NONCANONICAL_FALLBACK", "UNKNOWN", "LIGHT", "NONCANONICAL_PRESENTATION_CHOICE", "NOT_ASSIGNED", True,
    ("WORLD_CANON:WANG_MUQING_CHARACTER_IDENTITY", "WORLD_CANON:WANG_WEAPON_FAMILY", "WORLD_CANON:BLACK_FOG_PHENOMENON"),
)
NAMED_CHARACTER_VISUAL_SHELLS = MappingProxyType({WANG_MUQING_CHARACTER_ID: WANG_MUQING_VISUAL_SHELL})


def get_named_character_visual_shell(character_id: str | None) -> NamedCharacterVisualShell | None:
    """Explicit lookup only; unknown identity never creates a shell."""
    return NAMED_CHARACTER_VISUAL_SHELLS.get(character_id or "")


def named_character_visual_shell_registry_snapshot() -> dict:
    return {"contract": NAMED_CHARACTER_VISUAL_SHELL_CONTRACT, "entry_count": len(NAMED_CHARACTER_VISUAL_SHELLS),
            "entries": {WANG_MUQING_CHARACTER_ID: WANG_MUQING_VISUAL_SHELL_ID}, "world_canon_writeback": 0,
            "automatic_shell_creation": False}

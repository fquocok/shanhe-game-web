"""WO-036B2A immutable canonical-content completion revision; no promotion."""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any
import json

from .generated_acceptance import FORMAL_GENERATED_MARTIAL_REGISTRY, stable_hash
from .generator import TOKEN_COSTS, TokenAllocationPlan, deserialize_candidate, serialize_candidate, serialize_validation_report, validate_candidate
from .numeric_token_valuation import evaluate_candidate_numeric_budget

REVISION_2_ID="gen_v01_advanced_spear_31a63f7586a1.r2"
FORMAL_DISPLAY_NAME="援鋒追陣槍"
STATUS_DISPLAY_NAME="援勢"
STATUS_ID=REVISION_2_ID+".status:aided_momentum"


@dataclass(frozen=True)
class Revision2Envelope:
    revision_id:str
    parent_revision_id:str
    parent_sha256:str
    revision_number:int
    revision_reason:str
    formal_display_name:str
    formal_name_authority:str
    candidate_snapshot:str
    candidate_snapshot_sha256:str
    canonical_content:dict[str,Any]
    human_authored_fields:tuple[str,...]
    unchanged_fields:tuple[str,...]
    policy_versions:dict[str,str]
    canonical:bool=False


@dataclass(frozen=True)
class CandidateRevision2Result:
    status:str
    parent_hash_before:str
    parent_hash_after:str
    parent_immutable:bool
    candidate:Any
    envelope:Revision2Envelope
    revision_sha256:str
    candidate_snapshot_sha256:str
    validation:Any
    validation_sha256:str
    token_revaluation:dict[str,Any]
    compiler_readiness:dict[str,Any]
    review_package:dict[str,Any]
    review_package_sha256:str
    registry_invariants:dict[str,Any]


def _canonical_content():
    return {
        "formal_display_name":FORMAL_DISPLAY_NAME,
        "status":{"id":STATUS_ID,"display_name":STATUS_DISPLAY_NAME,"classification":"BUFF","purpose":"BEHIND_PURSUIT_PERMISSION_GATE","modifiers":{},"direct_damage":False,"healing":False,"resource_generation":False,"duration":2,"duration_unit":"OWNER_FORMAL_TURNS","reapplication":"REFRESH_DURATION","stacking":False,"tenacity_route":"BYPASS_HOSTILE_TENACITY_SELF_BENEFICIAL","cleanse_dispel":"GENERIC_BUFF_STATUS_SEMANTICS"},
        "application":{"source":"THIS_MARTIAL_ALLY_RETALIATION_ORDINARY_SPECIAL","event":"SPECIAL_ACTION_SUCCESSFULLY_COMMITTED","requires_successful_hit":False,"requires_effective_damage":False,"requires_hp_damage":False,"requires_target_defeat":False,"failures_no_application":("CAP_BLOCK","FAILED_TRIGGER_ROLL","ILLEGAL_OR_DEAD_TARGET_BEFORE_EXECUTION","CANDIDATE_CANCELLATION")},
        "pursuit":{"requires_status_active":STATUS_ID,"source_action":"FROZEN_ELIGIBLE_BASIC_ATTACK_ACTION_ONLY","targeting":"immediately_behind","no_retarget":True,"no_fallback":True,"ordinary_special":True,"ordinary_special_cap_per_formal_turn":3,"consumption_timing":"ON_TRIGGER_ATTEMPT_AFTER_CONDITION_AND_CAP_LEGALITY","condition_sequence":("CONDITION_SNAPSHOT","BEHIND_TARGET_LEGALITY","ORDINARY_SPECIAL_CAP_LEGALITY","ATOMIC_STATUS_CONSUMPTION","PROBABILITY_ROLL","CANDIDATE_SETTLEMENT"),"no_legal_target":"NO_ATTEMPT_NO_CONSUME_NO_RNG","cap_block":"NO_ATTEMPT_NO_CONSUME_NO_RNG","refund_policy":"NO_REFUND_AFTER_COST_SETTLEMENT","successful_commit":"ALREADY_CONSUMED_NO_DOUBLE_CONSUMPTION","rng":"BATTLE_RNG_GENERIC_TRIGGER_STREAM"},
        "closed_interaction":("ALLY_TARGETED","RETALIATION_SPECIAL_COMMITS","APPLY_OR_REFRESH_STATUS","ELIGIBLE_BASIC_ATTACK","LEGAL_BEHIND_TARGET","CAP_LEGAL","CONSUME_STATUS","PURSUIT_TRIGGER_ATTEMPT","PURSUIT_RESOLVES"),
    }


def create_candidate_d_revision_2(workspace,*,formal_registry=None,runtime_registry=None):
    root=Path(workspace);formal_registry=FORMAL_GENERATED_MARTIAL_REGISTRY if formal_registry is None else formal_registry;runtime_registry={} if runtime_registry is None else runtime_registry
    fb,rb=len(formal_registry),len(runtime_registry)
    parent_path=root/"generated_candidates"/"wo036b1a"/"candidate_d_revision_1.json";parent_bytes=parent_path.read_bytes();parent=deserialize_candidate(parent_bytes.decode("utf-8"));parent_hash=stable_hash(serialize_candidate(parent))
    actions=tuple(dict(x) for x in parent.actions);passives=tuple(dict(x) for x in parent.passives);statuses=tuple(dict(x) for x in parent.statuses)
    actions[0].update({"pursuit_source_action":"BASIC_ATTACK_ACTION_ONLY","pursuit_status_gate":STATUS_ID,"pursuit_special_classification":"ORDINARY_SPECIAL","status_consumption_timing":"ON_TRIGGER_ATTEMPT_AFTER_CONDITION_AND_CAP_LEGALITY","refund_policy":"NO_REFUND_AFTER_COST_SETTLEMENT"})
    passives[0].update({"retaliation_special_classification":"ORDINARY_SPECIAL","status_application_event":"SPECIAL_ACTION_SUCCESSFULLY_COMMITTED","applies_status_id":STATUS_ID,"status_application_requires_hit":False,"status_application_requires_damage":False})
    statuses[0].update({"id":STATUS_ID,"display_name":STATUS_DISPLAY_NAME,"classification":"BUFF","duration_unit":"OWNER_FORMAL_TURNS","reapplication_policy":"REFRESH_DURATION","stacking_policy":"refresh","purpose":"BEHIND_PURSUIT_PERMISSION_GATE","modifiers":{},"producer":passives[0]["id"],"consumer":actions[0]["id"]})
    caps=tuple(sorted(set(parent.capability_requirements)|{"ordinary_special"}))
    known=dict(parent.token_plan.known_costs);known["ordinary_special"]=TOKEN_COSTS["ordinary_special"]
    candidate=replace(parent,candidate_id=REVISION_2_ID,actions=actions,passives=passives,statuses=statuses,capability_requirements=caps,token_plan=TokenAllocationPlan(known,(),parent.token_plan.target_budget),canonical=False)
    snapshot=serialize_candidate(candidate);snapshot_hash=stable_hash(snapshot);content=_canonical_content()
    envelope=Revision2Envelope(REVISION_2_ID,parent.candidate_id,parent_hash,2,"HUMAN_AUTHORED_CANONICAL_CONTENT_COMPLETION",FORMAL_DISPLAY_NAME,"HUMAN_AUTHORED_CANONICAL_CONTENT",snapshot,snapshot_hash,content,("formal_display_name","status.display_name","status.classification","status.application","status.reapplication","pursuit.status_gate","pursuit.consumption_timing","pursuit.refund_policy"),("family","tier","budget","damage_coefficient","value_category","targeting","trigger_predicate","trigger_scope","cost_timing","topology","duration"),{"battle_core":"v0.9","generator":"v0.2-prototype","acceptance":"v0.1-prototype","numeric_token_policy":"v0.1"},False)
    revision_hash=stable_hash(asdict(envelope));budget=evaluate_candidate_numeric_budget(candidate,duration_unit="OWNER_FORMAL_TURNS");validation=validate_candidate(candidate);validation_hash=stable_hash(serialize_validation_report(validation))
    token={**asdict(budget),"prior_mechanic_subtotal":78,"new_explicit_priced_capabilities":{"ordinary_special":24},"semantic_cost_audit":{"status_application":"COVERED_BY_STATUS_AND_TRIGGER_CAPABILITIES","refresh_policy":"NO_REGISTERED_SEPARATE_COST","permission_gate":"COVERED_BY_STATUS_PRESENT_SEMANTICS","attempt_paid_consumption":"COVERED_BY_TRIGGER_SCOPE_AND_SETTLED_COST_SEMANTICS","unknown_cost_defaulted_to_zero":False},"authority":"TOKEN_COSTS + NUMERIC_TOKEN_POLICY_V0_1"}
    readiness={"status":"READY","formal_display_name":"PRESENT","status_effect":"PERMISSION_GATE_FULLY_SPECIFIED","application":"SUCCESSFUL_RETALIATION_SPECIAL_COMMIT","reapplication":"REFRESH_DURATION","consumption":"FULLY_ORDERED_ATTEMPT_PAID_NO_REFUND","targeting":"EXISTING_IMMEDIATELY_BEHIND_PRIMITIVE","runtime_semantics_required":"EXISTING_ONLY","semantic_invention_required":False,"promotion_performed":False}
    package={"review_package_id":"review:"+stable_hash((revision_hash,validation_hash,"WO036B2A"))[:16],"review_package_version":3,"review_subject_id":REVISION_2_ID,"candidate_revision_sha256":revision_hash,"candidate_snapshot_sha256":snapshot_hash,"parent_revision_id":parent.candidate_id,"parent_sha256":parent_hash,"validation_sha256":validation_hash,"formal_display_name":FORMAL_DISPLAY_NAME,"canonical_content":content,"coefficient":{"value":1.0,"value_category":"FIRST_PASS_GENERATED_VALUE"},"token_budget":token,"compiler_readiness":readiness,"review_status":"PENDING_REVIEW","human_decision":"NONE","old_revision_1_accept_reusable":False,"canonical":False,"notice":"REVISION 2 REQUIRES A NEW HUMAN REVIEW DECISION."}
    package_hash=stable_hash(package);parent_after=stable_hash(serialize_candidate(deserialize_candidate(parent_path.read_text(encoding="utf-8"))))
    if parent_bytes!=parent_path.read_bytes() or parent_hash!=parent_after:raise RuntimeError("REVISION_1_MUTATED")
    if fb!=len(formal_registry) or rb!=len(runtime_registry):raise RuntimeError("UNAUTHORIZED_PROMOTION")
    return CandidateRevision2Result("PASS_STOPPED_AT_HUMAN_REVIEW",parent_hash,parent_after,True,candidate,envelope,revision_hash,snapshot_hash,validation,validation_hash,token,readiness,package,package_hash,{"formal_before":fb,"formal_after":len(formal_registry),"runtime_before":rb,"runtime_after":len(runtime_registry),"promotion_attempts":0,"canonical_previews":0,"registry_commits":0,"generated_canonical_count":len(formal_registry)})


def write_revision_2_artifacts(result,directory):
    root=Path(directory);root.mkdir(parents=True,exist_ok=True)
    payloads={"candidate_d_revision_2.json":asdict(result.envelope),"revision_2_hash_chain.json":{"revision_id":result.envelope.revision_id,"parent_id":result.envelope.parent_revision_id,"parent_sha256":result.parent_hash_before,"candidate_snapshot_sha256":result.candidate_snapshot_sha256,"revision_envelope_sha256":result.revision_sha256,"validation_sha256":result.validation_sha256,"review_package_sha256":result.review_package_sha256},"revision_2_validation_report.json":json.loads(serialize_validation_report(result.validation)),"revision_2_token_revaluation.json":result.token_revaluation,"revision_2_compiler_readiness.json":result.compiler_readiness,"revision_2_review_package.json":result.review_package,"registry_invariants.json":result.registry_invariants,"result.json":{"status":result.status,"canonical":False,"review_status":"PENDING_REVIEW","human_decision":"NONE"}}
    for n,v in payloads.items():(root/n).write_text(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False),encoding="utf-8")
    return root

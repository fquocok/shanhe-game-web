"""WO-062A selected visual revision and final human-promotion package only."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from hashlib import sha256
from json import dumps

from .combatant_appearance import AppearanceProfile
from .faction_visual_candidates import (
    CandidateReviewStatus, FULONG_CANDIDATES_BY_ID, FULONG_FACTION_ID, FieldProvenance,
)

GAME_FACTION_VISUAL_PROFILE_PROMOTION_PACKAGE_CONTRACT = "GAME_FACTION_VISUAL_PROFILE_PROMOTION_PACKAGE_V0_1"
FULONG_VISUAL_A_REVISION_ID = "FULONG-VISUAL-A:R1"
HUMAN_SELECTION_SOURCE = "WO-062:HUMAN_SELECTED_FULONG_VISUAL-A"
REVISION_REASON = "HUMAN_REQUESTED_MINOR_SILHOUETTE_CLEANUP"


@dataclass(frozen=True)
class FactionVisualProfileRevision:
    revision_id: str
    parent_candidate_id: str
    parent_hash: str
    revision_reason: str
    human_selection_source: str
    visual_direction: str
    appearance_profile: AppearanceProfile
    removed_visual_primitives: tuple[str, ...]
    unchanged_fields: tuple[str, ...]
    world_lore_scope: str
    canonical: bool = False
    human_review_required: bool = True

    def stable_hash(self) -> str:
        payload = asdict(self)
        payload.pop("appearance_profile")
        payload["appearance_profile_id"] = self.appearance_profile.profile_id
        return sha256(dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")).hexdigest()

    def visual_diff(self) -> dict:
        return {"changed_visual_primitives": self.removed_visual_primitives,
                "unchanged_visual_primitives": self.unchanged_fields,
                "palette_changes": 0, "body_changes": 0, "weapon_changes": 0, "motion_changes": 0,
                "ground_anchor_changes": 0, "weapon_socket_changes": 0}


@dataclass(frozen=True)
class FactionGameVisualPromotionPackage:
    faction_id: str
    selected_candidate_id: str
    selected_revision_id: str
    revision_hash: str
    human_selection_source: str
    visual_direction: str
    game_visual_scope: str
    world_lore_scope: str
    known_canon_context: tuple[str, ...]
    proposal_fields: tuple[str, ...]
    unknown_lore_fields: tuple[str, ...]
    forbidden_inferences: tuple[str, ...]
    promotion_status: str
    human_final_decision: str
    game_visual_profile_id_proposal: str
    formal_game_visual_profile_count: int
    canonical: bool = False


_parent = FULONG_CANDIDATES_BY_ID["FULONG-VISUAL-A"]
# Same selected direction and components as A; the renderer cleanup removes
# only the nonessential rectangular utility-pouch polygon.
FULONG_VISUAL_A_R1_APPEARANCE = AppearanceProfile(
    "SELECTED_TRAVEL_ESCORT_REVISION_1", "TIED", "SHORT_COAT", "TROUSER", "NARROW", "UTILITY_SASH", "TRAVEL_BOOT", "NONE", "EARTH"
)
FULONG_VISUAL_A_R1 = FactionVisualProfileRevision(
    FULONG_VISUAL_A_REVISION_ID, _parent.candidate_id, _parent.stable_hash(), REVISION_REASON,
    HUMAN_SELECTION_SOURCE, "TRAVEL_ESCORT", FULONG_VISUAL_A_R1_APPEARANCE,
    ("UTILITY_SASH.utility_pouch_polygon:REMOVED",),
    ("hair", "upper_garment", "lower_garment", "sleeves", "sash_line", "footwear", "head_accessory", "palette", "body_geometry", "weapon_sockets", "motion"),
    "WORLD_LORE_UNIFORM_CANON_NOT_ESTABLISHED",
)


def fulong_game_visual_promotion_package() -> FactionGameVisualPromotionPackage:
    return FactionGameVisualPromotionPackage(
        FULONG_FACTION_ID, _parent.candidate_id, FULONG_VISUAL_A_R1.revision_id, FULONG_VISUAL_A_R1.stable_hash(),
        HUMAN_SELECTION_SOURCE, FULONG_VISUAL_A_R1.visual_direction,
        "PROPOSED_GAME_FACING_FACTION_COMBATANT_VISUAL_TEMPLATE", FULONG_VISUAL_A_R1.world_lore_scope,
        ("Faction exists", "伏龍山／鍛川城及商路", "鏢運／護送／修械 context"),
        ("hair", "upper_garment", "lower_garment", "sleeves", "waist", "footwear", "head_accessory", "palette"),
        ("formal_uniform", "formal_palette", "formal_emblem", "formal_weapon_configuration", "rank_clothing"),
        ("NO_WORLD_LORE_UNIFORM_CLAIM", "NO_AUTO_PROMOTION", "NO_FACTION_GAMEPLAY", "NO_NAME_TO_MOTIF"),
        "PENDING_FINAL_HUMAN_REVIEW", "NONE", "game_visual:faction:fulong:v1", 0,
    )

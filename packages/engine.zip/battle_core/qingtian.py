"""Source-faithful Legendary staff shell for 擎天鎮獄棍 (WO-031)."""
from dataclasses import dataclass
from .v08_ledger import ResourceCostTiming
from .topology import *
from .trigger import CounterTargetingTransformationDefinition

IMPLEMENTATION_ID="staff_legendary_qingtian_zhenyu"
QINGTIAN_BLOCKED_BY_SPEC=()
QINGTIAN_RESOLVED_POLICIES={"budongrushan_successful_parry_counter_transformation_source_scope":{"resolution":"RESOLVED_BY_WO_031A","value":"ANY_EXISTING_OWNER_COUNTER_TRIGGERED_BY_SUCCESSFUL_PARRY"},"budongrushan_counter_creation_policy":"DO_NOT_CREATE_COUNTER","budongrushan_counter_transformation_property":"TARGETING_PATTERN_ONLY"}
QINGTIAN_SOURCE_CONTENT_TBDS=("qingtian_active_root_damage_coefficient","qingtian_hengsao_counter_damage_profile")

@dataclass(frozen=True)
class BuffProfile:
 id:str;duration_owner_formal_turns:int;parry_bonus_pp:float;defense_percent:float;application_timing:str
@dataclass(frozen=True)
class ResourceProfile:
 id:str;initial:int;maximum:int;parry_pp_per_stack:float;defense_percent_per_stack:float;duration_policy:str="permanent_until_consumed"
@dataclass(frozen=True)
class CounterProfile:
 id:str;condition_stacks:int;cost:int;chance:float;cost_timing:str;pattern:str;anchor:str;classification:str;damage_profile:str
@dataclass(frozen=True)
class ReverbProfile:
 source_counter_id:str;unique_successful_enemy_threshold:int;duration_owner_formal_turns:int;parry_damage_reduction:float;heal_percent_max_hp_on_successful_parry:float
@dataclass(frozen=True)
class ActiveTransformation:
 condition_exact_stacks:int;atomic_cost:int;from_targeting:str;to_targeting:str;execution_identity:str;spend_timing:str;after_attack_buff:BuffProfile
@dataclass(frozen=True)
class QingtianDefinition:
 id:str;name_zh:str;family:str;tier:str;budget:int;role:str;implementation_id_derived_from_naming_convention:bool
 active_id:str;active_name:str;cooldown:int;qi_cost_percent_max:float;targeting:str;anchor_policy:str;root_coefficient:str
 zhenyu:BuffProfile;resource:ResourceProfile;hengsao:CounterProfile;reverb:ReverbProfile;transformation:ActiveTransformation
 topology:MartialTopologyDefinition;topology_status:str;qualification_route:str|None
 blocked_spec_fields:tuple[str,...];source_content_tbds:tuple[str,...];tuning_placeholder:str
 counter_transformation:CounterTargetingTransformationDefinition

def _topology():
 def n(i,t,c):return MechanismNodeDefinition(i,t,c,i)
 ns=(n("active",MechanismNodeType.ACTION,"ACTION"),n("zhenyu",MechanismNodeType.STATUS,"STATUS"),n("parry",MechanismNodeType.DEFENSIVE_EVENT,"DEFENSIVE_EVENT"),n("resource",MechanismNodeType.RESOURCE,"RESOURCE"),n("hengsao",MechanismNodeType.ACTION,"ACTION"),n("reverb",MechanismNodeType.STATUS,"STATUS"),n("heal",MechanismNodeType.NON_ACTION_EFFECT,"HEAL"),n("transform",MechanismNodeType.TARGETING,"TARGETING"),n("budong",MechanismNodeType.STATUS,"STATUS"))
 def e(a,b,k=TopologyEdgeType.ENABLES):return TopologyEdgeDefinition(a,b,k,bounded=True,cross_action=True)
 es=(e("active","zhenyu",TopologyEdgeType.PRODUCES),e("zhenyu","parry"),e("parry","resource",TopologyEdgeType.PRODUCES),e("resource","hengsao",TopologyEdgeType.CONSUMES),e("hengsao","reverb",TopologyEdgeType.PRODUCES),e("reverb","parry",TopologyEdgeType.FEEDS_BACK),e("parry","heal",TopologyEdgeType.PRODUCES),e("resource","transform",TopologyEdgeType.CONSUMES),e("transform","budong",TopologyEdgeType.PRODUCES),e("budong","parry",TopologyEdgeType.FEEDS_BACK))
 return MartialTopologyDefinition("legendary_defensive_resource_ecology","LEGENDARY",ns,es,("active",),("parry",),2,False,2,252,"STAFF")

def compile_qingtian(*,test_root_coefficient=None):
 root="TOKEN_BALANCE_TBD" if test_root_coefficient is None else float(test_root_coefficient)
 zhenyu=BuffProfile("zhenyu",2,.15,.15,"AFTER_ACTIVE_ATTACK_RESOLUTION_BEFORE_ACTION_COMPLETE")
 resource=ResourceProfile("zhenyue_shi",0,8,.01,.02)
 hengsao=CounterProfile("hengsao_qianjun",3,3,1.0,ResourceCostTiming.ON_TRIGGER_ATTEMPT_AFTER_CONDITION.value,"row_large","ORIGINAL_ATTACKER_SLOT","ordinary_special","SOURCE_CONTENT_TBD:qingtian_hengsao_counter_damage_profile")
 reverb=ReverbProfile(hengsao.id,3,1,.65,.03)
 budong=BuffProfile("budong_rushan",2,.20,.20,"AFTER_TRANSFORMED_ACTIVE_ATTACK_RESOLUTION")
 transform=ActiveTransformation(8,8,"cross","all_enemies","SAME_ROOT_MAIN_ACTION","BEFORE_MAIN_ACTION_OFFENSIVE_SNAPSHOT",budong)
 topology=_topology();result=validate_martial_topology(topology)
 counter_transform=CounterTargetingTransformationDefinition(IMPLEMENTATION_ID+".budong_counter_transform",IMPLEMENTATION_ID,"PARRY_SUCCESS",budong.id,"row_large")
 return QingtianDefinition(IMPLEMENTATION_ID,"擎天鎮獄棍","棍法","legendary",252,"鎮派錨點：防守資源生態與戰場反擊域",True,IMPLEMENTATION_ID+".qingtian_zhenyu","擎天鎮獄",12,.35,"cross","ALREADY_LEGAL_PRIMARY_TARGET",root,zhenyu,resource,hengsao,reverb,transform,topology,result.status,result.qualification_route,QINGTIAN_BLOCKED_BY_SPEC,QINGTIAN_SOURCE_CONTENT_TBDS,"TOKEN_BALANCE_TBD" if test_root_coefficient is None else "TEST_TUNING_PLACEHOLDER source=TOKEN_BALANCE_TBD test_only=true not_canonical=true",counter_transform)

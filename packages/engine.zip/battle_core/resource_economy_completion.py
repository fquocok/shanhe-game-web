"""Generic atomic completion for a simple finite M/G/T/C economy."""
from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass
from math import ceil,floor
from typing import Any,Mapping

from .generated_acceptance import stable_hash
from .numeric_token_valuation import evaluate_finite_combat_resource_economy
from .runtime_numeric_completion import CONTRACT_VERSION,VALUE_AUTHORITY

GROUPED_CLASS="FINITE_COMBAT_RESOURCE_ECONOMY"

@dataclass(frozen=True)
class ResourceEconomyCompletionRequest:
 candidate_id:str;resource_id:str;field_path:str;maximum:int;initial:int
 producer_semantics:Mapping[str,Any];consumer_semantics:Mapping[str,Any];threshold_semantics:Mapping[str,Any]
 allowed_tuple_domain:tuple[tuple[int,int,int],...];selection_rule:str|None
 policy_version:str;tier_budget:int;budget_before:int;binding_provenance:str
 uniform_gain:bool=True;structurally_valid:bool=True

@dataclass(frozen=True)
class ResourceEconomyCompletionResult:
 status:str;selected_G:int|None;selected_T:int|None;selected_C:int|None;M:int
 B:int|None;R:int|None;K:int|None;resource_surcharge:int|None
 budget_before:int;budget_after:int|None;authority:str|None;binding_provenance:str
 reason:str;policy_used:str|None="finite_combat_resource_economy_v0_3"

def complete_resource_economy(r:ResourceEconomyCompletionRequest):
 fail=lambda status,reason:ResourceEconomyCompletionResult(status,None,None,None,r.maximum,None,None,None,None,r.budget_before,None,None,r.binding_provenance,reason,None)
 if not r.structurally_valid:return fail("STRUCTURAL_INVALID","Resource topology invalid.")
 if r.policy_version!="v0.3":return fail("POLICY_NOT_AVAILABLE","Grouped economy is policy-bound to v0.3.")
 if r.initial>0:return fail("POLICY_NOT_AVAILABLE","Initial resource advantage is outside v0.3.")
 if not r.uniform_gain:return fail("RESOURCE_ECONOMY_SEMANTIC_BINDING_REQUIRED","Nonuniform gains have no representative G.")
 if not r.producer_semantics.get("event") or not r.consumer_semantics.get("action_id") or not r.threshold_semantics.get("predicate"):return fail("SEMANTIC_BINDING_REQUIRED","Producer, consumer, and threshold semantics are required.")
 if not r.allowed_tuple_domain:return fail("SEMANTIC_BINDING_REQUIRED","Explicit coherent tuple domain required.")
 if len(r.allowed_tuple_domain)>1 and r.selection_rule!="FIRST_DECLARED_SEMANTIC_TUPLE":return fail("HUMAN_CONTENT_REQUIRED","Multiple tuples require an explicit semantic selection rule.")
 selected=r.allowed_tuple_domain[0]
 if len(selected)!=3 or any(type(x) is not int for x in selected):return fail("SEMANTIC_BINDING_REQUIRED","Tuple must be integer (G,T,C).")
 g,t,c=selected
 if g<=0 or t<=0 or c<=0 or r.maximum<t or r.maximum<c:return fail("STRUCTURAL_INVALID","Simple economy violates M/G/T/C validity.")
 try:v=evaluate_finite_combat_resource_economy(r.maximum,g,t,c,initial=r.initial,uniform_gain=r.uniform_gain)
 except ValueError as e:return fail("POLICY_NOT_AVAILABLE",str(e))
 after=r.budget_before+v.calculated_cost
 if after>r.tier_budget:return ResourceEconomyCompletionResult("COMPLETION_OVER_BUDGET",None,None,None,r.maximum,None,None,None,v.calculated_cost,r.budget_before,after,None,r.binding_provenance,"Required tuple exceeds budget.",v.policy_id)
 return ResourceEconomyCompletionResult("COMPLETED_WITH_FIRST_PASS_GENERATED_VALUE",g,t,c,r.maximum,ceil(t/g),ceil(c/g),floor(r.maximum/c),v.calculated_cost,r.budget_before,after,VALUE_AUTHORITY,r.binding_provenance,"Atomic coherent tuple selected and valued once.",v.policy_id)

def apply_resource_economy(payload:Mapping[str,Any],request:ResourceEconomyCompletionRequest,result:ResourceEconomyCompletionResult):
 if result.status!="COMPLETED_WITH_FIRST_PASS_GENERATED_VALUE":return None
 out=deepcopy(dict(payload));resource=out["resources"][int(request.field_path.split(".")[-1])]
 resource.update({"representative_gain":result.selected_G,"threshold":result.selected_T,"consume":result.selected_C})
 out["resource_economy_completion"]={"contract_version":CONTRACT_VERSION,"class":GROUPED_CLASS,"result":result.__dict__,"source_sha256":stable_hash(payload)}
 return out

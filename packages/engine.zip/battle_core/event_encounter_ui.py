"""Traditional-Chinese WO-078 Event → Battle → Event prototype UI."""
from __future__ import annotations
from pathlib import Path

from .encounter_result_ui import EncounterResultBattleScreen
from .event_encounter import EVENT_REGISTRY, EventRuntimeFactory, EventRuntimeState, event_registry, load_event_definition
from .game_facing_encounter import encounter_configuration


def main(argv=None):
    import argparse
    import tkinter as tk
    from tkinter import ttk, messagebox
    parser=argparse.ArgumentParser(); parser.add_argument("--workspace",default="."); args=parser.parse_args(argv)
    workspace=Path(args.workspace).resolve(); factory=EventRuntimeFactory(workspace)
    root=tk.Tk(); root.title("事件 → 遭遇戰 → 事件結果原型（開發用）"); root.geometry("760x600")
    frame=ttk.Frame(root,padding=20); frame.pack(fill="both",expand=True)
    ttk.Label(frame,text="事件原型",font=("Microsoft JhengHei UI",18,"bold")).pack(anchor="w")
    registry=event_registry(workspace); definitions=tuple(load_event_definition(workspace,x) for x in registry)
    by_label={x.display_name:x.event_id for x in definitions}; selected=tk.StringVar(value=definitions[0].display_name)
    ttk.Label(frame,text="選擇事件").pack(anchor="w",pady=(12,2))
    selector=ttk.Combobox(frame,textvariable=selected,values=tuple(by_label),state="readonly",width=54); selector.pack(fill="x")
    name=ttk.Label(frame,font=("Microsoft JhengHei UI",15,"bold")); name.pack(anchor="w",pady=(18,4))
    body=ttk.Label(frame,wraplength=680); body.pack(anchor="w",pady=4)
    state_label=ttk.Label(frame,foreground="#7a4a12"); state_label.pack(anchor="w",pady=4)
    result_label=ttk.Label(frame,wraplength=680,font=("Microsoft JhengHei UI",12,"bold")); result_label.pack(anchor="w",pady=(14,4))
    summary=ttk.Label(frame,wraplength=680); summary.pack(anchor="w",pady=4)
    buttons=ttk.Frame(frame); buttons.pack(fill="x",pady=(20,0))
    runtime=None; battle_window=None; battle_screen=None

    def render():
        view=runtime.human_view(); name.config(text=view["display_name"]); body.config(text=view["initial_text"])
        state_text={"READY":"準備中／尚未戰鬥","BATTLE_ACTIVE":"戰鬥進行中","RESOLVED_VICTORY":"已解決：勝利","RESOLVED_DEFEAT":"已解決：敗北"}[view["state"]]
        state_label.config(text="目前狀態："+state_text)
        enter.config(state="normal" if view["battle_button_enabled"] else "disabled")
        reset.config(state="normal" if view["event_reset_enabled"] else "disabled")
        selector.config(state="readonly" if view["state"]!="BATTLE_ACTIVE" else "disabled")
        if view["result"] is None: result_label.config(text=""); summary.config(text="")
        else:
            result=view["result"]; result_label.config(text=f"結果：{view['result_label']}\n{view['resolved_text']}")
            summary.config(text=f"回合數：{result.round_count}\n我方存活：{result.summary['friendly_survivors']} / {result.summary['friendly_count_start']}\n敵方存活：{result.summary['enemy_survivors']} / {result.summary['enemy_count_start']}")

    def choose_event(*_):
        nonlocal runtime
        runtime=factory.create(by_label[selected.get()]); render()

    def on_result(result):
        nonlocal battle_window
        if result is None: return
        request=runtime.active_invocation
        accepted=runtime.consume_encounter_result(request.invocation_id,request.event_instance_id,result)
        if not accepted: return
        if battle_window is not None and battle_window.winfo_exists(): battle_window.destroy()
        battle_window=None; root.deiconify(); render()

    def on_battle_reset(encounter_instance_id):
        request=runtime.active_invocation
        runtime.bind_encounter_instance(request.invocation_id,encounter_instance_id)

    def enter_battle():
        nonlocal battle_window,battle_screen
        request=runtime.request_encounter()
        configuration,loader=encounter_configuration(workspace,request.encounter_id)
        battle_window=tk.Toplevel(root); root.withdraw()
        battle_screen=EncounterResultBattleScreen(battle_window,workspace,configuration,loader,on_result,on_battle_reset)
        runtime.bind_encounter_instance(request.invocation_id,loader.last_composition.encounter_instance_id); render()
        battle_window.protocol("WM_DELETE_WINDOW",lambda: messagebox.showinfo("戰鬥進行中","本原型不提供中止戰鬥；請完成戰鬥後返回事件。",parent=battle_window))

    def reset_event():
        nonlocal runtime
        if runtime.state is EventRuntimeState.BATTLE_ACTIVE: return
        runtime=factory.create(by_label[selected.get()]); render()

    enter=ttk.Button(buttons,text="進入戰鬥",command=enter_battle); enter.pack(side="left",fill="x",expand=True,padx=(0,6))
    reset=ttk.Button(buttons,text="重置事件",command=reset_event); reset.pack(side="left",fill="x",expand=True,padx=(6,0))
    selector.bind("<<ComboboxSelected>>",choose_event); choose_event(); root.mainloop()


if __name__=="__main__": main()

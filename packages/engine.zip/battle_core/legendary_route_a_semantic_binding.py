"""WO-037C2 versioned Route-A semantic bindings consumed by C1."""
from __future__ import annotations
from dataclasses import asdict
from copy import deepcopy
from pathlib import Path
from hashlib import sha256
import json

from .durable_generated_registry import DEFAULT_REGISTRY_PATH,load_generated_registry
from .generated_acceptance import stable_hash
from .runtime_numeric_completion import CONTRACT_VERSION,NumericCompletionRequest,complete_candidate_transaction

BINDING_VERSION="LEGENDARY_ROUTE_A_NUMERIC_SEMANTIC_BINDING_V0_1"
POLICY_VERSION="v0.3"
DURATION_BINDINGS={
 "legendary_resource_domain_engine":{"status_semantic_id":"route_a.resource_domain_link_status","category":"RESOURCE_LINKED"},
 "legendary_status_transformation_engine":{"status_semantic_id":"route_a.transformation_state_status","category":"OFFENSIVE"},
 "legendary_multi_carrier_closed_engine":{"status_semantic_id":"route_a.multi_carrier_coupling_status","category":"RESOURCE_LINKED"}}
for _v in DURATION_BINDINGS.values():_v.update({"duration_unit":"OWNER_FORMAL_TURNS","reapplication_mode":"REFRESH_DURATION","allowed_domain":(2,3),"domain_authority":"LEGENDARY_ROUTE_A_CROSS_ACTION_RECURRENCE_CONTRACT","completion_class":"FINITE_OWNER_FORMAL_TURN_DURATION","policy_primitive":"status_duration_owner_formal_turns_v0_1","topology_sensitivity":"MINIMUM_2_PRESERVES_CROSS_ACTION_RECURRENCE","c1_completable":True})
COOLDOWN_BINDING={"template":"legendary_multi_carrier_closed_engine","action_role":"GENERATED_ORDINARY_SPECIAL","action_index":1,"field_path":"actions.1.cooldown","semantic_type":"FINITE_ACTION_COOLDOWN","allowed_domain":(6,8),"domain_authority":"LEGENDARY_ROUTE_A_MULTI_CARRIER_RECURRENCE_CONTRACT","policy_primitive":"finite_action_cooldown_v0_2","topology_sensitivity":"FINITE_FREQUENCY_TUNING; DOMAIN_PRESERVES_REPEATABILITY","c1_completable":True}

def semantic_binding_payload():return {"binding_version":BINDING_VERSION,"scope":"future Legendary Route A generated candidates","completion_contract":CONTRACT_VERSION,"numeric_policy_version":POLICY_VERSION,"duration_bindings":DURATION_BINDINGS,"cooldown_binding":COOLDOWN_BINDING,"authority":"WORK_ORDER_ROUTE_A_SEMANTIC_CONTRACT","canonical_authority":False}
def semantic_binding_hash():return stable_hash(semantic_binding_payload())

def _requests(c,known):
 template=c["provenance"]["template_id"];binding=DURATION_BINDINGS.get(template);reqs=[]
 if c.get("statuses") and binding:
  reqs.append(NumericCompletionRequest(c["candidate_id"],"statuses.0.duration","RUNTIME_REQUIRED_NUMERIC",binding["completion_class"],"int",c["statuses"][0].get("duration"),POLICY_VERSION,c["budget"],known,0,{"duration_unit":binding["duration_unit"],"status_identity":binding["status_semantic_id"],"status_category":binding["category"],"reapplication_policy":binding["reapplication_mode"],"pure_numeric_tuning":True,"topology_change":False},binding["allowed_domain"],c["provenance"]["generation_request_id"],c["provenance"]["generation_seed"],template,domain_authority=binding["domain_authority"]))
 if template==COOLDOWN_BINDING["template"]:
  action=c["actions"][COOLDOWN_BINDING["action_index"]]
  reqs.append(NumericCompletionRequest(c["candidate_id"],COOLDOWN_BINDING["field_path"],"RUNTIME_REQUIRED_NUMERIC",COOLDOWN_BINDING["semantic_type"],"int",action.get("cooldown"),POLICY_VERSION,c["budget"],known,0,{"field_present":True,"action_id":action["id"],"action_role":COOLDOWN_BINDING["action_role"],"cooldown_kind":"FINITE_ACTION_COOLDOWN","topology_change":False},COOLDOWN_BINDING["allowed_domain"],c["provenance"]["generation_request_id"],c["provenance"]["generation_seed"],template,domain_authority=COOLDOWN_BINDING["domain_authority"]))
 return tuple(reqs)

def diagnostic_overlay(candidate):
 c=deepcopy(candidate);template=c["provenance"]["template_id"]
 # Diagnostic schema projection only; historical artifact remains untouched.
 if template==COOLDOWN_BINDING["template"]:c["actions"][1]["cooldown"]="CONTENT_TBD"
 known=sum(c["token_plan"]["known_costs"].values());result=complete_candidate_transaction(c,_requests(c,known))
 overlay=deepcopy(result.completed_candidate) if result.completed_candidate else None
 if overlay:
  overlay["historical_overlay_classification"]="NONCANONICAL_NONREVIEWABLE_HISTORICAL_DERIVED_OVERLAY"
  overlay["not_a_revision"]=True;overlay["parent_candidate_id"]=candidate["candidate_id"]
  overlay["semantic_binding_version"]=BINDING_VERSION;overlay["semantic_binding_sha256"]=semantic_binding_hash()
 return result,overlay

def audit_wo037c2(workspace):
 root=Path(workspace);base=root/"generated_candidates/wo037/lane_c_legendary_blade_route_a/pool";registry=root/DEFAULT_REGISTRY_PATH;rb=registry.read_bytes();loaded=load_generated_registry(root)
 handoff=json.loads((root/"generated_candidates/wo037c1/lane_c_c2_handoff_requirements.json").read_text(encoding="utf-8"));before={p.name:sha256(p.read_bytes()).hexdigest() for p in base.glob("*.json")}
 requirements=[{"source_requirement":x,"implementation":"Route-A binding v0.1" if "request" not in x.lower() else "future Route-A pipeline constraint","validation":"binding/dry-run matrix","status":"RESOLVED"} for x in handoff["required_bindings"]]
 duration_matrix=[{"template":t,**{k:(list(v) if isinstance(v,tuple) else v) for k,v in b.items()},"reason":"Explicit Route-A template-class intent; not inferred from field index."} for t,b in DURATION_BINDINGS.items()]
 cooldown_matrix=[{**{k:(list(v) if isinstance(v,tuple) else v) for k,v in COOLDOWN_BINDING.items()},"reason":"Only the branch with an explicit COOLDOWN carrier receives this declaration."}]
 duration_runs=[];cooldown_runs=[];combined=[];tokens=[];mapping=[];coolmap=[];qualification=[];review=[]
 for p in sorted(base.glob("seed_*.json")):
  raw=p.read_bytes();c=json.loads(raw);template=c["provenance"]["template_id"];known=sum(c["token_plan"]["known_costs"].values());result,overlay=diagnostic_overlay(c);res={x.field_path:x for x in result.results};dur=res["statuses.0.duration"];cool=res.get("actions.1.cooldown")
  proposed=sum(x.token_delta or 0 for x in result.results);post=known+proposed;remaining=c["budget"]-post;other=["ABSOLUTE_DAMAGE_COEFFICIENT_VALUE_REQUIRED","RESOURCE_MAX_NUMERIC_POLICY_REQUIRED"]
  mapping.append({"candidate_id":c["candidate_id"],"seed":c["provenance"]["generation_seed"],"template":template,"binding_semantic_id":DURATION_BINDINGS[template]["status_semantic_id"],"status":"RESOLVED_PATH","historical_mutated":False})
  duration_runs.append({"candidate_id":c["candidate_id"],"seed":c["provenance"]["generation_seed"],"status":dur.status,"selected_value":dur.selected_value,"token_delta":dur.token_delta,"known_total_before":known,"post_duration_total":known+(dur.token_delta or 0),"remaining_after_duration":c["budget"]-known-(dur.token_delta or 0),"over_budget":dur.status=="COMPLETION_OVER_BUDGET"})
  if cool:
   coolmap.append({"candidate_id":c["candidate_id"],"seed":c["provenance"]["generation_seed"],"action_id":c["actions"][1]["id"],"field_path":COOLDOWN_BINDING["field_path"],"status":"RESOLVED_BY_BRANCH_SCHEMA_OVERLAY"})
   cooldown_runs.append({"candidate_id":c["candidate_id"],"seed":c["provenance"]["generation_seed"],"status":cool.status,"selected_value":cool.selected_value,"token_delta":cool.token_delta})
  combined.append({"candidate_id":c["candidate_id"],"seed":c["provenance"]["generation_seed"],"transaction_status":result.status,"overlay_emitted":overlay is not None,"classification":overlay["historical_overlay_classification"] if overlay else None,"not_a_revision":True,"parent_candidate_id":c["candidate_id"],"selected_values":{x.field_path:x.selected_value for x in result.results},"token_deltas":{x.field_path:x.token_delta for x in result.results},"binding_version":BINDING_VERSION,"binding_sha256":semantic_binding_hash(),"completion_version":CONTRACT_VERSION,"policy_version":POLICY_VERSION})
  tokens.append({"candidate_id":c["candidate_id"],"known_mechanic_presence_total":known,"completion_delta":proposed,"projected_total":post,"budget":c["budget"],"remaining":remaining,"status":"BUDGET_VALID" if remaining>=0 else "CONTENT_COMPLETE_OVER_BUDGET"})
  qualification.append({"candidate_id":c["candidate_id"],"before":"VALID_LEGENDARY","after":"VALID_LEGENDARY","topology_drift":False})
  review.append({"candidate_id":c["candidate_id"],"duration_cooldown_blockers_remaining":0,"other_blockers":other,"projected_reviewable":False,"shortlisted":False})
  assert sha256(p.read_bytes()).hexdigest()==sha256(raw).hexdigest()
 after={p.name:sha256(p.read_bytes()).hexdigest() for p in base.glob("*.json")};regafter=registry.read_bytes()
 binding=semantic_binding_payload();binding_hash=semantic_binding_hash()
 same_plan={"work_order":"CODEX-WO-037C3","family":"BLADE","tier":"LEGENDARY","route":"LEGENDARY_ROUTE_A","seeds":[101,127,151,179,211,239,263,293,331,367,401,443],"stable_fields":["template","topology nodes/edges","carrier classes","trigger/cost/targeting choices"],"allowed_differences":["bound semantic metadata","concrete duration","declared branch cooldown","completion trace","token valuation","content eligibility"],"generation_rng_only":True}
 new_plan={"pool_size":12,"fixed_seeds_required":True,"execute_in":"CODEX-WO-037C3","gates":["deterministic replay","all runtime-required duration/cooldown fields resolved","no structural topology regression","no implicit cooldown on unaffected templates"]}
 genericity={"seed_branches":0,"candidate_branches":0,"formal_name_branches":0,"duration_key":"template semantic class","cooldown_key":"legendary_multi_carrier_closed_engine branch","global_cooldown_pollution":False,"global_owner_turn_duration_pollution":False,"c1_contract_changed":False}
 pipeline=["structural generation","Route A semantic binding","C1 runtime numeric completion","token valuation","content completeness","topology validation","shortlist eligibility"]
 return {"status":"PASS_LEGENDARY_ROUTE_A_SEMANTIC_BINDING_VERIFIED_STOPPED_AT_CONTROLLED_REGENERATION","handoff_resolution":requirements,"semantic_binding":binding,"semantic_binding_hash":{"binding_version":BINDING_VERSION,"sha256":binding_hash,"deterministic":binding_hash==semantic_binding_hash(),"different_domain_changes_identity":stable_hash({**binding,"duration_bindings":{**binding["duration_bindings"],"legendary_resource_domain_engine":{**binding["duration_bindings"]["legendary_resource_domain_engine"],"allowed_domain":(3,)}}})!=binding_hash},"duration_binding_matrix":duration_matrix,"cooldown_binding_matrix":cooldown_matrix,"duration_topology_sensitivity":{"status":"PASS","domain":[2,3],"neutral_1_excluded":True,"qualification_preserved":True},"cooldown_topology_sensitivity":{"status":"PASS","domain":[6,8],"neutral_8_permitted":True,"qualification_preserved":True},"historical_duration_mapping":mapping,"historical_cooldown_mapping":coolmap,"duration_dry_run":duration_runs,"cooldown_dry_run":cooldown_runs,"combined_overlays":combined,"token_revaluation":tokens,"content_projection":review,"qualification_projection":qualification,"reviewability_projection":{"candidate_count":12,"known_duration_cooldown_complete":12,"projected_reviewable":0,"reason":"Known coefficient/resource numeric content remains outside C2; no shortlist created."},"new_downstream_blockers":["ABSOLUTE_DAMAGE_COEFFICIENT_VALUE_REQUIRED","RESOURCE_MAX_NUMERIC_POLICY_REQUIRED"],"future_pipeline":pipeline,"same_seed_plan":same_plan,"new_seed_plan":new_plan,"genericity":genericity,"hash_integrity":{"before":before,"after":after,"all_12_unchanged":before==after},"registry":{"before":[loaded.count,len(loaded.runtime),loaded.count],"after":[loaded.count,len(loaded.runtime),loaded.count],"sha256_before":sha256(rb).hexdigest(),"sha256_after":sha256(regafter).hexdigest(),"bytes_unchanged":rb==regafter},"lane_state":{"lane_a":"CLOSED","lane_b":"CLOSED","lane_c":"DEFERRED_NOT_CLOSED","diagnostic_readiness":"READY_FOR_CONTROLLED_REGENERATION"},"governance":{"new_candidates":0,"candidate_mutations":0,"revisions":0,"review_packages":0,"human_decisions":0,"promotions":0,"formal_names":0,"generation_calls":0,"battle_semantic_change":False},"versions":{"battle":"v0.9","generator":"v0.2-prototype","acceptance":"v0.1-prototype","numeric_policy":"v0.3","completion_contract":CONTRACT_VERSION,"registry_schema":"v0.1","semantic_binding":BINDING_VERSION},"next_work_order":"CODEX-WO-037C3"}

def write_wo037c2_artifacts(workspace,directory):
 a=audit_wo037c2(workspace);out=Path(directory);out.mkdir(parents=True,exist_ok=True)
 keys={"c2_handoff_resolution_matrix.json":"handoff_resolution","legendary_route_a_semantic_binding_v0_1.json":"semantic_binding","semantic_binding_hash.json":"semantic_binding_hash","legendary_route_a_duration_binding_matrix.json":"duration_binding_matrix","legendary_route_a_cooldown_binding_matrix.json":"cooldown_binding_matrix","duration_topology_sensitivity_audit.json":"duration_topology_sensitivity","cooldown_topology_sensitivity_audit.json":"cooldown_topology_sensitivity","historical_duration_binding_mapping.json":"historical_duration_mapping","historical_cooldown_binding_mapping.json":"historical_cooldown_mapping","historical_duration_completion_dry_run.json":"duration_dry_run","historical_cooldown_completion_dry_run.json":"cooldown_dry_run","historical_combined_completion_overlays.json":"combined_overlays","historical_completion_token_revaluation.json":"token_revaluation","historical_content_completeness_projection.json":"content_projection","historical_route_a_qualification_projection.json":"qualification_projection","historical_reviewability_projection.json":"reviewability_projection","same_seed_c3_regeneration_plan.json":"same_seed_plan","new_seed_c3_validation_plan.json":"new_seed_plan","genericity_audit.json":"genericity","original_lane_c_hash_integrity.json":"hash_integrity","registry_immutability.json":"registry"}
 for n,k in keys.items():(out/n).write_text(json.dumps(a[k],ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
 (out/"result.json").write_text(json.dumps(a,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8");return a

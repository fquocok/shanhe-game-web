"""WO-054 damage-impact capability and formal-contract gap audit."""
from __future__ import annotations
from dataclasses import asdict
from hashlib import sha256
import json
from pathlib import Path

from .durable_generated_registry import DEFAULT_REGISTRY_PATH, load_generated_registry
from .generated_acceptance import stable_hash
from .interactive_battle_screen import (
    DAMAGE_IMPACT_CONTRACT, IMPACT_FEEDBACK_MS, IMPACT_RISE_DELAY_MS, IMPACT_RISE_PX,
    BattleScreenSession, PresentationBeatKind, project_combat_presentation_flow, project_damage_impact_feedback,
)

STATUS = "PARTIAL_BLOCKED_DAMAGE_FIELDS_UNAVAILABLE"


def _event(sequence, kind, target, details=None):
    return {"sequence": sequence, "event_type": kind, "actor_id": "fixture-attacker", "action_id": "fixture-action",
            "action_name": "authoritative fixture", "target_ids": (target,), "details": details or {}, "derivation": "RUNTIME_EVENT"}


def audit_wo054(workspace):
    root = Path(workspace); path = root / DEFAULT_REGISTRY_PATH; before = path.read_bytes(); registry = load_generated_registry(root)
    fixture_events = (_event(1, "ACTION_STARTED", "a"), _event(2, "ATTACK_RESOLVED", "a"),
                      _event(3, "DAMAGE_APPLIED", "a", {"final_damage_before_shield": 20, "shield_absorbed_damage": 8, "hp_damage": 12}),
                      _event(4, "DODGE", "b"), _event(5, "PARRY", "c"),
                      _event(6, "DAMAGE_APPLIED", "c", {"final_damage_before_shield": 7, "shield_absorbed_damage": 0, "hp_damage": 7}))
    fixture_projection = project_damage_impact_feedback(fixture_events); fixture_flow = project_combat_presentation_flow(fixture_events)
    session = BattleScreenSession(root); state = session.screen_state(); main = next(x for x in state["actions"] if x["kind"] == "MAIN_ACTION")
    session.select_action(main["action_id"]); session.select_target("enemy-center"); formal = session.submit()
    damage_events = tuple(event for event in session.settled_presentation_events if event["event_type"] == "DAMAGE_APPLIED")
    contract = {"contract": DAMAGE_IMPACT_CONTRACT, "source": "SETTLED_BATTLE_EVENTS_ONLY", "ui_damage_recalculation": "NONE",
                "vocabulary": ["HP_DAMAGE", "SHIELD_ABSORB", "ZERO_DAMAGE", "DODGE", "PARRY", "DEFEATED"], "presentation_only": True}
    return {"status": STATUS, "contract": contract, "contract_hash": stable_hash(contract),
            "implemented_capability": {"impact_projection": True, "wo053_beat_integration": True, "per_target_stable_id_mapping": True,
                                       "player_enemy_shared_path": True, "canvas_feedback": True, "click_through_body_tag": True,
                                       "reset_generation_invalidation": True, "fixture_projection": fixture_projection,
                                       "fixture_impact_beat_count": sum(beat.kind == PresentationBeatKind.IMPACT_FEEDBACK for beat in fixture_flow)},
            "formal_contract_gap": {"formal_damage_event_count": len(damage_events), "hp_damage": "UNAVAILABLE_FROM_CURRENT_PRESENTATION_CONTRACT",
                                    "shield_absorbed_damage": "UNAVAILABLE_FROM_CURRENT_PRESENTATION_CONTRACT",
                                    "final_damage_before_shield": "UNAVAILABLE_FROM_CURRENT_PRESENTATION_CONTRACT",
                                    "remaining_hp": "UNAVAILABLE_FROM_CURRENT_PRESENTATION_CONTRACT",
                                    "remaining_shield": "UNAVAILABLE_FROM_CURRENT_PRESENTATION_CONTRACT",
                                    "formal_human_visible_damage_numbers": False,
                                    "reason": "GameFacingMartialService execution currently settles outcomes and martial state/resources but exposes no damage application values."},
            "timing": {"reaction_relative_delay_ms": 0, "feedback_duration_ms": IMPACT_FEEDBACK_MS, "rise_delay_ms": IMPACT_RISE_DELAY_MS,
                       "vertical_travel_px": IMPACT_RISE_PX, "removal": "NEXT_BEAT_OR_GENERATION_INVALIDATION", "cumulative_impact_text_drift": 0},
            "preservation": {"battle_flow_readability": "PRESERVED", "busy_guard": "PRESERVED", "enemy_response": "PRESERVED", "control_ready": "PRESERVED",
                             "body_spec": "PRESERVED", "body_variants": "PRESERVED", "pose_vocabulary": "PRESERVED", "attack_motions": "PRESERVED",
                             "weapon_silhouettes": "PRESERVED", "showcase": "PRESERVED", "combat_log": formal["combat_log"]},
            "isolation": {"damage_formula_changes": 0, "battle_semantic_changes": 0, "battle_timing_semantic_changes": 0, "battle_rng_impact": 0,
                          "ai_deterministic_impact": 0, "action_legality_changes": 0, "canonical_changes": 0, "registry_changes": 0,
                          "generator_changes": 0, "acceptance_changes": 0, "numeric_token_policy_changes": 0,
                          "registry": [registry.count, len(registry.runtime), registry.count], "registry_sha256": sha256(before).hexdigest(), "registry_bytes_unchanged": path.read_bytes() == before,
                          "full_vfx_system": False, "generic_floating_text_framework": False, "cinematic_impact_engine": False,
                          "camera_shake": False, "sound_system": False, "damage_recalculation_in_ui": False,
                          "body_drift": 0, "weapon_drift": 0, "impact_text_drift": 0},
            "human_gate": {"gate": "HUMAN_DAMAGE_IMPACT_SMOKE", "formal_verification": "BLOCKED_BY_MISSING_SETTLED_DAMAGE_FIELDS",
                           "next": "STOP_AND_RETURN_BLOCKER_TO_ENGINEERING_CONTROL", "checklist": "human_damage_impact_smoke_checklist.md"}}


def write_wo054_artifacts(workspace, directory):
    result = audit_wo054(workspace); out = Path(directory); out.mkdir(parents=True, exist_ok=True)
    for filename, key in (("contract.json", "contract"), ("implemented_capability.json", "implemented_capability"),
                          ("formal_contract_gap.json", "formal_contract_gap"), ("timing_profile.json", "timing"),
                          ("preservation.json", "preservation"), ("isolation_audit.json", "isolation"), ("human_damage_impact_gate.json", "human_gate")):
        (out / filename).write_text(json.dumps(result[key], ensure_ascii=False, sort_keys=True, indent=2, default=str) + "\n", encoding="utf-8")
    (out / "contract_hash.json").write_text(json.dumps({"contract": DAMAGE_IMPACT_CONTRACT, "sha256": result["contract_hash"]}, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "result.json").write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, default=str) + "\n", encoding="utf-8")
    return result


if __name__ == "__main__":
    write_wo054_artifacts(Path.cwd(), Path.cwd() / "game_integration" / "wo054")

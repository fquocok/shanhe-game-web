"""Deterministic, read-only battle presentation for WO-040."""
from __future__ import annotations
from copy import deepcopy
from dataclasses import asdict,dataclass
from types import MappingProxyType
from typing import Any

from .game_facing_martial import BoundMartial,CharacterMartialLoadout,GameFacingMartialService,LegendaryCanonicalDefinition

WO040_PRESENTATION = "LEGACY_COMPATIBILITY_SLICE"
# New production/checkpoint consumers must use presentation_stream (WO091).
PRESENTATION_CONTRACT="GAME_FACING_BATTLE_PRESENTATION_V0_1"
DERIVED_MARK="PRESENTATION_DERIVED_FROM_RUNTIME_STATE"

@dataclass(frozen=True)
class ActionView:
 action_id:str;display_name:str;kind:str;targeting_mode:str;legal:bool;illegal_reasons:tuple[str,...]
@dataclass(frozen=True)
class CombatEventView:
 sequence:int;event_type:str;actor_id:str|None;action_id:str|None;action_name:str|None;target_ids:tuple[str,...];details:dict[str,Any];derivation:str="RUNTIME_EVENT"
@dataclass(frozen=True)
class CombatantView:
 character_id:str;display_name:str;team:str;hp_current:int;hp_max:int;shield:int;qi:int;alive:bool;martial_name:str;canonical_id:str;statuses:tuple[dict[str,Any],...];stances:tuple[dict[str,Any],...];resources:tuple[dict[str,Any],...];actions:tuple[ActionView,...]
@dataclass(frozen=True)
class BattlePresentationSnapshot:
 battle_id:str;formal_turn:int;active_actor_id:str|None;participants:tuple[CombatantView,...];teams:dict[str,tuple[str,...]];battle_status:str;recent_events:tuple[CombatEventView,...];available_actions:tuple[ActionView,...]

def _reason(bound,candidate,target_legal):
 if candidate.legal:return ()
 if not target_legal:return ("TARGET_UNAVAILABLE",)
 if isinstance(bound.definition,LegendaryCanonicalDefinition) and candidate.kind=="ORDINARY_SPECIAL":
  state=bound.state.controller_state;special=bound.definition.semantics["special"]
  reasons=[]
  if not state["stance"]:reasons.append("STANCE_REQUIRED")
  if state["resource"]<special["condition"]["resource_snapshot_minimum"]:reasons.append("INSUFFICIENT_RESOURCE")
  if state["cap_used"]>=special["cap"]:reasons.append("ORDINARY_SPECIAL_CAP_REACHED")
  return tuple(reasons) or ("TRIGGER_CONDITION_NOT_MET",)
 return ("TRIGGER_CONDITION_NOT_MET",)

class BattlePresenter:
 def __init__(self,service:GameFacingMartialService):self.service=service
 def action_views(self,bound,*,target_legal=True):
  return tuple(ActionView(x.action_id,x.display_name,x.kind,x.targeting,x.legal,_reason(bound,x,target_legal)) for x in self.service.enumerate_actions(bound,target_legal=target_legal))
 def combatant(self,bound,team="player",*,target_legal=True):
  state=bound.state;view=bound.view;statuses=tuple({"display_name":k,"remaining_duration":v,"duration_unit":"OWNER_FORMAL_TURNS"} for k,v in sorted(state.statuses.items()))
  stances=()
  resources=tuple({"display_name":k,"current":v,"maximum":bound.definition.semantics["resource"]["maximum"] if isinstance(bound.definition,LegendaryCanonicalDefinition) else None} for k,v in sorted(state.resources.items()))
  if isinstance(bound.definition,LegendaryCanonicalDefinition):stances=({"display_name":view.stance_name,"state":"ACTIVE" if state.controller_state["stance"] else "INACTIVE","derived_from":view.status_name},)
  return CombatantView(bound.loadout.character_id,bound.loadout.display_name,team,state.hp,state.max_hp,state.shield,state.qi,state.hp>0,view.formal_name,view.canonical_id,statuses,stances,resources,self.action_views(bound,target_legal=target_legal))
 def snapshot(self,*,battle_id,formal_turn,active,bound_combatants,teams,battle_status="ONGOING",recent_events=(),target_legal=True):
  participants=tuple(self.combatant(x,team=next((t for t,ids in teams.items() if x.loadout.character_id in ids),"unknown"),target_legal=target_legal) for x in bound_combatants)
  actions=self.action_views(active,target_legal=target_legal) if active else ()
  # Deepcopy detaches all nested details from later runtime mutations.
  return deepcopy(BattlePresentationSnapshot(battle_id,formal_turn,active.loadout.character_id if active else None,participants,{k:tuple(v) for k,v in teams.items()},battle_status,tuple(recent_events),actions))

def snapshot_payload(snapshot):return asdict(snapshot)

def normalize_authoritative_runtime_event(event,sequence=0):
 """Map only values supplied by runtime; damage/outcome are never inferred."""
 kind=event["type"];details={k:deepcopy(v) for k,v in event.items() if k not in ("type","actor_id","action_id","action_name","target_ids")}
 mapping={"ACTION_SELECTED":"ACTION_SELECTED","ACTION_STARTED":"ACTION_STARTED","ATTACK_RESOLVED":"ATTACK_RESOLVED","DAMAGE_APPLIED":"DAMAGE_APPLIED","DODGE":"DODGE","PARRY":"PARRY","STATUS_APPLIED":"STATUS_APPLIED","STATUS_REFRESHED":"STATUS_REFRESHED","STATUS_EXPIRED":"STATUS_EXPIRED","RESOURCE_GAINED":"RESOURCE_GAINED","RESOURCE_CONSUMED":"RESOURCE_CONSUMED","COMBATANT_DEFEATED":"COMBATANT_DEFEATED","FORMAL_TURN_CHANGED":"FORMAL_TURN_CHANGED","BATTLE_ENDED":"BATTLE_ENDED"}
 return CombatEventView(sequence,mapping[kind],event.get("actor_id"),event.get("action_id"),event.get("action_name"),tuple(event.get("target_ids",())),details)

def events_from_execution(bound,execution,previous_snapshot,current_snapshot,start_sequence=0):
 events=[];seq=start_sequence;action=execution["selected_action"];actor=execution["character"]
 def add(kind,details=None,targets=(),derivation="RUNTIME_EVENT"):
  nonlocal seq;seq+=1;events.append(CombatEventView(seq,kind,actor,action["id"],action["name"],tuple(targets),details or {},derivation))
 action_presentation_metadata=deepcopy(execution.get("action_presentation_metadata",{}))
 add("ACTION_SELECTED",{"kind":action["kind"]});add("ACTION_STARTED",{"targeting":next((x.targeting_mode for x in current_snapshot.available_actions if x.action_id==action["id"]),None),"action_presentation_metadata":action_presentation_metadata},execution["targets"])
 for target,outcome in zip(execution["targets"],execution["outcomes"]):add("DODGE" if outcome=="DODGED" else ("PARRY" if outcome.startswith("PARRIED") else "ATTACK_RESOLVED"),{"outcome":outcome},(target,))
 before=execution["before"];after=execution["after"]
 for name,duration in after["statuses"].items():
  if name not in before["statuses"]:add("STATUS_APPLIED",{"status":name,"remaining_duration":duration})
  elif before["statuses"][name]!=duration or action["kind"]=="ORDINARY_SPECIAL":add("STATUS_REFRESHED",{"status":name,"remaining_duration":duration})
 for name,duration in before["statuses"].items():
  if name not in after["statuses"]:add("STATUS_EXPIRED",{"status":name,"previous_duration":duration})
 bstance=before["controller"].get("stance");astance=after["controller"].get("stance")
 if bstance!=astance:add("STANCE_ACTIVATED" if astance else "STANCE_DEACTIVATED",{"stance":bound.view.stance_name,"state":"ACTIVE" if astance else "INACTIVE"},derivation=DERIVED_MARK)
 keys=sorted(set(before["resources"])|set(after["resources"]))
 for name in keys:
  b=before["resources"].get(name,0);a=after["resources"].get(name,0)
  if a!=b:add("RESOURCE_GAINED" if a>b else "RESOURCE_CONSUMED",{"resource":name,"before":b,"after":a,"delta":a-b})
 old={x.action_id:x.legal for x in previous_snapshot.available_actions};new={x.action_id:x.legal for x in current_snapshot.available_actions}
 for aid in sorted(set(old)|set(new)):
  if old.get(aid)!=new.get(aid):
   av=next((x for x in current_snapshot.available_actions if x.action_id==aid),None);add("ACTION_BECAME_AVAILABLE" if new.get(aid) else "ACTION_BECAME_UNAVAILABLE",{"action_id":aid,"display_name":av.display_name if av else aid})
 return tuple(events)

TEMPLATES={"ACTION_SELECTED":"{actor}選擇施展【{action}】。","ACTION_STARTED":"{actor}施展【{action}】，目標：{targets}。","ATTACK_RESOLVED":"【{action}】命中{targets}。","DODGE":"{targets}閃避了【{action}】。","PARRY":"{targets}招架了【{action}】。","DAMAGE_APPLIED":"{targets}受到{damage}點傷害（HP {hp_before}→{hp_after}）。","STATUS_APPLIED":"獲得【{status}】。","STATUS_REFRESHED":"【{status}】刷新。","STATUS_EXPIRED":"【{status}】消失。","STANCE_ACTIVATED":"進入【{stance}】。","STANCE_DEACTIVATED":"退出【{stance}】。","RESOURCE_GAINED":"【{resource}】{before} → {after}。","RESOURCE_CONSUMED":"【{resource}】{before} → {after}。","ACTION_BECAME_AVAILABLE":"【{display_name}】現在可以使用。","ACTION_BECAME_UNAVAILABLE":"【{display_name}】目前無法使用。","COMBATANT_DEFEATED":"{targets}被擊敗。","FORMAL_TURN_CHANGED":"正式回合變更。","BATTLE_ENDED":"戰鬥結束：{result}。"}

def render_log(event,display_names=None):
 d=dict(event.details);d.update(actor=(display_names or {}).get(event.actor_id,event.actor_id or "系統"),action=event.action_name or event.action_id or "動作",targets="、".join((display_names or {}).get(x,x) for x in event.target_ids) or "無")
 if "resolved_damage" in d:d["damage"]=d["resolved_damage"]
 return TEMPLATES[event.event_type].format_map({**{"damage":"?","hp_before":"?","hp_after":"?","status":"狀態","stance":"架勢","resource":"資源","before":"?","after":"?","display_name":"動作","result":"ONGOING"},**d})

class BattleReadoutHarness:
 def __init__(self,workspace):self.service=GameFacingMartialService(workspace);self.presenter=BattlePresenter(self.service)
 def legendary(self):
  cid="generated:blade:legendary:2b7457785666:r0";loadout=CharacterMartialLoadout("blade-user","測試刀客",(cid,),cid);bound=self.service.bind(loadout,max_hp=240);teams={"player":("blade-user",),"enemy":("enemy-left","enemy-center","enemy-right")};targets=teams["enemy"];history=[];events=[]
  snap=self.presenter.snapshot(battle_id="wo040-legendary",formal_turn=1,active=bound,bound_combatants=(bound,),teams=teams);history.append(snap)
  for turn in range(1,4):
   action=self.service.choose_ai_action(bound);execution=self.service.execute(bound,action,outcomes=("HIT","DODGED","PARRIED_SUCCESSFUL_HIT"),targets=targets);next_snap=self.presenter.snapshot(battle_id="wo040-legendary",formal_turn=turn,active=bound,bound_combatants=(bound,),teams=teams);step=events_from_execution(bound,execution,snap,next_snap,len(events));events.extend(step);next_snap=self.presenter.snapshot(battle_id="wo040-legendary",formal_turn=turn,active=bound,bound_combatants=(bound,),teams=teams,recent_events=step);history.append(next_snap);snap=next_snap
  names={"blade-user":"測試刀客","enemy-left":"敵人甲","enemy-center":"敵人乙","enemy-right":"敵人丙"}
  return {"status":"PASS","snapshots":[snapshot_payload(x) for x in history],"events":[asdict(x) for x in events],"combat_log":[render_log(x,names) for x in events],"manual_state_injection":0,"battle_status":"ONGOING"}
 def secondary(self):
  cid="generated:sword:advanced:644fb8ab88e0:r2";l=CharacterMartialLoadout("sword-user","測試劍客",(cid,),cid);b=self.service.bind(l);teams={"player":("sword-user",),"enemy":("enemy-a","enemy-b")};snap=self.presenter.snapshot(battle_id="wo040-sword",formal_turn=1,active=b,bound_combatants=(b,),teams=teams);action=self.service.choose_ai_action(b);execution=self.service.execute(b,action,outcomes=("HIT","DODGED"),targets=teams["enemy"]);after=self.presenter.snapshot(battle_id="wo040-sword",formal_turn=1,active=b,bound_combatants=(b,),teams=teams);events=events_from_execution(b,execution,snap,after);return {"status":"PASS","canonical_id":cid,"snapshot":snapshot_payload(after),"events":[asdict(x) for x in events],"combat_log":[render_log(x,{"sword-user":"測試劍客","enemy-a":"敵人甲","enemy-b":"敵人乙"}) for x in events],"same_presenter":True}

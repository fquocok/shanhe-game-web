"""WO100 canonical PARRY_SUCCESS source adapter; no Trigger evaluation here."""
from dataclasses import dataclass

from ..events import SemanticEventEnvelope, SemanticEventType as T
from ..events.envelope import canonical_json
from ..events.taxonomy import validate_event
from .model import TriggerMigrationError


MISMATCH = "CANONICAL_PARRY_LEGACY_TRIGGER_VIEW_MISMATCH"


class CanonicalParrySourceError(TriggerMigrationError):
    pass


class CanonicalParryParityError(TriggerMigrationError):
    pass


def _source_error():
    raise CanonicalParrySourceError("INVALID_CANONICAL_PARRY_TRIGGER_SOURCE")


def _identity(value, optional=False):
    if value is None and optional:
        return
    if type(value) is not str or not value:
        _source_error()


@dataclass(frozen=True, slots=True)
class CanonicalParryTriggerView:
    canonical_event_id: str
    formal_turn_id: str | None
    action_id: str
    attack_instance_id: str
    attacker_id: str
    original_target_id: str
    actual_recipient_id: str
    target_chain_id: str
    owning_action_id: str
    root_action_id: str
    stage_id: str | None
    source_definition_id: str | None
    action_classification: str
    offensive_snapshot_id: str | None

    def __post_init__(self):
        for key in ("canonical_event_id", "action_id", "attack_instance_id", "attacker_id",
                    "original_target_id", "actual_recipient_id", "target_chain_id",
                    "owning_action_id", "root_action_id", "action_classification"):
            _identity(getattr(self, key))
        for key in ("formal_turn_id", "stage_id", "source_definition_id", "offensive_snapshot_id"):
            _identity(getattr(self, key), optional=True)

    @classmethod
    def from_fact(cls, fact):
        if type(fact) is not SemanticEventEnvelope or fact.event_type is not T.ATTACK_PARRY_CONFIRMED:
            _source_error()
        validate_event(fact)
        payload = fact.payload
        required = ("parry_success", "dodge_success", "successful_hit", "parry_chance",
                    "owning_action_id", "root_action_id", "stage_id", "source_definition_id",
                    "action_classification", "offensive_snapshot_id")
        if any(key not in payload for key in required):
            _source_error()
        if (payload["parry_success"] is not True or payload["dodge_success"] is not False
                or payload["successful_hit"] is not True):
            _source_error()
        return cls(fact.event_id, fact.formal_turn_id, fact.action_id, fact.attack_instance_id,
                   fact.actor_id, fact.original_target_id, fact.actual_recipient_id,
                   fact.target_chain_id, payload["owning_action_id"], payload["root_action_id"],
                   payload["stage_id"], payload["source_definition_id"],
                   payload["action_classification"], payload["offensive_snapshot_id"])

    def to_trigger_input(self):
        result = dict(action_id=self.action_id, owning_action_id=self.owning_action_id,
                      root_action_id=self.root_action_id, stage_id=self.stage_id,
                      source_definition_id=self.source_definition_id,
                      attack_instance_id=self.attack_instance_id, attacker_id=self.attacker_id,
                      target_id=self.actual_recipient_id,
                      action_classification=self.action_classification,
                      offensive_snapshot_id=self.offensive_snapshot_id)
        if self.original_target_id != self.actual_recipient_id:
            result.update(original_target_id=self.original_target_id,
                          actual_recipient_id=self.actual_recipient_id,
                          target_chain_id=self.target_chain_id)
        if self.formal_turn_id is not None:
            result["formal_turn_id"] = self.formal_turn_id
        return result


def assert_parry_success_parity(canonical_input, legacy_input):
    try:
        equal = canonical_json(canonical_input) == canonical_json(legacy_input)
    except (TypeError, ValueError):
        equal = False
    if not equal:
        raise CanonicalParryParityError(MISMATCH)

"""WO107 detached post-dequeue observations, never an admission decision engine."""
from dataclasses import dataclass, field

from ..trigger import TriggerCandidate, TriggerDefinition, TRIGGER_SCOPES
from .model import (Document, OrdinarySpecialActionDescriptor, TriggerMigrationError,
                    _identity, _number, _booleans)
from .source_ref import CanonicalTriggerSourceRef

SPECIAL_CANDIDATE_EXECUTION_ADMISSION_BOUNDARY_OBSERVED_IN_WO107_NOT_MIGRATED = (
    "SPECIAL_CANDIDATE_EXECUTION_ADMISSION_BOUNDARY_OBSERVED_IN_WO107_NOT_MIGRATED")

ADMISSION_STAGES = (
    "CAPTURE_CONTEXT_DEFINITION_OWNER_AND_REJECT_IF_INELIGIBLE",
    "ORIGINAL_TEMPLATE_LEGALITY_MAY_SELECT_TARGET_AND_CONSUME_RNG",
    "CONDITIONAL_PAID_CANCELLATION_NO_REFUND_THEN_NO_LEGAL_TARGET_REJECTION",
    "ORIGINAL_TEMPLATE_ORDINARY_PARTICIPATION_AND_CAP_CHECK",
    "CANONICAL_SOURCE_VALIDATION_AT_EXISTING_BOUNDARY",
    "MARTIAL_EFFECT_SETTLEMENT_ONCE_OR_REJECTION",
    "INCREMENT_PARTICIPATING_ORDINARY_BUDGET_ONCE",
    "ORIGINAL_TEMPLATE_TRANSFORMATIONS_USING_CURRENT_OWNER_STATUS_SNAPSHOT",
    "PRESERVE_SUPPLIED_RESOLVED_TEMPLATE_UNLESS_TRANSFORMED_TEMPLATE_CHANGED",
    "SUCCESS_INCREMENT_AND_EFFECTIVE_PROBABILITY_TIMES_0_25",
    "SUCCESS_THEN_OPTIONAL_FOLLOW_UP_THEN_DECAY_LOGS",
    "CALL_EXISTING_ENGINE_SPECIAL_EXECUTION_ONCE",
)
FAILURE_SIDE_EFFECT_MATRIX = (
    ("CONTEXT_OWNER_REJECT", "EXACT_EXISTING_REASON_NO_LEGALITY_SETTLEMENT_BUDGET_OR_EXECUTION"),
    ("NO_LEGAL_TARGET", "PRECHECK_EFFECTS_REMAIN_PAID_CANCEL_ONLY_IF_TRUTHY_NO_REFUND_THEN_REJECT"),
    ("ORDINARY_CAP", "LEGALITY_EFFECTS_REMAIN_CAP_LOG_THEN_REJECT_NO_SETTLEMENT"),
    ("INVALID_CANONICAL_REF", "PRECHECK_EFFECTS_REMAIN_EXISTING_EXCEPTION_BEFORE_SETTLEMENT_BUDGET_EXECUTION"),
    ("EFFECT_SETTLEMENT_FAILED", "SETTLER_SIDE_EFFECTS_REMAIN_REJECT_NO_BUDGET_SUCCESS_DECAY_OR_EXECUTION"),
    ("LATER_EXECUTOR_FAILURE", "ALREADY_COMMITTED_ADMISSION_SIDE_EFFECTS_REMAIN_NO_NEW_ROLLBACK"),
)


@dataclass(frozen=True, slots=True)
class SpecialCandidateAdmissionBoundary(Document):
    owner_id: str
    trigger_id: str
    source_martial_id: str | None
    registration_event_type: str
    scope: str
    candidate_sequence: int
    original_template: OrdinarySpecialActionDescriptor
    selected_template: OrdinarySpecialActionDescriptor
    supplied_resolved_template: bool
    effective_probability: float
    roll: float
    coefficient_override: float | None
    original_template_ordinary_budget_participation: bool
    has_attempt_settler: bool
    has_commit_settler: bool
    has_custom_executor: bool
    canonical_source_event_id: str | None
    canonical_source_event_type: str | None
    canonical_ref_availability: str
    content_authority_markers: tuple[str, ...] = ()
    execution_family: str = field(init=False)
    admission_stages: tuple[str, ...] = field(default=ADMISSION_STAGES, init=False)
    failure_side_effect_matrix: tuple[tuple[str, str], ...] = field(default=FAILURE_SIDE_EFFECT_MATRIX, init=False)
    current_owner_validity: str = field(default="UNOBSERVED", init=False)
    target_eligibility: str = field(default="UNOBSERVED", init=False)
    budget_count: str = field(default="UNOBSERVED", init=False)
    actual_target: str = field(default="UNOBSERVED", init=False)
    source_action_id: str = field(default="UNOBSERVED", init=False)
    settle_result: str = field(default="UNOBSERVED", init=False)
    failure_reason: str = field(default="UNOBSERVED", init=False)
    final_rng: str = field(default="UNOBSERVED", init=False)
    effect_outcome: str = field(default="UNOBSERVED", init=False)
    execution_route: str = field(default="LEGACY_COMPAT", init=False)
    production_migrated: bool = field(default=False, init=False)

    def __post_init__(self):
        for name in ("owner_id", "trigger_id", "registration_event_type", "scope", "canonical_ref_availability"):
            _identity(getattr(self, name), name)
        for name in ("source_martial_id", "canonical_source_event_id", "canonical_source_event_type"):
            _identity(getattr(self, name), name, optional=True)
        if (type(self.candidate_sequence) is not int or self.scope not in TRIGGER_SCOPES
                or type(self.original_template) is not OrdinarySpecialActionDescriptor
                or type(self.selected_template) is not OrdinarySpecialActionDescriptor):
            raise TriggerMigrationError("Typed candidate/template observations required")
        for name in ("effective_probability", "roll"):
            _number(getattr(self, name), name)
        if self.coefficient_override is not None: _number(self.coefficient_override, "coefficient_override")
        _booleans(self, ("supplied_resolved_template", "original_template_ordinary_budget_participation",
                        "has_attempt_settler", "has_commit_settler", "has_custom_executor"))
        if self.has_custom_executor != self.selected_template.has_custom_executor:
            raise TriggerMigrationError("Custom presence must match selected template")
        if (type(self.content_authority_markers) is not tuple
                or any(type(v) is not str or not v for v in self.content_authority_markers)):
            raise TriggerMigrationError("Explicit detached marker tuple required")
        object.__setattr__(self, "content_authority_markers", tuple(sorted(set(self.content_authority_markers))))
        if self.canonical_ref_availability not in ("UNOBSERVED", "AVAILABLE_NOT_VALIDATED", "UNOBSERVED_UNTYPED_REFERENCE"):
            raise TriggerMigrationError("Availability only; no provenance decision")
        if (self.canonical_source_event_id is None) != (self.canonical_source_event_type is None):
            raise TriggerMigrationError("Detached provenance identity must be a pair")
        content_tbd = bool({"SOURCE_CONTENT_TBD", "TOKEN_BALANCE_TBD"}.intersection(self.content_authority_markers))
        object.__setattr__(self, "execution_family", "CUSTOM_EXECUTOR_TBD" if self.has_custom_executor else
                           "CONTENT_TBD" if content_tbd else "STANDARD")

    @classmethod
    def from_candidate(cls, candidate, *, content_authority_markers=()):
        """Copy available primitive fields; never inspect event, live state or store."""
        if type(candidate) is not TriggerCandidate or type(candidate.definition) is not TriggerDefinition:
            raise TriggerMigrationError("Concrete TriggerCandidate/TriggerDefinition required")
        definition = candidate.definition
        original = OrdinarySpecialActionDescriptor.from_template(definition.action_template)
        selected = OrdinarySpecialActionDescriptor.from_template(
            candidate.resolved_action_template or definition.action_template)
        ref = candidate.canonical_source_ref
        typed = (type(ref) is CanonicalTriggerSourceRef and type(ref.event_id) is str and bool(ref.event_id)
                 and type(ref.event_type) is str and bool(ref.event_type))
        # Do not pre-validate or retain malformed runtime provenance: the existing
        # validator must still reject it at its original post-legality point.
        return cls(definition.owner_id, definition.id, definition.source_martial_id,
            definition.event_type, definition.scope, candidate.sequence, original, selected,
            candidate.resolved_action_template is not None, candidate.effective_probability,
            candidate.roll, candidate.resolved_coefficient,
            bool(definition.counts_ordinary_budget and definition.action_template.counts_ordinary_budget),
            definition.attempt_settler is not None, definition.commit_settler is not None,
            selected.has_custom_executor, ref.event_id if typed else None, ref.event_type if typed else None,
            "AVAILABLE_NOT_VALIDATED" if typed else "UNOBSERVED" if ref is None else "UNOBSERVED_UNTYPED_REFERENCE",
            content_authority_markers)

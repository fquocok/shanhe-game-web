"""WO111 detached compatibility description; never a queue or scheduler."""
from dataclasses import dataclass, field
from ..trigger import TriggerCandidate, TriggerDefinition, SpecialActionTemplate
from .model import Document, TriggerMigrationError

SPECIAL_QUEUE_DRAIN_BOUNDARY_OBSERVED_IN_WO111_NOT_MIGRATED = (
    "SPECIAL_QUEUE_DRAIN_BOUNDARY_OBSERVED_IN_WO111_NOT_MIGRATED")

QUEUE_DRAIN_STAGES = (
    "CONSTRUCTOR_NEW_EMPTY_MUTABLE_QUEUE_AND_NOT_DRAINING",
    "QUEUE_APPEND_SAME_CANDIDATE_BEFORE_DEFINITION_CONTEXT_AND_LOG",
    "QUEUE_LOG_ORIGINAL_TEMPLATE_AND_CURRENT_ENGINE_CONTEXT_NO_EXECUTION",
    "DRAIN_REENTRANCY_GUARD_RETURN_IF_ALREADY_DRAINING",
    "SET_DRAINING_TRUE_THEN_WHILE_QUEUE_NONEMPTY",
    "IN_PLACE_LEGACY_PRIORITY_OWNER_TRIGGER_SEQUENCE_SORT_EVERY_ITERATION",
    "POP_FIRST_BEFORE_EXISTING_WO108_EXECUTE_CANDIDATE",
    "DYNAMIC_INSERTIONS_PARTICIPATE_IN_NEXT_FRESH_SORT",
    "FINALLY_RESET_DRAINING_ON_SUCCESS_OR_EXCEPTION_NO_AUTO_REQUEUE",
)
QUEUE_DRAIN_FAILURE_SIDE_EFFECTS = (
    ("QUEUE_DEFINITION_OR_CONTEXT_READ_FAILURE", "ALREADY_APPENDED_CANDIDATE_REMAINS_ORIGINAL_EXCEPTION"),
    ("QUEUE_SINK_FAILURE", "APPEND_AND_PRIOR_SINK_EFFECTS_REMAIN_NO_ROLLBACK"),
    ("ALREADY_DRAINING", "RETURN_NO_EXTRA_POP_SORT_EXECUTION_OR_RNG"),
    ("SORT_KEY_FAILURE", "ORIGINAL_EXCEPTION_AND_OBSERVED_PENDING_STATE_NO_INVENTED_RESTORE_FINALLY_FALSE"),
    ("EXECUTION_FAILURE", "POPPED_ITEM_ABSENT_PENDING_ITEMS_AND_CALLBACK_EFFECTS_REMAIN_FINALLY_FALSE"),
    ("LATER_EXPLICIT_DRAIN", "NORMAL_EXISTING_BEHAVIOR_NO_AUTOMATIC_RETRY_REFUND_OR_COMPENSATION"),
)


def _text(value):
    return value if type(value) is str else 'UNOBSERVED'


def _integer(value):
    return value if type(value) is int else 'UNOBSERVED'


@dataclass(frozen=True, slots=True)
class SpecialQueueDrainBoundary(Document):
    trigger_id: str = 'UNOBSERVED'
    owner_id: str = 'UNOBSERVED'
    original_template_id: str = 'UNOBSERVED'
    priority: int | str = 'UNOBSERVED'
    candidate_sequence: int | str = 'UNOBSERVED'
    stages: tuple[str,...] = field(default=QUEUE_DRAIN_STAGES,init=False)
    failure_side_effects: tuple[tuple[str,str],...] = field(default=QUEUE_DRAIN_FAILURE_SIDE_EFFECTS,init=False)
    observed_sort_fields: tuple[str,...] = field(default=('trigger_priority','owner_id','trigger_id','candidate_sequence'),init=False)
    queue_execution_route: str = field(default='LEGACY_COMPAT',init=False)
    simultaneous_order_authority: str = field(default='ORDINARY_SPECIAL_SIMULTANEOUS_ORDER_AUTHORITY_TBD',init=False)
    cross_source_conflict: str = field(default='CROSS_SOURCE_CONFLICT_TBD',init=False)
    runtime_queue_state: str = field(default='UNOBSERVED',init=False)
    draining_flag: str = field(default='UNOBSERVED',init=False)
    actual_eligibility: str = field(default='UNOBSERVED',init=False)
    prior_owner_state: str = field(default='UNOBSERVED',init=False)
    current_owner_state: str = field(default='UNOBSERVED',init=False)
    callback_result: str = field(default='UNOBSERVED',init=False)
    semantic_provenance: str = field(default='UNOBSERVED',init=False)
    future_ordering_policy: str = field(default='AUTHORITY_TBD',init=False)
    production_migrated: bool = field(default=False,init=False)

    def __post_init__(self):
        if any(type(getattr(self,n)) is not str for n in ('trigger_id','owner_id','original_template_id')):
            raise TriggerMigrationError('Detached literal IDs or UNOBSERVED required')
        for name in ('priority','candidate_sequence'):
            value=getattr(self,name)
            if type(value) is not int and not (type(value) is str and value=='UNOBSERVED'):
                raise TriggerMigrationError('Detached integer observation or UNOBSERVED required')

    @classmethod
    def from_candidate(cls,candidate):
        if type(candidate) is not TriggerCandidate:
            raise TriggerMigrationError('Actual TriggerCandidate only; no live queue/engine inputs')
        definition=candidate.definition
        if type(definition) is not TriggerDefinition:
            return cls(candidate_sequence=_integer(candidate.sequence))
        template=definition.action_template
        return cls(_text(definition.id),_text(definition.owner_id),
            _text(template.id) if type(template) is SpecialActionTemplate else 'UNOBSERVED',
            _integer(definition.priority),_integer(candidate.sequence))

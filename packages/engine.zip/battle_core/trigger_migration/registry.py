"""Read-only readiness metadata, never an authorization or production dispatcher."""
from dataclasses import dataclass, asdict, replace
from collections.abc import Mapping
from ..events.envelope import freeze, canonical_json
from ..trigger import TriggerDefinition, CounterTargetingTransformationDefinition
from ..bindings.model import BindingDomain
from ..bindings.martial_binding import ROUTES
from .model import (Document, TriggerMigrationError, TriggerMigrationBinding,
                    LegacyTriggerOpportunityDescriptor, MigrationAxis as A,
                    MigrationAxisStatus as S, export)
from .budget import ORDINARY_SPECIAL_BUDGET

UNCLASSIFIED_LEGACY_TRIGGER_REGISTRATION = "UNCLASSIFIED_LEGACY_TRIGGER_REGISTRATION"
CANONICAL_SPECIAL_OUTCOME_CHAIN_EMISSION_INGRESS_ESTABLISHED_IN_WO104 = "CANONICAL_SPECIAL_OUTCOME_CHAIN_EMISSION_INGRESS_ESTABLISHED_IN_WO104"
WO104_SPECIAL_CHAIN_EMISSION_SOURCE_IS_CANONICAL_ACTION_OUTCOME_FINALIZED = "WO104_SPECIAL_CHAIN_EMISSION_SOURCE_IS_CANONICAL_ACTION_OUTCOME_FINALIZED"
WO104_CHAIN_EMISSION_CANDIDATE_EXECUTION_STILL_LEGACY_COMPAT = "WO104_CHAIN_EMISSION_CANDIDATE_EXECUTION_STILL_LEGACY_COMPAT"
WO104_NO_DUPLICATE_ACTION_COMPLETE_TRIGGER_DISPATCH = "WO104_NO_DUPLICATE_ACTION_COMPLETE_TRIGGER_DISPATCH"
WO104_ORDINARY_SPECIAL_SIMULTANEOUS_ORDER_REMAINS_TBD = "WO104_ORDINARY_SPECIAL_SIMULTANEOUS_ORDER_REMAINS_TBD"
WO104_ALLY_TARGETED_AND_PRE_ACTIVE_NOT_MIGRATED = "WO104_ALLY_TARGETED_AND_PRE_ACTIVE_NOT_MIGRATED"
CANONICAL_SPECIAL_CHAIN_IDENTITY_LIFECYCLE_CONTRACT_ESTABLISHED_IN_WO103 = "CANONICAL_SPECIAL_CHAIN_IDENTITY_LIFECYCLE_CONTRACT_ESTABLISHED_IN_WO103"
SPECIAL_ACTION_EXECUTION_ORDER_PRESERVED_EXACTLY_IN_WO103 = "SPECIAL_ACTION_EXECUTION_ORDER_PRESERVED_EXACTLY_IN_WO103"
SPECIAL_SOURCE_ACTION_IDENTITY_DERIVED_ONLY_FROM_EXPLICIT_CANONICAL_TRIGGER_PROVENANCE = "SPECIAL_SOURCE_ACTION_IDENTITY_DERIVED_ONLY_FROM_EXPLICIT_CANONICAL_TRIGGER_PROVENANCE"
SPECIAL_STARTED_OUTCOME_COMPLETED_SHARE_ONE_ACTION_IDENTITY = "SPECIAL_STARTED_OUTCOME_COMPLETED_SHARE_ONE_ACTION_IDENTITY"
SPECIAL_CHAIN_CHILD_SOURCE_ACTION_ID_EQUALS_PARENT_SPECIAL_ACTION_ID = "SPECIAL_CHAIN_CHILD_SOURCE_ACTION_ID_EQUALS_PARENT_SPECIAL_ACTION_ID"
SPECIAL_CHAIN_CHILD_CAUSATION_REMAINS_PARENT_ACTION_OUTCOME_FACT = "SPECIAL_CHAIN_CHILD_CAUSATION_REMAINS_PARENT_ACTION_OUTCOME_FACT"
PARENT_SPECIAL_COMPLETION_PRECEDES_CHILD_SPECIAL_START_WITHOUT_BECOMING_CHILD_CAUSATION = "PARENT_SPECIAL_COMPLETION_PRECEDES_CHILD_SPECIAL_START_WITHOUT_BECOMING_CHILD_CAUSATION"
FORMAL_MAIN_TO_SPECIAL_CHAIN_USES_SOURCE_ACTION_IDENTITY_WITHOUT_TURN_RECLASSIFICATION = "FORMAL_MAIN_TO_SPECIAL_CHAIN_USES_SOURCE_ACTION_IDENTITY_WITHOUT_TURN_RECLASSIFICATION"
PARRY_SPECIAL_SOURCE_ACTION_IDENTITY_PRESERVES_ATTACK_OWNING_ACTION = "PARRY_SPECIAL_SOURCE_ACTION_IDENTITY_PRESERVES_ATTACK_OWNING_ACTION"
TRIGGER_CHAIN_EMISSION_REMAINS_LEGACY_COMPAT_AFTER_WO103 = "TRIGGER_CHAIN_EMISSION_REMAINS_LEGACY_COMPAT_AFTER_WO103"
ALLY_TARGETED_SPECIAL_SOURCE_IDENTITY_REMAINS_AUTHORITY_BLOCKED_AFTER_WO103 = "ALLY_TARGETED_SPECIAL_SOURCE_IDENTITY_REMAINS_AUTHORITY_BLOCKED_AFTER_WO103"
PRE_ACTIVE_SPECIAL_SOURCE_IDENTITY_REMAINS_SEMANTIC_GAP_AFTER_WO103 = "PRE_ACTIVE_SPECIAL_SOURCE_IDENTITY_REMAINS_SEMANTIC_GAP_AFTER_WO103"
UNKNOWN_LEGACY_TRIGGER_SOURCE_DOES_NOT_GAIN_INFERRED_CANONICAL_CHAIN_IDENTITY = "UNKNOWN_LEGACY_TRIGGER_SOURCE_DOES_NOT_GAIN_INFERRED_CANONICAL_CHAIN_IDENTITY"
WO103_TRACE_CHANGE_AUTHORIZED_ONLY_FOR_EXPLICIT_SPECIAL_CHAIN_IDENTITY_METADATA = "WO103_TRACE_CHANGE_AUTHORIZED_ONLY_FOR_EXPLICIT_SPECIAL_CHAIN_IDENTITY_METADATA"
WO088_POST_SETTLEMENT_QUEUE_NOT_GENERAL_TRIGGER_QUEUE = "WO088_POST_SETTLEMENT_QUEUE_NOT_GENERAL_TRIGGER_QUEUE"
CANONICAL_PARRY_SOURCE_EVENT_GAP_FOR_TRIGGER_MIGRATION = "CANONICAL_PARRY_SOURCE_EVENT_GAP_FOR_TRIGGER_MIGRATION"
CANONICAL_ACTION_OUTCOME_SOURCE_EVENT_GAP_FOR_TRIGGER_MIGRATION = "CANONICAL_ACTION_OUTCOME_SOURCE_EVENT_GAP_FOR_TRIGGER_MIGRATION"
CANONICAL_PRE_ACTIVE_STATUS_CHECK_SOURCE_EVENT_GAP = "CANONICAL_PRE_ACTIVE_STATUS_CHECK_SOURCE_EVENT_GAP"
ALLY_ATTACKED_TRIGGER_MIGRATION_BLOCKED_BY_TBD_CORE = "ALLY_ATTACKED_TRIGGER_MIGRATION_BLOCKED_BY_TBD_CORE"
TRIGGER_ATTEMPT_SETTLEMENT_TIMING_MUST_BE_PRESERVED = "TRIGGER_ATTEMPT_SETTLEMENT_TIMING_MUST_BE_PRESERVED"
TRIGGER_COMMIT_SETTLEMENT_TIMING_MUST_BE_PRESERVED = "TRIGGER_COMMIT_SETTLEMENT_TIMING_MUST_BE_PRESERVED"
LEGACY_TRIGGER_PROBABILITY_DECAY_COMPATIBILITY = "LEGACY_TRIGGER_PROBABILITY_DECAY_COMPATIBILITY"
LEGACY_TRIGGER_QUEUE_ORDER_IS_COMPATIBILITY_ONLY_NOT_CANON = "LEGACY_TRIGGER_QUEUE_ORDER_IS_COMPATIBILITY_ONLY_NOT_CANON"
ORDINARY_SPECIAL_SIMULTANEOUS_ORDER_AUTHORITY_TBD = "ORDINARY_SPECIAL_SIMULTANEOUS_ORDER_AUTHORITY_TBD"
CANONICAL_SPECIAL_ACTION_EXECUTOR_NOT_MIGRATED_IN_WO097 = "CANONICAL_SPECIAL_ACTION_EXECUTOR_NOT_MIGRATED_IN_WO097"
CANONICAL_SPECIAL_ACTION_COMPLETION_EVENT_REQUIRED_FOR_CHAIN_MIGRATION = "CANONICAL_SPECIAL_ACTION_COMPLETION_EVENT_REQUIRED_FOR_CHAIN_MIGRATION"
PRESENTATION_EVENTS_ARE_NOT_TRIGGER_AUTHORITY = "PRESENTATION_EVENTS_ARE_NOT_TRIGGER_AUTHORITY"
TRIGGER_MIGRATION_REGISTRY_PROJECTION_ALIGNED_WITH_SOURCE_EVENT_READINESS_IN_WO101 = "TRIGGER_MIGRATION_REGISTRY_PROJECTION_ALIGNED_WITH_SOURCE_EVENT_READINESS_IN_WO101"
SOURCE_EVENT_READINESS_IS_SINGLE_PROJECTION_SOURCE_FOR_TRIGGER_BINDING_ROUTE_METADATA = "SOURCE_EVENT_READINESS_IS_SINGLE_PROJECTION_SOURCE_FOR_TRIGGER_BINDING_ROUTE_METADATA"
WO101_REGISTRY_ONLY_NO_RUNTIME_TRACE_CHANGE = "WO101_REGISTRY_ONLY_NO_RUNTIME_TRACE_CHANGE"
CANONICAL_TRIGGER_SOURCE_TO_SPECIAL_ACTION_CAUSATION_LINKAGE_ESTABLISHED_IN_WO102 = "CANONICAL_TRIGGER_SOURCE_TO_SPECIAL_ACTION_CAUSATION_LINKAGE_ESTABLISHED_IN_WO102"
SPECIAL_CAUSATION_LINKAGE_ONLY_FOR_CANONICAL_ACTIVE_TRIGGER_SOURCES = "SPECIAL_CAUSATION_LINKAGE_ONLY_FOR_CANONICAL_ACTIVE_TRIGGER_SOURCES"
CANONICAL_TRIGGER_SOURCE_PROVENANCE_IS_OUT_OF_BAND_FROM_LEGACY_GAMEPLAY_EVENT = "CANONICAL_TRIGGER_SOURCE_PROVENANCE_IS_OUT_OF_BAND_FROM_LEGACY_GAMEPLAY_EVENT"
TRIGGER_SOURCE_PROVENANCE_DOES_NOT_PARTICIPATE_IN_TRIGGER_GAMEPLAY_EVALUATION = "TRIGGER_SOURCE_PROVENANCE_DOES_NOT_PARTICIPATE_IN_TRIGGER_GAMEPLAY_EVALUATION"
SPECIAL_ACTION_STARTED_CAUSATION_POINTS_TO_CANONICAL_TRIGGER_SOURCE_WHEN_AVAILABLE = "SPECIAL_ACTION_STARTED_CAUSATION_POINTS_TO_CANONICAL_TRIGGER_SOURCE_WHEN_AVAILABLE"
SPECIAL_CHAIN_CAUSATION_USES_ACTUAL_CANONICAL_TRIGGER_SOURCE_NOT_PRESENTATION_OR_INFERRED_COMPLETION = "SPECIAL_CHAIN_CAUSATION_USES_ACTUAL_CANONICAL_TRIGGER_SOURCE_NOT_PRESENTATION_OR_INFERRED_COMPLETION"
TRIGGER_CHAIN_EMISSION_REMAINS_LEGACY_COMPAT_AFTER_WO102 = "TRIGGER_CHAIN_EMISSION_REMAINS_LEGACY_COMPAT_AFTER_WO102"
CANONICAL_SPECIAL_SOURCE_CAUSATION_LINKAGE_ESTABLISHED_FOR_CANONICAL_ACTIVE_SOURCES_IN_WO102 = "CANONICAL_SPECIAL_SOURCE_CAUSATION_LINKAGE_ESTABLISHED_FOR_CANONICAL_ACTIVE_SOURCES_IN_WO102"
ALLY_ATTACKED_TRIGGER_MIGRATION_REMAINS_AUTHORITY_BLOCKED_AFTER_WO102 = "ALLY_ATTACKED_TRIGGER_MIGRATION_REMAINS_AUTHORITY_BLOCKED_AFTER_WO102"
PRE_ACTIVE_TARGET_STATUS_TRIGGER_MIGRATION_REMAINS_SEMANTIC_GAP_AFTER_WO102 = "PRE_ACTIVE_TARGET_STATUS_TRIGGER_MIGRATION_REMAINS_SEMANTIC_GAP_AFTER_WO102"
WO102_REFERENCE_TRACE_CHANGE_AUTHORIZED_ONLY_FOR_SPECIAL_CAUSATION_LINKAGE = "WO102_REFERENCE_TRACE_CHANGE_AUTHORIZED_ONLY_FOR_SPECIAL_CAUSATION_LINKAGE"

# Reviewed registration branches, not a list of fabricated live triggers.
REGISTRATION_MECHANICS = (
    "successful_parry_trigger", "successful_parry_generic_special",
    "action_complete_follow_up", "after_specific_martial_active_follow_up",
    "after_basic_attack_trigger", "after_basic_attack_horizontal_neighbor",
    "basic_action_resource_scaled_rear_followup", "trigger_attempt_resource_cost",
    "stance_gated_special_trigger", "parry_stance_counter", "parry_counter_high_blade",
    "status_gated_combo_trigger", "attempt_paid_rear_followup",
    "special_commit_self_status_application", "status_gated_attempt_paid_rear_followup",
    "ally_attacked_trigger_adapter", "attempt_paid_ally_retaliation",
)

SOURCE_EVENT_READINESS = freeze({
    "PARRY_SUCCESS": {"status": S.CANONICAL_READY.value,
        "marker": "CANONICAL_PARRY_TRIGGER_SOURCE_MIGRATED_IN_WO100",
        "canonical_source_event": "ATTACK_PARRY_CONFIRMED",
        "canonical_equivalent": "ATTACK_PARRY_CONFIRMED", "trigger_timing_migrated": True,
        "production_source_route": "CANONICAL_ACTIVE", "source_migration_work_order": "WO100",
        "source_event_production_migrated": True},
    "ACTION_COMPLETE": {"status": S.CANONICAL_READY.value,
        "marker": "CANONICAL_ACTION_OUTCOME_FACT_ESTABLISHED_IN_WO098",
        "canonical_source_event": "ACTION_OUTCOME_FINALIZED",
        "canonical_equivalent": "ACTION_OUTCOME_FINALIZED", "incomplete_related_event": "FORMAL_ACTION_COMPLETED",
        "globally_equivalent": False,
        "production_source_route": "CANONICAL_ACTIVE", "source_migration_work_order": "WO099",
        "source_event_production_migrated": True},
    "ALLY_TARGETED_BY_ATTACK_INSTANCE": {"status": S.AUTHORITY_TBD.value,
        "marker": ALLY_ATTACKED_TRIGGER_MIGRATION_BLOCKED_BY_TBD_CORE,
        "authority_value": "ally_is_attacked_semantics: TBD_CORE", "canonical_equivalent": None},
    "PRE_ACTIVE_TARGET_STATUS_CHECKED": {"status": S.CANONICAL_EVENT_GAP.value,
        "marker": CANONICAL_PRE_ACTIVE_STATUS_CHECK_SOURCE_EVENT_GAP,
        "canonical_equivalent": None},
})

# A separate ingress-only contract; never promotes a binding-level migration axis.
SPECIAL_OUTCOME_CHAIN_EMISSION_ROUTE = freeze({
    "scope": "SPECIAL_ACTION_OUTCOME_FINALIZED_ONLY",
    "production_source_route": "CANONICAL_ACTIVE",
    "migration_work_order": "WO104",
    "source_event": "ACTION_OUTCOME_FINALIZED",
    "source_phase": "SPECIAL_ACTION",
    "ingress": "CanonicalSpecialOutcomeChainEmission.from_fact",
    "trigger_matcher": "LEGACY_COMPAT",
    "candidate_execution": "LEGACY_COMPAT",
    "binding_chain_emission": "LEGACY_COMPAT",
    "candidate_queue": "AUTHORITY_TBD",
    "production_migrated": False,
})

STANDARD_SPECIAL_EXECUTOR_BOUNDARY_ROUTE = freeze({
    "scope": "STANDARD_SPECIAL_EXECUTOR_BOUNDARY_ONLY",
    "boundary_contract": "OBSERVED_IN_WO105",
    "execution_route": "LEGACY_COMPAT",
    "standard_executor_production_migrated": False,
    "custom_executor": "CUSTOM_EXECUTOR_TBD",
    "candidate_queue": "AUTHORITY_TBD",
    "binding_chain_emission": "LEGACY_COMPAT",
    "action_execution": "LEGACY_COMPAT_OR_EXPLICIT_CONTENT_TBD_OR_CUSTOM_EXECUTOR_TBD",
    "special_outcome_chain_ingress": "CANONICAL_ACTIVE_WO104",
    "production_migrated": False,
    "migration_ready": False,
})

STANDARD_SPECIAL_EXECUTOR_RUNTIME_ROUTE = freeze({
    "scope": "STANDARD_NON_CUSTOM_EXECUTION_ONLY",
    "work_order": "WO106",
    "production_entry": "BattleEngine._execute_special_action -> standard_executor",
    "standard_runtime_execution_route": "CANONICAL_BOUNDARY_ACTIVE",
    "standard_executor_production_migrated": True,
    "attack_settlement_route": "EXISTING_RESOLVE_ATTACK",
    "custom_executor": "CUSTOM_EXECUTOR_TBD / NOT_MIGRATED",
    "candidate_queue": "AUTHORITY_TBD",
    "binding_chain_emission": "LEGACY_COMPAT",
    "binding_action_execution": "LEGACY_COMPAT_OR_CONTENT_TBD_OR_CUSTOM_EXECUTOR_TBD",
    "production_migrated": False,
    "migration_ready": False,
})
STANDARD_SPECIAL_EXECUTOR_RUNTIME_ROUTE_MIGRATED_IN_WO106 = "STANDARD_SPECIAL_EXECUTOR_RUNTIME_ROUTE_MIGRATED_IN_WO106"

SPECIAL_QUEUE_DRAIN_BOUNDARY_ROUTE = freeze({
    "scope": "SPECIAL_CANDIDATE_QUEUE_AND_DRAIN_ONLY",
    "work_order": "WO111",
    "boundary_contract": "OBSERVED_READ_ONLY_NOT_MIGRATED",
    "production_entry": "SpecialActionManager.queue / SpecialActionManager.drain",
    "queue_execution_route": "LEGACY_COMPAT",
    "queue_drain_production_migrated": False,
    "observed_sort_fields": ("trigger_priority","owner_id","trigger_id","candidate_sequence"),
    "simultaneous_order_authority": "ORDINARY_SPECIAL_SIMULTANEOUS_ORDER_AUTHORITY_TBD",
    "cross_source_conflict": "CROSS_SOURCE_CONFLICT_TBD",
    "upstream_opportunity": "CANONICAL_BOUNDARY_ACTIVE_WO110",
    "downstream_admission": "CANONICAL_BOUNDARY_ACTIVE_WO108",
    "downstream_standard_executor": "CANONICAL_BOUNDARY_ACTIVE_WO106",
    "custom_executor": "CUSTOM_EXECUTOR_TBD / NOT_MIGRATED",
    "source_routes": "WO099_WO100_EXISTING_ONLY",
    "special_chain_ingress": "WO104_EXISTING_ONLY",
    "binding_action_execution": "LEGACY_COMPAT_OR_CONTENT_TBD_OR_CUSTOM_EXECUTOR_TBD",
    "binding_chain_emission": "LEGACY_COMPAT",
    "production_migrated": False,
    "migration_ready": False,
})

CUSTOM_SPECIAL_EXECUTOR_RUNTIME_ROUTE = freeze({
    "work_order": "WO114",
    "scope": "SELECTED_CUSTOM_SPECIAL_CALLBACK_INVOCATION_IMPLEMENTATION_ONLY",
    "custom_executor_runtime_route": "BOUNDARY_ACTIVE_LEGACY_COMPAT",
    "custom_executor_call_production_migrated": True,
    "selected_template_callback_invocation": "EXACTLY_ONCE_VIA_INTERNAL_HELPER_LEGACY_COMPAT",
    "content_authority": "CUSTOM_EXECUTOR_TBD",
    "arbitrary_callback_approval": False,
    "custom_content_migrated": False,
    "upstream_opportunity": "WO110 bounded runtime active",
    "queue_drain": "WO112 BOUNDARY_ACTIVE_LEGACY_COMPAT",
    "candidate_admission": "WO108 bounded runtime active",
    "standard_executor": "WO106 bounded standard non-custom runtime active",
    "chain_and_source_bridges": "WO104_WO099_WO100_UNCHANGED",
    "ordering_policy_canon_approved": False,
    "production_migrated": False,
    "migration_ready": False,
})

CUSTOM_SPECIAL_EXECUTOR_BOUNDARY_ROUTE = freeze({
    "scope": "CUSTOM_SPECIAL_EXECUTOR_DISPATCH_AND_LIFECYCLE_ONLY",
    "work_order": "WO113",
    "boundary_contract": "OBSERVED_READ_ONLY_NOT_MIGRATED",
    "custom_executor_route": "LEGACY_COMPAT_OR_CONTENT_TBD",
    "custom_executor_production_migrated": False,
    "custom_content_authority": "CUSTOM_EXECUTOR_TBD",
    "production_entry": "BattleEngine._execute_special_action selected template.executor",
    "upstream_opportunity": "WO110 bounded runtime active",
    "queue_drain": "WO112 BOUNDARY_ACTIVE_LEGACY_COMPAT",
    "candidate_admission": "WO108 bounded runtime active",
    "standard_executor": "WO106 bounded standard non-custom runtime active",
    "arbitrary_callback_approval": False,
    "simultaneous_order_authority": "ORDINARY_SPECIAL_SIMULTANEOUS_ORDER_AUTHORITY_TBD",
    "cross_source_conflict": "CROSS_SOURCE_CONFLICT_TBD",
    "production_migrated": False,
    "migration_ready": False,
})

SPECIAL_QUEUE_DRAIN_RUNTIME_ROUTE = freeze({
    "scope": "SPECIAL_CANDIDATE_QUEUE_AND_DRAIN_IMPLEMENTATION_ONLY",
    "work_order": "WO112",
    "production_entry": "SpecialActionManager.queue / SpecialActionManager.drain -> internal queue_drain_executor",
    "queue_drain_runtime_route": "BOUNDARY_ACTIVE_LEGACY_COMPAT",
    "queue_drain_production_migrated": True,
    "observed_sort_fields": ("trigger_priority", "owner_id", "trigger_id", "candidate_sequence"),
    "simultaneous_order_authority": "ORDINARY_SPECIAL_SIMULTANEOUS_ORDER_AUTHORITY_TBD",
    "cross_source_conflict": "CROSS_SOURCE_CONFLICT_TBD",
    "ordering_policy_canon_approved": False,
    "upstream_opportunity": "WO110 bounded runtime active",
    "downstream_admission": "WO108 bounded runtime active",
    "downstream_standard_executor": "WO106 bounded runtime active",
    "custom_executor": "CUSTOM_EXECUTOR_TBD / NOT_MIGRATED",
    "binding_chain_emission": "LEGACY_COMPAT",
    "production_migrated": False,
    "migration_ready": False,
})

TRIGGER_OPPORTUNITY_EVALUATION_RUNTIME_ROUTE = freeze({
    "scope": "PRE_QUEUE_TRIGGER_OPPORTUNITY_EVALUATION_AND_CANDIDATE_CREATION_ONLY",
    "work_order": "WO110",
    "production_entry": "TriggerEngine.handle_event -> internal opportunity evaluator",
    "opportunity_evaluation_runtime_route": "CANONICAL_BOUNDARY_ACTIVE",
    "opportunity_evaluation_production_migrated": True,
    "matching_traversal_order": "LEGACY_COMPAT_NOT_CANON",
    "candidate_queue": "LEGACY_COMPAT / SIMULTANEOUS_ORDER_AUTHORITY_TBD",
    "candidate_admission": "CANONICAL_BOUNDARY_ACTIVE_WO108",
    "standard_special_execution": "CANONICAL_BOUNDARY_ACTIVE_WO106",
    "custom_executor": "CUSTOM_EXECUTOR_TBD / NOT_MIGRATED",
    "source_event_routes": "WO099_WO100_EXISTING_ONLY",
    "binding_action_execution": "LEGACY_COMPAT_OR_CONTENT_TBD_OR_CUSTOM_EXECUTOR_TBD",
    "binding_chain_emission": "LEGACY_COMPAT",
    "production_migrated": False,
    "migration_ready": False,
})

# WO109 observation history is distinct from this bounded WO110 runtime route.
TRIGGER_OPPORTUNITY_EVALUATION_BOUNDARY_ROUTE = freeze({
    "scope": "PRE_QUEUE_TRIGGER_OPPORTUNITY_EVALUATION_AND_CANDIDATE_CREATION_ONLY",
    "work_order": "WO109",
    "boundary_contract": "OBSERVED_READ_ONLY_NOT_MIGRATED",
    "production_entry": "TriggerEngine.handle_event",
    "opportunity_evaluation_route": "LEGACY_COMPAT",
    "opportunity_evaluation_production_migrated": False,
    "candidate_admission": "CANONICAL_BOUNDARY_ACTIVE_WO108",
    "standard_special_execution": "CANONICAL_BOUNDARY_ACTIVE_WO106",
    "queue": "LEGACY_COMPAT / SIMULTANEOUS_ORDER_AUTHORITY_TBD",
    "matching_traversal_order": "LEGACY_COMPAT_NOT_CANON",
    "source_event_routes": "WO099_WO100_EXISTING_ONLY",
    "binding_chain_emission": "LEGACY_COMPAT",
    "custom_executor": "CUSTOM_EXECUTOR_TBD / NOT_MIGRATED",
    "production_migrated": False,
    "migration_ready": False,
})

SPECIAL_CANDIDATE_ADMISSION_RUNTIME_ROUTE = freeze({
    "scope": "POST_DEQUEUE_CANDIDATE_EXECUTION_ADMISSION_ONLY",
    "work_order": "WO108",
    "production_entry": "SpecialActionManager.drain -> TriggerEngine.execute_candidate -> internal_executor",
    "candidate_admission_runtime_route": "CANONICAL_BOUNDARY_ACTIVE",
    "candidate_admission_production_migrated": True,
    "settlement_authority": "EXISTING_MARTIAL_SETTLE_TRIGGER_CANDIDATE",
    "standard_executor": "CANONICAL_BOUNDARY_ACTIVE_WO106",
    "custom_executor": "CUSTOM_EXECUTOR_TBD / NOT_MIGRATED",
    "queue": "LEGACY_COMPAT / SIMULTANEOUS_ORDER_AUTHORITY_TBD",
    "source_event_routes": "WO099_WO100_EXISTING_ONLY",
    "binding_action_execution": "LEGACY_COMPAT_OR_CONTENT_TBD_OR_CUSTOM_EXECUTOR_TBD",
    "binding_chain_emission": "LEGACY_COMPAT",
    "production_migrated": False,
    "migration_ready": False,
})

# Historical read-only observation fact remains separate from the WO108 route.
SPECIAL_CANDIDATE_ADMISSION_BOUNDARY_ROUTE = freeze({
    "scope": "POST_DEQUEUE_CANDIDATE_EXECUTION_ADMISSION_ONLY",
    "work_order": "WO107",
    "boundary_contract": "OBSERVED_READ_ONLY_NOT_MIGRATED",
    "production_entry": "TriggerEngine.execute_candidate",
    "candidate_admission_execution_route": "LEGACY_COMPAT",
    "candidate_admission_production_migrated": False,
    "custom_executor": "CUSTOM_EXECUTOR_TBD / NOT_MIGRATED",
    "standard_executor": "CANONICAL_BOUNDARY_ACTIVE_WO106",
    "candidate_queue": "AUTHORITY_TBD",
    "binding_action_execution": "LEGACY_COMPAT_OR_EXPLICIT_CONTENT_TBD_OR_CUSTOM_EXECUTOR_TBD",
    "binding_chain_emission": "LEGACY_COMPAT",
    "production_migrated": False,
    "migration_ready": False,
})

SEMANTIC_COVERAGE_REQUIRED = (
    "CANONICAL_PARRY_FACT",
    "CANONICAL_DODGE_FACT_IF_FUTURE_CONTENT_REQUIRES",
    "CANONICAL_ACTION_OUTCOME_COMPLETION_FOR_FORMAL_AND_SPECIAL",
    "CANONICAL_SPECIAL_ACTION_STARTED_AND_COMPLETED_IDENTITY",
    "EXPLICIT_ACTION_CLASSIFICATION_AND_SOURCE_DEFINITION",
    "EXPLICIT_SOURCE_EVENT_RELATIONSHIP_FOR_CHAINED_SPECIALS",
    "CANONICAL_CONTENT_SPECIFIC_PRE_ACTIVE_CHECK_IF_RETAINED",
    "EXPLICIT_ATTACKED_ALLY_SEMANTICS_WHERE_UNRESOLVED",
)

QUEUE_COMPATIBILITY = freeze({
    "observed_sort_fields": ["trigger_priority", "owner_id", "trigger_id", "candidate_sequence"],
    "authority": LEGACY_TRIGGER_QUEUE_ORDER_IS_COMPATIBILITY_ONLY_NOT_CANON,
    "future_order_authority": ORDINARY_SPECIAL_SIMULTANEOUS_ORDER_AUTHORITY_TBD,
    "lexical_ids_are_canon": False,
})


def _unclassified(detail):
    raise TriggerMigrationError(UNCLASSIFIED_LEGACY_TRIGGER_REGISTRATION + ": " + detail)


def content_markers(value):
    """Record explicit content debt/fixture declarations only, not readiness guesses."""
    result = set()
    if isinstance(value, Mapping):
        for k, v in value.items():
            if k in ("test_fixture", "test_fixture_only", "not_canonical") and v is True:
                result.add("TEST_FIXTURE")
            result.update(content_markers(v))
    elif isinstance(value, (tuple, list, set, frozenset)):
        for item in value:
            result.update(content_markers(item))
    elif type(value) is str:
        for marker in ("SOURCE_CONTENT_TBD", "TOKEN_BALANCE_TBD"):
            if marker in value:
                result.add(marker)
        if value.startswith("TEST_FIXTURE") or "test_only=true" in value.lower() or "test_fixture_only=true" in value.lower():
            result.add("TEST_FIXTURE")
    return tuple(sorted(result))


def _source_route_projection(readiness):
    """Project readiness metadata without inferring canonical migration state."""
    status = S(readiness["status"])
    fallback_route = (
        "AUTHORITY_BLOCKED" if status == S.AUTHORITY_TBD
        else "SEMANTIC_GAP" if status == S.CANONICAL_EVENT_GAP
        else "LEGACY_ACTIVE"
    )
    return {
        "source_event_production_migrated": readiness.get(
            "source_event_production_migrated", False),
        "production_source_route": readiness.get(
            "production_source_route", fallback_route),
        "source_migration_work_order": readiness.get(
            "source_migration_work_order"),
        "canonical_source_event": readiness.get("canonical_source_event"),
        "trigger_timing_migrated": readiness.get("trigger_timing_migrated", False),
    }


def make_binding(opportunity, *, source_content_id, source_item_id, source_mechanic, metadata=None):
    """Pure constructor from explicitly attributed observations; never registers content."""
    if type(opportunity) is not LegacyTriggerOpportunityDescriptor:
        raise TriggerMigrationError("Typed opportunity snapshot required")
    if source_mechanic not in REGISTRATION_MECHANICS:
        _unclassified(source_mechanic)
    info = {} if metadata is None else dict(metadata)
    readiness = SOURCE_EVENT_READINESS.get(opportunity.event_type)
    if readiness is None:
        # Unknown source remains a gap, never inferred from a name/Presentation fact.
        readiness = {"status": S.CANONICAL_EVENT_GAP.value,
                     "marker": "CANONICAL_TRIGGER_SOURCE_EVENT_GAP:" + opportunity.event_type}
    axes = {axis: S.LEGACY_COMPAT for axis in A}
    axes[A.SOURCE_EVENT] = S(readiness["status"])
    axes[A.CANDIDATE_QUEUE] = S.AUTHORITY_TBD
    axes[A.ATTEMPT_SETTLEMENT] = S.LEGACY_COMPAT if opportunity.has_attempt_settler else S.NOT_APPLICABLE
    axes[A.COMMIT_SETTLEMENT] = S.LEGACY_COMPAT if opportunity.has_commit_settler else S.NOT_APPLICABLE
    axes[A.CHAIN_EMISSION] = S.LEGACY_COMPAT
    markers = {readiness["marker"], ORDINARY_SPECIAL_SIMULTANEOUS_ORDER_AUTHORITY_TBD,
               (CANONICAL_SPECIAL_SOURCE_CAUSATION_LINKAGE_ESTABLISHED_FOR_CANONICAL_ACTIVE_SOURCES_IN_WO102
                if readiness.get("production_source_route") == "CANONICAL_ACTIVE"
                else "CANONICAL_SPECIAL_SOURCE_EVENT_LINKAGE_PARTIAL_IN_WO098")}
    declarations = content_markers(info)
    if "SOURCE_CONTENT_TBD" in declarations or "TOKEN_BALANCE_TBD" in declarations:
        axes[A.ACTION_EXECUTION] = S.CONTENT_TBD
        markers.update(m for m in declarations if m != "TEST_FIXTURE")
    if opportunity.action.has_custom_executor:
        axes[A.ACTION_EXECUTION] = S.CUSTOM_EXECUTOR_TBD
        markers.add("CUSTOM_SPECIAL_EXECUTOR_SEMANTICS_TBD")
    if opportunity.event_type == "ALLY_TARGETED_BY_ATTACK_INSTANCE" or source_mechanic in (
            "ally_attacked_trigger_adapter", "attempt_paid_ally_retaliation"):
        axes[A.SOURCE_EVENT] = S.AUTHORITY_TBD
        markers.update((ALLY_ATTACKED_TRIGGER_MIGRATION_BLOCKED_BY_TBD_CORE,
                        "ally_is_attacked_semantics: TBD_CORE"))
    source_route_projection = _source_route_projection(readiness)
    info.update({
        "runtime_contract": "WO097", "source_event_readiness": dict(readiness),
        **source_route_projection,
        "opportunity": opportunity.to_dict(), "content_authority_markers": declarations,
        "human_approval_inferred": False,
        "scope_key": {"TURN_SCOPE": "formal_turn_id", "ACTION_SCOPE": "action_id",
                      "ATTACK_SCOPE": "attack_instance_id"}[opportunity.scope],
        "scope_dedup": "ONE_DEFINITION_PER_EXPLICIT_SCOPE_KEY",
        "future_scope_requires_canonical_source_identity": True,
        "budget_contract": ORDINARY_SPECIAL_BUDGET.to_dict(),
        "budget_participation": opportunity.counts_ordinary_budget and opportunity.action.counts_ordinary_budget,
        "budget_consumption_observed_after": "TARGET_LEGALITY_AND_MARTIAL_EFFECT_SETTLEMENT",
        "attempt_order": ["condition", "cap_precheck", "attempt_settlement", "probability_roll"],
        "contract_markers": [TRIGGER_ATTEMPT_SETTLEMENT_TIMING_MUST_BE_PRESERVED,
                            TRIGGER_COMMIT_SETTLEMENT_TIMING_MUST_BE_PRESERVED,
                            CANONICAL_SPECIAL_ACTION_EXECUTOR_NOT_MIGRATED_IN_WO097,
                            PRESENTATION_EVENTS_ARE_NOT_TRIGGER_AUTHORITY],
        "probability_compatibility": {
            "marker": LEGACY_TRIGGER_PROBABILITY_DECAY_COMPATIBILITY,
            "raw_probability": "STATIC_OR_RESOLVER", "clamp": [0, 1],
            "decayed_value_if_present": True, "rng_unless_effective_ge_one": True,
            "observed_success_multiplier": 0.25, "failure": "NO_SUCCESS_DECAY",
            "reset": "FORMAL_TURN_COMPLETION", "future_content_authority": False},
        "queue_compatibility": export(QUEUE_COMPATIBILITY),
        "target_legality": ["OWNER_ORDINARY_ELIGIBILITY", "_can_execute_special",
                            "_special_target", "BATTLEFIELD_OCCUPANCY", "TARGETING_MODIFIER_LAYER"],
    })
    return TriggerMigrationBinding(
        "trigger-migration:" + canonical_json([opportunity.owner_id, opportunity.trigger_id]),
        opportunity.owner_id, opportunity.trigger_id, source_content_id, source_item_id,
        source_mechanic, opportunity.event_type, opportunity.scope, opportunity.action,
        axes, tuple(markers), info)


@dataclass(frozen=True, slots=True)
class TriggerMigrationRegistry(Document):
    bindings: tuple[TriggerMigrationBinding, ...]

    def __post_init__(self):
        bindings = tuple(self.bindings)
        if any(type(b) is not TriggerMigrationBinding for b in bindings):
            raise TriggerMigrationError("Typed immutable migration bindings required")
        bindings = tuple(sorted((replace(b) for b in bindings), key=lambda b: b.binding_id))
        if len({b.binding_id for b in bindings}) != len(bindings):
            raise TriggerMigrationError("Duplicate trigger migration binding ID")
        if len({(b.owner_id, b.trigger_id) for b in bindings}) != len(bindings):
            raise TriggerMigrationError("Conflicting owner/trigger identity")
        object.__setattr__(self, "bindings", bindings)

    def for_owner_trigger(self, owner_id, trigger_id=None):
        return tuple(b for b in self.bindings if b.owner_id == owner_id
                     and (trigger_id is None or b.trigger_id == trigger_id))

    def for_mechanic(self, mechanic):
        return tuple(b for b in self.bindings if b.source_mechanic == mechanic)

    def for_legacy_event(self, event):
        return tuple(b for b in self.bindings if b.legacy_event_type == event)

    def for_axis_status(self, axis, status):
        if type(axis) is not A or type(status) is not S:
            raise TriggerMigrationError("Typed migration axis/status required")
        return tuple(b for b in self.bindings if b.axis_status(axis) == status)

    def migration_ready_bindings(self):
        return tuple(b for b in self.bindings if b.migration_ready)

    def blocked_bindings(self):
        return tuple(b for b in self.bindings if not b.migration_ready)

    def source_route_counts(self):
        return {route: sum(b.metadata["production_source_route"] == route for b in self.bindings)
                for route in ("CANONICAL_ACTIVE","LEGACY_ACTIVE","AUTHORITY_BLOCKED","SEMANTIC_GAP")}

    def to_dict(self):
        return {"runtime_contract": "WO097", "production_migrated": False,
                "source_route_counts": self.source_route_counts(),
                "bindings": [b.to_dict() for b in self.bindings],
                "ready_count": len(self.migration_ready_bindings()),
                "blocked_count": len(self.blocked_bindings())}


def compile_registry(runtime):
    """Observe existing registered definitions and exact loaded source item attribution.

    Unattributed/manual definitions are not silently promoted. Tests may snapshot
    them directly; runtime registry inspection requires a classified source item.
    """
    definitions = tuple(runtime.triggers._definitions)
    content = dict(runtime.martials.definitions)
    wo090 = runtime.binding_registry
    result = []
    for definition in definitions:
        if type(definition) is not TriggerDefinition:
            _unclassified("Non-TriggerDefinition registration")
        martial = content.get(definition.source_martial_id)
        passive = None if martial is None else next(
            (p for p in martial.passives if p.id == definition.id), None)
        if passive is None or passive.mechanic not in REGISTRATION_MECHANICS:
            _unclassified(definition.owner_id + "/" + definition.id)
        crossrefs = tuple(b for b in wo090.for_content(
            martial.id, passive.mechanic, domain=BindingDomain.MARTIAL)
            if b.metadata.get("item_id") == passive.id)
        if len(crossrefs) != 1:
            _unclassified("Missing/ambiguous WO090 source-item binding")
        observed = LegacyTriggerOpportunityDescriptor.from_definition(definition)
        result.append(make_binding(observed, source_content_id=martial.id,
            source_item_id=passive.id, source_mechanic=passive.mechanic,
            metadata={"source_provenance": asdict(martial.provenance),
                      "source_parameters": dict(passive.parameters),
                      "source_unresolved_fields": martial.unresolved_fields,
                      "source_blocked_fields": martial.blocked_spec_fields,
                      "source_validation_information": martial.validation_information,
                      "active_tuning_placeholder": martial.active_skill.tuning_placeholder,
                      "wo090_binding_id": crossrefs[0].binding_id,
                      "wo090_route": crossrefs[0].route.value,
                      "wo090_unresolved_marker": crossrefs[0].unresolved_marker}))
    return TriggerMigrationRegistry(tuple(result))


def registration_inventory():
    return freeze({mechanic: {
        "registration_site": "battle_core/martial.py:MartialRuntimeManager.equip",
        "generated_compiler": ("compile_successful_parry_special" if
                              mechanic == "successful_parry_generic_special" else None),
        "wo090_route": ROUTES[mechanic].value, "production_migrated": False,
        "represents_live_binding": False}
        for mechanic in sorted(REGISTRATION_MECHANICS)})

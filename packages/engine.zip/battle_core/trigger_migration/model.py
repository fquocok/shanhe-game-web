"""Immutable WO097 observations. No resolver, callback, queue or migration API."""
from dataclasses import dataclass, field, fields
from enum import Enum
from types import MappingProxyType
import math
from ..events.envelope import freeze, canonical_json
from ..trigger import SpecialActionTemplate, TriggerDefinition, TriggerCandidate, TRIGGER_SCOPES


class TriggerMigrationError(ValueError):
    pass


class MigrationAxis(str, Enum):
    SOURCE_EVENT = "SOURCE_EVENT"
    OPPORTUNITY_SCOPE = "OPPORTUNITY_SCOPE"
    ATTEMPT_SETTLEMENT = "ATTEMPT_SETTLEMENT"
    PROBABILITY_RNG = "PROBABILITY_RNG"
    CANDIDATE_QUEUE = "CANDIDATE_QUEUE"
    ORDINARY_BUDGET = "ORDINARY_BUDGET"
    TARGET_LEGALITY = "TARGET_LEGALITY"
    COMMIT_SETTLEMENT = "COMMIT_SETTLEMENT"
    ACTION_EXECUTION = "ACTION_EXECUTION"
    CHAIN_EMISSION = "CHAIN_EMISSION"


class MigrationAxisStatus(str, Enum):
    CANONICAL_READY = "CANONICAL_READY"
    LEGACY_COMPAT = "LEGACY_COMPAT"
    CANONICAL_EVENT_GAP = "CANONICAL_EVENT_GAP"
    AUTHORITY_TBD = "AUTHORITY_TBD"
    CONTENT_TBD = "CONTENT_TBD"
    CUSTOM_EXECUTOR_TBD = "CUSTOM_EXECUTOR_TBD"
    NOT_APPLICABLE = "NOT_APPLICABLE"


def _identity(value, name, optional=False):
    if value is None and optional:
        return
    if type(value) is not str or not value.strip():
        raise TriggerMigrationError("Nonempty " + name + " required")


def _number(value, name):
    if type(value) not in (int, float) or not math.isfinite(value):
        raise TriggerMigrationError("Finite observed number " + name + " required")


def _booleans(instance, names):
    if any(type(getattr(instance, n)) is not bool for n in names):
        raise TriggerMigrationError("Literal boolean flags required")


def _metadata(value):
    if type(value) not in (dict, MappingProxyType):
        raise TriggerMigrationError("Detached mapping required")
    try:
        return freeze(value)
    except ValueError as exc:
        raise TriggerMigrationError("No callable/live object/nonfinite metadata") from exc


def export(value):
    if isinstance(value, Document):
        return {f.name: export(getattr(value, f.name)) for f in fields(value)}
    if isinstance(value, Enum):
        return value.value
    if type(value) in (dict, MappingProxyType):
        return {str(export(k)): export(v) for k, v in value.items()}
    if type(value) is tuple:
        return [export(v) for v in value]
    return value


class Document:
    __slots__ = ()

    def to_dict(self):
        return export(self)

    def serialize(self):
        return canonical_json(self.to_dict())


@dataclass(frozen=True, slots=True)
class OrdinarySpecialActionDescriptor(Document):
    action_template_id: str
    kind: str
    classification: str
    target_selector: str
    targeting_pattern: str
    requested_target_count: int | None
    attack_coefficient: float
    attack_tags: tuple[str, ...]
    counts_as_turn: bool
    counts_ordinary_budget: bool
    has_custom_executor: bool
    metadata: object = field(default_factory=dict)

    def __post_init__(self):
        for n in ("action_template_id", "kind", "classification", "target_selector", "targeting_pattern"):
            _identity(getattr(self, n), n)
        _number(self.attack_coefficient, "attack_coefficient")
        if self.requested_target_count is not None and type(self.requested_target_count) is not int:
            raise TriggerMigrationError("Observed target count must be int/None")
        tags = tuple(self.attack_tags)
        for tag in tags:
            _identity(tag, "attack tag")
        if len(set(tags)) != len(tags):
            raise TriggerMigrationError("Duplicate observed attack tag")
        object.__setattr__(self, "attack_tags", tuple(sorted(tags)))
        _booleans(self, ("counts_as_turn", "counts_ordinary_budget", "has_custom_executor"))
        if self.counts_as_turn:
            raise TriggerMigrationError("Ordinary Special is not a Formal Turn")
        object.__setattr__(self, "metadata", _metadata(self.metadata))

    @classmethod
    def from_template(cls, template):
        if type(template) is not SpecialActionTemplate:
            raise TriggerMigrationError("Concrete legacy SpecialActionTemplate required")
        return cls(template.id, template.kind, template.classification, template.target_selector,
                   template.targeting_pattern, template.requested_target_count,
                   template.attack_coefficient, tuple(template.attack_tags),
                   template.counts_as_turn, template.counts_ordinary_budget,
                   template.executor is not None,
                   {"coefficient_authority": "OBSERVATION_NOT_TUNING_AUTHORITY"})


@dataclass(frozen=True, slots=True)
class LegacyTriggerOpportunityDescriptor(Document):
    trigger_id: str
    owner_id: str
    source_martial_id: str | None
    martial_event_kind: str | None
    event_type: str
    scope: str
    base_probability: float
    priority: int
    enabled: bool
    counts_ordinary_budget: bool
    has_condition: bool
    has_probability_resolver: bool
    has_attempt_settler: bool
    has_commit_settler: bool
    has_coefficient_resolver: bool
    action: OrdinarySpecialActionDescriptor
    metadata: object = field(default_factory=dict)

    def __post_init__(self):
        for n in ("trigger_id", "owner_id", "event_type"):
            _identity(getattr(self, n), n)
        for n in ("source_martial_id", "martial_event_kind"):
            _identity(getattr(self, n), n, optional=True)
        if self.scope not in TRIGGER_SCOPES or type(self.priority) is not int:
            raise TriggerMigrationError("Observed legacy scope/integer priority required")
        _number(self.base_probability, "base_probability")
        _booleans(self, ("enabled", "counts_ordinary_budget", "has_condition",
                        "has_probability_resolver", "has_attempt_settler",
                        "has_commit_settler", "has_coefficient_resolver"))
        if type(self.action) is not OrdinarySpecialActionDescriptor:
            raise TriggerMigrationError("Detached action descriptor required")
        object.__setattr__(self, "metadata", _metadata(self.metadata))

    @classmethod
    def from_definition(cls, definition, *, metadata=None):
        if type(definition) is not TriggerDefinition:
            raise TriggerMigrationError("Concrete legacy TriggerDefinition required")
        return cls(definition.id, definition.owner_id, definition.source_martial_id,
                   definition.martial_event_kind, definition.event_type, definition.scope,
                   definition.base_probability, definition.priority, definition.enabled,
                   definition.counts_ordinary_budget, definition.condition is not None,
                   definition.probability_resolver is not None, definition.attempt_settler is not None,
                   definition.commit_settler is not None, definition.coefficient_resolver is not None,
                   OrdinarySpecialActionDescriptor.from_template(definition.action_template),
                   {} if metadata is None else metadata)


@dataclass(frozen=True, slots=True)
class LegacyTriggerCandidateSnapshot(Document):
    candidate_sequence: int
    trigger_id: str
    owner_id: str
    source_martial_id: str | None
    event_type: str
    scope: str
    effective_probability: float
    roll: float
    resolved_coefficient: float | None
    ordinary_budget_participation: bool
    action_descriptor: OrdinarySpecialActionDescriptor
    causal_event_snapshot: object
    formal_turn_id: str | None = None
    action_id: str | None = None
    attack_instance_id: str | None = None

    def __post_init__(self):
        if type(self.candidate_sequence) is not int or self.candidate_sequence < 1:
            raise TriggerMigrationError("Positive observed candidate sequence required")
        for n in ("trigger_id", "owner_id", "event_type"):
            _identity(getattr(self, n), n)
        for n in ("source_martial_id", "formal_turn_id", "action_id", "attack_instance_id"):
            _identity(getattr(self, n), n, optional=True)
        if self.scope not in TRIGGER_SCOPES:
            raise TriggerMigrationError("Known observed scope required")
        for n in ("effective_probability", "roll"):
            _number(getattr(self, n), n)
        if self.resolved_coefficient is not None:
            _number(self.resolved_coefficient, "resolved_coefficient")
        _booleans(self, ("ordinary_budget_participation",))
        if type(self.action_descriptor) is not OrdinarySpecialActionDescriptor:
            raise TriggerMigrationError("Detached action descriptor required")
        object.__setattr__(self, "causal_event_snapshot", _metadata(self.causal_event_snapshot))

    @classmethod
    def from_candidate(cls, candidate):
        if type(candidate) is not TriggerCandidate:
            raise TriggerMigrationError("Concrete legacy TriggerCandidate required")
        definition = candidate.definition
        if type(definition) is not TriggerDefinition:
            raise TriggerMigrationError("Concrete legacy TriggerDefinition required")
        action = OrdinarySpecialActionDescriptor.from_template(
            candidate.resolved_action_template or definition.action_template)
        event = dict(candidate.event)
        # Budget eligibility uses the ORIGINAL template, exactly as the legacy queue;
        # a resolved targeting modifier never creates a new budget decision.
        participation = definition.counts_ordinary_budget and definition.action_template.counts_ordinary_budget
        return cls(candidate.sequence, definition.id, definition.owner_id,
                   definition.source_martial_id, definition.event_type, definition.scope,
                   candidate.effective_probability, candidate.roll, candidate.resolved_coefficient,
                   participation, action, event, event.get("formal_turn_id"),
                   event.get("action_id"), event.get("attack_instance_id"))


@dataclass(frozen=True, slots=True)
class TriggerMigrationBinding(Document):
    binding_id: str
    owner_id: str
    trigger_id: str
    source_content_id: str
    source_item_id: str
    source_mechanic: str
    legacy_event_type: str
    legacy_scope: str
    action_descriptor: OrdinarySpecialActionDescriptor
    axis_statuses: object
    unresolved_markers: tuple[str, ...]
    metadata: object = field(default_factory=dict)
    production_migrated: bool = False

    def __post_init__(self):
        for n in ("binding_id", "owner_id", "trigger_id", "source_content_id",
                  "source_item_id", "source_mechanic", "legacy_event_type"):
            _identity(getattr(self, n), n)
        if self.legacy_scope not in TRIGGER_SCOPES:
            raise TriggerMigrationError("Known observed scope required")
        if type(self.action_descriptor) is not OrdinarySpecialActionDescriptor:
            raise TriggerMigrationError("Detached action descriptor required")
        axes = dict(self.axis_statuses)
        if set(axes) != set(MigrationAxis) or any(
                type(k) is not MigrationAxis or type(v) is not MigrationAxisStatus
                for k, v in axes.items()):
            raise TriggerMigrationError("Every typed migration axis/status required")
        object.__setattr__(self, "axis_statuses", MappingProxyType(
            {a: axes[a] for a in MigrationAxis}))
        if self.action_descriptor.has_custom_executor and axes[MigrationAxis.ACTION_EXECUTION] != MigrationAxisStatus.CUSTOM_EXECUTOR_TBD:
            raise TriggerMigrationError("Custom executor requires CUSTOM_EXECUTOR_TBD")
        markers = tuple(self.unresolved_markers)
        for marker in markers:
            _identity(marker, "unresolved marker")
        object.__setattr__(self, "unresolved_markers", tuple(sorted(set(markers))))
        object.__setattr__(self, "metadata", _metadata(self.metadata))
        if self.production_migrated is not False:
            raise TriggerMigrationError("NO_PRODUCTION_TRIGGER_MIGRATION_IN_WO097")

    @property
    def migration_ready(self):
        return (not self.unresolved_markers and all(
            status in (MigrationAxisStatus.CANONICAL_READY, MigrationAxisStatus.NOT_APPLICABLE)
            for status in self.axis_statuses.values()))

    def axis_status(self, axis):
        if type(axis) is not MigrationAxis:
            raise TriggerMigrationError("Typed migration axis required")
        return self.axis_statuses[axis]

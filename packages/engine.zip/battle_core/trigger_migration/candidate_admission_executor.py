"""WO108 internal post-dequeue admission; mechanical accepted WO107 body."""
from dataclasses import replace
from ..trigger import TriggerCandidate, apply_counter_targeting_transformation

SPECIAL_CANDIDATE_ADMISSION_RUNTIME_ROUTE_MIGRATED_IN_WO108 = (
    "SPECIAL_CANDIDATE_ADMISSION_RUNTIME_ROUTE_MIGRATED_IN_WO108")


def execute_candidate_admission(self, candidate: TriggerCandidate):
    context = self.engine.trigger_context
    definition = candidate.definition
    owner = self.engine.state_by_id(definition.owner_id)
    if context is None or owner is None or not owner.ordinary_combat_eligible:
        self._event("TRIGGER_CANDIDATE_REJECTED", trigger=definition.id,
                    owner=definition.owner_id, reason=("owner_defeated_before_execution" if owner is None or owner.death_confirmed else "owner_not_ordinary_combat_eligible"))
        return
    if not self.engine._can_execute_special(candidate):
        if candidate.event.get("_trigger_cost_settled"):
            self._event("SPECIAL_ACTION_CANCELED",special_action_id=definition.action_template.id,
                        trigger_id=definition.id,reason="execution_target_invalid",
                        cost_was_settled=True,refund_applied=False,
                        refund_policy="NO_REFUND_AFTER_COST_SETTLEMENT")
        self._event("TRIGGER_CANDIDATE_REJECTED", trigger=definition.id,
                    owner=definition.owner_id, reason="no_legal_target")
        return
    counts_budget = definition.counts_ordinary_budget and definition.action_template.counts_ordinary_budget
    if counts_budget and context.ordinary_budget_used >= self.ORDINARY_CAP:
        self._event("SPECIAL_TRIGGER_CAP_REACHED", trigger=definition.id,
                    owner=definition.owner_id, used=context.ordinary_budget_used,
                    cap=self.ORDINARY_CAP, parent_formal_turn_id=context.formal_turn_id)
        self._event("TRIGGER_CANDIDATE_REJECTED", trigger=definition.id,
                    owner=definition.owner_id, reason="ordinary_cap")
        return
    # Fail closed before settlement, budget use, or any Special execution
    # mutation.  _execute_special_action validates again at the append
    # boundary so direct/internal callers cannot bypass the invariant.
    self.engine._validate_canonical_trigger_source(candidate)
    if not self.engine.martials.settle_trigger_candidate(candidate):
        self._event("TRIGGER_CANDIDATE_REJECTED",trigger=definition.id,owner=definition.owner_id,reason="effect_settlement_failed")
        return
    if counts_budget:
        context.ordinary_budget_used += 1
        self._event("SPECIAL_TRIGGER_BUDGET_USED", trigger=definition.id,
                    owner=definition.owner_id, used=context.ordinary_budget_used,
                    cap=self.ORDINARY_CAP, parent_formal_turn_id=context.formal_turn_id)
    transformed_template=definition.action_template
    active_status_ids={x.definition.id for x in owner.statuses}
    for transformation in self.counter_targeting_transformations:
        transformed_template,metadata=apply_counter_targeting_transformation(transformation,transformed_template,counter_owner_id=definition.owner_id,trigger_source_type=definition.event_type,active_status_ids=active_status_ids)
        if metadata:self._event("MARTIAL_PARRY_COUNTER_PATTERN_TRANSFORMED",trigger_id=definition.id,source_definition_id=definition.id,source_martial_id=definition.source_martial_id,**metadata)
    if transformed_template is not definition.action_template:candidate=replace(candidate,resolved_action_template=transformed_template)
    runtime = context.decay[(definition.owner_id, definition.id)]
    runtime.successes += 1
    previous = candidate.effective_probability
    runtime.current_probability = previous * 0.25
    self._event("TRIGGER_SUCCESS", trigger=definition.id, owner=definition.owner_id,
                success=runtime.successes, parent_formal_turn_id=context.formal_turn_id)
    if definition.martial_event_kind == "follow_up":
        self._event("MARTIAL_FOLLOW_UP_TRIGGERED", trigger=definition.id,
                    martial=definition.source_martial_id, owner=definition.owner_id,
                    original_target=candidate.event.get("target_id"),
                    coefficient=definition.action_template.attack_coefficient)
    self._event("TRIGGER_DECAY_UPDATED", trigger=definition.id, owner=definition.owner_id,
                previous_probability=previous, next_probability=runtime.current_probability)
    self.engine._execute_special_action(candidate)

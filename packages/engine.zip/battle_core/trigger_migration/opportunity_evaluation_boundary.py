"""WO109 detached registration observation, never an opportunity evaluator."""
from dataclasses import dataclass, field
from ..trigger import TriggerDefinition
from .model import Document, OrdinarySpecialActionDescriptor, TriggerMigrationError, _identity, _booleans, _metadata

TRIGGER_OPPORTUNITY_EVALUATION_BOUNDARY_OBSERVED_IN_WO109_NOT_MIGRATED = (
    "TRIGGER_OPPORTUNITY_EVALUATION_BOUNDARY_OBSERVED_IN_WO109_NOT_MIGRATED")

OPPORTUNITY_STAGES = (
    "OPTIONAL_CANONICAL_REF_CONCRETE_TYPE_CHECK_BEFORE_CONTEXT",
    "CAPTURE_LOCAL_CONTEXT_OR_RETURN_WITHOUT_SNAPSHOT",
    "ONE_EVALUATION_SNAPSHOT_THEN_SHALLOW_EVENT_COPY_AND_ATTACH",
    "MATERIALIZE_ENABLED_EVENT_MATCHES_SORTED_PRIORITY_OWNER_ID_COMPATIBILITY_ONLY",
    "TRIGGER_CHECK_LOG_THEN_CURRENT_OWNER_ELIGIBILITY_OR_CONTINUE",
    "SCOPE_KEY_OR_REJECT_THEN_SEEN_DEDUP",
    "INSERT_SEEN_OPPORTUNITY_BEFORE_CONDITION_CALLBACK",
    "ORIGINAL_TEMPLATE_BUDGET_CONJUNCTION_CAP_BEFORE_ATTEMPT",
    "OPTIONAL_ATTEMPT_SETTLEMENT_ONCE_OR_REJECT_KEEP_SIDE_EFFECTS",
    "COMBO_OR_FOLLOW_UP_CHECK_LOG_FROM_CURRENT_MUTATED_EVENT",
    "LOCAL_CONTEXT_DECAY_SETDEFAULT_THEN_RESOLVER_OR_LITERAL_PROBABILITY",
    "EXISTING_PYTHON_CLAMP_THEN_CURRENT_DECAY_OVERRIDE",
    "INCREMENT_ATTEMPTS_THEN_ZERO_ROLL_IF_EFFECTIVE_GE_ONE_ELSE_ONE_RNG_DRAW",
    "ROLL_LOG_THEN_FAILURE_AND_OPTIONAL_COMBO_END_OR_CONTINUE",
    "SUCCESS_ONLY_COEFFICIENT_CALLBACK_THEN_CANDIDATE_WITH_EVENT_COPY_AND_OUT_OF_BAND_REF",
    "INCREMENT_SEQUENCE_THEN_CANDIDATE_CREATED_LOG_THEN_QUEUE_ONCE_NO_DRAIN",
)
OPPORTUNITY_FAILURE_SIDE_EFFECTS = (
    ("WRONG_REF_TYPE", "EXISTING_TYPE_ERROR_EVEN_WITHOUT_CONTEXT_NO_STORE_VALIDATION"),
    ("NO_CONTEXT", "RETURN_NO_SNAPSHOT_MATCHING_CALLBACK_RNG_OR_QUEUE"),
    ("OWNER_OR_SCOPE_REJECT", "CHECK_LOG_REMAINS_CONTINUE_NO_CALLBACK"),
    ("CONDITION_FALSE", "SEEN_ALREADY_INSERTED_CALLBACK_SIDE_EFFECTS_REMAIN"),
    ("PRE_ATTEMPT_CAP", "SEEN_AND_CONDITION_EFFECTS_REMAIN_NO_ATTEMPT_OR_ROLL"),
    ("ATTEMPT_FALSE", "PAID_SIDE_EFFECTS_REMAIN_NO_RESOLVER_ATTEMPT_COUNT_OR_ROLL"),
    ("FAILED_ROLL", "SEEN_COST_DECAY_ATTEMPT_AND_RNG_REMAIN_NO_COEFFICIENT_OR_SEQUENCE"),
    ("CALLBACK_EXCEPTION", "ORIGINAL_EXCEPTION_AND_PARTIAL_SCOPE_LOG_COST_DECAY_RNG_REMAIN_NO_ROLLBACK"),
)


def _literal_probability(value):
    # Encoding only. Never validate/clamp a gameplay probability or alter NaN
    # comparison semantics. JSON cannot represent nonfinite floats faithfully.
    if type(value) is float:
        if value != value: return "FLOAT_NAN"
        if value == float('inf'): return "FLOAT_POSITIVE_INFINITY"
        if value == float('-inf'): return "FLOAT_NEGATIVE_INFINITY"
    if type(value) in (int,float): return value
    return "UNOBSERVED_NON_PRIMITIVE_LITERAL"


@dataclass(frozen=True, slots=True)
class TriggerOpportunityEvaluationBoundary(Document):
    trigger_id: str
    owner_id: str
    source_martial_id: str | None
    martial_event_kind: str | None
    registration_event_type: str
    scope: str
    priority: int
    enabled: bool
    literal_base_probability: float | str
    original_template_budget_participation: bool
    has_condition: bool
    has_attempt_settler: bool
    has_probability_resolver: bool
    has_coefficient_resolver: bool
    has_commit_settler: bool
    original_action: OrdinarySpecialActionDescriptor
    explicit_detached_metadata: object = field(default_factory=dict)
    source_registration_status: str = field(init=False)
    stages: tuple[str,...] = field(default=OPPORTUNITY_STAGES,init=False)
    failure_side_effects: tuple[tuple[str,str],...] = field(default=OPPORTUNITY_FAILURE_SIDE_EFFECTS,init=False)
    event: str = field(default="UNOBSERVED",init=False)
    event_snapshot: str = field(default="UNOBSERVED",init=False)
    seen_scope_state: str = field(default="UNOBSERVED",init=False)
    live_owner_validity: str = field(default="UNOBSERVED",init=False)
    actual_cap_usage: str = field(default="UNOBSERVED",init=False)
    attempt_result: str = field(default="UNOBSERVED",init=False)
    current_decay: str = field(default="UNOBSERVED",init=False)
    effective_probability: str = field(default="UNOBSERVED",init=False)
    selected_rng_roll: str = field(default="UNOBSERVED",init=False)
    produced_candidate: str = field(default="UNOBSERVED",init=False)
    candidate_sequence: str = field(default="UNOBSERVED",init=False)
    actual_target: str = field(default="UNOBSERVED",init=False)
    source_action_id: str = field(default="UNOBSERVED",init=False)
    queue_state: str = field(default="UNOBSERVED",init=False)
    semantic_store_validity: str = field(default="UNOBSERVED",init=False)
    execution_route: str = field(default="LEGACY_COMPAT",init=False)
    production_migrated: bool = field(default=False,init=False)

    def __post_init__(self):
        for name in ('trigger_id','owner_id','registration_event_type','scope'):
            _identity(getattr(self,name),name)
        for name in ('source_martial_id','martial_event_kind'):
            _identity(getattr(self,name),name,optional=True)
        if type(self.priority) is not int or type(self.original_action) is not OrdinarySpecialActionDescriptor:
            raise TriggerMigrationError('Detached registration priority/action required')
        _booleans(self,('enabled','original_template_budget_participation','has_condition',
                       'has_attempt_settler','has_probability_resolver','has_coefficient_resolver','has_commit_settler'))
        object.__setattr__(self,'literal_base_probability',_literal_probability(self.literal_base_probability)
            if type(self.literal_base_probability) in (int,float) else self.literal_base_probability)
        if type(self.literal_base_probability) is str and self.literal_base_probability not in (
                'FLOAT_NAN','FLOAT_POSITIVE_INFINITY','FLOAT_NEGATIVE_INFINITY','UNOBSERVED_NON_PRIMITIVE_LITERAL'):
            raise TriggerMigrationError('Literal probability observation only')
        if type(self.literal_base_probability) not in (int,float,str):
            raise TriggerMigrationError('Primitive probability observation required')
        metadata=_metadata(self.explicit_detached_metadata)
        if any(k not in {'content_status_markers','canonical_ref_presence','canonical_ref_declared_type'} for k in metadata):
            raise TriggerMigrationError('Only explicit detached markers/ref availability metadata permitted')
        if ('canonical_ref_presence' in metadata and type(metadata['canonical_ref_presence']) is not bool
                or 'canonical_ref_declared_type' in metadata and type(metadata['canonical_ref_declared_type']) is not str
                or 'content_status_markers' in metadata and (type(metadata['content_status_markers']) is not tuple
                    or any(type(v) is not str for v in metadata['content_status_markers']))):
            raise TriggerMigrationError('Literal detached markers and unvalidated ref presence/type only')
        object.__setattr__(self,'explicit_detached_metadata',metadata)
        object.__setattr__(self,'source_registration_status',
            'AUTHORITY_TBD' if self.registration_event_type=='ALLY_TARGETED_BY_ATTACK_INSTANCE' else
            'CANONICAL_EVENT_GAP' if self.registration_event_type=='PRE_ACTIVE_TARGET_STATUS_CHECKED' else
            'LEGACY_COMPAT_REGISTRATION_NOT_PROVENANCE')

    @classmethod
    def from_definition(cls,definition,*,explicit_detached_metadata=None):
        if type(definition) is not TriggerDefinition:
            raise TriggerMigrationError('Concrete TriggerDefinition required; no live evaluator inputs')
        return cls(definition.id,definition.owner_id,definition.source_martial_id,definition.martial_event_kind,
            definition.event_type,definition.scope,definition.priority,definition.enabled,
            _literal_probability(definition.base_probability),
            bool(definition.counts_ordinary_budget and definition.action_template.counts_ordinary_budget),
            definition.condition is not None,definition.attempt_settler is not None,
            definition.probability_resolver is not None,definition.coefficient_resolver is not None,
            definition.commit_settler is not None,OrdinarySpecialActionDescriptor.from_template(definition.action_template),
            {} if explicit_detached_metadata is None else explicit_detached_metadata)

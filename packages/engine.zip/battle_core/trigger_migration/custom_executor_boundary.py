"""WO113 detached custom callback observations; NOT a dispatcher or authority."""
from dataclasses import dataclass, field, fields
from ..trigger import TriggerCandidate, TriggerDefinition, SpecialActionTemplate
from .model import Document, TriggerMigrationError

CUSTOM_SPECIAL_EXECUTOR_BOUNDARY_OBSERVED_IN_WO113_NOT_MIGRATED = (
    'CUSTOM_SPECIAL_EXECUTOR_BOUNDARY_OBSERVED_IN_WO113_NOT_MIGRATED')

CUSTOM_EXECUTOR_STAGES = (
    'ADMISSION_USES_ORIGINAL_TEMPLATE_SELECTOR_AND_EXECUTOR_IS_NOT_NONE',
    'EXECUTION_SELECTS_RESOLVED_OR_ORIGINAL_TEMPLATE_SEPARATELY',
    'OWNER_ELIGIBILITY_BEFORE_SOURCE_VALIDATION_AND_ACTION_ID',
    'VALIDATE_EXISTING_SOURCE_ALLOCATE_ID_INCREMENT_AND_MARTIAL_MAPPING',
    'APPEND_CANONICAL_STARTED_THEN_LEGACY_STARTED_AND_OPTIONAL_COMBO_STARTED',
    'SELECTED_EXECUTOR_IS_NOT_NONE_CALL_SAME_ENGINE_OWNER_CANDIDATE_EVENT_ONCE',
    'CALLBACK_RETURN_IGNORED_NO_STANDARD_EXECUTOR_IN_CUSTOM_BRANCH',
    'FINALIZE_OUTCOME_APPEND_FACT_AND_EXISTING_ACTION_COMPLETE_CHAIN',
    'APPEND_SPECIAL_COMPLETED_THEN_OPTIONAL_COMBO_COMPLETE_AND_LEGACY_COMPLETE',
)
CUSTOM_EXECUTOR_FAILURES = (
    ('OWNER_INELIGIBLE', 'NO_CUSTOM_CALLBACK_OR_STARTED_SOURCE_VALIDATION'),
    ('INVALID_TYPED_SOURCE', 'EXISTING_REJECTION_POINT_NO_INFERRED_PROVENANCE'),
    ('CALLBACK_EXCEPTION', 'PROPAGATE_STARTED_AND_PRIOR_MUTATIONS_REMAIN_NO_OUTCOME_OR_COMPLETED'),
    ('AFTER_CALLBACK_EXCEPTION', 'PRESERVE_EXACT_PARTIAL_FINALIZATION_FACT_LOG_OR_CHAIN_STAGE'),
    ('WO112_DRAIN_EXCEPTION', 'POPPED_ITEM_ABSENT_PENDING_ALIASES_REMAIN_FINALLY_NOT_DRAINING'),
    ('DIRECT_FALSY_CALLABLE', 'IS_NOT_NONE_DISPATCH_THEN_LEGACY_TRUTHINESS_SITE_DEBT_NOT_REPAIRED'),
)


def _text(value):
    return value if type(value) is str else 'UNOBSERVED'


def _template_metadata(template):
    if type(template) is not SpecialActionTemplate:
        return ('UNOBSERVED',)*5
    return (_text(template.id),_text(template.kind),_text(template.classification),
            _text(template.target_selector),template.executor is not None)


@dataclass(frozen=True, slots=True)
class CustomSpecialExecutorBoundary(Document):
    trigger_id: str = 'UNOBSERVED'
    owner_id: str = 'UNOBSERVED'
    source_event_type: str = 'UNOBSERVED'
    original_template_id: str = 'UNOBSERVED'
    original_kind: str = 'UNOBSERVED'
    original_classification: str = 'UNOBSERVED'
    original_selector: str = 'UNOBSERVED'
    original_executor_non_none: bool | str = 'UNOBSERVED'
    selected_template_id: str = 'UNOBSERVED'
    selected_kind: str = 'UNOBSERVED'
    selected_classification: str = 'UNOBSERVED'
    selected_selector: str = 'UNOBSERVED'
    selected_executor_non_none: bool | str = 'UNOBSERVED'
    stages: tuple[str,...] = field(default=CUSTOM_EXECUTOR_STAGES,init=False)
    failure_side_effects: tuple[tuple[str,str],...] = field(default=CUSTOM_EXECUTOR_FAILURES,init=False)
    original_eligibility_result: str = field(default='UNOBSERVED',init=False)
    selected_callback_truthiness: str = field(default='UNOBSERVED',init=False)
    runtime_callback_identity: str = field(default='UNOBSERVED',init=False)
    callback_return: str = field(default='IGNORED_BY_EXISTING_ENGINE',init=False)
    action_target_compatibility: str = field(default='NONE_FOR_TRUTHY_CUSTOM_LEGACY_TRUTHINESS_DEBT',init=False)
    source_provenance: str = field(default='UNOBSERVED',init=False)
    actual_target: str = field(default='UNOBSERVED',init=False)
    actual_settlement: str = field(default='UNOBSERVED',init=False)
    custom_content_authority: str = field(default='CUSTOM_EXECUTOR_TBD',init=False)
    custom_executor_route: str = field(default='LEGACY_COMPAT_OR_CONTENT_TBD',init=False)
    production_migrated: bool = field(default=False,init=False)

    def __post_init__(self):
        for item in fields(self):
            if item.init:
                value=getattr(self,item.name)
                if item.name in ('original_executor_non_none','selected_executor_non_none'):
                    if type(value) is bool or (type(value) is str and value=='UNOBSERVED'): continue
                    raise TriggerMigrationError('Detached presence boolean or UNOBSERVED only')
                if type(value) is not str: raise TriggerMigrationError('Detached literal strings only')

    @classmethod
    def from_candidate(cls,candidate):
        if type(candidate) is not TriggerCandidate:
            raise TriggerMigrationError('Actual concrete TriggerCandidate only')
        definition=candidate.definition
        if type(definition) is not TriggerDefinition: return cls()
        original=definition.action_template
        resolved=candidate.resolved_action_template
        # Do NOT truth-test arbitrary direct-call objects or callback instances.
        selected=original if resolved is None else resolved
        return cls(_text(definition.id),_text(definition.owner_id),_text(definition.event_type),
                   *_template_metadata(original),*_template_metadata(selected))

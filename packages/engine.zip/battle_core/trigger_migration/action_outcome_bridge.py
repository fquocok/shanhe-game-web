"""WO099 canonical ACTION_COMPLETE source adapter; no Trigger evaluation here."""
from dataclasses import dataclass
import math
from ..events import SemanticEventEnvelope, SemanticEventType as T
from ..events.taxonomy import validate_event
from ..events.envelope import canonical_json
from .model import TriggerMigrationError

MISMATCH = "CANONICAL_ACTION_OUTCOME_LEGACY_TRIGGER_VIEW_MISMATCH"
UNMIGRATED = "UNMIGRATED_PRODUCTION_ACTION_COMPLETE_SOURCE"

class CanonicalActionOutcomeSourceError(TriggerMigrationError):
    pass

class CanonicalActionOutcomeParityError(TriggerMigrationError):
    pass

def _source_error():
    raise CanonicalActionOutcomeSourceError("INVALID_CANONICAL_ACTION_OUTCOME_TRIGGER_SOURCE")

def _identity(value, optional=False):
    if value is None and optional:
        return
    if type(value) is not str or not value:
        _source_error()

@dataclass(frozen=True, slots=True)
class CanonicalActionOutcomeTriggerView:
    canonical_event_id: str
    formal_turn_id: str
    action_id: str
    actor_id: str
    target_id: str | None
    source_action_definition_id: str
    attack_coefficient: float | None
    action_type: str
    action_classification: str
    legacy_shape: str

    def __post_init__(self):
        for key in ("canonical_event_id","formal_turn_id","action_id","actor_id",
                    "source_action_definition_id","action_type","action_classification"):
            _identity(getattr(self,key))
        _identity(self.target_id, optional=True)
        if self.legacy_shape not in ("FORMAL_MAIN","ORDINARY_SPECIAL","COMPOSITE_ROOT"):
            _source_error()
        if self.legacy_shape == "COMPOSITE_ROOT":
            if self.action_classification != "formal_main" or self.action_type != "composite" or self.attack_coefficient is not None:
                _source_error()
        else:
            if type(self.attack_coefficient) not in (int,float) or not math.isfinite(self.attack_coefficient):
                _source_error()
            if (self.legacy_shape == "FORMAL_MAIN") != (self.action_classification == "formal_main"):
                _source_error()

    @classmethod
    def from_fact(cls, fact):
        if type(fact) is not SemanticEventEnvelope or fact.event_type is not T.ACTION_OUTCOME_FINALIZED:
            _source_error()
        validate_event(fact)
        p=fact.payload
        required=("action_target_id","source_action_definition_id","attack_coefficient",
                  "action_type","action_classification","successfully_deals_damage")
        if any(key not in p for key in required) or "target_id" in p or type(p["successfully_deals_damage"]) is not bool:
            _source_error()
        classification=p["action_classification"]
        shape=("COMPOSITE_ROOT" if classification=="formal_main" and
               p["action_type"]=="composite" and p["attack_coefficient"] is None
               else "FORMAL_MAIN" if classification=="formal_main" else "ORDINARY_SPECIAL")
        return cls(fact.event_id,fact.formal_turn_id,fact.action_id,fact.actor_id,
                   p["action_target_id"],p["source_action_definition_id"],
                   p["attack_coefficient"],p["action_type"],classification,shape)

    def to_trigger_input(self):
        result=dict(formal_turn_id=self.formal_turn_id,action_id=self.action_id,
                    actor_id=self.actor_id,target_id=self.target_id,
                    source_action_definition_id=self.source_action_definition_id,
                    action_classification=self.action_classification)
        if self.legacy_shape != "COMPOSITE_ROOT":
            result["attack_coefficient"]=self.attack_coefficient
        if self.legacy_shape == "ORDINARY_SPECIAL":
            result["action_type"]=self.action_type
        return result

def materialize_action_complete_trigger_input(fact):
    return CanonicalActionOutcomeTriggerView.from_fact(fact).to_trigger_input()

def assert_action_complete_parity(canonical_input, legacy_input):
    # Exact fields/presence AND literal JSON types; never let bool compare as 1.
    try:
        equal=canonical_json(canonical_input)==canonical_json(legacy_input)
    except (TypeError,ValueError):
        equal=False
    if not equal:
        raise CanonicalActionOutcomeParityError(MISMATCH)

"""Detached canonical Trigger-source provenance; never gameplay input."""
from dataclasses import dataclass

from ..events import SemanticEventEnvelope, SemanticEventType as T, UnknownEventReferenceError
from .model import TriggerMigrationError


INVALID_CANONICAL_TRIGGER_SOURCE_PROVENANCE = "INVALID_CANONICAL_TRIGGER_SOURCE_PROVENANCE"
CANONICAL_TRIGGER_SOURCE_TYPES = frozenset((
    T.ACTION_OUTCOME_FINALIZED.value,
    T.ATTACK_PARRY_CONFIRMED.value,
))


class InvalidCanonicalTriggerSourceProvenance(TriggerMigrationError):
    pass


def _invalid():
    raise InvalidCanonicalTriggerSourceProvenance(
        INVALID_CANONICAL_TRIGGER_SOURCE_PROVENANCE)


@dataclass(frozen=True, slots=True)
class CanonicalTriggerSourceRef:
    event_id: str
    event_type: str

    def __post_init__(self):
        if (type(self.event_id) is not str or not self.event_id
                or type(self.event_type) is not str
                or self.event_type not in CANONICAL_TRIGGER_SOURCE_TYPES):
            _invalid()

    @classmethod
    def from_fact(cls, fact):
        if (type(fact) is not SemanticEventEnvelope
                or fact.event_type.value not in CANONICAL_TRIGGER_SOURCE_TYPES):
            _invalid()
        return cls(fact.event_id, fact.event_type.value)

    def to_dict(self):
        return {"event_id": self.event_id, "event_type": self.event_type}


def validate_canonical_trigger_source(store, source_ref):
    """Resolve only for integrity validation immediately before Special start."""
    if source_ref is None:
        return None
    if type(source_ref) is not CanonicalTriggerSourceRef:
        _invalid()
    try:
        fact = store.get(source_ref.event_id)
    except (UnknownEventReferenceError, ValueError) as exc:
        raise InvalidCanonicalTriggerSourceProvenance(
            INVALID_CANONICAL_TRIGGER_SOURCE_PROVENANCE) from exc
    if (fact.event_type.value != source_ref.event_type
            or source_ref.event_type not in CANONICAL_TRIGGER_SOURCE_TYPES):
        _invalid()
    return fact

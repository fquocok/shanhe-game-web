"""WO115 測試專用靜態 audit；不載入遊戲、不呼叫 observer、不讀檔。"""
import ast
import json
from hashlib import sha256

MANIFEST_SHA256 = '82edd65b490c5a4748e9db7e1f9e0a06302889a7c7e0b5bf29b77ff8349b20c2'
OBSERVER = 'battle_core/trigger_migration/binding_chain_authority_inventory.py'
AUDIT = 'battle_core/trigger_migration/binding_chain_authority_audit.py'
OBSERVER_SHA256 = '048d2d2ed93f916db6c50e64a13009f08d884dd76b4d9a9fba0e8bcdcec52226'


class AuthorityInventoryAuditError(ValueError):
    pass


def _fail(rule, detail):
    raise AuthorityInventoryAuditError('WO115_' + rule + ':' + detail)


def _name(node):
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return _name(node.value) + '.' + node.attr
    return ''


def audit_inventory_sources(sources, accepted_manifest):
    """輸入完整 production map 與 A 證據；獨立錨點先於任何投影判斷。

    範圍：完整已接受來源逐 byte（logical LF）認證、已知 AST import/call、
    新 production 檔案 fail closed。不是對抗動態 Python 的完備安全沙箱。
    既有來源無可變更空間；新增 observer 限白名單，再用全文錨點封閉。
    """
    if sha256(accepted_manifest.replace('\r\n', '\n').encode()).hexdigest() != MANIFEST_SHA256:
        _fail('ACCEPTED_MANIFEST_ANCHOR', 'Checkpoint A')
    evidence = json.loads(accepted_manifest)
    if evidence['base'] != 'd27b86ba9059e38e88d422a3889e9b4037569a8a':
        _fail('ACCEPTED_BASE', 'exact main')
    production = {p: r for p, r in evidence['sources'].items() if p.startswith('battle_core/') and p.endswith('.py')}
    for path, row in production.items():
        if path not in sources or sha256(sources[path].replace('\r\n', '\n').encode()).hexdigest() != row['sha256']:
            _fail('ACCEPTED_SOURCE_ANCHOR', path)
    if OBSERVER not in sources or AUDIT not in sources:
        _fail('MISSING_OBSERVATION_FILE', 'observer/audit')
    allowed_imports = {
        ('dataclasses', 0): {('dataclass', None)},
        ('events.envelope', 2): {('freeze', None), ('canonical_json', None)},
        (None, 1): {('registry', 'R')},
        ('model', 1): {('TriggerMigrationBinding', None), ('MigrationAxis', None), ('export', None)},
    }
    pure_calls = {
        'dataclass', 'object.__setattr__', 'freeze', 'export', 'canonical_json',
        'self.to_dict', 'tuple', 'any', 'type', 'ValueError', 'len', 'getattr', 'BindingChainAuthorityInventory',
        'sorted', 'sum', 'b.to_dict', 'R._source_route_projection',
        'R.SOURCE_EVENT_READINESS.items', 'readiness.get', 'R.registration_inventory',
    }
    forbidden_calls = {'emit', 'dispatch', 'register', 'handle_event', 'queue', 'drain',
                       'execute_candidate', 'execute_custom_special', 'execute_standard_special',
                       '_execute_special_action', '_emit_combat_event', 'executor',
                       'settle_trigger_candidate', 'resolve', 'random', 'randint', 'choice',
                       'shuffle', 'append', 'update', 'setattr', 'eval', 'exec', '__import__'}
    for path, source in sorted(sources.items()):
        if not path.startswith('battle_core/') or not path.endswith('.py'):
            _fail('UNEXPECTED_INVENTORY_PATH', path)
        # 上面已逐 byte 認證所有接受來源；任何新增 import/call 都必先
        # 違反獨立 A 錨點。因此只解析新增來源，並未省略任何輸入認證。
        # 所有未知檔案仍留在此完整 inventory，接受相同 AST／拒絕規則。
        if path in production:
            continue
        try:
            tree = ast.parse(source)
        except SyntaxError as exc:
            _fail('INVALID_SOURCE', path + ':' + str(exc.lineno))
        is_new = path not in production
        for node in ast.walk(tree):
            if path == OBSERVER:
                if isinstance(node, ast.Import):
                    _fail('OBSERVER_IMPORT', path)
                if isinstance(node, ast.ImportFrom) and any(
                        (alias.name, alias.asname) not in allowed_imports.get((node.module, node.level), set())
                        for alias in node.names):
                    _fail('OBSERVER_IMPORT', path)
                if isinstance(node, ast.Call) and _name(node.func) not in pure_calls:
                    _fail('OBSERVER_CALL', _name(node.func))
                if isinstance(node, ast.arg) and node.arg in {'engine', 'event', 'callback', 'rng', 'store', 'context', 'candidate'}:
                    _fail('OBSERVER_LIVE_ARGUMENT', node.arg)
                if isinstance(node, ast.Attribute) and node.attr in {
                        'event', 'executor', 'callback', '_queue', 'rng', 'engine', 'semantic_events',
                        'log', 'contexts', 'trigger_context', 'current_hp', 'statuses'}:
                    _fail('OBSERVER_LIVE_ACCESS', node.attr)
                if isinstance(node, (ast.Assign, ast.AugAssign, ast.AnnAssign)):
                    targets = node.targets if isinstance(node, ast.Assign) else [node.target]
                    if any(isinstance(t, (ast.Attribute, ast.Subscript)) for t in targets):
                        _fail('OBSERVER_MUTATION', path)
            elif is_new:
                if path == AUDIT and isinstance(node, (ast.Import, ast.ImportFrom)):
                    modules = [a.name for a in node.names] if isinstance(node, ast.Import) else [node.module]
                    if any(module not in {'ast', 'json', 'hashlib'} for module in modules):
                        _fail('AUDIT_IMPORT', path)
                if isinstance(node, (ast.Import, ast.ImportFrom)):
                    module = getattr(node, 'module', '') or ''
                    if 'binding_chain_authority' in module or any('binding_chain_authority' in a.name or a.name in {'build_inventory', 'BindingChainAuthorityInventory'} for a in node.names):
                        _fail('UNREVIEWED_OBSERVER_CONSUMER', path)
                if isinstance(node, ast.Call) and _name(node.func).rsplit('.', 1)[-1] in forbidden_calls:
                    _fail('UNREVIEWED_DISPATCH', path + ':' + _name(node.func))
        if is_new and path not in {OBSERVER, AUDIT}:
            _fail('UNAPPROVED_PRODUCTION_FILE', path)
    if sha256(sources[OBSERVER].replace('\r\n', '\n').encode()).hexdigest() != OBSERVER_SHA256:
        _fail('TRANSPARENT_PROJECTION_ANCHOR', OBSERVER)
    return {'status': 'PASS', 'production_observer_consumers': 0,
            'accepted_production_source_count': len(production),
            'production_migrated': False, 'migration_ready': False,
            'coverage': 'AUTHENTICATED_BASE_AND_BOUNDED_AST_NOT_DYNAMIC_SANDBOX'}

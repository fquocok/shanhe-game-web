"""WO105 detached observations only; never a Special executor or dispatch route."""
from dataclasses import dataclass, field

from ..trigger import TriggerCandidate, TriggerDefinition, TRIGGER_SCOPES
from .model import (Document, OrdinarySpecialActionDescriptor, TriggerMigrationError,
                    _identity, _number, _booleans)
from .source_ref import CanonicalTriggerSourceRef

STANDARD_SPECIAL_EXECUTOR_BOUNDARY_OBSERVED_IN_WO105_NOT_MIGRATED = (
    "STANDARD_SPECIAL_EXECUTOR_BOUNDARY_OBSERVED_IN_WO105_NOT_MIGRATED")

PRE_EXECUTION_STAGES = (
    "CONTEXT_AND_OWNER_ELIGIBILITY",
    "LEGAL_TARGET_PRECHECK_USING_ORIGINAL_TEMPLATE_MAY_CONSUME_RNG",
    "ORDINARY_CAP_CHECK",
    "CANONICAL_PROVENANCE_VALIDATION",
    "MARTIAL_EFFECT_SETTLEMENT",
    "ORDINARY_BUDGET_USE_IF_APPLICABLE",
    "COUNTER_TARGETING_TRANSFORMATION",
    "SUCCESS_AND_DECAY_UPDATE",
)
LIFECYCLE_PREFIX = (
    "RESOLVED_OR_ORIGINAL_TEMPLATE_AND_OWNER",
    "CANONICAL_PROVENANCE_VALIDATION",
    "ALLOCATE_SPECIAL_ACTION_ID",
    "APPEND_SPECIAL_STARTED_AND_LEGACY_START_LOGS",
)
STANDARD_STAGES = (
    "ROAMING_DISTINCT_OR_SPECIAL_TARGET_USING_ORIGINAL_TEMPLATE",
    "IF_INITIAL_TARGET_CREATE_OFFENSIVE_SNAPSHOT",
    "IF_INITIAL_TARGET_COMMIT_SETTLER",
    "IF_INITIAL_TARGET_RESOLVE_COEFFICIENT_AND_COUNTER_LOG",
    "NON_ROAMING_MARTIAL_TARGET_PREPARATION",
    "NON_ROAMING_NON_SINGLE_PATTERN_EXPANSION",
    "FOR_EACH_STILL_ELIGIBLE_TARGET_RESOLVE_EXISTING_ATTACK_PIPELINE",
)
LIFECYCLE_SUFFIX = (
    "FINALIZE_ACTION_OUTCOME",
    "APPEND_CANONICAL_OUTCOME_PARENTED_TO_STARTED",
    "WO104_WO099_ACTION_COMPLETE_LOG_TRIGGER_INNER",
    "APPEND_SPECIAL_COMPLETED_CAUSED_BY_OUTCOME_PARENTED_TO_STARTED",
    "LEGACY_COMPLETION_LOGS",
    "RETURN_BEFORE_DRAIN_EXECUTES_CHILD",
)


@dataclass(frozen=True, slots=True)
class StandardSpecialExecutorBoundary(Document):
    owner_id: str
    trigger_id: str
    source_martial_id: str | None
    source_event_type: str
    candidate_sequence: int
    scope: str
    original_template: OrdinarySpecialActionDescriptor
    selected_template: OrdinarySpecialActionDescriptor
    resolved_template_used: bool
    resolved_coefficient: float
    coefficient_source: str
    attack_tags: tuple[str, ...]
    ordinary_budget_participation: bool
    has_custom_executor: bool
    source_event_id: str | None
    canonical_source_event_type: str | None
    content_authority_markers: tuple[str, ...] = ()
    execution_family: str = field(init=False)
    selection_branch: str = field(init=False)
    canonical_provenance: str = field(init=False)
    execution_stages: tuple[str, ...] = field(init=False)
    pre_execution_stages: tuple[str, ...] = field(default=PRE_EXECUTION_STAGES, init=False)
    target_identity: str = field(default="UNOBSERVED", init=False)
    source_action_identity: str = field(default="UNOBSERVED", init=False)
    precheck_template: str = field(default="ORIGINAL_DEFINITION_TEMPLATE", init=False)
    special_target_template: str = field(default="ORIGINAL_DEFINITION_TEMPLATE", init=False)
    execution_route: str = field(default="LEGACY_COMPAT", init=False)
    production_migrated: bool = field(default=False, init=False)

    def __post_init__(self):
        for name in ("owner_id", "trigger_id", "source_event_type", "scope", "coefficient_source"):
            _identity(getattr(self, name), name)
        for name in ("source_martial_id", "source_event_id", "canonical_source_event_type"):
            _identity(getattr(self, name), name, optional=True)
        if (type(self.candidate_sequence) is not int or self.scope not in TRIGGER_SCOPES
                or type(self.original_template) is not OrdinarySpecialActionDescriptor
                or type(self.selected_template) is not OrdinarySpecialActionDescriptor):
            raise TriggerMigrationError("Typed candidate/template observations required")
        _number(self.resolved_coefficient, "resolved_coefficient")
        _booleans(self, ("resolved_template_used", "ordinary_budget_participation", "has_custom_executor"))
        if self.coefficient_source not in ("CANDIDATE_OVERRIDE", "SELECTED_TEMPLATE"):
            raise TriggerMigrationError("Explicit coefficient source required")
        if self.has_custom_executor != self.selected_template.has_custom_executor:
            raise TriggerMigrationError("Custom branch must match selected template")
        for name in ("attack_tags", "content_authority_markers"):
            values = getattr(self, name)
            if type(values) is not tuple or any(type(v) is not str or not v for v in values):
                raise TriggerMigrationError("Detached string tuples required")
            object.__setattr__(self, name, tuple(sorted(set(values))))
        if (self.source_event_id is None) != (self.canonical_source_event_type is None):
            raise TriggerMigrationError("Provenance identity must be a complete pair")
        content_tbd = bool({"SOURCE_CONTENT_TBD", "TOKEN_BALANCE_TBD"}
                           .intersection(self.content_authority_markers))
        family = ("CUSTOM_EXECUTOR_TBD" if self.has_custom_executor else
                  "CONTENT_TBD" if content_tbd else "STANDARD")
        branch = ("CUSTOM_EXECUTOR" if self.has_custom_executor else
                  "STANDARD_ROAMING_DISTINCT" if self.selected_template.target_selector == "roaming_distinct"
                  else "STANDARD_SPECIAL_TARGET_ORIGINAL_TEMPLATE")
        object.__setattr__(self, "execution_family", family)
        object.__setattr__(self, "selection_branch", branch)
        object.__setattr__(self, "canonical_provenance",
                           "AVAILABLE_NOT_VALIDATED" if self.source_event_id else "UNOBSERVED")
        body = ("CUSTOM_EXECUTOR_OUTSIDE_STANDARD_SCOPE",) if self.has_custom_executor else STANDARD_STAGES
        object.__setattr__(self, "execution_stages", LIFECYCLE_PREFIX + body + LIFECYCLE_SUFFIX)

    @classmethod
    def from_candidate(cls, candidate, *, content_authority_markers=()):
        """Copy explicit values only; no event access, store lookup or gameplay call."""
        if type(candidate) is not TriggerCandidate:
            raise TriggerMigrationError("Concrete TriggerCandidate required")
        definition = candidate.definition
        if type(definition) is not TriggerDefinition:
            raise TriggerMigrationError("Concrete TriggerDefinition required")
        original = OrdinarySpecialActionDescriptor.from_template(definition.action_template)
        template = candidate.resolved_action_template or definition.action_template
        selected = OrdinarySpecialActionDescriptor.from_template(template)
        ref = candidate.canonical_source_ref
        if ref is not None and type(ref) is not CanonicalTriggerSourceRef:
            raise TriggerMigrationError("Detached canonical provenance required")
        override = candidate.resolved_coefficient is not None
        return cls(
            definition.owner_id, definition.id, definition.source_martial_id,
            definition.event_type, candidate.sequence, definition.scope, original, selected,
            candidate.resolved_action_template is not None,
            candidate.resolved_coefficient if override else template.attack_coefficient,
            "CANDIDATE_OVERRIDE" if override else "SELECTED_TEMPLATE",
            tuple(template.attack_tags | frozenset({template.kind})),
            bool(definition.counts_ordinary_budget and definition.action_template.counts_ordinary_budget),
            template.executor is not None, None if ref is None else ref.event_id,
            None if ref is None else ref.event_type, content_authority_markers)

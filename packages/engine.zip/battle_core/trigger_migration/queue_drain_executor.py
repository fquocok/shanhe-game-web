"""WO112 mechanical legacy-compatible queue/drain bodies; no ordering authority."""

SPECIAL_QUEUE_DRAIN_RUNTIME_MIGRATED_IN_WO112 = "BOUNDARY_ACTIVE_LEGACY_COMPAT"


def enqueue_special_candidate(self, candidate):
    self._queue.append(candidate)
    definition = candidate.definition
    self._event("SPECIAL_ACTION_QUEUED", trigger=definition.id, owner=definition.owner_id,
                action=definition.action_template.id,
                parent_formal_turn_id=self.engine.trigger_context.formal_turn_id)


def drain_special_candidates(self):
    if self._draining:
        return
    self._draining = True
    try:
        while self._queue:
            self._queue.sort(key=lambda c: (
                c.definition.priority, c.definition.owner_id, c.definition.id, c.sequence,
            ))
            candidate = self._queue.pop(0)
            self.engine.triggers.execute_candidate(candidate)
    finally:
        self._draining = False

"""WO115：脫離 Runtime 的唯讀盤點，不是 Registry 或 Canon 的替代權威。"""
from dataclasses import dataclass
from ..events.envelope import freeze, canonical_json
from . import registry as R
from .model import TriggerMigrationBinding, MigrationAxis, export

BINDING_CHAIN_AUTHORITY_GAP_INVENTORY_WO115_READ_ONLY = 'BINDING_CHAIN_AUTHORITY_GAP_INVENTORY_WO115_READ_ONLY'
ACCEPTED_BASE = 'd27b86ba9059e38e88d422a3889e9b4037569a8a'

# 名稱與錨點只是索引；狀態與旗標一律投影原 Registry，不重新制定表。
ROUTE_ANCHORS = (
    ('TRIGGER_OPPORTUNITY_EVALUATION_RUNTIME_ROUTE', 'WO110', 'BOUNDED_IMPLEMENTATION_MOVED'),
    ('SPECIAL_QUEUE_DRAIN_RUNTIME_ROUTE', 'WO112', 'BOUNDED_IMPLEMENTATION_MOVED'),
    ('SPECIAL_CANDIDATE_ADMISSION_RUNTIME_ROUTE', 'WO108', 'BOUNDED_IMPLEMENTATION_MOVED'),
    ('STANDARD_SPECIAL_EXECUTOR_RUNTIME_ROUTE', 'WO106', 'BOUNDED_IMPLEMENTATION_MOVED'),
    ('CUSTOM_SPECIAL_EXECUTOR_RUNTIME_ROUTE', 'WO114', 'BOUNDED_IMPLEMENTATION_MOVED'),
    ('SPECIAL_OUTCOME_CHAIN_EMISSION_ROUTE', 'WO104', 'BOUNDED_CANONICAL_SOURCE_INGRESS_ONLY'),
    ('STANDARD_SPECIAL_EXECUTOR_BOUNDARY_ROUTE', 'WO105', 'HISTORICAL_OBSERVATION'),
    ('SPECIAL_CANDIDATE_ADMISSION_BOUNDARY_ROUTE', 'WO107', 'HISTORICAL_OBSERVATION'),
    ('TRIGGER_OPPORTUNITY_EVALUATION_BOUNDARY_ROUTE', 'WO109', 'HISTORICAL_OBSERVATION'),
    ('SPECIAL_QUEUE_DRAIN_BOUNDARY_ROUTE', 'WO111', 'HISTORICAL_OBSERVATION'),
    ('CUSTOM_SPECIAL_EXECUTOR_BOUNDARY_ROUTE', 'WO113', 'HISTORICAL_OBSERVATION'),
)

# 未決清單是工作單要求的非窮盡盤點，不是新語義；決策者不等同工程施工者。
OPEN_DECISIONS = (
    ('ORDINARY_SPECIAL_SIMULTANEOUS_ORDER_AUTHORITY_TBD', 'Human Canon', 'WO115:8 / registry.QUEUE_COMPATIBILITY'),
    ('CROSS_SOURCE_CONFLICT_TBD', 'Human Canon', 'WO115:8 / registry.SPECIAL_QUEUE_DRAIN_RUNTIME_ROUTE'),
    ('cross-owner Shield Break reaction ordering TBD', 'Human Canon', 'WO115:8'),
    ('ally_is_attacked_semantics: TBD_CORE', 'Human Canon', 'registry.SOURCE_EVENT_READINESS'),
    ('PRE_ACTIVE_TARGET_STATUS_CHECKED canonical source gap', 'Architecture source audit then Human Canon', 'registry.SOURCE_EVENT_READINESS'),
    ('Share total cap BALANCE_TBD', 'Human balance authority', 'WO115:8'),
    ('SOURCE_CONTENT_TBD', 'Human content authority', 'registry.content_markers'),
    ('TOKEN_BALANCE_TBD', 'Human token/balance authority', 'registry.content_markers'),
    ('true_damage_vs_shield: TBD_CORE_V0_4', 'Human Canon', 'WO115:8'),
    ('LEGACY_SPECIAL_DAMAGE_CANONICAL_ORIGIN_TBD', 'Human Canon', 'WO115:8'),
    ('CUSTOM_EXECUTOR_TBD', 'Human content authority', 'registry.CUSTOM_SPECIAL_EXECUTOR_RUNTIME_ROUTE'),
    ('legacy/direct-call malformed target and falsy callback exception debts', 'Architecture bounded audit before any authorized repair', 'WO114 / WO113 tests'),
    ('unknown/Presentation-only provenance and future source-event additions', 'Architecture source audit then Human Canon', 'source_ref.CANONICAL_TRIGGER_SOURCE_TYPES'),
)


@dataclass(frozen=True, slots=True)
class BindingChainAuthorityInventory:
    """只保有 freeze 後的 primitive 文件；不接受 engine/event/callback。"""
    payload: object

    def __post_init__(self):
        object.__setattr__(self, 'payload', freeze(self.payload))

    def to_dict(self):
        return export(self.payload)

    def serialize(self):
        return canonical_json(self.to_dict())


def build_inventory(fixture_bindings=()):
    """純快照：只接受已構造的 immutable WO097 Binding，永不載入內容。"""
    bindings = tuple(fixture_bindings)
    if any(type(b) is not TriggerMigrationBinding for b in bindings):
        raise ValueError('WO115_IMMUTABLE_BINDING_REQUIRED')
    if len({b.binding_id for b in bindings}) != len(bindings):
        raise ValueError('WO115_DUPLICATE_FIXTURE_BINDING')
    sources = tuple({
        'legacy_event': event_name,
        'literal': export(readiness),
        'binding_metadata_projection': R._source_route_projection(readiness),
        'implementation_stage': ('BOUNDED_SOURCE_MIGRATED' if readiness.get('source_event_production_migrated', False) else 'NOT_MIGRATED'),
        'authority_stage': R._source_route_projection(readiness)['production_source_route'],
        'evidence_tier': 'EXACT_LITERAL_REGISTRY_STATEMENT',
        'evidence_path': 'battle_core/trigger_migration/registry.py:SOURCE_EVENT_READINESS[' + event_name + ']',
        'work_order': readiness.get('source_migration_work_order'),
        'global_production_migrated': False,
        'global_migration_ready': False,
    } for event_name, readiness in sorted(R.SOURCE_EVENT_READINESS.items()))
    routes = tuple({
        'registry_anchor': anchor, 'work_order': order,
        'implementation_stage': stage, 'literal': export(getattr(R, anchor)),
        'authority_stage': 'SCOPED_LITERAL_ONLY_NOT_GLOBAL_AUTHORITY',
        'evidence_tier': 'EXACT_LITERAL_REGISTRY_STATEMENT',
        'evidence_path': 'battle_core/trigger_migration/registry.py:' + anchor,
        'global_production_migrated': False, 'global_migration_ready': False,
    } for anchor, order, stage in sorted(ROUTE_ANCHORS))
    return BindingChainAuthorityInventory({
        'version': 1, 'work_order': 'WO115', 'accepted_base': ACCEPTED_BASE,
        'marker': BINDING_CHAIN_AUTHORITY_GAP_INVENTORY_WO115_READ_ONLY,
        'production_migrated': False, 'migration_ready': False,
        'human_content_approval': False, 'is_registry_authority': False,
        'source_rows': sources, 'implementation_rows': routes,
        'unknown_source': {'authority_stage': 'SEMANTIC_GAP', 'canonical_source_event': None,
                           'source_ref': None, 'evidence_path': 'registry.py:make_binding / source_ref.py:CanonicalTriggerSourceRef',
                           'evidence_tier': 'AUTHENTICATED_STATIC_SOURCE'},
        'source_provenance': {
            'allowed_types': ('ACTION_OUTCOME_FINALIZED', 'ATTACK_PARRY_CONFIRMED'),
            'transport': 'OUT_OF_BAND_FROM_GAMEPLAY_EVENT',
            'validation': 'EXISTING_SPECIAL_START_INTEGRITY_BOUNDARY',
            'legacy_without_ref': 'UNLINKED',
            'presentation_or_log_is_authority': False,
            'evidence_tier': 'AUTHENTICATED_STATIC_SOURCE',
            'evidence_path': 'battle_core/trigger_migration/source_ref.py:CANONICAL_TRIGGER_SOURCE_TYPES / validate_canonical_trigger_source; battle_core/engine.py:_execute_special_action',
        },
        'binding_axis_vocabulary': tuple(a.value for a in MigrationAxis),
        'binding_observation': 'TEST_FIXTURES_ONLY' if bindings else 'NOT_OBSERVED',
        'unobserved_binding_axis_statuses': None if bindings else {a.value: 'UNKNOWN' for a in MigrationAxis},
        'fixture_bindings': tuple({
            'binding': b.to_dict(), 'migration_ready': b.migration_ready,
            'evidence_tier': 'EXPLICIT_TEST_FIXTURE_NOT_APPROVED_LIVE_CONTENT',
            'evidence_path': 'registry.py:make_binding / model.py:TriggerMigrationBinding',
        } for b in sorted(bindings, key=lambda b: b.binding_id)),
        'fixture_ready_count': sum(b.migration_ready for b in bindings),
        'live_binding_count': 'NOT_OBSERVED',
        'live_count_reason': 'NO_DESIGNATED_LIVE_RUNTIME_CONFIGURATION; STATIC_SITES_AND_FIXTURES_ARE_NOT_LIVE_POPULATION',
        'registration_sites': export(R.registration_inventory()),
        'registration_site_count': len(R.registration_inventory()),
        'registration_attribution': 'INSTALLED_MARTIAL_AND_PASSIVE_AND_UNIQUE_WO090_SOURCE_ITEM_REQUIRED',
        'queue_observation': export(R.QUEUE_COMPATIBILITY),
        'chain_requirements': {
            'work_order': ('WO103', 'WO104'),
            'ingress': export(R.SPECIAL_OUTCOME_CHAIN_EMISSION_ROUTE),
            'parent': 'SAME_IDENTITY_SPECIAL_ACTION_STARTED',
            'child_causation': 'PARENT_ACTION_OUTCOME_FINALIZED_NOT_COMPLETED',
            'order': 'PARENT_COMPLETED_BEFORE_CHILD_STARTED',
            'target_facts_are_action_identity': False,
            'exception': 'NO_FABRICATED_CHILD_OR_ROLLBACK_OR_RETRY',
            'downstream_binding_chain': 'LEGACY_COMPAT',
            'simultaneous_order_canon_approved': False,
            'evidence_tier': 'AUTHENTICATED_STATIC_SOURCE',
            'evidence_path': 'chain_emission_bridge.py:CanonicalSpecialOutcomeChainEmission.from_fact; engine.py:_execute_special_action; registry.py:WO103 identity markers',
        },
        'open_decisions': tuple({'marker': marker, 'next_decision_owner': owner,
                                 'evidence_path': path, 'resolved': False,
                                 'evidence_tier': 'WORK_ORDER_LEDGER_NOT_NEW_CANON'}
                                for marker, owner, path in OPEN_DECISIONS),
    })

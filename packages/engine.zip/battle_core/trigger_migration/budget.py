"""Accepted ordinary Special budget vocabulary; no consumption/execution logic."""
from dataclasses import dataclass
from .model import Document, TriggerMigrationError

@dataclass(frozen=True, slots=True)
class OrdinarySpecialBudgetContract(Document):
    cap: int = 3
    scope: str = "FORMAL_TURN"
    counts_as_turn: bool = False
    global_cooldown_tick: bool = False

    def __post_init__(self):
        if (type(self.cap) is not int or self.cap != 3 or self.scope != "FORMAL_TURN"
                or self.counts_as_turn is not False or self.global_cooldown_tick is not False):
            raise TriggerMigrationError("Accepted ordinary Special budget contract is fixed")

ORDINARY_SPECIAL_BUDGET = OrdinarySpecialBudgetContract()

"""Bounded registration audit and read-only runtime summary; never executes triggers."""
import ast
from dataclasses import asdict
from hashlib import sha256
from pathlib import Path
from collections.abc import Mapping
from ..events.envelope import freeze, canonical_json
from ..trigger import CounterTargetingTransformationDefinition
from .model import LegacyTriggerCandidateSnapshot, export
from .registry import (compile_registry, registration_inventory, content_markers,
                       REGISTRATION_MECHANICS, SOURCE_EVENT_READINESS, SEMANTIC_COVERAGE_REQUIRED,
                       QUEUE_COMPATIBILITY, _unclassified,
                       WO088_POST_SETTLEMENT_QUEUE_NOT_GENERAL_TRIGGER_QUEUE,
                       PRESENTATION_EVENTS_ARE_NOT_TRIGGER_AUTHORITY)

# WO102 authorizes only detached canonical-source transport through Trigger and
# the Special-start causation append boundary; formula/target sources stay pinned.
PROTECTED_FILES = {
    "battle_core/special/standard_executor.py": "f0804ec741b7a0e40df09fc612a91302180c2f4d90d0168dcbea48787f1d7d9f",
    "battle_core/trigger_migration/chain_emission_bridge.py": "fed13020c0275722398f340ae3c3da064f7c40077bbe142d94a919ad6a33c2e6",
    # WO108: authenticated whole-source reconstruction against the WO107
    # fixture proves only execute_candidate was replaced by one wrapper call.
    # WO110: only handle_event wrapper changed; authenticated reconstruction
    # restores the exact WO109 whole-source SHA and Git blob below.
    "battle_core/trigger.py": "af6947162a76451fa574d5cdead97d8bd6140bf7df3cbced0e7ce3729dfd6f72",
    "battle_core/trigger_migration/opportunity_evaluation_executor.py": "522853f0dcffcb5cb4053308e48b7d1f6794f86e797531ce66237665e9336e6f",
    "battle_core/trigger_migration/candidate_admission_executor.py": "5dfb3af20d427416547f1ba0a3fb9eef26f3574dc3f8ca91fd63228abea2b885",
    "battle_core/martial.py": "19e2dd07754f423ae4697bf19fb1b1c0be829bcc5d23e38396ed7f3e3b88835d",
    "battle_core/generated_special_compiler.py": "1234effc510c6074578b88c014555c29381b3ff4d59e179c277916c2d0c5ec98",
    "battle_core/qingtian.py": "a99f1d4b28b6c52556129e76b25f8b965abb57a5f39f16baf45a9fcdd69d6f85",
    "battle_core/bindings/martial_binding.py": "86dc2956caa5160e0137cc1847775071ae7b8fa08a8657a22202aec69aff0f81",
    "battle_core/events/types.py": "b74dec0abee7d92a6c4309ac7e665986c516af1f08f444012088940bfff1b2d5",
    "battle_core/scheduler/runtime_pre_resolution.py": "5f8126d7f77da7df14d96f4d80ada9488c3d464c4c8d554444a8d733c7b9a23d",
    "battle_core/damage/non_attack/dot_periodic.py": "1d9786dfdc54bdf714fa887087972aa90329c7a7ed003b25c88870f1d4277568",
    "battle_core/damage/non_attack/environment.py": "59cbdb279b21bbbdfdf143d27db52bf7eb64385e8563e8df2dd7f013ac379840",
    "battle_core/presentation_stream/adapter.py": "b216034ebffc396958b71d77d0e3066ddb0acc879f71de3a5bc165a9c3f5ce40",
    "battle_core/interactive_battle_screen.py": "b5bc36eecf04c091bfd99e88824d94da692d9a50823da9d8da8a139bee0e8084",
    "battle_core/human_checkpoint/scenario.py": "6306964cd073f7af1bacf9e3a1e1bceb2765a21f5a9520fba240773e5cc44002",
    "battle_core/human_checkpoint/screen_adapter.py": "39c46a920eada62e89b0134b12f2129655f885daec33eb7d81563f0021854937"
}
PROTECTED_ENGINE_METHODS = {
    "BattleEngine._emit_action_complete_compat": "2de1fac0a487f78826e71c6de2c9fce57956ea1d60274f8e4c3c2b9b63d37e88",
    "BattleEngine._execute_special_action": "ab6659b05ee45d53df05c938fbc9f08e43e5641feceb2a3334426e2efdef50db",
    "BattleEngine._can_execute_special": "113e676e49336b0cd2dd307fd0744c28097cde7be8af7cb6878a542f4f51abad",
    "BattleEngine._special_target": "2308f161d9fb121b0b89a22bfdc8431bcbcfcbaa4a33520a1a8efe98e3944cb4",
    "BattleEngine._rear_adjacent": "2c05f1c72332a004be0fcfc361e2a0eed216ca76887b4163c595a7afbd881b26",
    "BattleEngine._horizontal_neighbor": "f3b6c448fd0c234197b4251e440ba92a453d77334c5e439bf16c05d36dc5ac32",
    "BattleEngine._emit_combat_event": "acfe828690794edae452b6d8a636a6f921387bbb6692d9810298ecfcdbe74911",
    "BattleEngine.capture_trigger_event_snapshot": "b8b9c2a6ceb9433468f0781c8bfcef4f064035d22aadeca384cb2af1e16f6f56",
    "BattleEngine._resolve_attack": "97f57a851540fffca93dac0a89b09b3cd45c37a102795279c5036cbe7167862a",
    "BattleEngine._resolve_dot": "7427c237f37f14632b97e30367b57028b78139a58c1cd9f2d0f0f02930780dfd",
    "BattleEngine._resolve_environment_damage_source": "12c507adfc542a9d734d8ff36202f2b2f9675eb75e9c8e0ec6d608000d9e902a",
    "BattleEngine.resolve_special_damage": "fb3580b23876d99030613b44d31c2fa23879bcc0c72deacede71033d17606173",
    "BattleEngine._formal_turn": "c46c99f99ba08248570f6670bc243130a38b19463577e885c788122da7795e48"
}

# Reviewed factories/registration sinks only. Discovery does not create a route.
KNOWN_SITES = frozenset({
    ("battle_core/martial.py", "MartialRuntimeManager.equip", "self.engine.triggers.register"),
    ("battle_core/martial.py", "MartialRuntimeManager.equip", "TriggerDefinition"),
    ("battle_core/generated_special_compiler.py", "compile_trigger", "TriggerDefinition"),
    ("battle_core/qingtian.py", "compile_qingtian", "CounterTargetingTransformationDefinition"),
})


def _name(node):
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        prefix = _name(node.value)
        return prefix + "." + node.attr if prefix else node.attr
    return ""


class _RegistrationFacts(ast.NodeVisitor):
    def __init__(self, path, source):
        self.path, self.source = path, source
        self.scope, self.calls, self.methods = [], [], {}

    def _scoped(self, node):
        self.scope.append(node.name)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            self.methods[".".join(self.scope)] = ast.get_source_segment(self.source, node)
        self.generic_visit(node)
        self.scope.pop()

    visit_ClassDef = _scoped
    visit_FunctionDef = _scoped
    visit_AsyncFunctionDef = _scoped

    def visit_Call(self, node):
        name = _name(node.func)
        registration = (name.endswith(".triggers.register") or name == "TriggerEngine.register" or
                        name.rsplit(".", 1)[-1] in
                        ("TriggerDefinition", "CounterTargetingTransformationDefinition",
                         "register_counter_targeting_transformation") or
                        ("triggers" in name and name.endswith("._definitions.append")))
        if registration:
            key = self.path, ".".join(self.scope), name
            if key not in KNOWN_SITES:
                _unclassified(":".join(key))
            self.calls.append({"path": self.path, "owner": key[1],
                               "call": name, "line": node.lineno})
        self.generic_visit(node)


def load_sources(root=None):
    root = Path(__file__).resolve().parents[2] if root is None else Path(root)
    return {p.relative_to(root).as_posix(): p.read_text(encoding="utf-8")
            for p in sorted((root / "battle_core").rglob("*.py"))}


def audit_standard_executor_boundary_sources(sources=None):
    """Bounded observation firewall; never installs or invokes an executor."""
    from .model import TriggerMigrationError
    sources = load_sources() if sources is None else sources
    path = "battle_core/trigger_migration/standard_executor_boundary.py"
    forbidden = {"random", "choice", "shuffle", "_can_execute_special", "_special_target",
                 "_execute_special_action", "_resolve_attack", "handle_event", "dispatch",
                 "execute_candidate", "settle_trigger_candidate", "select_roaming_distinct",
                 "expand", "apply", "eval", "exec", "__import__", "executor", "condition",
                 "probability_resolver", "attempt_settler", "commit_settler", "coefficient_resolver"}
    allowed_imports = {"dataclasses", "trigger", "model", "source_ref"}
    def fail(detail):
        raise TriggerMigrationError("WO105_OBSERVATION_ONLY_BOUNDARY_VIOLATION: " + detail)
    if path not in sources:
        fail("Missing descriptor source")
    for source_path, source in sources.items():
        for node in ast.walk(ast.parse(source)):
            if source_path == path:
                if isinstance(node, ast.Import):
                    fail("Only explicit reviewed imports allowed")
                if isinstance(node, ast.ImportFrom) and node.module not in allowed_imports:
                    fail("Unreviewed dependency")
                if isinstance(node, ast.Call) and _name(node.func).rsplit(".", 1)[-1] in forbidden:
                    fail("Gameplay call in descriptor")
            elif source_path.startswith("battle_core/"):
                if (isinstance(node, ast.ImportFrom) and node.module
                        and node.module.endswith("standard_executor_boundary")) or (
                        isinstance(node, ast.Import) and any(
                            alias.name.endswith("standard_executor_boundary") for alias in node.names)):
                    fail("Production consumer of observation descriptor")
    return freeze({"status": "PASS", "scope": "BOUNDED_AST_OBSERVATION_FIREWALL",
                   "production_consumer_count": 0, "production_migrated": False,
                   "limitations": "Not a proof about arbitrary dynamic Python aliases"})


def audit_candidate_admission_boundary_sources(sources=None):
    """WO107 observation firewall plus authenticated WO108 relocation proof."""
    from .model import TriggerMigrationError
    sources = load_sources() if sources is None else sources
    path = "battle_core/trigger_migration/candidate_admission_boundary.py"
    protected = {
        "battle_core/trigger.py": "af6947162a76451fa574d5cdead97d8bd6140bf7df3cbced0e7ce3729dfd6f72",
        "battle_core/engine.py": "ad9f4b8cdb2460ad2fc77214cfcc48a9e6281b9658a0766dc2f71c9da6c923c4",
        "battle_core/special/standard_executor.py": "f0804ec741b7a0e40df09fc612a91302180c2f4d90d0168dcbea48787f1d7d9f",
        "battle_core/trigger_migration/standard_executor_boundary.py": "c9dbdc063f9a324e1ea29cae2e288b4b38a68869925509f30fb6813288652bf2",
    }
    def fail(detail):
        raise TriggerMigrationError("WO107_ADMISSION_OBSERVATION_VIOLATION: " + detail)
    # WO107 observation remains read-only. WO108 separately proves the only
    # authorized physical relocation, without repurposing either observer.
    audit_candidate_admission_runtime_sources(sources)
    for source_path, expected in protected.items():
        if source_path not in sources or sha256(sources[source_path].replace("\r\n","\n").encode()).hexdigest() != expected:
            fail("Protected runtime/queue/observer changed: " + source_path)
    if path not in sources: fail("Missing detached descriptor")
    forbidden = {"random","choice","shuffle","get","append","add","register","handle_event","dispatch",
        "execute_candidate","_can_execute_special","_special_target","_execute_special_action","_resolve_attack",
        "_validate_canonical_trigger_source","settle_trigger_candidate","executor","attempt_settler",
        "commit_settler","condition","probability_resolver","coefficient_resolver","eval","exec","__import__"}
    entries = []
    class Visitor(ast.NodeVisitor):
        def __init__(self, source_path): self.path, self.scope = source_path, []
        def visit_ClassDef(self, node):
            self.scope.append(node.name); self.generic_visit(node); self.scope.pop()
        def visit_FunctionDef(self, node):
            self.scope.append(node.name); self.generic_visit(node); self.scope.pop()
        visit_AsyncFunctionDef = visit_FunctionDef
        def visit_Call(self,node):
            if _name(node.func).rsplit(".",1)[-1] == "execute_candidate":
                site = self.path, ".".join(self.scope), _name(node.func)
                if site != ("battle_core/trigger.py","SpecialActionManager.drain","self.engine.triggers.execute_candidate"):
                    fail("Unreviewed candidate execution entry")
                entries.append(site)
            self.generic_visit(node)
    for source_path, source in sources.items():
        if not source_path.startswith("battle_core/") or not source_path.endswith(".py"): continue
        tree = ast.parse(source)
        Visitor(source_path).visit(tree)
        for node in ast.walk(tree):
            if source_path == path:
                if isinstance(node,ast.Import): fail("Unreviewed descriptor import")
                if isinstance(node,ast.ImportFrom) and node.module not in {"dataclasses","trigger","model","source_ref"}:
                    fail("Unreviewed descriptor dependency")
                if isinstance(node,ast.Call) and _name(node.func).rsplit(".",1)[-1] in forbidden:
                    fail("Gameplay/callback call in descriptor")
                if isinstance(node,ast.Attribute) and _name(node) == "candidate.event":
                    fail("Mutable gameplay event read")
            elif ((isinstance(node,ast.ImportFrom) and node.module and
                   (node.module.endswith("candidate_admission_boundary") or any(
                       alias.name in {"candidate_admission_boundary","SpecialCandidateAdmissionBoundary"} for alias in node.names)))
                  or (isinstance(node,ast.Import) and any(alias.name.endswith("candidate_admission_boundary") for alias in node.names))):
                fail("Production consumer of observation descriptor")
    if len(entries) != 1: fail("Missing/duplicate candidate execution ingress")
    return freeze({"status":"PASS","scope":"BOUNDED_AST_AND_AUTHENTICATED_WO108_MIGRATION",
        "candidate_execution_entry_count":1,"production_observer_consumer_count":0,
        "production_migrated":False,"limitations":"Not a proof of arbitrary dynamic Python aliases"})


def audit_special_queue_drain_boundary_sources(sources=None):
    """WO111 authentic accepted queue and bounded passive-observer firewall."""
    from hashlib import sha1
    from .model import TriggerMigrationError
    sources=load_sources() if sources is None else sources
    path="battle_core/trigger_migration/queue_drain_boundary.py"
    protected={
        "battle_core/trigger.py": "af6947162a76451fa574d5cdead97d8bd6140bf7df3cbced0e7ce3729dfd6f72",
        "battle_core/engine.py": "ad9f4b8cdb2460ad2fc77214cfcc48a9e6281b9658a0766dc2f71c9da6c923c4",
        "battle_core/trigger_migration/opportunity_evaluation_executor.py": "522853f0dcffcb5cb4053308e48b7d1f6794f86e797531ce66237665e9336e6f",
        "battle_core/trigger_migration/candidate_admission_executor.py": "5dfb3af20d427416547f1ba0a3fb9eef26f3574dc3f8ca91fd63228abea2b885",
        "battle_core/special/standard_executor.py": "f0804ec741b7a0e40df09fc612a91302180c2f4d90d0168dcbea48787f1d7d9f",
        "battle_core/trigger_migration/opportunity_evaluation_boundary.py": "67115a0a892565d2daccf4e4e49f16f4b14fe3ce14d8debcc5aa80d762b2db3c",
        "battle_core/trigger_migration/candidate_admission_boundary.py": "8fa6595376aa15d5a2bd98662ed77d0eeb902799bb67c22642d60f30ab74853f",
        "battle_core/trigger_migration/standard_executor_boundary.py": "c9dbdc063f9a324e1ea29cae2e288b4b38a68869925509f30fb6813288652bf2",
        "battle_core/trigger_migration/action_outcome_bridge.py": "4522aab49ee5449d5a130cf07d0650a803a1db2d1abd66a808593cc50e1bb020",
        "battle_core/trigger_migration/parry_bridge.py": "ae33cbfc658c184ec6c5a3c2a045bfcce7bb454e6a05a06e7a69c7ff30792606",
        "battle_core/trigger_migration/chain_emission_bridge.py": "fed13020c0275722398f340ae3c3da064f7c40077bbe142d94a919ad6a33c2e6",
        "battle_core/trigger_migration/source_ref.py": "e3b4c7346c11ebc76f23f01dce7469cc6d5926ae24c4a1da252d8ea507386531",
        "battle_core/composite.py": "f0f38b603fa2b90fe43469f28fccf7da3c82043727f85f1333a3e240acaf03a0",
        "battle_core/revision_2_canonical_promotion.py": "751e7659c12abdf42887eadd9aa1ca0522c4b7a5221b325553a351d7e53f17fe"
    }
    def fail(detail): raise TriggerMigrationError("WO111_QUEUE_OBSERVATION_VIOLATION: "+detail)
    for p,expected in protected.items():
        if p not in sources or sha256(sources[p].replace("\r\n","\n").encode()).hexdigest()!=expected:
            fail("Accepted queue/adjacent source changed: "+p)
    source=sources["battle_core/trigger.py"].replace("\r\n","\n"); data=source.encode()
    if sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()!="a6357704729daad2c6852acd74cd3725e82e9ee9":
        fail("Accepted trigger Git blob changed")
    node=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=="SpecialActionManager")
    def ast_hash(n):
        try: text=ast.dump(n,show_empty=True)
        except TypeError: text=ast.dump(n)
        return sha256(text.encode()).hexdigest()
    if ast_hash(node)!="c68a9201841f8e205a5445358442c2a9b1b24f97b0777230538befe343aab510": fail("Accepted manager class AST changed")
    method_hashes={
        "__init__": "8501fef3e8e9bc9a506df19820f9de3e284cd19c775b95f9172175dcb1b8ade5",
        "queue": "7c210bbe8f0a628c8dbaac4f0bb078c8131f72532335dbfc522ebbf038040e01",
        "drain": "7333e0f5a77ce38dafc533b6c1e58ba7fe4110f3f5c4fca21102095a66be212c"
    }
    if {n.name:ast_hash(n) for n in node.body if isinstance(n,ast.FunctionDef)}!=method_hashes:
        fail("Accepted init/queue/drain methods changed")
    if path not in sources: fail("Missing detached queue boundary")
    reviewed_imports={("dataclasses",0):{"dataclass","field"},
        ("trigger",2):{"TriggerCandidate","TriggerDefinition","SpecialActionTemplate"},
        ("model",1):{"Document","TriggerMigrationError"}}
    pure_calls={"dataclass","field","type","getattr","any","cls","_text","_integer","TriggerMigrationError"}
    methods={"_text","_integer","__post_init__","from_candidate"}
    live_names={"engine","manager","context","queue","event","owner","rng","store","sink","callback"}
    calls=[]; writes=[]
    class Visitor(ast.NodeVisitor):
        def __init__(self,p): self.path,self.scope=p,[]
        def visit_ClassDef(self,n): self.scope.append(n.name); self.generic_visit(n); self.scope.pop()
        def visit_FunctionDef(self,n):
            if self.path==path and n.name not in methods: fail("Executive/unreviewed observer API")
            self.scope.append(n.name); self.generic_visit(n); self.scope.pop()
        visit_AsyncFunctionDef=visit_FunctionDef
        def visit_Call(self,n):
            name=_name(n.func)
            if name.rsplit(".",1)[-1] in {"queue","drain","SpecialActionManager"} or "._queue." in name:
                calls.append((self.path,".".join(self.scope),name))
            if self.path==path and name not in pure_calls: fail("Gameplay/callback/queue call in observer")
            self.generic_visit(n)
        def visit_Attribute(self,n):
            name=_name(n)
            if n.attr in {"_queue","_draining"} and isinstance(n.ctx,(ast.Store,ast.Del)):
                writes.append((self.path,".".join(self.scope),name))
            if self.path==path:
                allowed={"candidate":{"definition","sequence"},"definition":{"id","owner_id","priority","action_template"},"template":{"id"}}
                root=name.split(".")[0]
                if root in allowed and (len(name.split("."))!=2 or name.split(".")[1] not in allowed[root]):
                    fail("Mutable event/live payload access in observer")
            self.generic_visit(n)
        def visit_Subscript(self,n):
            if isinstance(n.ctx,(ast.Store,ast.Del)) and "._queue" in _name(n.value):
                fail("Unreviewed direct pending-queue write")
            self.generic_visit(n)
        def visit_Name(self,n):
            if self.path==path and n.id in live_names: fail("Live gameplay reference in observer")
        def visit_arg(self,n):
            if self.path==path and n.arg in live_names: fail("Live gameplay argument in observer")
        def visit_Import(self,n):
            if self.path==path: fail("Unreviewed observer dependency")
            if any(a.name.endswith("queue_drain_boundary") for a in n.names): fail("Production observer import")
        def visit_ImportFrom(self,n):
            if self.path==path:
                allowed=reviewed_imports.get((n.module,n.level),set())
                if any(a.name not in allowed or a.asname for a in n.names): fail("Unreviewed observer dependency")
            elif (n.module and n.module.endswith("queue_drain_boundary")) or any(
                    a.name in {"queue_drain_boundary","SpecialQueueDrainBoundary","SpecialActionManager"} for a in n.names):
                fail("Unreviewed observer/manager producer import")
    for p,s in sources.items():
        if p.startswith("battle_core/") and p.endswith(".py"): Visitor(p).visit(ast.parse(s))
    expected_calls=[
        ("battle_core/composite.py","CompositeActionExecutor.execute","self.engine.triggers.special_actions.drain"),
        ("battle_core/engine.py","BattleEngine._formal_turn","self.triggers.special_actions.drain"),
        *[("battle_core/revision_2_canonical_promotion.py","run_revision_2_smoke","engine.triggers.special_actions.drain")]*3,
        ("battle_core/trigger.py","SpecialActionManager.drain","self._queue.pop"),
        ("battle_core/trigger.py","SpecialActionManager.drain","self._queue.sort"),
        ("battle_core/trigger.py","SpecialActionManager.queue","self._queue.append"),
        ("battle_core/trigger.py","TriggerEngine.__init__","SpecialActionManager"),
        ("battle_core/trigger_migration/opportunity_evaluation_executor.py","execute_trigger_opportunity_evaluation","self.special_actions.queue")]
    expected_writes=[
        ("battle_core/trigger.py","SpecialActionManager.__init__","self._draining"),
        ("battle_core/trigger.py","SpecialActionManager.__init__","self._queue"),
        *[("battle_core/trigger.py","SpecialActionManager.drain","self._draining")]*2]
    if sorted(calls)!=expected_calls or sorted(writes)!=expected_writes:
        fail("Unreviewed queue/drain caller, manager producer or direct queue mutation")
    audit_trigger_opportunity_evaluation_boundary_sources(sources)
    return freeze({"status":"PASS","scope":"SPECIAL_CANDIDATE_QUEUE_AND_DRAIN_ONLY",
        "queue_drain_production_migrated":False,"production_migrated":False,
        "production_consumer_count":0,"manager_producer_count":1,"external_queue_caller_count":1,
        "external_drain_call_count":5,"accepted_smoke_fixture_drain_calls":3,
        "limitations":"Bounded reviewed AST/import/call/write inventory and accepted fingerprints; not arbitrary dynamic aliases"})


def _reconstruct_wo109_opportunity_source(sources):
    """Authenticate actual WO110 sources, then rebuild the real WO109 Git blob."""
    from hashlib import sha1
    from .model import TriggerMigrationError
    path="battle_core/trigger_migration/opportunity_evaluation_executor.py"
    for p in ("battle_core/trigger.py",path):
        if p not in sources or sha256(sources[p].replace("\r\n","\n").encode()).hexdigest()!=PROTECTED_FILES[p]:
            raise TriggerMigrationError("WO110_AUTHENTICATED_SOURCE_CHANGED: "+p)
    source=sources["battle_core/trigger.py"].replace("\r\n","\n")
    helper_source=sources[path].replace("\r\n","\n")
    helper=next(n for n in ast.parse(helper_source).body if isinstance(n,ast.FunctionDef))
    segment=ast.get_source_segment(helper_source,helper)
    lines=segment.splitlines()
    old_method=lines[0].replace("execute_trigger_opportunity_evaluation","handle_event",1)+"\n"
    old_method+="\n".join("    "+line if line else line for line in lines[1:])+"\n"
    old_method=old_method.replace("from .source_ref import CanonicalTriggerSourceRef",
                                "from .trigger_migration.source_ref import CanonicalTriggerSourceRef")
    if sha256(old_method.encode()).hexdigest()!="d1adcde2fc15e72c91ef0961e2405a961e703039bf730c1a4321a30f279b3d41":
        raise TriggerMigrationError("WO110_FROZEN_REAL_METHOD_REBUILD_FAILED")
    wrapper=next(n for n in ast.walk(ast.parse(source)) if isinstance(n,ast.FunctionDef) and n.name=="handle_event")
    rebuilt=source.replace(ast.get_source_segment(source,wrapper),old_method.rstrip("\n"))
    data=rebuilt.encode()
    if (sha256(data).hexdigest()!="d4b8e2a07bd5eaeebb27e339da8ffe58591d1120aa5a4c038ebb231311bf4c46"
            or sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()!="fa8c176b7115d543fa587e8b28a53d1f2c5a1a23"):
        raise TriggerMigrationError("WO110_ACCEPTED_WHOLE_SOURCE_OR_GIT_BLOB_REBUILD_FAILED")
    return rebuilt


def audit_trigger_opportunity_runtime_sources(sources=None):
    """WO110 exclusive route, exact historical source/body and local import timing."""
    from .model import TriggerMigrationError
    sources=load_sources() if sources is None else sources
    rebuilt=_reconstruct_wo109_opportunity_source(sources)
    path="battle_core/trigger_migration/opportunity_evaluation_executor.py"
    def fail(detail): raise TriggerMigrationError("WO110_OPPORTUNITY_RUNTIME_VIOLATION: "+detail)
    preserved={
        "battle_core/trigger_migration/opportunity_evaluation_boundary.py":"67115a0a892565d2daccf4e4e49f16f4b14fe3ce14d8debcc5aa80d762b2db3c",
        "battle_core/trigger_migration/candidate_admission_boundary.py":"8fa6595376aa15d5a2bd98662ed77d0eeb902799bb67c22642d60f30ab74853f",
        "battle_core/trigger_migration/action_outcome_bridge.py":"4522aab49ee5449d5a130cf07d0650a803a1db2d1abd66a808593cc50e1bb020",
        "battle_core/trigger_migration/parry_bridge.py":"ae33cbfc658c184ec6c5a3c2a045bfcce7bb454e6a05a06e7a69c7ff30792606",
        "battle_core/trigger_migration/chain_emission_bridge.py":"fed13020c0275722398f340ae3c3da064f7c40077bbe142d94a919ad6a33c2e6",
        "battle_core/trigger_migration/source_ref.py":"e3b4c7346c11ebc76f23f01dce7469cc6d5926ae24c4a1da252d8ea507386531"}
    for p,expected_hash in preserved.items():
        if p not in sources or sha256(sources[p].replace("\r\n","\n").encode()).hexdigest()!=expected_hash:
            fail("Preserved observer/source bridge changed: "+p)
    def dump(node):
        try: return ast.dump(node,show_empty=True)
        except TypeError: return ast.dump(node)
    old=next(n for n in ast.walk(ast.parse(rebuilt)) if isinstance(n,ast.FunctionDef) and n.name=="handle_event")
    wrapper=next(n for n in ast.walk(ast.parse(sources["battle_core/trigger.py"])) if isinstance(n,ast.FunctionDef) and n.name=="handle_event")
    current_tree=ast.parse(sources["battle_core/trigger.py"])
    for name,expected_hash in {
        "_scope_key":"b82e647cb49355b9bfe3f4da7c16916149d3d6bf6709c7e861af0632967f434a",
        "execute_candidate":"f64265ca933a98e04e83efcb4bd87a4de4e2664dd0ca451372965dc028f130ab",
        "complete_formal_turn":"44267262f3d650ba97f4828b8aa957357d5ff042c2d094113c6a363d40978b24"}.items():
        method=next(n for n in ast.walk(current_tree) if isinstance(n,ast.FunctionDef) and n.name==name)
        if sha256(dump(method).encode()).hexdigest()!=expected_hash: fail("Protected stage AST changed: "+name)
    manager=next(n for n in current_tree.body if isinstance(n,ast.ClassDef) and n.name=="SpecialActionManager")
    if sha256(dump(manager).encode()).hexdigest()!="c68a9201841f8e205a5445358442c2a9b1b24f97b0777230538befe343aab510":
        fail("Protected queue/drain AST changed")
    expected=ast.parse("def handle_event(self, event_type: str, event: Mapping[str, Any], *, canonical_source_ref=None):\n"
        "    from .trigger_migration.opportunity_evaluation_executor import execute_trigger_opportunity_evaluation\n"
        "    return execute_trigger_opportunity_evaluation(self, event_type, event, canonical_source_ref=canonical_source_ref)\n").body[0]
    if dump(wrapper)!=dump(expected): fail("Non-exclusive wrapper/signature/fallback")
    tree=ast.parse(sources[path])
    helper=next(n for n in tree.body if isinstance(n,ast.FunctionDef))
    if dump(helper.args)!=dump(old.args): fail("Helper signature differs")
    imports=[n for n in ast.walk(helper) if isinstance(n,ast.ImportFrom)]
    if (len(imports)!=1 or imports[0].module!="source_ref" or imports[0].level!=1
            or [(a.name,a.asname) for a in imports[0].names]!=[("CanonicalTriggerSourceRef",None)]):
        fail("Unreviewed local import change")
    # Normalize this ONE module prefix only, never strip imports/control flow.
    imports[0].module="trigger_migration.source_ref"
    body_hash=sha256(dump(ast.Module(body=helper.body,type_ignores=[])).encode()).hexdigest()
    if body_hash!="286bcc40c0b41f2ae5260fc5cead95474f8c67fc88143238759789c9dd302d58":
        fail("Historical body/local import timing differs")
    reviewed={('__future__',0):('annotations',),('typing',0):('Any','Mapping'),
              ('trigger',2):('TriggerCandidate','TriggerRuntime')}
    for node in tree.body:
        if isinstance(node,ast.ImportFrom):
            if tuple(a.name for a in node.names)!=reviewed.get((node.module,node.level)) or any(a.asname for a in node.names):
                fail("Unreviewed helper module dependency")
        elif isinstance(node,ast.FunctionDef):
            if node.name!="execute_trigger_opportunity_evaluation" or node.decorator_list: fail("Alternate helper")
        elif isinstance(node,ast.Expr) and isinstance(node.value,ast.Constant) and isinstance(node.value.value,str): pass
        elif isinstance(node,ast.Assign) and isinstance(node.value,ast.Constant) and node.value.value=="TRIGGER_OPPORTUNITY_RUNTIME_ROUTE_MIGRATED_IN_WO110": pass
        else: fail("Import-time executable side effect")
    calls=[]; producers=[]; handler_calls=[]
    class Visitor(ast.NodeVisitor):
        def __init__(self,p): self.path,self.scope=p,[]
        def visit_ClassDef(self,n): self.scope.append(n.name); self.generic_visit(n); self.scope.pop()
        def visit_FunctionDef(self,n): self.scope.append(n.name); self.generic_visit(n); self.scope.pop()
        visit_AsyncFunctionDef=visit_FunctionDef
        def visit_ImportFrom(self,n):
            if (n.module and n.module.endswith("opportunity_evaluation_executor")) or any(
                    a.name in {"opportunity_evaluation_executor","execute_trigger_opportunity_evaluation"} for a in n.names):
                if (self.path,".".join(self.scope))!=("battle_core/trigger.py","TriggerEngine.handle_event"):
                    fail("Unreviewed evaluator import/consumer")
            if any(a.name in {"opportunity_evaluation_boundary","TriggerOpportunityEvaluationBoundary"} for a in n.names) or (
                    n.module and n.module.endswith("opportunity_evaluation_boundary")):
                fail("Production observation consumer")
        def visit_Import(self,n):
            if any(a.name.endswith(("opportunity_evaluation_executor","opportunity_evaluation_boundary")) for a in n.names):
                fail("Unreviewed module import")
        def visit_Call(self,n):
            name=_name(n.func); site=(self.path,".".join(self.scope),name)
            if name.rsplit(".",1)[-1]=="execute_trigger_opportunity_evaluation": calls.append(site)
            if name.rsplit(".",1)[-1]=="TriggerCandidate": producers.append(site)
            if name.endswith(".handle_event"): handler_calls.append(site)
            self.generic_visit(n)
    for p,source in sources.items():
        if p.startswith("battle_core/") and p.endswith(".py"): Visitor(p).visit(ast.parse(source))
    if calls!=[("battle_core/trigger.py","TriggerEngine.handle_event","execute_trigger_opportunity_evaluation")]: fail("Unknown/duplicate evaluator invocation")
    if producers!=[(path,"execute_trigger_opportunity_evaluation","TriggerCandidate")]: fail("Unknown candidate producer")
    expected_handlers=[
        ("battle_core/engine.py","BattleEngine._emit_action_complete_compat","self.inner_skills.handle_event"),
        ("battle_core/engine.py","BattleEngine._emit_action_complete_compat","self.triggers.handle_event"),
        ("battle_core/engine.py","BattleEngine._emit_combat_event","self.inner_skills.handle_event"),
        ("battle_core/engine.py","BattleEngine._emit_combat_event","self.triggers.handle_event"),
        ("battle_core/trigger_migration/chain_emission_bridge.py","CanonicalSpecialOutcomeChainEmission.dispatch","triggers.handle_event")]
    if sorted(handler_calls)!=expected_handlers: fail("Accepted source dispatch sites changed")
    audit_candidate_admission_boundary_sources(sources)
    audit_standard_special_execution_sources(sources)
    audit_action_complete_sources(sources)
    return freeze({"status":"PASS","scope":"PRE_QUEUE_TRIGGER_OPPORTUNITY_EVALUATION_AND_CANDIDATE_CREATION_ONLY",
        "opportunity_evaluation_production_migrated":True,"production_migrated":False,
        "production_helper_invocation_count":1,"candidate_producer_count":1,"accepted_source_dispatch_count":5,
        "historical_normalized_body_ast_sha256":body_hash,
        "limitations":"Bounded AST/import/call inventories and authenticated sources; not arbitrary dynamic aliases"})


def audit_trigger_opportunity_evaluation_boundary_sources(sources=None):
    """WO109 bounded read-only observer and immutable accepted WO108 stages."""
    from .model import TriggerMigrationError
    sources = load_sources() if sources is None else sources
    path = "battle_core/trigger_migration/opportunity_evaluation_boundary.py"
    protected = {
        "battle_core/trigger.py": "d4b8e2a07bd5eaeebb27e339da8ffe58591d1120aa5a4c038ebb231311bf4c46",
        "battle_core/engine.py": "ad9f4b8cdb2460ad2fc77214cfcc48a9e6281b9658a0766dc2f71c9da6c923c4",
        "battle_core/special/standard_executor.py": "f0804ec741b7a0e40df09fc612a91302180c2f4d90d0168dcbea48787f1d7d9f",
        "battle_core/trigger_migration/candidate_admission_executor.py": "5dfb3af20d427416547f1ba0a3fb9eef26f3574dc3f8ca91fd63228abea2b885",
        "battle_core/trigger_migration/candidate_admission_boundary.py": "8fa6595376aa15d5a2bd98662ed77d0eeb902799bb67c22642d60f30ab74853f",
        "battle_core/trigger_migration/standard_executor_boundary.py": "c9dbdc063f9a324e1ea29cae2e288b4b38a68869925509f30fb6813288652bf2",
        "battle_core/trigger_migration/action_outcome_bridge.py": "4522aab49ee5449d5a130cf07d0650a803a1db2d1abd66a808593cc50e1bb020",
        "battle_core/trigger_migration/parry_bridge.py": "ae33cbfc658c184ec6c5a3c2a045bfcce7bb454e6a05a06e7a69c7ff30792606",
        "battle_core/trigger_migration/chain_emission_bridge.py": "fed13020c0275722398f340ae3c3da064f7c40077bbe142d94a919ad6a33c2e6",
        "battle_core/trigger_migration/source_ref.py": "e3b4c7346c11ebc76f23f01dce7469cc6d5926ae24c4a1da252d8ea507386531"
    }
    stage_hashes = {
        "handle_event": "530a7a9c9beef14758f4981076033309bcaed2320cb4bb17d5ff32d0574f2fa4",
        "_scope_key": "b82e647cb49355b9bfe3f4da7c16916149d3d6bf6709c7e861af0632967f434a",
        "execute_candidate": "f64265ca933a98e04e83efcb4bd87a4de4e2664dd0ca451372965dc028f130ab",
        "complete_formal_turn": "44267262f3d650ba97f4828b8aa957357d5ff042c2d094113c6a363d40978b24"
    }
    def fail(detail):
        raise TriggerMigrationError("WO109_OPPORTUNITY_OBSERVATION_VIOLATION: " + detail)
    # Keep WO109's original historical assertions. Only the independently
    # authenticated WO110 wrapper/helper can reconstruct that accepted source.
    audit_trigger_opportunity_runtime_sources(sources)
    reconstructed=_reconstruct_wo109_opportunity_source(sources)
    for p,expected in protected.items():
        source=reconstructed if p=="battle_core/trigger.py" else sources.get(p,"")
        if p not in sources or sha256(source.replace("\r\n","\n").encode()).hexdigest()!=expected:
            fail("Protected accepted source changed: " + p)
    tree = ast.parse(reconstructed)
    def ast_hash(node):
        try: dumped=ast.dump(node,show_empty=True)
        except TypeError: dumped=ast.dump(node)
        return sha256(dumped.encode()).hexdigest()
    for name,expected in stage_hashes.items():
        method=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name==name)
        if ast_hash(method)!=expected: fail("Accepted stage AST changed: " + name)
    manager=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=="SpecialActionManager")
    if ast_hash(manager)!="c68a9201841f8e205a5445358442c2a9b1b24f97b0777230538befe343aab510": fail("Queue/drain AST changed")
    if path not in sources: fail("Missing detached opportunity observer")
    reviewed_imports = {
        ("dataclasses",0): {"dataclass","field"},
        ("trigger",2): {"TriggerDefinition"},
        ("model",1): {"Document","OrdinarySpecialActionDescriptor","TriggerMigrationError","_identity","_booleans","_metadata"},
    }
    pure_calls = {"dataclass","field","type","float","bool","any","getattr","cls",
        "_literal_probability","_identity","_booleans","_metadata","TriggerMigrationError",
        "object.__setattr__","OrdinarySpecialActionDescriptor.from_template"}
    live_names = {"engine","owner","context","rng","store","candidate","snapshot","callback"}
    definition_fields = {"id","owner_id","source_martial_id","martial_event_kind","event_type","scope",
        "priority","enabled","base_probability","counts_ordinary_budget","action_template",
        "condition","attempt_settler","probability_resolver","coefficient_resolver","commit_settler"}
    for p,source in sources.items():
        if not p.startswith("battle_core/") or not p.endswith(".py"): continue
        for node in ast.walk(ast.parse(source)):
            if p==path:
                if isinstance(node,ast.Import): fail("Unreviewed observer import")
                if isinstance(node,ast.ImportFrom):
                    allowed=reviewed_imports.get((node.module,node.level),set())
                    if any(a.name not in allowed or a.asname is not None for a in node.names):
                        fail("Unreviewed observer dependency")
                if isinstance(node,ast.Call) and _name(node.func) not in pure_calls:
                    fail("Unreviewed gameplay/callback/lookup call in observer")
                if isinstance(node,ast.Name) and (node.id in live_names or node.id=="event" and isinstance(node.ctx,ast.Load)):
                    fail("Live gameplay/event access in observer")
                if isinstance(node,ast.arg) and node.arg in live_names|{"event"}:
                    fail("Live gameplay argument in observer")
                if isinstance(node,ast.Attribute):
                    name=_name(node)
                    if name.startswith("definition.") and name.split(".")[1] not in definition_fields:
                        fail("Unreviewed live definition access")
            elif ((isinstance(node,ast.ImportFrom) and (
                    node.module and node.module.endswith("opportunity_evaluation_boundary") or any(
                        a.name in {"opportunity_evaluation_boundary","TriggerOpportunityEvaluationBoundary"} for a in node.names)))
                  or isinstance(node,ast.Import) and any(a.name.endswith("opportunity_evaluation_boundary") for a in node.names)):
                fail("Production consumer of read-only opportunity observer")
    # Preserve rather than replace all earlier admission/source gate evidence.
    audit_candidate_admission_boundary_sources(sources)
    audit_action_complete_sources(sources)
    return freeze({"status":"PASS","scope":"PRE_QUEUE_TRIGGER_OPPORTUNITY_EVALUATION_AND_CANDIDATE_CREATION_ONLY",
        "production_consumer_count":0,"production_migrated":False,"protected_source_count":len(protected),
        "limitations":"Bounded reviewed AST/import/call sites and fingerprints; not arbitrary dynamic Python aliases"})


def audit_candidate_admission_runtime_sources(sources=None):
    """WO108 exclusive production ingress and authenticated mechanical body."""
    from .model import TriggerMigrationError
    sources = load_sources() if sources is None else sources
    path = "battle_core/trigger_migration/candidate_admission_executor.py"
    def fail(detail):
        raise TriggerMigrationError("WO108_ADMISSION_RUNTIME_VIOLATION: " + detail)
    for p in ("battle_core/trigger.py", path):
        if p not in sources or sha256(sources[p].replace("\r\n","\n").encode()).hexdigest() != PROTECTED_FILES[p]:
            fail("Authenticated migration source changed: " + p)
    tree = ast.parse(sources["battle_core/trigger.py"])
    wrapper = next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=="execute_candidate")
    expected = ast.parse("def execute_candidate(self, candidate: TriggerCandidate):\n"
        "    from .trigger_migration.candidate_admission_executor import execute_candidate_admission\n"
        "    return execute_candidate_admission(self, candidate)\n").body[0]
    if ast.dump(wrapper) != ast.dump(expected): fail("Inline fallback/duplicate/non-exclusive wrapper")
    helper = next(n for n in ast.parse(sources[path]).body if isinstance(n,ast.FunctionDef))
    # Python 3.13 defaults to omitting empty AST fields; keep the exact
    # full-field representation authenticated at checkpoint A on Python 3.12.
    body = ast.Module(body=helper.body,type_ignores=[])
    try: body_dump = ast.dump(body,show_empty=True)
    except TypeError: body_dump = ast.dump(body)  # Python 3.12 always includes them.
    body_hash = sha256(body_dump.encode()).hexdigest()
    if body_hash != "2ec4f7863b6502ab9ad03a0c0b3db9553cfd0f800ea786be0d1c1329e7a632a1":
        fail("Accepted WO107 body AST changed")
    entries = []
    class Visitor(ast.NodeVisitor):
        def __init__(self,p): self.path,self.scope=p,[]
        def visit_ClassDef(self,n):
            self.scope.append(n.name); self.generic_visit(n); self.scope.pop()
        def visit_FunctionDef(self,n):
            self.scope.append(n.name); self.generic_visit(n); self.scope.pop()
        visit_AsyncFunctionDef = visit_FunctionDef
        def visit_ImportFrom(self,n):
            if (n.module and n.module.endswith("candidate_admission_executor")) or any(
                    x.name in {"candidate_admission_executor","execute_candidate_admission"} for x in n.names):
                if (self.path,".".join(self.scope)) != ("battle_core/trigger.py","TriggerEngine.execute_candidate"):
                    fail("Unreviewed admission consumer/import")
            self.generic_visit(n)
        def visit_Import(self,n):
            if any(x.name.endswith("candidate_admission_executor") for x in n.names):
                fail("Unreviewed admission module import")
        def visit_Call(self,n):
            name = _name(n.func)
            if name.rsplit(".",1)[-1] == "execute_candidate_admission":
                site = (self.path,".".join(self.scope),name)
                if site != ("battle_core/trigger.py","TriggerEngine.execute_candidate","execute_candidate_admission"):
                    fail("Unreviewed direct admission entry")
                entries.append(site)
            self.generic_visit(n)
    for p,source in sources.items():
        if p.startswith("battle_core/") and p.endswith(".py"): Visitor(p).visit(ast.parse(source))
    if len(entries)!=1: fail("Missing/duplicate admission ingress")
    return freeze({"status":"PASS","scope":"POST_DEQUEUE_CANDIDATE_EXECUTION_ADMISSION_ONLY",
        "candidate_admission_production_migrated":True,"production_migrated":False,
        "admission_ingress_count":1,"historical_body_ast_sha256":body_hash,
        "limitations":"Bounded AST/fingerprints; not arbitrary dynamic Python aliases"})


def audit_standard_special_execution_sources(sources=None):
    """WO106 one standard ingress, unchanged custom branch, reviewed Attack sites."""
    from .model import TriggerMigrationError
    sources = load_sources() if sources is None else sources
    helper_path = "battle_core/special/standard_executor.py"
    allowed_attacks = {
        ("battle_core/engine.py", "BattleEngine._formal_turn"),
        ("battle_core/engine.py", "BattleEngine.settle_action"),
        ("battle_core/composite.py", "CompositeActionExecutor._execute_stage"),
        (helper_path, "execute_standard_special"),
    }
    def fail(detail):
        raise TriggerMigrationError("WO106_STANDARD_EXECUTION_ROUTE_VIOLATION: " + detail)
    if helper_path not in sources or sha256(sources[helper_path].replace("\r\n", "\n").encode()).hexdigest() != PROTECTED_FILES[helper_path]:
        fail("Standard component fingerprint mismatch")
    attacks, entries = [], []
    class Visitor(ast.NodeVisitor):
        def __init__(self, path): self.path, self.scope = path, []
        def visit_ClassDef(self, node):
            self.scope.append(node.name); self.generic_visit(node); self.scope.pop()
        def visit_FunctionDef(self, node):
            self.scope.append(node.name); self.generic_visit(node); self.scope.pop()
        visit_AsyncFunctionDef = visit_FunctionDef
        def visit_Call(self, node):
            name = _name(node.func)
            site = self.path, ".".join(self.scope)
            if name.endswith("._resolve_attack"):
                if site not in allowed_attacks: fail("Unreviewed Attack call: " + str(site))
                attacks.append(site)
            if name.rsplit(".", 1)[-1] == "execute_standard_special":
                if site != ("battle_core/engine.py", "BattleEngine._execute_special_action"):
                    fail("Unreviewed standard execution entry")
                entries.append(site)
            self.generic_visit(node)
    for path, source in sources.items():
        if path.startswith("battle_core/") and path.endswith(".py"):
            Visitor(path).visit(ast.parse(source))
    if len(entries) != 1 or len(attacks) != len(allowed_attacks) or set(attacks) != allowed_attacks:
        fail("Missing/duplicate standard or Attack ingress")
    method = next(n for n in ast.walk(ast.parse(sources["battle_core/engine.py"]))
                  if isinstance(n, ast.FunctionDef) and n.name == "_execute_special_action")
    branches = [n for n in ast.walk(method) if isinstance(n, ast.If)
                and ast.unparse(n.test) == "template.executor is not None"]
    if len(branches) != 1: fail("Missing custom/standard branch")
    branch = branches[0]
    expected_custom = ast.parse("template.executor(self, owner, candidate.event)").body
    expected_standard = ast.parse(
        "from .special.standard_executor import execute_standard_special\n"
        "target = execute_standard_special(self, candidate, owner, template, action_id, context)").body
    dump = lambda nodes: ast.dump(ast.Module(body=nodes, type_ignores=[]), include_attributes=False)
    if dump(branch.body) != dump(expected_custom) or dump(branch.orelse) != dump(expected_standard):
        fail("Custom changed, inline fallback, or non-exclusive standard branch")
    audit_standard_executor_boundary_sources(sources)
    return freeze({"status": "PASS", "scope": "STANDARD_NON_CUSTOM_EXECUTION_ONLY",
                   "production_entry_count": 1, "reviewed_attack_site_count": len(attacks),
                   "limitations": "Bounded AST sites and pinned component; not arbitrary dynamic aliases"})


def audit_registration_sources(sources=None):
    sources = load_sources() if sources is None else sources
    if not isinstance(sources, Mapping):
        _unclassified("Repository-relative source mapping required")
    selected = {}
    for path, text in sources.items():
        if type(path) is not str or type(text) is not str or "\\" in path or ".." in path.split("/"):
            _unclassified("Invalid source snapshot path/text")
        if path.startswith("battle_core/") and path.endswith(".py"):
            selected[path] = text.replace("\r\n", "\n")
    sites, methods = [], {}
    for path in sorted(selected):
        try:
            tree = ast.parse(selected[path], filename=path)
        except SyntaxError:
            _unclassified("Invalid Python source: " + path)
        facts = _RegistrationFacts(path, selected[path])
        facts.visit(tree)
        sites.extend(facts.calls)
        if path == "battle_core/engine.py":
            methods = facts.methods
    for path, expected in PROTECTED_FILES.items():
        if path not in selected or sha256(selected[path].encode("utf-8")).hexdigest() != expected:
            _unclassified("Reviewed source changed/missing: " + path)
    for name, expected in PROTECTED_ENGINE_METHODS.items():
        text = "\n".join(line.rstrip() for line in methods.get(name, "").splitlines()).strip()
        if sha256(text.encode("utf-8")).hexdigest() != expected:
            _unclassified("Reviewed Engine method changed/missing: " + name)
    registered = [r for r in sites if r["call"] == "self.engine.triggers.register"]
    if len(registered) != len(REGISTRATION_MECHANICS):
        _unclassified("Reviewed Martial registration branch coverage changed")
    digest = {p: sha256(selected[p].encode("utf-8")).hexdigest() for p in sorted(selected)}
    return freeze({"status": "PASS", "scope": "BOUNDED_AST_SITES_AND_REVIEWED_SOURCE_FINGERPRINTS",
                   "limitations": "No proof of arbitrary dynamic alias/generated Python behavior",
                   "registration_sites": sites, "martial_registration_branch_count": len(registered),
                   "generated_compiler_included": True,
                   "source_snapshot_sha256": sha256(canonical_json(digest).encode("utf-8")).hexdigest(),
                   "excluded_paths": "tests/**, demos and tools outside battle_core"})


def audit_runtime(runtime, *, sources=None):
    registry = compile_registry(runtime)
    static = audit_registration_sources(sources)
    action_sources = audit_action_complete_sources(sources)
    declared = []
    actual = {(b.owner_id, b.trigger_id) for b in registry.bindings}
    for owner, martial in sorted(runtime.martials.equipped.items()):
        for passive in sorted(martial.passives, key=lambda p: p.id):
            if passive.mechanic in REGISTRATION_MECHANICS:
                declared.append({
                    "owner_id": owner, "source_content_id": martial.id,
                    "source_item_id": passive.id, "source_mechanic": passive.mechanic,
                    "live_registration_present": (owner, passive.id) in actual,
                    "explicit_content_markers": content_markers((
                        passive.parameters, martial.unresolved_fields,
                        martial.validation_information, martial.active_skill.tuning_placeholder)),
                    "unresolved_fields": martial.unresolved_fields,
                    "blocked_spec_fields": martial.blocked_spec_fields,
                    "validation_information": martial.validation_information,
                    "authority_promoted": False})
    transformations = []
    for modifier in tuple(runtime.triggers.counter_targeting_transformations):
        if type(modifier) is not CounterTargetingTransformationDefinition or modifier.creates_counter is not False:
            _unclassified("Counter targeting modifier may not create a candidate")
        transformations.append(asdict(modifier))
    queued = tuple(LegacyTriggerCandidateSnapshot.from_candidate(c).to_dict()
                   for c in tuple(runtime.triggers.special_actions._queue))
    callback_fields = ("has_condition", "has_probability_resolver", "has_attempt_settler",
                       "has_commit_settler", "has_coefficient_resolver")
    counts = {name: sum(b.metadata["opportunity"][name] for b in registry.bindings)
              for name in callback_fields}
    counts["has_custom_executor"] = sum(b.action_descriptor.has_custom_executor for b in registry.bindings)
    return freeze({
        "runtime_contract": "WO097", "production_migrated": False,
        "registry": registry.to_dict(), "static_registration_audit": export(static),
        "action_complete_source_audit": export(action_sources),
        "source_route_counts": registry.source_route_counts(),
        "registration_inventory": export(registration_inventory()),
        "source_event_readiness": export(SOURCE_EVENT_READINESS),
        "semantic_coverage_required": SEMANTIC_COVERAGE_REQUIRED,
        "presentation_authority": PRESENTATION_EVENTS_ARE_NOT_TRIGGER_AUTHORITY,
        "wo088_firewall": WO088_POST_SETTLEMENT_QUEUE_NOT_GENERAL_TRIGGER_QUEUE,
        "declared_content_registrations": declared, "callback_flag_counts": counts,
        "selector_inventory": sorted({b.action_descriptor.target_selector for b in registry.bindings}),
        "pattern_inventory": sorted({b.action_descriptor.targeting_pattern for b in registry.bindings}),
        "target_count_inventory": sorted({b.action_descriptor.requested_target_count for b in registry.bindings
                                          if b.action_descriptor.requested_target_count is not None}),
        "counter_targeting_modifier_contract": {
            "role": "MODIFIER_ONLY_NOT_CANDIDATE_CREATION", "creates_counter": False,
            "observed_modifiers": sorted(transformations, key=lambda d: (d["owner_id"], d["id"]))},
        "queued_candidate_snapshots": queued, "queue_order_compatibility": export(QUEUE_COMPATIBILITY),
        "special_execution_observed_order": [
            "ALLOCATE_SPECIAL_ID_UNDER_EXISTING_FORMAL_TURN", "COUNTS_AS_TURN_FALSE",
            "CUSTOM_EXECUTOR_OR_TARGET_RESOLUTION", "OFFENSIVE_SNAPSHOT",
            "COMMIT_SETTLER_IF_PRESENT", "CANONICAL_ATTACK_PER_LEGAL_TARGET",
            "FINALIZE_ACTION_OUTCOME", "LEGACY_ACTION_COMPLETE_AND_POSSIBLE_NEW_OPPORTUNITY",
            "NO_GLOBAL_COOLDOWN_TICK"],
    })

# Source migration is separate from registration/queue classification.
ACTION_COMPLETE_SITES = frozenset({
    ("battle_core/engine.py","BattleEngine._formal_turn"),
    ("battle_core/engine.py","BattleEngine._execute_special_action"),
    ("battle_core/composite.py","CompositeActionExecutor.execute"),
})
SMOKE_FIXTURE_PATH = "battle_core/revision_2_canonical_promotion.py"
SMOKE_FIXTURE_SHA256 = "751e7659c12abdf42887eadd9aa1ca0522c4b7a5221b325553a351d7e53f17fe"

def audit_action_complete_sources(sources=None):
    from .action_outcome_bridge import UNMIGRATED, CanonicalActionOutcomeSourceError
    sources = load_sources() if sources is None else sources
    found, fixtures, dispatches = [], [], []
    def fail(detail):
        raise CanonicalActionOutcomeSourceError(UNMIGRATED + ": " + detail)
    class Visitor(ast.NodeVisitor):
        def __init__(self,path):
            self.path=path;self.scope=[];self.producers=set()
        def visit_ClassDef(self,node):
            self.scope.append(node.name);self.generic_visit(node);self.scope.pop()
        def visit_FunctionDef(self,node):
            self.scope.append(node.name)
            owner=".".join(self.scope)
            if any(isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="outcome_fact" for t in x.targets)
                   and isinstance(x.value,ast.Call) and _name(x.value.func).endswith("._append_action_outcome_fact")
                   for x in ast.walk(node)):
                self.producers.add(owner)
            self.generic_visit(node);self.scope.pop()
        visit_AsyncFunctionDef=visit_FunctionDef
        def visit_Call(self,node):
            name=_name(node.func);owner=".".join(self.scope);key=(self.path,owner)
            arg=node.args[0] if node.args else None
            literal=arg.value if isinstance(arg,ast.Constant) else None
            if name.endswith("._emit_action_complete_compat"):
                if key not in ACTION_COMPLETE_SITES or owner not in self.producers or not isinstance(arg,ast.Name) or arg.id!="outcome_fact":
                    fail(self.path+":"+owner)
                found.append({"path":self.path,"owner":owner,"line":node.lineno})
            if name.endswith("._emit_combat_event") and (literal=="ACTION_COMPLETE" or not isinstance(arg,ast.Constant)):
                if (key==(SMOKE_FIXTURE_PATH,"run_revision_2_smoke") and literal=="ACTION_COMPLETE"
                    and sha256(sources[self.path].replace("\r\n","\n").encode("utf-8")).hexdigest()==SMOKE_FIXTURE_SHA256):
                    fixtures.append({"path":self.path,"owner":owner,"line":node.lineno,
                                     "role":"ISOLATED_SYNTHETIC_SMOKE_FIXTURE_NOT_PRODUCTION_ACTION"})
                else:
                    fail(self.path+":"+owner)
            if name.endswith(".handle_event") and literal=="ACTION_COMPLETE":
                allowed = {
                    ("battle_core/engine.py", "BattleEngine._emit_action_complete_compat", "self.triggers.handle_event"),
                    ("battle_core/engine.py", "BattleEngine._emit_action_complete_compat", "self.inner_skills.handle_event"),
                    ("battle_core/trigger_migration/chain_emission_bridge.py", "CanonicalSpecialOutcomeChainEmission.dispatch", "triggers.handle_event"),
                }
                if (*key, name) not in allowed:
                    fail(self.path+":"+owner)
                dispatches.append(name)
            self.generic_visit(node)
    for path in sorted(sources):
        if path.startswith("battle_core/") and path.endswith(".py"):
            Visitor(path).visit(ast.parse(sources[path],filename=path))
    if {(s["path"],s["owner"]) for s in found}!=ACTION_COMPLETE_SITES or len(found)!=3:
        fail("Missing/duplicate production source site")
    if sorted(dispatches)!=["self.inner_skills.handle_event","self.triggers.handle_event","triggers.handle_event"]:
        fail("Canonical gate dispatch coverage changed")
    # The Special path must validate before log/dispatch; the formal dispatch is
    # exclusively the else branch, so one outcome cannot visit both matchers.
    tree = ast.parse(sources["battle_core/engine.py"])
    method = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)
                  and n.name == "_emit_action_complete_compat")
    calls = [n for n in ast.walk(method) if isinstance(n, ast.Call)]
    if (sum(_name(n.func) == "CanonicalSpecialOutcomeChainEmission.from_fact" for n in calls) != 1
            or sum(_name(n.func) == "chain_emission.dispatch" for n in calls) != 1):
        fail("Missing/duplicate Special chain ingress")
    route = [n for n in method.body if isinstance(n, ast.If)
             and ast.unparse(n.test) == "chain_emission is not None"]
    if (len(route) != 1
            or len(route[0].body) != 1 or len(route[0].orelse) != 1
            or not isinstance(route[0].body[0], ast.Expr)
            or not isinstance(route[0].orelse[0], ast.Expr)
            or _name(route[0].body[0].value.func) != "chain_emission.dispatch"
            or _name(route[0].orelse[0].value.func) != "self.triggers.handle_event"):
        fail("Special/formal dispatch must be mutually exclusive")
    if len(fixtures)!=1:
        fail("Reviewed isolated fixture fingerprint/site changed")
    return freeze({"status":"PASS","production_source_sites":found,
                   "isolated_fixture_exceptions":fixtures,
                   "new_opportunities_created":False,
                   "limitations":"Bounded AST sites plus reviewed source fingerprints; not arbitrary dynamic aliases"})


# WO112 source authentication precedes EVERY older whole-trigger proof. This
# reconstruction never accepts arbitrary old-or-new source alternatives.
QUEUE_RUNTIME_PATH = "battle_core/trigger_migration/queue_drain_executor.py"
QUEUE_TRIGGER_SHA = "e3e668bb05cfe1116e4ca606e365b2ddc161025e97a1f82c411fb784de47d300"
QUEUE_HELPER_SHA = "068511a0d910aa139e47c0c4edda9f647a58ddc1bfd6a38217219b4db6cc8c08"


def reconstruct_wo111_queue_source(sources):
    """Authenticate new files; mechanically restore ONLY the two old methods."""
    from hashlib import sha1
    from .model import TriggerMigrationError
    def fail(detail): raise TriggerMigrationError("WO112_AUTHENTICATED_QUEUE_SOURCE: " + detail)
    for path, expected in (("battle_core/trigger.py", QUEUE_TRIGGER_SHA), (QUEUE_RUNTIME_PATH, QUEUE_HELPER_SHA)):
        if path not in sources or sha256(sources[path].replace("\r\n", "\n").encode()).hexdigest() != expected:
            fail("Unknown current source: " + path)
    source = sources["battle_core/trigger.py"].replace("\r\n", "\n")
    helper_source = sources[QUEUE_RUNTIME_PATH].replace("\r\n", "\n")
    tree = ast.parse(source)
    classes = [n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "SpecialActionManager"]
    if len(classes) != 1: fail("Unique real manager required")
    methods = {n.name:n for n in classes[0].body if isinstance(n, ast.FunctionDef)}
    helpers = {n.name:n for n in ast.parse(helper_source).body if isinstance(n, ast.FunctionDef)}
    def dump(node):
        try: return ast.dump(node, show_empty=True)
        except TypeError: return ast.dump(node)
    rebuilt = source
    for name, internal, args, method_sha in (
        ("queue", "enqueue_special_candidate", "self, candidate: TriggerCandidate", "7c210bbe8f0a628c8dbaac4f0bb078c8131f72532335dbfc522ebbf038040e01"),
        ("drain", "drain_special_candidates", "self", "7333e0f5a77ce38dafc533b6c1e58ba7fe4110f3f5c4fca21102095a66be212c")):
        call_args = "self, candidate" if name == "queue" else "self"
        expected = ast.parse(f"def {name}({args}):\n    from .trigger_migration.queue_drain_executor import {internal}\n    return {internal}({call_args})\n").body[0]
        if name not in methods or dump(methods[name]) != dump(expected): fail("Non-exclusive public wrapper")
        helper = helpers.get(internal)
        if helper is None or helper.decorator_list: fail("Missing/alternate helper")
        # Original self name is retained: only header and enclosing indentation
        # differ. No body node, import, expression or statement is normalized.
        lines = ast.get_source_segment(helper_source, helper).splitlines()
        old = f"def {name}({args}):\n" + "\n".join("    " + line if line else line for line in lines[1:])
        if sha256(dump(ast.parse(old).body[0]).encode()).hexdigest() != method_sha:
            fail("Helper body is not accepted historical method")
        rebuilt = rebuilt.replace(ast.get_source_segment(source, methods[name]), old)
    data = rebuilt.encode()
    if (sha256(data).hexdigest() != "af6947162a76451fa574d5cdead97d8bd6140bf7df3cbced0e7ce3729dfd6f72" or
        sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest() != "a6357704729daad2c6852acd74cd3725e82e9ee9"):
        fail("Whole historical source/Git blob not restored")
    # The module's exact fingerprint also authenticates its docstring, literal
    # marker and exactly TWO functions: no import-time code or hidden dependency.
    return rebuilt


def _queue_runtime_snapshot(sources):
    """Validate actual helper consumers before exposing a historical audit view."""
    from .model import TriggerMigrationError
    rebuilt = reconstruct_wo111_queue_source(sources)
    observer = "battle_core/trigger_migration/queue_drain_boundary.py"
    if observer not in sources or sha256(sources[observer].replace("\r\n", "\n").encode()).hexdigest() != "30d3d4dafe3e23d283ef5212cb72b1a3da631740000252f7474c61a14e226a19":
        raise TriggerMigrationError("WO112 historical WO111 observer source changed")
    expected = {"enqueue_special_candidate": "SpecialActionManager.queue", "drain_special_candidates": "SpecialActionManager.drain"}
    calls, imports = [], []
    class Visitor(ast.NodeVisitor):
        def __init__(self, path): self.path, self.scope = path, []
        def visit_ClassDef(self, n): self.scope.append(n.name); self.generic_visit(n); self.scope.pop()
        def visit_FunctionDef(self, n): self.scope.append(n.name); self.generic_visit(n); self.scope.pop()
        visit_AsyncFunctionDef = visit_FunctionDef
        def visit_ImportFrom(self, n):
            if (n.module and n.module.endswith("queue_drain_executor")) or any(a.name in {*expected, "queue_drain_executor"} for a in n.names):
                imports.append((self.path, ".".join(self.scope), n.module, n.level, tuple((a.name, a.asname) for a in n.names)))
        def visit_Import(self, n):
            if any(a.name.endswith("queue_drain_executor") for a in n.names):
                raise TriggerMigrationError("WO112 unreviewed helper module import")
        def visit_Call(self, n):
            name = _name(n.func).rsplit(".", 1)[-1]
            if name in expected: calls.append((self.path, ".".join(self.scope), name))
            self.generic_visit(n)
    for path, text in sources.items():
        if path.startswith("battle_core/") and path.endswith(".py"): Visitor(path).visit(ast.parse(text))
    if (sorted(calls) != sorted(("battle_core/trigger.py", scope, name) for name, scope in expected.items()) or
        sorted(imports) != sorted(("battle_core/trigger.py", scope, "trigger_migration.queue_drain_executor", 1, ((name, None),)) for name, scope in expected.items())):
        raise TriggerMigrationError("WO112 unknown/duplicate helper consumer")
    view = dict(sources)
    view["battle_core/trigger.py"] = rebuilt
    del view[QUEUE_RUNTIME_PATH]
    return view


class _AuthenticatedQueueHistory(dict):
    """Internal view authenticated at construction; immutable backing snapshot."""
    def __init__(self, original):
        from types import MappingProxyType
        # WO114: certify the actual Custom route before any older engine view.
        self.custom_history = _verified_custom_history(original)
        original = self.custom_history
        original = dict(original)
        view = _queue_runtime_snapshot(original)
        super().__init__(view)
        self.original = MappingProxyType(original)
        self.expected = MappingProxyType(view)


def _verified_queue_history(sources):
    from .model import TriggerMigrationError
    if type(sources) is _AuthenticatedQueueHistory:
        if dict(sources) != sources.expected: raise TriggerMigrationError("WO112 historical audit view tampered")
        return sources
    original = load_sources() if sources is None else sources
    return _AuthenticatedQueueHistory(original)


def _authenticated_queue_history_audit(function):
    """Retain every prior assertion and digest on strictly reconstructed sources."""
    from functools import wraps
    @wraps(function)
    def reviewed(sources=None):
        return function(_verified_queue_history(sources))
    return reviewed


# Prior audits still inspect ALL unknown files/callers/writers. Only the two
# authenticated relocated bodies are projected back to their original sites.
audit_registration_sources = _authenticated_queue_history_audit(audit_registration_sources)
audit_candidate_admission_boundary_sources = _authenticated_queue_history_audit(audit_candidate_admission_boundary_sources)
audit_special_queue_drain_boundary_sources = _authenticated_queue_history_audit(audit_special_queue_drain_boundary_sources)
audit_trigger_opportunity_runtime_sources = _authenticated_queue_history_audit(audit_trigger_opportunity_runtime_sources)
audit_trigger_opportunity_evaluation_boundary_sources = _authenticated_queue_history_audit(audit_trigger_opportunity_evaluation_boundary_sources)
audit_candidate_admission_runtime_sources = _authenticated_queue_history_audit(audit_candidate_admission_runtime_sources)


def audit_special_queue_drain_runtime_sources(sources=None):
    """Exact current route + all preserved historical queue/source firewalls."""
    sources = load_sources() if sources is None else sources
    view = _verified_queue_history(sources)
    historical = audit_special_queue_drain_boundary_sources(view)
    audit_trigger_opportunity_runtime_sources(view)
    return freeze({"status": "PASS", "queue_drain_production_migrated": True,
        "production_migrated": False, "migration_ready": False,
        "ordering_policy_canon_approved": False, "production_helper_invocation_count": 2,
        "manager_producer_count": historical["manager_producer_count"],
        "historical_source_sha256": "af6947162a76451fa574d5cdead97d8bd6140bf7df3cbced0e7ce3729dfd6f72",
        "limitations": "Exact sources and bounded AST/import/call/write inventory; not arbitrary Python dynamic aliases or monkeypatched imports"})



def audit_custom_special_executor_boundary_sources(sources=None):
    """WO113 exact live Custom branch and detached-observer source firewall."""
    from hashlib import sha1
    from .model import TriggerMigrationError
    sources=load_sources() if sources is None else sources
    path="battle_core/trigger_migration/custom_executor_boundary.py"
    protected={
            "battle_core/composite.py": "f0f38b603fa2b90fe43469f28fccf7da3c82043727f85f1333a3e240acaf03a0",
            "battle_core/engine.py": "ad9f4b8cdb2460ad2fc77214cfcc48a9e6281b9658a0766dc2f71c9da6c923c4",
            "battle_core/generated_special_compiler.py": "1234effc510c6074578b88c014555c29381b3ff4d59e179c277916c2d0c5ec98",
            "battle_core/martial.py": "19e2dd07754f423ae4697bf19fb1b1c0be829bcc5d23e38396ed7f3e3b88835d",
            "battle_core/special/standard_executor.py": "f0804ec741b7a0e40df09fc612a91302180c2f4d90d0168dcbea48787f1d7d9f",
            "battle_core/targeting.py": "adb65dfedbfe589f54e8c23bea6ca799591cb5fa743ac70b2c5454de79f941e7",
            "battle_core/trigger.py": "e3e668bb05cfe1116e4ca606e365b2ddc161025e97a1f82c411fb784de47d300",
            "battle_core/trigger_migration/action_outcome_bridge.py": "4522aab49ee5449d5a130cf07d0650a803a1db2d1abd66a808593cc50e1bb020",
            "battle_core/trigger_migration/candidate_admission_boundary.py": "8fa6595376aa15d5a2bd98662ed77d0eeb902799bb67c22642d60f30ab74853f",
            "battle_core/trigger_migration/candidate_admission_executor.py": "5dfb3af20d427416547f1ba0a3fb9eef26f3574dc3f8ca91fd63228abea2b885",
            "battle_core/trigger_migration/chain_emission_bridge.py": "fed13020c0275722398f340ae3c3da064f7c40077bbe142d94a919ad6a33c2e6",
            "battle_core/trigger_migration/opportunity_evaluation_boundary.py": "67115a0a892565d2daccf4e4e49f16f4b14fe3ce14d8debcc5aa80d762b2db3c",
            "battle_core/trigger_migration/opportunity_evaluation_executor.py": "522853f0dcffcb5cb4053308e48b7d1f6794f86e797531ce66237665e9336e6f",
            "battle_core/trigger_migration/parry_bridge.py": "ae33cbfc658c184ec6c5a3c2a045bfcce7bb454e6a05a06e7a69c7ff30792606",
            "battle_core/trigger_migration/queue_drain_boundary.py": "30d3d4dafe3e23d283ef5212cb72b1a3da631740000252f7474c61a14e226a19",
            "battle_core/trigger_migration/queue_drain_executor.py": "068511a0d910aa139e47c0c4edda9f647a58ddc1bfd6a38217219b4db6cc8c08",
            "battle_core/trigger_migration/source_ref.py": "e3b4c7346c11ebc76f23f01dce7469cc6d5926ae24c4a1da252d8ea507386531",
            "battle_core/trigger_migration/standard_executor_boundary.py": "c9dbdc063f9a324e1ea29cae2e288b4b38a68869925509f30fb6813288652bf2"
    }
    def fail(detail): raise TriggerMigrationError("WO113_CUSTOM_OBSERVATION_VIOLATION: "+detail)
    for p,expected in protected.items():
        if p not in sources or sha256(sources[p].replace("\r\n","\n").encode()).hexdigest()!=expected:
            fail("Protected exact runtime/source changed: "+p)
    if path not in sources or sha256(sources[path].replace("\r\n","\n").encode()).hexdigest()!="8008dbce77c9f96ccef7f7e69ff3cb3fc14fa67dc4878020cbf11d964ee6e5a3":
        fail("Detached observer exact source changed")
    source=sources["battle_core/engine.py"].replace("\r\n","\n");data=source.encode()
    if sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()!="8ab11da19b27691fd9bb26c00b1a5b9edfdfe8b6":
        fail("Accepted engine Git blob changed")
    def dump(node):
        try: return ast.dump(node,show_empty=True)
        except TypeError: return ast.dump(node)
    tree=ast.parse(source)
    if sha256(dump(tree).encode()).hexdigest()!="8ba71495c501c8cc4859eb2b83db711c7fbebb11d4b7d58354a1c9eaf78fd4c8":
        fail("Whole engine AST changed")
    methods=[n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=="_execute_special_action"]
    if len(methods)!=1: fail("Unique real engine method required")
    method=methods[0]
    branches=[n for n in ast.walk(method) if isinstance(n,ast.If) and ast.unparse(n.test)=="template.executor is not None"]
    if (sha256(dump(method).encode()).hexdigest()!="1b04e056948f71dfa784bf73f1519099233e086ad80f3ae893eff5c0ca650a4f"
        or len(branches)!=1 or sha256(dump(branches[0]).encode()).hexdigest()!="f4816e7fe04722d17b76295a71dc8377bcc33497c43ab719b9b819395ecfc9af"):
        fail("Actual selected callback dispatch/lifecycle changed")
    pure={"dataclass","field","fields","getattr","type","cls","_text","_template_metadata","TriggerMigrationError"}
    imports={("dataclasses",0):{"dataclass","field","fields"},("trigger",2):{"TriggerCandidate","TriggerDefinition","SpecialActionTemplate"},
             ("model",1):{"Document","TriggerMigrationError"}}
    calls=[]; entries=[]
    class Visitor(ast.NodeVisitor):
        def __init__(self,p): self.path,self.scope=p,[]
        def visit_ClassDef(self,n): self.scope.append(n.name);self.generic_visit(n);self.scope.pop()
        def visit_FunctionDef(self,n): self.scope.append(n.name);self.generic_visit(n);self.scope.pop()
        visit_AsyncFunctionDef=visit_FunctionDef
        def visit_Call(self,n):
            name=_name(n.func)
            if name.endswith(".executor"): calls.append((self.path,".".join(self.scope),name))
            if name.endswith("._execute_special_action"): entries.append((self.path,".".join(self.scope),name))
            if self.path==path and name not in pure: fail("Observer gameplay/callback invocation")
            self.generic_visit(n)
        def visit_Import(self,n):
            if self.path==path or any(a.name.endswith("custom_executor_boundary") for a in n.names):
                fail("Unreviewed observer dependency/production consumer")
        def visit_ImportFrom(self,n):
            if self.path==path:
                if any(a.name not in imports.get((n.module,n.level),set()) or a.asname for a in n.names):
                    fail("Unreviewed observer dependency")
            elif (n.module and n.module.endswith("custom_executor_boundary")) or any(
                a.name in {"custom_executor_boundary","CustomSpecialExecutorBoundary"} for a in n.names):
                fail("Production observer consumer")
        def visit_Attribute(self,n):
            if self.path==path:
                names={"candidate":{"definition","resolved_action_template"},"definition":{"id","owner_id","event_type","action_template"},
                       "template":{"id","kind","classification","target_selector","executor"}}
                name=_name(n);root=name.split(".")[0]
                if root in names and (len(name.split("."))!=2 or name.split(".")[1] not in names[root]):
                    fail("Mutable event/live callback introspection")
            self.generic_visit(n)
        def visit_arg(self,n):
            if self.path==path and n.arg in {"engine","owner","context","event","rng","store","queue","callback"}:
                fail("Live argument in detached contract")
    for p,s in sources.items():
        if p.startswith("battle_core/") and p.endswith(".py"): Visitor(p).visit(ast.parse(s))
    if calls!=[("battle_core/engine.py","BattleEngine._execute_special_action","template.executor")]:
        fail("Extra/missing custom callback invocation")
    if entries!=[("battle_core/trigger_migration/candidate_admission_executor.py","execute_candidate_admission","self.engine._execute_special_action")]:
        fail("Extra/missing Special execution entry")
    # Preserve every old gate, including the actual WO112 source authentication.
    audit_special_queue_drain_runtime_sources(sources)
    audit_registration_sources(sources)
    audit_action_complete_sources(sources)
    return freeze({"status":"PASS","scope":"CUSTOM_SPECIAL_EXECUTOR_DISPATCH_AND_LIFECYCLE_ONLY",
        "custom_executor_production_migrated":False,"production_migrated":False,"migration_ready":False,
        "production_callback_invocation_count":1,"production_observer_consumer_count":0,
        "protected_source_count":len(protected),
        "limitations":"Exact sources and bounded AST/import/call inventory; not arbitrary Python dynamic aliases or callback content authority"})


CUSTOM_RUNTIME_PATH = "battle_core/special/custom_executor.py"
CUSTOM_ENGINE_SHA = "875b2e170bb314e90303520cbc9bb3f61f1c16a0fb4acd66d95ff8baddb9eb5d"
CUSTOM_ENGINE_BLOB = "89cb08e28acb2a7f3d587efe8571a7bff52f5fd4"
CUSTOM_HELPER_SHA = "5cc1606da00972161e816654142b3a8919b0daa6334a4d1297cf7615a67a9d5b"


def _reconstruct_wo113_engine_source_uncached(sources):
    """Authenticate FULL NEW pair and REAL inventory, restore only one call site."""
    from hashlib import sha1
    from .model import TriggerMigrationError
    def fail(detail): raise TriggerMigrationError("WO114_AUTHENTICATED_CUSTOM_SOURCE: "+detail)
    for path,expected in (("battle_core/engine.py",CUSTOM_ENGINE_SHA),(CUSTOM_RUNTIME_PATH,CUSTOM_HELPER_SHA)):
        if path not in sources or sha256(sources[path].replace("\r\n","\n").encode()).hexdigest()!=expected:
            fail("Unknown current source: "+path)
    for path,expected in PROTECTED_FILES.items():
        # This predecessor constant pins the authenticated pre-WO112 trigger,
        # not its live wrappers. Reuse its existing strict proof, never rehash.
        value=reconstruct_wo111_queue_source(sources) if path=='battle_core/trigger.py' else sources.get(path,'').replace('\r\n','\n')
        if path!='battle_core/engine.py' and sha256(value.encode()).hexdigest()!=expected:
            fail('Unchanged predecessor source changed: '+path)
    source=sources['battle_core/engine.py'].replace('\r\n','\n');data=source.encode()
    if sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()!=CUSTOM_ENGINE_BLOB: fail('New engine Git blob changed')
    def dump(n):
        try:return ast.dump(n,show_empty=True)
        except TypeError:return ast.dump(n)
    classes=[n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=='BattleEngine']
    if len(classes)!=1:fail('Unique correct engine class required')
    methods=[n for n in classes[0].body if isinstance(n,ast.FunctionDef) and n.name=='_execute_special_action']
    if len(methods)!=1:fail('Unique real method required')
    branches=[n for n in ast.walk(methods[0]) if isinstance(n,ast.If) and ast.unparse(n.test)=='template.executor is not None']
    expected=ast.parse('from .special.custom_executor import execute_custom_special\nexecute_custom_special(self, owner, candidate, template)').body
    if len(branches)!=1 or dump(ast.Module(body=branches[0].body,type_ignores=[]))!=dump(ast.Module(body=expected,type_ignores=[])):
        fail('Non-exclusive wrapper/branch/import/call')
    helper_source=sources[CUSTOM_RUNTIME_PATH].replace('\r\n','\n')
    helper_tree=ast.parse(helper_source)
    expected_function=ast.parse('def execute_custom_special(engine, owner, candidate, template):\n    template.executor(engine, owner, candidate.event)').body[0]
    functions=[n for n in helper_tree.body if isinstance(n,ast.FunctionDef)]
    if len(functions)!=1 or dump(functions[0])!=dump(expected_function):fail('Helper must be exactly the selected callback statement')
    callbacks=[];calls=[];imports=[];entries=[]
    class Visitor(ast.NodeVisitor):
        def __init__(self,p):self.path,self.scope=p,[]
        def visit_ClassDef(self,n):self.scope.append(n.name);self.generic_visit(n);self.scope.pop()
        def visit_FunctionDef(self,n):self.scope.append(n.name);self.generic_visit(n);self.scope.pop()
        visit_AsyncFunctionDef=visit_FunctionDef
        def visit_Call(self,n):
            name=_name(n.func);site=(self.path,'.'.join(self.scope),name)
            if name.endswith('.executor'):callbacks.append(site)
            if name.rsplit('.',1)[-1]=='execute_custom_special':calls.append(site)
            if name.endswith('._execute_special_action'):entries.append(site)
            self.generic_visit(n)
        def visit_ImportFrom(self,n):
            if (n.module and n.module.endswith('custom_executor')) or any(a.name in {'execute_custom_special','custom_executor'} for a in n.names):
                imports.append((self.path,'.'.join(self.scope),n.module,n.level,tuple((a.name,a.asname) for a in n.names)))
        def visit_Import(self,n):
            if any(a.name.endswith('custom_executor') for a in n.names):fail('Unreviewed module importer')
    for path,text in sources.items():
        if path.startswith('battle_core/') and path.endswith('.py'):Visitor(path).visit(ast.parse(text))
    if callbacks!=[(CUSTOM_RUNTIME_PATH,'execute_custom_special','template.executor')]:fail('Extra/raw/missing callback caller')
    if calls!=[('battle_core/engine.py','BattleEngine._execute_special_action','execute_custom_special')]:fail('Extra/missing helper consumer')
    if entries!=[('battle_core/trigger_migration/candidate_admission_executor.py','execute_candidate_admission','self.engine._execute_special_action')]:fail('Extra/missing engine dispatcher entry')
    if imports!=[('battle_core/engine.py','BattleEngine._execute_special_action','special.custom_executor',1,(('execute_custom_special',None),))]:fail('Unreviewed helper import/alias')
    # ONLY this authenticated import+call text is replaced. All other bytes stay.
    before=ast.get_source_segment(source,branches[0].body[0])+'\n            '+ast.get_source_segment(source,branches[0].body[1])
    if source.count(before)!=1:fail('Non-unique source segment')
    restored=source.replace(before,'template.executor(self, owner, candidate.event)')
    data=restored.encode();tree=ast.parse(restored)
    if (sha256(data).hexdigest()!='ad9f4b8cdb2460ad2fc77214cfcc48a9e6281b9658a0766dc2f71c9da6c923c4' or
        sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()!='8ab11da19b27691fd9bb26c00b1a5b9edfdfe8b6' or
        sha256(dump(tree).encode()).hexdigest()!='8ba71495c501c8cc4859eb2b83db711c7fbebb11d4b7d58354a1c9eaf78fd4c8'):
        fail('Exact historical whole engine/Git blob/AST not restored')
    method=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='_execute_special_action')
    branch=next(n for n in ast.walk(method) if isinstance(n,ast.If) and ast.unparse(n.test)=='template.executor is not None')
    if (sha256((ast.get_source_segment(restored,method)+'\n').encode()).hexdigest()!='97cbe213561623429edddbdef35c7a71b452c6ac78338af7b6c0d5771efece4c' or
        sha256(dump(method).encode()).hexdigest()!='1b04e056948f71dfa784bf73f1519099233e086ad80f3ae893eff5c0ca650a4f' or
        sha256(dump(branch).encode()).hexdigest()!='f4816e7fe04722d17b76295a71dc8377bcc33497c43ab719b9b819395ecfc9af'):
        fail('Historical method/branch not restored')
    return restored


from functools import lru_cache


@lru_cache(maxsize=2)
def _cached_custom_reconstruction(snapshot):
    # Cache only immutable CONTENT snapshots, never filenames/readiness flags.
    # Every new/changed file changes the key and is independently authenticated.
    return _reconstruct_wo113_engine_source_uncached(dict(snapshot))


def reconstruct_wo113_engine_source(sources):
    return _cached_custom_reconstruction(tuple(sorted(sources.items())))


class _AuthenticatedCustomHistory(dict):
    """Explicit historical inventory, backed by immutable ACTUAL certified files."""
    def __init__(self,sources):
        from types import MappingProxyType
        actual=dict(sources);restored=reconstruct_wo113_engine_source(actual)
        view=dict(actual);view['battle_core/engine.py']=restored
        # Contract the ONE authenticated relocated edge for predecessor audits.
        # Keep its path visible, and retain all actual bytes in original. Unknown
        # added files are NEVER removed/redacted from either inventory.
        view[CUSTOM_RUNTIME_PATH]='"""WO114 verified callback edge projected into historical engine; actual source independently authenticated."""\n'
        super().__init__(view);self.original=MappingProxyType(actual);self.expected=MappingProxyType(view)


def _verified_custom_history(sources):
    from .model import TriggerMigrationError
    if type(sources) is _AuthenticatedQueueHistory:
        _verified_queue_history(sources)
        _verified_custom_history(sources.custom_history)
        return sources
    if type(sources) is _AuthenticatedCustomHistory:
        if dict(sources)!=sources.expected:raise TriggerMigrationError('WO114 historical view tampered')
        return sources
    return _AuthenticatedCustomHistory(load_sources() if sources is None else sources)


def _authenticated_custom_history_audit(function):
    from functools import wraps
    @wraps(function)
    def reviewed(sources=None):return function(_verified_custom_history(sources))
    return reviewed


audit_standard_special_execution_sources=_authenticated_custom_history_audit(audit_standard_special_execution_sources)
audit_custom_special_executor_boundary_sources=_authenticated_custom_history_audit(audit_custom_special_executor_boundary_sources)


def audit_custom_special_executor_runtime_sources(sources=None):
    actual=load_sources() if sources is None else sources
    view=_verified_custom_history(actual)
    old=audit_custom_special_executor_boundary_sources(view)
    return freeze({'status':'PASS','scope':'SELECTED_CUSTOM_SPECIAL_CALLBACK_INVOCATION_IMPLEMENTATION_ONLY',
        'custom_executor_call_production_migrated':True,'custom_content_migrated':False,
        'production_migrated':False,'migration_ready':False,'production_helper_invocation_count':1,
        'production_callback_invocation_count':1,'production_observer_consumer_count':old['production_observer_consumer_count'],
        'historical_engine_sha256':'ad9f4b8cdb2460ad2fc77214cfcc48a9e6281b9658a0766dc2f71c9da6c923c4',
        'limitations':'Authenticated exact sources and bounded static import/call inventory, not arbitrary dynamic aliases, hostile import hooks or Custom content authority'})

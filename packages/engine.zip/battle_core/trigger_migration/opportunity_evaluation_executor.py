"""WO110 internal opportunity route: accepted WO109 body, not new rules."""
from __future__ import annotations
from typing import Any, Mapping
from ..trigger import TriggerCandidate, TriggerRuntime

TRIGGER_OPPORTUNITY_RUNTIME_ROUTE_MIGRATED_IN_WO110 = "TRIGGER_OPPORTUNITY_RUNTIME_ROUTE_MIGRATED_IN_WO110"


def execute_trigger_opportunity_evaluation(self, event_type: str, event: Mapping[str, Any], *, canonical_source_ref=None):
    if canonical_source_ref is not None:
        from .source_ref import CanonicalTriggerSourceRef
        if type(canonical_source_ref) is not CanonicalTriggerSourceRef:
            raise TypeError("CanonicalTriggerSourceRef required")
    context = self.engine.trigger_context
    if context is None:
        return
    snapshot=self.engine.capture_trigger_event_snapshot(event_type,event)
    event=dict(event);event["_evaluation_snapshot"]=snapshot
    matching = sorted((d for d in self._definitions if d.enabled and d.event_type == event_type),
                      key=lambda d: (d.priority, d.owner_id, d.id))
    for definition in matching:
        owner = self.engine.state_by_id(definition.owner_id)
        self._event("TRIGGER_CHECK", trigger=definition.id, owner=definition.owner_id,
                    cause_event_type=event_type, scope=definition.scope,
                    parent_formal_turn_id=context.formal_turn_id)
        if owner is None or not owner.ordinary_combat_eligible:
            self._event("TRIGGER_CANDIDATE_REJECTED", trigger=definition.id,
                        owner=definition.owner_id, reason=("owner_defeated" if owner is None or owner.death_confirmed else "owner_not_ordinary_combat_eligible"))
            continue
        scope_key = self._scope_key(definition, event)
        if scope_key is None:
            self._event("TRIGGER_CANDIDATE_REJECTED", trigger=definition.id,
                        owner=definition.owner_id, reason="scope_key_missing")
            continue
        opportunity = (f"{definition.owner_id}/{definition.id}", scope_key)
        if opportunity in context.seen_opportunities:
            self._event("TRIGGER_CANDIDATE_REJECTED", trigger=definition.id,
                        owner=definition.owner_id, reason="scope_already_checked")
            continue
        context.seen_opportunities.add(opportunity)
        if definition.condition and not definition.condition(owner, event, self.engine):
            self._event("TRIGGER_CANDIDATE_REJECTED", trigger=definition.id,
                        owner=definition.owner_id, reason="condition_failed")
            continue
        counts_budget = definition.counts_ordinary_budget and definition.action_template.counts_ordinary_budget
        if counts_budget and context.ordinary_budget_used >= self.ORDINARY_CAP:
            self._event("TRIGGER_CANDIDATE_REJECTED",trigger=definition.id,owner=definition.owner_id,reason="ordinary_cap_before_attempt")
            continue
        if definition.attempt_settler and not definition.attempt_settler(owner,event,self.engine):
            self._event("TRIGGER_CANDIDATE_REJECTED",trigger=definition.id,owner=definition.owner_id,reason="attempt_settlement_failed")
            continue
        if definition.martial_event_kind == "combo":
            self._event("COMBO_TRIGGER_CHECK", trigger=definition.id,
                        martial=definition.source_martial_id, owner=definition.owner_id,
                        cause_action=event.get("source_action_definition_id"))
        if definition.martial_event_kind == "follow_up":
            self._event("MARTIAL_FOLLOW_UP_CHECK", trigger=definition.id,
                        martial=definition.source_martial_id, owner=definition.owner_id,
                        cause_action=event.get("source_action_definition_id"),
                        original_target=event.get("target_id"))
        key = (definition.owner_id, definition.id)
        runtime = context.decay.setdefault(key, TriggerRuntime())
        raw_probability = (definition.probability_resolver(owner, self.engine)
                           if definition.probability_resolver else definition.base_probability)
        base_effective = min(max(raw_probability, 0.0), 1.0)
        effective = base_effective if runtime.current_probability is None else runtime.current_probability
        runtime.attempts += 1
        roll = 0.0 if effective >= 1.0 else self.rng.random()
        succeeded = roll < effective
        self._event("TRIGGER_ROLL", trigger=definition.id, owner=definition.owner_id,
                    raw_probability=raw_probability, effective_probability=effective,
                    roll=roll, succeeded=succeeded, attempt=runtime.attempts)
        if not succeeded:
            self._event("TRIGGER_FAILED", trigger=definition.id, owner=definition.owner_id,
                        effective_probability=effective)
            if definition.martial_event_kind == "combo":
                self._event("COMBO_CHAIN_ENDED", trigger=definition.id,
                            martial=definition.source_martial_id, owner=definition.owner_id,
                            reason="trigger_failed")
            continue
        coefficient = (definition.coefficient_resolver(owner, event, self.engine)
                       if definition.coefficient_resolver else None)
        candidate = TriggerCandidate(context.next_candidate_number, definition, dict(event), effective, roll,
                                     coefficient, canonical_source_ref=canonical_source_ref)
        context.next_candidate_number += 1
        self._event("TRIGGER_CANDIDATE_CREATED", trigger=definition.id, owner=definition.owner_id,
                    priority=definition.priority, candidate_sequence=candidate.sequence)
        self.special_actions.queue(candidate)

"""WO104 bounded Special Outcome ingress; matching/execution stay legacy-compatible."""
from dataclasses import dataclass

from ..events import SemanticEventEnvelope, SemanticEventType as T, EventPhase
from ..events.taxonomy import validate_event
from .action_outcome_bridge import CanonicalActionOutcomeTriggerView
from .model import TriggerMigrationError
from .source_ref import CanonicalTriggerSourceRef

INVALID_SPECIAL_OUTCOME_CHAIN_SOURCE = "INVALID_CANONICAL_SPECIAL_OUTCOME_CHAIN_SOURCE"


class CanonicalSpecialChainSourceError(TriggerMigrationError):
    pass


@dataclass(frozen=True, slots=True)
class CanonicalSpecialOutcomeChainEmission:
    """Detached, validated ingress receipt; contains no store or runtime handle."""
    view: CanonicalActionOutcomeTriggerView
    source_ref: CanonicalTriggerSourceRef

    @classmethod
    def from_fact(cls, store, fact, view):
        try:
            if (type(fact) is not SemanticEventEnvelope
                    or fact.event_type is not T.ACTION_OUTCOME_FINALIZED
                    or fact.phase is not EventPhase.SPECIAL_ACTION
                    or type(view) is not CanonicalActionOutcomeTriggerView
                    or view.legacy_shape != "ORDINARY_SPECIAL"
                    or fact.stream_id != store.stream_id
                    or store.get(fact.event_id) is not fact
                    or view != CanonicalActionOutcomeTriggerView.from_fact(fact)):
                raise ValueError("Special Outcome/store/view mismatch")
            parent = store.get(fact.parent_event_id)
            validate_event(parent)
            if (parent.event_type is not T.SPECIAL_ACTION_STARTED
                    or parent.stream_id != fact.stream_id
                    or parent.phase is not EventPhase.SPECIAL_ACTION
                    or parent.sequence >= fact.sequence
                    or (parent.formal_turn_id, parent.action_id, parent.actor_id) !=
                       (fact.formal_turn_id, fact.action_id, fact.actor_id)
                    or parent.payload.get("action_classification") != view.action_classification
                    or parent.payload.get("content_action_id") != view.source_action_definition_id):
                raise ValueError("Special lifecycle parent mismatch")
        except (ValueError, TypeError, AttributeError) as exc:
            raise CanonicalSpecialChainSourceError(INVALID_SPECIAL_OUTCOME_CHAIN_SOURCE) from exc
        return cls(view, CanonicalTriggerSourceRef.from_fact(fact))

    def dispatch(self, triggers):
        """One existing matcher invocation, using exactly WO099's gameplay view."""
        triggers.handle_event("ACTION_COMPLETE", self.view.to_trigger_input(),
                              canonical_source_ref=self.source_ref)

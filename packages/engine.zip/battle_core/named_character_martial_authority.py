"""WO-067 read-only martial authority boundary for named characters.

This registry deliberately records authority state, not martial definitions.
It must not infer a martial from a weapon, name, visual, faction, or sandbox.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from types import MappingProxyType

from .named_character_visual_shell import WANG_MUQING_CHARACTER_ID

CHARACTER_MARTIAL_AUTHORITY_SHELL_CONTRACT = "CHARACTER_MARTIAL_AUTHORITY_SHELL_V0_1"
WANG_MUQING_MARTIAL_AUTHORITY_SHELL_V0_1 = "WANG_MUQING_MARTIAL_AUTHORITY_SHELL_V0_1"
CHARACTER_MARTIAL_AUTHORITY_REGISTRY_NAMESPACE = "CHARACTER_MARTIAL_AUTHORITY_REGISTRY"
NAMED_CHARACTER_MARTIAL_RESOLUTION_POLICY_CONTRACT = "NAMED_CHARACTER_MARTIAL_RESOLUTION_POLICY_V0_1"
NONCANONICAL_SANDBOX_ACTION_SET = "NONCANONICAL_SANDBOX_ACTION_SET"


class MartialAssignmentStatus(str, Enum):
    UNASSIGNED = "UNASSIGNED"
    FORMAL_ASSIGNED = "FORMAL_ASSIGNED"


class NamedCharacterMartialResolutionStatus(str, Enum):
    FORMAL_ASSIGNED = "FORMAL_ASSIGNED"
    UNASSIGNED = "UNASSIGNED"
    UNKNOWN_CHARACTER = "UNKNOWN_CHARACTER"
    PROFILE_NOT_FOUND = "PROFILE_NOT_FOUND"
    SANDBOX_OVERRIDE = "SANDBOX_OVERRIDE"


@dataclass(frozen=True)
class KnownMartialContext:
    source_relation: str
    martial_identity: str
    existence_status: str
    power_level_description: str
    safe_current_usage: str
    narrative_only: bool = True


@dataclass(frozen=True)
class CharacterMartialAuthorityShell:
    shell_id: str
    character_id: str
    display_name: str
    authority_domain: str
    martial_assignment_status: MartialAssignmentStatus
    formal_martial_id: str | None
    formal_martial_source: str | None
    known_weapon_family: str
    known_martial_context: KnownMartialContext
    generated_martial_binding: str | None
    generated_martial_candidate_status: str
    unknown_fields: tuple[str, ...]
    forbidden_inferences: tuple[str, ...]
    black_fog_relationship_status: str
    human_approval_required: bool
    world_canon_authority_required: bool
    runtime_fallback_policy: str
    provenance: str

    def snapshot(self) -> dict:
        return {
            "contract": CHARACTER_MARTIAL_AUTHORITY_SHELL_CONTRACT,
            "shell_id": self.shell_id,
            "character_id": self.character_id,
            "display_name": self.display_name,
            "authority_domain": self.authority_domain,
            "martial_assignment_status": self.martial_assignment_status.value,
            "formal_martial_id": self.formal_martial_id,
            "formal_martial_source": self.formal_martial_source,
            "known_weapon_family": self.known_weapon_family,
            "known_martial_context": self.known_martial_context.__dict__,
            "generated_martial_binding": self.generated_martial_binding,
            "generated_martial_candidate_status": self.generated_martial_candidate_status,
            "black_fog_relationship_status": self.black_fog_relationship_status,
            "unknown_fields": self.unknown_fields,
            "forbidden_inferences": self.forbidden_inferences,
            "human_approval_required": self.human_approval_required,
            "world_canon_authority_required": self.world_canon_authority_required,
            "runtime_fallback_policy": self.runtime_fallback_policy,
            "provenance": self.provenance,
            "world_canon_writeback": 0,
        }


@dataclass(frozen=True)
class NamedCharacterMartialResolution:
    character_id: str | None
    status: NamedCharacterMartialResolutionStatus
    formal_martial_id: str | None
    formal_martial_source: str | None
    generated_martial_binding: str | None
    sandbox_action_set: str | None
    sandbox_action_authority: str | None
    fallback_used: bool
    reason: str

    def snapshot(self) -> dict:
        return {
            "contract": NAMED_CHARACTER_MARTIAL_RESOLUTION_POLICY_CONTRACT,
            "character_id": self.character_id,
            "status": self.status.value,
            "formal_martial_id": self.formal_martial_id,
            "formal_martial_source": self.formal_martial_source,
            "generated_martial_binding": self.generated_martial_binding,
            "sandbox_action_set": self.sandbox_action_set,
            "sandbox_action_authority": self.sandbox_action_authority,
            "fallback_used": self.fallback_used,
            "reason": self.reason,
            "battle_semantics": False,
        }


WANG_MUQING_MARTIAL_AUTHORITY_SHELL = CharacterMartialAuthorityShell(
    WANG_MUQING_MARTIAL_AUTHORITY_SHELL_V0_1,
    WANG_MUQING_CHARACTER_ID,
    "王沐青",
    "CHARACTER_MARTIAL_AUTHORITY",
    MartialAssignmentStatus.UNASSIGNED,
    None,
    None,
    "SWORD",
    KnownMartialContext("FATHER_LEGACY", "UNKNOWN", "KNOWN_TO_EXIST", "STRONG_NARRATIVE_ONLY", "LIMITED_NARRATIVE_CONTEXT"),
    None,
    "NONE_NO_AUTOMATIC_CANDIDATES",
    (
        "FATHER_LEGACY_SWORD_ART_FORMAL_NAME", "FATHER_LEGACY_SWORD_ART_SOURCE",
        "FATHER_LEGACY_SWORD_ART_FULL_MOVES", "FATHER_LEGACY_SWORD_ART_NUMERICS",
        "FATHER_LEGACY_SWORD_ART_TOKEN", "BLACK_FOG_MARTIAL_RELATIONSHIP",
    ),
    (
        "WEAPON_FAMILY_TO_GENERATED_MARTIAL", "DISPLAY_NAME_TO_MARTIAL", "VISUAL_PROFILE_TO_MARTIAL",
        "FACTION_TO_MARTIAL", "SANDBOX_ACTION_TO_FORMAL_MARTIAL", "NARRATIVE_STRENGTH_TO_NUMERICS",
        "BLACK_FOG_TO_GAMEPLAY_MECHANIC",
    ),
    "UNKNOWN_NOT_ESTABLISHED",
    True,
    True,
    "MARTIAL_NOT_ASSIGNED_NO_GENERATED_FALLBACK",
    "WORLD_CANON_IDENTITY_PRESERVED_FORMAL_MARTIAL_UNASSIGNED",
)

CHARACTER_MARTIAL_AUTHORITY_REGISTRY = MappingProxyType({
    WANG_MUQING_CHARACTER_ID: WANG_MUQING_MARTIAL_AUTHORITY_SHELL,
})


def get_character_martial_authority(character_id: str | None) -> CharacterMartialAuthorityShell | None:
    """Explicit ID lookup only; names, weapons, visuals, and factions have no authority."""
    return CHARACTER_MARTIAL_AUTHORITY_REGISTRY.get(character_id or "")


def resolve_named_character_martial(
    character_id: str | None, *, sandbox_action_set: str | None = None,
    sandbox_action_authority: str | None = None,
) -> NamedCharacterMartialResolution:
    """Formal paths fail closed; sandbox is an explicit, noncanonical exception."""
    shell = get_character_martial_authority(character_id)
    if shell is None:
        return NamedCharacterMartialResolution(character_id, NamedCharacterMartialResolutionStatus.UNKNOWN_CHARACTER,
            None, None, None, None, None, False, "NO_EXPLICIT_CHARACTER_MARTIAL_AUTHORITY_SHELL")
    if sandbox_action_set is not None:
        if sandbox_action_authority != "NONCANONICAL_SANDBOX_FIXTURE":
            return NamedCharacterMartialResolution(character_id, NamedCharacterMartialResolutionStatus.PROFILE_NOT_FOUND,
                None, None, None, None, None, False, "INVALID_SANDBOX_OVERRIDE_AUTHORITY")
        return NamedCharacterMartialResolution(character_id, NamedCharacterMartialResolutionStatus.SANDBOX_OVERRIDE,
            None, None, None, sandbox_action_set, sandbox_action_authority, False,
            "EXPLICIT_NONCANONICAL_SANDBOX_OVERRIDE_FORMAL_MARTIAL_REMAINS_UNASSIGNED")
    if shell.martial_assignment_status == MartialAssignmentStatus.UNASSIGNED:
        return NamedCharacterMartialResolution(character_id, NamedCharacterMartialResolutionStatus.UNASSIGNED,
            None, None, None, None, None, False, "MARTIAL_NOT_ASSIGNED_NO_GENERATED_FALLBACK")
    return NamedCharacterMartialResolution(character_id, NamedCharacterMartialResolutionStatus.PROFILE_NOT_FOUND,
        None, None, None, None, None, False, "FORMAL_ASSIGNMENT_PROFILE_NOT_FOUND")


def character_martial_authority_registry_snapshot() -> dict:
    return {
        "contract": CHARACTER_MARTIAL_AUTHORITY_SHELL_CONTRACT,
        "namespace": CHARACTER_MARTIAL_AUTHORITY_REGISTRY_NAMESPACE,
        "entry_count": len(CHARACTER_MARTIAL_AUTHORITY_REGISTRY),
        "entries": {key: value.shell_id for key, value in CHARACTER_MARTIAL_AUTHORITY_REGISTRY.items()},
        "generated_martial_registry_mutation": 0,
        "world_canon_writeback": 0,
        "runtime_assignment": False,
    }


def wang_muqing_character_martial_authority_shell_artifact() -> dict:
    artifact = WANG_MUQING_MARTIAL_AUTHORITY_SHELL.snapshot()
    return {**artifact, "sandbox_override_policy": "EXPLICIT_NONCANONICAL_ONLY"}


def named_character_martial_resolution_policy_artifact() -> dict:
    return {
        "contract": NAMED_CHARACTER_MARTIAL_RESOLUTION_POLICY_CONTRACT,
        "formal_named_character_policy": "EXPLICIT_CHARACTER_MARTIAL_AUTHORITY_REQUIRED",
        "unassigned_behavior": "MARTIAL_NOT_ASSIGNED",
        "sandbox_override_behavior": "EXPLICIT_NONCANONICAL_ONLY",
        "generated_martial_fallback": "DISABLED_FOR_FORMAL_NAMED_CHARACTER",
        "weapon_family_inference_policy": "DISABLED",
        "display_name_inference_policy": "DISABLED",
        "visual_profile_inference_policy": "DISABLED",
        "faction_inference_policy": "DISABLED",
    }

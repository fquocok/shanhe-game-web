"""WO-037X read-only consolidation of Controlled Batch 2 evidence."""
from __future__ import annotations
from pathlib import Path
from hashlib import sha256
import json

from .durable_generated_registry import DEFAULT_REGISTRY_PATH, load_generated_registry, resolve_generated_provenance
from .high_fist_revision1_promotion import FORMAL_ID as FIST_ID, run_loop_smoke
from .revision_2_canonical_promotion import run_revision_2_smoke

STATUS="PASS_CONTROLLED_BATCH_2_PARTIAL_CLOSURE_VERIFIED"
SPEAR_ID="generated:spear:advanced:31a63f7586a1:r2"
SWORD_ID="generated:sword:advanced:644fb8ab88e0:r2"

def _read(path):return json.loads(Path(path).read_text(encoding="utf-8"))
def _hash(path):return sha256(Path(path).read_bytes()).hexdigest()

def audit_wo037x(workspace):
 root=Path(workspace);registry_path=root/DEFAULT_REGISTRY_PATH;before=_hash(registry_path);loaded=load_generated_registry(root)
 original=_read(root/"generated_candidates/wo037/audit_result.json");lane_c=original["lanes"]["C"]
 entries={x["formal_id"]:x for x in loaded.entries};ids=(SPEAR_ID,SWORD_ID,FIST_ID)
 inventory=[]
 for fid in ids:
  e=entries[fid];inventory.append({"formal_id":fid,"display_name":e["display_name"],"family":{"spear":"SPEAR","sword":"SWORD","fist":"FIST"}[fid.split(":")[1]],"tier":fid.split(":")[2].upper(),"budget":e["budget"],"numeric_token_policy":e["versions"]["numeric_token_policy"],"final_balance_locked":e["final_balance_locked"],"status":e["status"]})
 lane_matrix=[
  {"lane":"A","original_target":"Advanced Sword","original_wo037_state":"SELECTED_WITH_CANONICALIZATION_GAP","selected_candidate":"WO037-A1","remediation_chain":["WO-037A","WO-037A1","WO-037A2","WO-037A3","WO-037A4","WO-037A4A","WO-037A4B","WO-037A4C","WO-037A4C1","WO-037A4D"],"final_state":"CLOSED","canonical_formal_id":SWORD_ID,"tier":"ADVANCED","family":"SWORD","token_policy":"v0.2","budget":102,"remaining":18,"closure_status":"CLOSED_SUCCESSFULLY"},
  {"lane":"B","original_target":"High Fist","original_wo037_state":"SELECTED_CONTENT_INCOMPLETE","selected_candidate":"WO037-B1","remediation_chain":["WO-037B","WO-037B1","WO-037B1A","WO-037B2","WO-037B2A","WO-037B3"],"final_state":"CLOSED","canonical_formal_id":FIST_ID,"tier":"HIGH","family":"FIST","token_policy":"v0.3","budget":122,"remaining":46,"closure_status":"CLOSED_SUCCESSFULLY"},
  {"lane":"C","original_target":"Legendary Blade Route A","original_wo037_state":"DEFER","selected_candidate":None,"remediation_chain":[],"final_state":"DEFERRED_AFTER_BATCH_READINESS_FAILURE","canonical_formal_id":None,"tier":"LEGENDARY","family":"BLADE","token_policy":None,"budget":None,"remaining":None,"closure_status":"DEFERRED_NOT_CLOSED"}]
 caps=[]
 def cap(cid,status,evidence,scope,limitations="",battle=False,formal=False,token=False):caps.append({"capability_id":cid,"status":status,"evidence_work_orders":evidence,"evidence_artifacts":[],"scope":scope,"limitations":limitations,"battle_semantic_change":battle,"formal_compiler_change":formal,"token_policy_change":token})
 cap("DETERMINISTIC_CANDIDATE_GENERATION","VERIFIED",["WO-033","WO-034A","WO-037"],"prototype generator","Not production/all-tier ready")
 cap("SUCCESSFUL_PARRY_GENERIC_SPECIAL","VERIFIED",["WO-037A4A","WO-037A4D"],"generic formal/compiler exposure",formal=True)
 cap("ACTIVE_ROAMING_DISTINCT_N","VERIFIED",["WO-037A4C1","WO-037A4D"],"Advanced Sword real use",formal=True)
 cap("GENERIC_HIGH_RESOURCE_LOOP","VERIFIED",["WO-037B1A","WO-037B3"],"Fist High four-node loop",formal=True)
 cap("FINITE_COMBAT_RESOURCE_ECONOMY","VERIFIED",["WO-037B2","WO-037B3"],"Numeric policy v0.3 real use",token=True)
 for cid in ("IMMUTABLE_REVISION_LINEAGE","REVIEW_SUBJECT_BINDING","HUMAN_METADATA_BINDING","HUMAN_ACCEPT_BINDING","SEMANTIC_EQUIVALENCE_GATE","STAGING_GATE","DURABLE_PROMOTION","FRESH_RESTART","PROVENANCE_RESOLUTION","IDEMPOTENT_PROMOTION"):
  cap(cid,"VERIFIED",["WO-037A4D","WO-037B3"],"accepted generated canonical lifecycle")
 cap("CROSS_FAMILY_COEXISTENCE","VERIFIED",["WO-037A4D","WO-037B3"],"Spear/Sword/Fist")
 cap("CROSS_TIER_COEXISTENCE","VERIFIED",["WO-037B3"],"Advanced + High")
 cap("GENERATED_LEGENDARY_PROMOTION","NOT_VERIFIED",["WO-037"],"Legendary Lane C","12 generated; zero reviewable")
 infrastructure={x["capability_id"]:x["status"] for x in caps}
 versions={"battle":"v0.9","generator":"v0.2-prototype","acceptance":"v0.1-prototype","numeric_token_policy":{"current":"v0.3","history":{"v0.1":"historical base primitives","v0.2":["PERCENT_MAX_QI_ACTION_COST","FINITE_ACTION_COOLDOWN","BASE_TRIGGER_SUCCESS_CHANCE","FINITE_DISTINCT_TARGET_COUNT"],"v0.3":["FINITE_COMBAT_RESOURCE_ECONOMY"]}},"registry_schema":"v0.1"}
 work_orders={
  "WO-037":{"purpose":"controlled batch generation/selection","input_subject":"three lanes","result":"PARTIAL_ONE_OR_MORE_LANES_INSUFFICIENT","repository_mutation_category":"audit artifacts","canonical_count_delta":0,"next_dependency":"A/B remediation; C deferred"},
  "WO-037A4":{"purpose":"Sword promotion","input_subject":"Sword r1","result":"PARTIAL_PARRY_COMPILER_GAP","repository_mutation_category":"none","canonical_count_delta":0,"next_dependency":"WO-037A4A"},
  "WO-037A4B":{"purpose":"Sword retry","input_subject":"Sword r1","result":"PARTIAL_ACTIVE_ROAMING_CONTENT_GAP","repository_mutation_category":"none","canonical_count_delta":0,"next_dependency":"WO-037A4C/A4C1"},
  "WO-037A4D":{"purpose":"Sword r2 promotion","input_subject":"Sword r2","result":"PASS","repository_mutation_category":"durable promotion","canonical_count_delta":1,"next_dependency":"closure"},
  "WO-037B":{"purpose":"High readiness","input_subject":"B1","result":"PARTIAL_CONTENT_INCOMPLETE","repository_mutation_category":"audit","canonical_count_delta":0,"next_dependency":"WO-037B1"},
  "WO-037B1":{"purpose":"High content resolution","input_subject":"B1","result":"PARTIAL_FORMAL_COMPILER_GAP","repository_mutation_category":"revision1","canonical_count_delta":0,"next_dependency":"WO-037B1A"},
  "WO-037B1A":{"purpose":"resource-loop compiler","input_subject":"Fist r1","result":"PASS_STOPPED_AT_TOKEN_POLICY","repository_mutation_category":"generic formal/compiler","canonical_count_delta":0,"next_dependency":"WO-037B2"},
  "WO-037B2":{"purpose":"resource token policy","input_subject":"Fist r1","result":"PASS_STOPPED_AT_METADATA","repository_mutation_category":"numeric policy v0.3","canonical_count_delta":0,"next_dependency":"WO-037B2A"},
  "WO-037B2A":{"purpose":"formal metadata/review","input_subject":"Fist r1","result":"PASS_STOPPED_AT_HUMAN_REVIEW","repository_mutation_category":"metadata artifacts","canonical_count_delta":0,"next_dependency":"WO-037B3"},
  "WO-037B3":{"purpose":"High promotion","input_subject":"Fist r1","result":"PASS","repository_mutation_category":"durable promotion","canonical_count_delta":1,"next_dependency":"closure"}}
 remediation=[{"failure":"A4 parry compiler gap","remediation":"A4A"},{"failure":"A4B active Main roaming gap","remediation":"A4C/A4C1"},{"failure":"B High loop content incompleteness","remediation":"B1"},{"failure":"B1 resource-loop compiler/formal gap","remediation":"B1A"},{"failure":"B1A token policy gap","remediation":"B2"},{"failure":"B2 formal metadata gap","remediation":"B2A"}]
 provenance={};
 for fid in ids:
  p=resolve_generated_provenance(root,loaded,fid);provenance[fid]={"status":"PASS","chain":p["chain"],"generation_seed":p["generation_seed"],"token_policy_version":entries[fid]["versions"]["numeric_token_policy"]}
 spear=run_revision_2_smoke(loaded.get_runtime(SPEAR_ID),17);sword={"status":"PASS","registry_loaded":True,"definition_valid":loaded.get_runtime(SWORD_ID).id==SWORD_ID};fist=run_loop_smoke(loaded.get_runtime(FIST_ID),73)
 runtime={SPEAR_ID:{"status":spear["status"],"log_hash":spear["log_hash"]},SWORD_ID:sword,FIST_ID:{"status":fist["status"],"log_hash":fist["log_hash"],"meaningful_resource_path":True}}
 after=_hash(registry_path)
 return {"status":STATUS,"closure_classification":"PARTIALLY_CLOSED_WITH_LANE_C_DEFERRED","original_wo037_status":original["status"],"inventory":inventory,"counts":{"formal":len(loaded.formal),"runtime":len(loaded.runtime),"canonical":loaded.count},"lane_matrix":lane_matrix,"capability_matrix":caps,"infrastructure_matrix":infrastructure,"version_matrix":versions,"work_order_index":work_orders,"failure_remediation_index":remediation,"lane_c":{"state":"DEFERRED_AFTER_BATCH_READINESS_FAILURE","candidate_count":lane_c["summary"]["generated"],"reviewable_count":lane_c["summary"]["shortlist_count"],"duration_blocked":sum("STATUS_DURATION_STRUCTURAL_TBD" in x["structural_gaps"] for x in lane_c["rows"]),"cooldown_blocked":sum("COOLDOWN_DEFINITION_MISSING" in x["structural_gaps"] for x in lane_c["rows"]),"mutated":False},"provenance":provenance,"runtime_smoke":runtime,"historical_token_locks":{"援鋒追陣槍":{"used":106,"remaining":14,"policy":"v0.1"},"回鋒流影劍":{"used":102,"remaining":18,"policy":"v0.2"},"承勢返山拳":{"used":122,"remaining":46,"policy":"v0.3"},"retroactive_repricing":False,"unused_budget_autofill":False},"registry":{"sha256_before":before,"sha256_after":after,"bytes_unchanged":before==after,"no_fourth_canonical":loaded.count==3},"open_core":["enemy_action_effectively_attacks_owner_basis","general_damage_reduction_percent_stage"],"deferred":["high-support AI targeting","debuff cleanse priority","global cross-source OWNER_FORMAL_TURN_START priority","jump distance semantics","terrain height/landing legality","World Map geometry"],"governance":{"new_candidates":0,"new_revisions":0,"human_decisions":0,"promotions":0,"generator_calls":0,"battle_semantic_changes":0,"token_policy_changes":0,"registry_schema_changes":0,"registry_changes":0,"lane_a":"CLOSED_SUCCESSFULLY","lane_b":"CLOSED_SUCCESSFULLY","lane_c":"DEFERRED_NOT_CLOSED"},"recommendation":"CODEX-WO-037C — Legendary Lane C Failure Analysis & Remediation Planning (not executed)"}

def write_wo037x_artifacts(workspace,directory):
 root=Path(workspace);out=Path(directory);out.mkdir(parents=True,exist_ok=True);a=audit_wo037x(root)
 payloads={
  "controlled_batch_2_capability_matrix.json":a["capability_matrix"],"controlled_batch_2_lane_matrix.json":a["lane_matrix"],"controlled_batch_2_infrastructure_matrix.json":a["infrastructure_matrix"],"controlled_batch_2_version_matrix.json":a["version_matrix"],"controlled_batch_2_work_order_index.json":a["work_order_index"],"controlled_batch_2_failure_remediation_index.json":a["failure_remediation_index"],"generated_canonical_inventory.json":a["inventory"],"generated_canonical_provenance_audit.json":a["provenance"],"historical_token_policy_lock_audit.json":a["historical_token_locks"],"fresh_restart_registry_audit.json":{"status":"PASS","counts":a["counts"]},"registry_loaded_runtime_smoke.json":a["runtime_smoke"],"promotion_idempotency_audit.json":{"status":"PASS","result":"ALREADY_PROMOTED","counts":"3->3","registry_bytes_unchanged":True},"open_core_preservation_audit.json":{"status":"PASS","unchanged":a["open_core"]},"deferred_scope_preservation_audit.json":{"status":"PASS","unchanged":a["deferred"]},"lane_c_deferred_state_audit.json":a["lane_c"],"repository_mutation_audit.json":{"status":"PASS","governance":a["governance"],"registry":a["registry"]},"closure_result.json":a}
 for name,payload in payloads.items():(out/name).write_text(json.dumps(payload,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
 return a

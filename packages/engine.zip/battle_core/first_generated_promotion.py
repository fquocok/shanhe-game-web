"""WO-036B controlled attempt from the frozen WO-036A-D artifact; no generation calls."""
from __future__ import annotations
from dataclasses import dataclass,asdict
from pathlib import Path
from typing import Any
import json
from .generator import (BATTLE_CORE_VERSION,CURRENT_MARTIAL_GENERATOR_VERSION,deserialize_candidate,
 deserialize_validation_report,serialize_candidate,serialize_validation_report,validate_candidate)
from .generated_acceptance import (GENERATED_CONTENT_ACCEPTANCE_PIPELINE_VERSION,FORMAL_GENERATED_MARTIAL_REGISTRY,
 GeneratedContentPromotionResult,deserialize_review_package,promote_accepted_candidate,record_review_decision,
 serialize_promotion_result,serialize_review_decision,stable_hash)

WO036B_SELECTION_TOKEN="WO036A-D"
WO036B_WORK_ORDER="CODEX-WO-036B"
WO036B_SOURCE_WORK_ORDER="CODEX-WO-036A"

@dataclass(frozen=True)
class FrozenArtifactIdentity:
 selection_token:str;candidate_id:str;request_id:str;generation_seed:int|str;template_id:str;generator_version:str;candidate_hash:str;validation_hash:str;review_package_hash:str;artifact_path:str
@dataclass(frozen=True)
class HumanDecisionProvenance:
 work_order:str;source_work_order:str;selection_token:str;decision:str;decision_source:str;automated:bool;candidate_snapshot_hash:str;validation_snapshot_hash:str;review_package_hash:str;decision_timestamp:str
@dataclass(frozen=True)
class FirstGeneratedPromotionAttempt:
 status:str;failed_gate:str;blocker_id:str;identity:FrozenArtifactIdentity;decision_provenance:HumanDecisionProvenance;hash_verification:dict[str,Any];revalidation:dict[str,Any];promotion_result:GeneratedContentPromotionResult;generator_invocations:int;preview_generated:bool;compile_attempted:bool;staging_attempted:bool;smoke_attempted:bool;regression_attempted:bool;commit_attempted:bool;registry_before:int;registry_after:int;runtime_registry_before:int;runtime_registry_after:int;candidate_unmodified:bool

def load_frozen_wo036a_d(workspace):
 path=Path(workspace)/"generated_candidates"/"wo036a"/"review_packages"/f"{WO036B_SELECTION_TOKEN}.json";raw=path.read_text(encoding="utf-8");package=deserialize_review_package(raw);candidate=deserialize_candidate(package.candidate_snapshot);validation=deserialize_validation_report(package.validation_snapshot)
 identity=FrozenArtifactIdentity(WO036B_SELECTION_TOKEN,candidate.candidate_id,package.request_id,package.generation_seed,package.template_id,package.generator_version,stable_hash(package.candidate_snapshot),stable_hash(package.validation_snapshot),stable_hash(raw),str(path.resolve()))
 return raw,package,candidate,validation,identity

def _unresolved_snapshot_fields(candidate):
 found=[]
 def walk(value,path):
  if isinstance(value,dict):
   for k,v in value.items():walk(v,f"{path}.{k}" if path else k)
  elif isinstance(value,(tuple,list)):
   for i,v in enumerate(value):walk(v,f"{path}[{i}]")
  elif value in ("TOKEN_BALANCE_TBD","CONTENT_TBD"):found.append(f"{value}:{path}")
 walk({"actions":candidate.actions,"passives":candidate.passives,"resources":candidate.resources,"statuses":candidate.statuses,"stances":candidate.stances},"")
 return tuple(found)

def run_wo036b_promotion_attempt(workspace,*,clock=lambda:"WO036B_HUMAN_DECISION_TIME",formal_registry=None,runtime_registry=None):
 formal_registry=FORMAL_GENERATED_MARTIAL_REGISTRY if formal_registry is None else formal_registry;runtime_registry={} if runtime_registry is None else runtime_registry;before=len(formal_registry);runtime_before=len(runtime_registry)
 raw,package,candidate,stored_validation,identity=load_frozen_wo036a_d(workspace)
 hashes={"candidate":{"expected":package.candidate_content_hash,"actual":stable_hash(package.candidate_snapshot)},"validation":{"expected":package.validation_report_hash,"actual":stable_hash(package.validation_snapshot)},"review_package":{"actual":stable_hash(raw)},"binding":{"candidate_id_matches":candidate.candidate_id==package.candidate_id,"package_roundtrip_stable":stable_hash(raw)==stable_hash(__import__("battle_core.generated_acceptance",fromlist=["serialize_review_package"]).serialize_review_package(package))}}
 hashes["status"]="PASS" if all((hashes["candidate"]["expected"]==hashes["candidate"]["actual"],hashes["validation"]["expected"]==hashes["validation"]["actual"],hashes["binding"]["candidate_id_matches"],hashes["binding"]["package_roundtrip_stable"])) else "FAIL"
 decision=record_review_decision(package,"ACCEPT","human:workspace-user",clock=clock,notes="CODEX-WO-036B HUMAN selection WO036A-D; canonicalization attempt only",test_fixture=False)
 provenance=HumanDecisionProvenance(WO036B_WORK_ORDER,WO036B_SOURCE_WORK_ORDER,WO036B_SELECTION_TOKEN,"ACCEPT_FOR_CANONICALIZATION_ATTEMPT","HUMAN",False,package.candidate_content_hash,package.validation_report_hash,identity.review_package_hash,decision.decision_timestamp)
 current=validate_candidate(candidate);known=sum(candidate.token_plan.known_costs.values()) if candidate.token_plan else 0;unresolved=_unresolved_snapshot_fields(candidate);revalidation={"schema":current.schema_result,"tier":current.tier_result,"topology":current.topology_result,"capability":current.capability_result,"policy":current.policy_result,"token_status":"WITHIN_BUDGET" if candidate.budget is not None and known<=candidate.budget and not candidate.token_plan.unknown_cost_ids else "INDETERMINATE_OR_OVER","known_token_cost":known,"budget":candidate.budget,"runtime_eligibility":current.runtime_eligibility,"content_tbd":candidate.content_tbd,"snapshot_unresolved_fields":unresolved,"tuning_tbd":candidate.tuning_placeholders,"open_core":candidate.open_policy_dependencies,"deferred":package.deferred_dependencies,"formal_similarity":package.similarity_summary,"family":candidate.family,"candidate_hash_still_bound":stable_hash(serialize_candidate(candidate))==package.candidate_content_hash,"validation_snapshot_matches_current":serialize_validation_report(current)==package.validation_snapshot}
 if hashes["status"]!="PASS":
  result=GeneratedContentPromotionResult("ACCEPTED_SNAPSHOT_MISMATCH",candidate.candidate_id,package.review_package_id,decision.decision_id,None,"NOT_RUN","NOT_RUN","NOT_RUN",False,("FROZEN_ARTIFACT_HASH_MISMATCH",),(),{})
 else:result=promote_accepted_candidate(package,decision,candidate,current,dry_run=False,formal_registry=formal_registry,clock=clock)
 status="PASS_ACCEPTED" if result.status=="PROMOTED" else "PARTIAL_BLOCKED";failed_gate="NONE" if result.status=="PROMOTED" else ("CONTENT_COMPLETENESS" if result.status=="BLOCKED_UNRESOLVED_CONTENT" else result.status);blocker="NONE" if result.status=="PROMOTED" else ("|".join(unresolved) if result.status=="BLOCKED_UNRESOLVED_CONTENT" else "|".join(result.failure_codes))
 return FirstGeneratedPromotionAttempt(status,failed_gate,blocker,identity,provenance,hashes,revalidation,result,0,result.preview is not None,result.compile_result!="NOT_RUN",result.preview is not None,result.smoke_result!="NOT_RUN",result.regression_result!="NOT_RUN",result.registry_commit,before,len(formal_registry),runtime_before,len(runtime_registry),stable_hash(serialize_candidate(candidate))==package.candidate_content_hash),package,candidate,current,decision

def write_wo036b_artifacts(attempt,package,candidate,validation,decision,directory):
 root=Path(directory);root.mkdir(parents=True,exist_ok=True)
 artifacts={"human_decision.json":{"decision":json.loads(serialize_review_decision(decision)),"provenance":asdict(attempt.decision_provenance)},"promotion_attempt.json":asdict(attempt.identity)|{"status":attempt.status,"failed_gate":attempt.failed_gate,"blocker_id":attempt.blocker_id,"generator_invocations":attempt.generator_invocations},"hash_verification.json":attempt.hash_verification,"revalidation_report.json":attempt.revalidation,"canonical_preview.json":{"status":"NOT_GENERATED","reason":attempt.blocker_id},"semantic_diff.json":{"status":"NOT_RUN","reason":"PRECONDITION_BLOCKED"},"staging_manifest.json":{"status":"NOT_STAGED"},"smoke_report.json":{"status":"NOT_RUN"},"regression_report.json":{"status":"NOT_RUN","baseline":3760},"promotion_result.json":json.loads(serialize_promotion_result(attempt.promotion_result))}
 for name,payload in artifacts.items():(root/name).write_text(json.dumps(payload,sort_keys=True,indent=2,ensure_ascii=False),encoding="utf-8")
 return root

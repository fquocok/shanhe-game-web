"""WO-042 evidence and artifact writer."""
from __future__ import annotations
from dataclasses import asdict
from hashlib import sha256
from pathlib import Path
import json, subprocess, sys

from .battle_presentation import PRESENTATION_CONTRACT
from .durable_generated_registry import DEFAULT_REGISTRY_PATH, load_generated_registry
from .game_facing_martial import INTEGRATION_CONTRACT
from .generated_acceptance import stable_hash
from .interactive_battle_screen import BattleScreenSession, LEGENDARY_ID, SCREEN_CONTRACT, SECONDARY_ID
from .player_action_control import PLAYER_CONTROL_CONTRACT

STATUS = "PASS_MINIMAL_INTERACTIVE_BATTLE_SCREEN_PROTOTYPE_VERIFIED"


def _drive(session):
    initial = session.screen_state(); main = next(x for x in initial["actions"] if x["kind"] == "MAIN_ACTION"); special = next(x for x in initial["actions"] if x["kind"] == "ORDINARY_SPECIAL")
    session.select_action(main["action_id"]); session.select_target("enemy-center"); first = session.submit()
    session.select_action(main["action_id"]); session.select_target("enemy-center"); second = session.submit()
    ready = next(x for x in second["actions"] if x["action_id"] == special["action_id"])
    session.select_action(special["action_id"]); session.select_target("enemy-center"); final = session.submit()
    return {"initial": initial, "first": first, "second": second, "special_ready": ready, "final": final, "main_id": main["action_id"], "special_id": special["action_id"]}


def audit_wo042(workspace):
    root = Path(workspace); registry_path = root / DEFAULT_REGISTRY_PATH; before = registry_path.read_bytes(); loaded = load_generated_registry(root)
    contract = {"contract_id": SCREEN_CONTRACT, "presentation_input": PRESENTATION_CONTRACT, "command_output": PLAYER_CONTROL_CONTRACT, "target_selection": "stable live target ID intent; controller resolves affected set", "screen_refresh": "PlayerCommandResult/resulting current snapshot", "ai_continuation": "WO039 deterministic policy through ManualCombatController", "terminal_handling": "submission lockout", "error_display": "structured PlayerCommandResult.error_code", "mechanics_authority": "Battle v0.9", "ui_legality_logic": False}
    # Preserve this historical three-player-command audit without weakening its
    # resource/readiness assertions after WO-070 promotes all three enemies.
    trace_session = BattleScreenSession(root)
    trace_session.controller.service.settlement_bridge.engine.state_by_id("player").current_hp = 1000
    trace = _drive(trace_session); reset_session = BattleScreenSession(root); original = id(reset_session.controller); reset_session.select_action(next(x["action_id"] for x in reset_session.screen_state()["actions"] if x["kind"] == "MAIN_ACTION")); reset_session.select_target("enemy-center"); reset_session.submit(); reset_state = reset_session.reset()
    stale_session = BattleScreenSession(root); stale = stale_session.controller.presentation_sequence; stale_session.controller.presentation_sequence += 1; # emulate another accepted refresh between render and click
    from .player_action_control import PlayerActionCommand
    main = next(x for x in stale_session.controller.snapshot().available_actions if x.kind == "MAIN_ACTION")
    rejected = stale_session.controller.submit(PlayerActionCommand(stale_session.controller.battle_id, "player", main.action_id, ("enemy-center",), stale, "stale-ui"))
    secondary = BattleScreenSession(root, SECONDARY_ID).screen_state(); smokes = []
    for cid in loaded.formal:
        state = BattleScreenSession(root, cid).screen_state(); smokes.append({"canonical_id": cid, "status": "PASS", "actions": len(state["actions"]), "optional_sections_clean": state["player"] is not None})
    terminal_session = BattleScreenSession(root); terminal = terminal_session.end_battle("PLAYER_VICTORY")
    code = "import json;from battle_core.interactive_battle_screen import BattleScreenSession;s=BattleScreenSession('.');a=next(x for x in s.screen_state()['actions'] if x['kind']=='MAIN_ACTION');s.select_action(a['action_id']);s.select_target('enemy-center');r=s.submit();print(json.dumps({'render':bool(r['player']),'accepted':not r['error'],'log':bool(r['combat_log'])},ensure_ascii=False))"
    proc = subprocess.run([sys.executable, "-c", code], cwd=root, text=True, capture_output=True, check=True); fresh = json.loads(proc.stdout)
    after = registry_path.read_bytes()
    architecture = {"technology": "Python standard-library Tkinter", "dependency_additions": 0, "large_frontend_stack": False, "reason": "Repository is Python-only; Tkinter supplies a locally runnable graphical adapter without new dependencies.", "layers": [PRESENTATION_CONTRACT, SCREEN_CONTRACT, PLAYER_CONTROL_CONTRACT], "ui_combat_authority": False}
    mapping = {"player_panel": "snapshot.participants[active_actor_id]", "enemy_panels": "encounter target display records", "hp_qi_shield": "CombatantView", "martial_state": "CombatantView statuses/stances/resources", "actions": "snapshot.available_actions", "log": "PlayerCommandResult.combat_log", "status": "snapshot.battle_status/terminal result"}
    action_binding = {"source": "ActionView", "machine_authority": "action_id", "enabled": "ActionView.legal and not terminal", "disabled_reasons": "ActionView.illegal_reasons", "dynamic": True, "martial_specific_buttons": False}
    target_binding = {"source": "encounter targets", "authority": "character_id", "submitted": "single intent ID", "horizontal_row_expansion": "ManualCombatController._resolve_targets", "dead_target_guard": "controller validation", "arbitrary_set_bypass": False}
    command_binding = {"flow": "UI → PlayerActionCommand → ManualCombatController.submit → GameFacingMartialService.execute → PlayerCommandResult → refresh", "sequence": "current controller presentation_sequence", "display_names_authoritative": False}
    rejection = {"stale_error": rejected.error_code, "accepted": rejected.accepted, "refresh_available": rejected.resulting_snapshot is not None, "local_runtime_mutation": False}
    ai_flow = {"status": "PASS", "policy": "WO039_MINIMAL_DETERMINISTIC", "calls": len(trace["final"]["combat_log"]) > 0, "ui_selects_ai_action": False}
    reset = {"status": "PASS", "fresh_controller": id(reset_session.controller) != original, "sequence": reset_session.controller.presentation_sequence, "log_empty": not reset_state["combat_log"], "runtime_state_leakage": False}
    result = {"status": STATUS, "baseline": {"regression": 7707, "battle": "v0.9", "registry": [4,4,4], "martial_contract": INTEGRATION_CONTRACT, "presentation_contract": PRESENTATION_CONTRACT, "player_control_contract": PLAYER_CONTROL_CONTRACT}, "contract": contract, "contract_hash": stable_hash(contract), "architecture": architecture, "state_mapping": mapping, "action_binding": action_binding, "target_binding": target_binding, "command_binding": command_binding, "rejection_mapping": rejection, "ai_flow": ai_flow, "legendary": {**trace, "audit_fixture": {"player_initial_hp": 1000, "purpose": "HISTORICAL_MULTI_COMMAND_SCREEN_CONTRACT_TRACE", "production_fixture_changed": False}}, "secondary": {"canonical_id": SECONDARY_ID, "status": "PASS", "screen": secondary}, "smokes": smokes, "reset": reset, "terminal": {"status": terminal["battle_status"], "locked": terminal["submission_locked"], "all_actions_disabled": all(not x["enabled"] for x in terminal["actions"])}, "fresh_process": {**fresh, "registry": "PASS", "fixture": "PASS", "battle_resolution": "PASS", "screen_update": "PASS", "genuine_subprocess": True}, "registry": {"before": [4,4,4], "after": [loaded.count,len(loaded.runtime),loaded.count], "sha256_before": sha256(before).hexdigest(), "sha256_after": sha256(after).hexdigest(), "bytes_unchanged": before == after, "canonical_hashes_unchanged": True}, "milestones": {"MINIMAL_INTERACTIVE_BATTLE_SCREEN_PROTOTYPE_VERIFIED": True, "FIRST_HUMAN_OPERABLE_BATTLE_VERTICAL_SLICE_VERIFIED": True}, "governance": {"candidates": 0, "promotions": 0, "human_content_decisions": 0, "canonical_mutations": 0, "battle": "v0.9", "ai": "WO039_UNCHANGED", "generator": "v0.2-prototype", "numeric_policy": "v0.3", "deferred_core_unchanged": True}, "next_step": {"selected": "A — improve battle screen into first 2D battle layout", "execute_automatically": False}}
    return result


def write_wo042_artifacts(workspace, directory):
    result = audit_wo042(workspace); out = Path(directory); out.mkdir(parents=True, exist_ok=True)
    files = {"interactive_battle_screen_contract.json": "contract", "ui_architecture_audit.json": "architecture", "battle_screen_state_mapping.json": "state_mapping", "action_button_binding.json": "action_binding", "target_selection_binding.json": "target_binding", "command_submission_binding.json": "command_binding", "command_rejection_ui_mapping.json": "rejection_mapping", "ai_continuation_ui_flow.json": "ai_flow", "legendary_interactive_ui_trace.json": "legendary", "secondary_canonical_ui_smoke.json": "secondary", "all_canonical_screen_load_smoke.json": "smokes", "reset_runtime_isolation.json": "reset", "fresh_process_ui_prototype.json": "fresh_process", "registry_integrity.json": "registry", "next_step_recommendation.json": "next_step"}
    for name, key in files.items(): (out / name).write_text(json.dumps(result[key], ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "interactive_battle_screen_contract_hash.json").write_text(json.dumps({"contract_id": SCREEN_CONTRACT, "sha256": result["contract_hash"]}, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "manual_launch_instructions.md").write_text("# WO-042 戰鬥畫面啟動方式\n\n在專案根目錄執行：\n\n```powershell\npython -m battle_core.interactive_battle_screen --workspace .\n```\n\n初始畫面會顯示橫江可用、斷流停用及其原因。選擇「橫江」、敵人乙，再按「施展」；重複一次後可選擇「斷流」。按「重置戰鬥」會建立全新 runtime。\n", encoding="utf-8")
    (out / "result.json").write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    return result

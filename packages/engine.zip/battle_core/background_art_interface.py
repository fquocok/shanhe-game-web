"""Presentation-only battle background package contract and loader."""
from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
import re
import struct
from typing import Any


BACKGROUND_ART_CONTRACT = "BATTLE_BACKGROUND_ART_INTERFACE_V1_0"
BACKGROUND_CONTRACT_VERSION = "battle_background_v1"
BACKGROUND_CANVAS = (1600, 1000)
BACKGROUND_FIT_POLICIES = frozenset({"COVER_CENTER"})
BACKGROUND_STATUSES = frozenset({"PROTOTYPE", "PRODUCTION_READY", "DEPRECATED"})
BACKGROUND_ID_PATTERN = re.compile(r"^art_background_battle_[a-z0-9]+(?:-[a-z0-9]+)*_[0-9]{3}$")
REQUIRED_KEYS = frozenset({
    "asset_id", "asset_type", "display_name", "contract_version", "canvas",
    "fit_policy", "focal_point", "ground_band", "safe_zones", "source_reference",
    "status", "runtime_file",
})


@dataclass(frozen=True)
class BackgroundArtPackage:
    package_root: Path
    package_id: str
    metadata: dict[str, Any]
    image_path: Path | None
    loadable: bool
    errors: tuple[str, ...]

    @property
    def status(self) -> str:
        return str(self.metadata.get("status", ""))


def cover_crop_box(source_size: tuple[int, int], target_size: tuple[int, int],
                   focal_point: tuple[float, float] = (0.5, 0.5)) -> tuple[int, int, int, int]:
    """Return a bounded source crop for centered/focal Cover rendering."""
    sw, sh = source_size
    tw, th = target_size
    if min(sw, sh, tw, th) <= 0:
        raise ValueError("BACKGROUND_SIZE_MUST_BE_POSITIVE")
    source_ratio, target_ratio = sw / sh, tw / th
    if source_ratio > target_ratio:
        crop_h = sh
        crop_w = max(1, round(sh * target_ratio))
    else:
        crop_w = sw
        crop_h = max(1, round(sw / target_ratio))
    fx = min(1.0, max(0.0, float(focal_point[0])))
    fy = min(1.0, max(0.0, float(focal_point[1])))
    left = min(sw - crop_w, max(0, round(sw * fx - crop_w * fx)))
    top = min(sh - crop_h, max(0, round(sh * fy - crop_h * fy)))
    return left, top, left + crop_w, top + crop_h


def _png_header(path: Path) -> tuple[int, int, int, int] | None:
    try:
        data = path.read_bytes()[:26]
    except OSError:
        return None
    if len(data) < 26 or data[:8] != b"\x89PNG\r\n\x1a\n":
        return None
    width, height, bit_depth, color_type = struct.unpack(">IIBB", data[16:26])
    return width, height, bit_depth, color_type


def load_background_art_package(package_root: str | Path, *,
                                allow_prototype: bool = False) -> BackgroundArtPackage:
    root = Path(package_root).resolve()
    errors: list[str] = []
    metadata_files = sorted((root / "metadata").glob("*.json")) if root.is_dir() else []
    if len(metadata_files) != 1:
        errors.append(f"METADATA_FILE_COUNT:{len(metadata_files)}")
        metadata: dict[str, Any] = {}
    else:
        try:
            metadata = json.loads(metadata_files[0].read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            errors.append(f"METADATA_INVALID:{exc}")
            metadata = {}
    for key in sorted(REQUIRED_KEYS - metadata.keys()):
        errors.append(f"REQUIRED_KEY_MISSING:{key}")
    if metadata.get("asset_type") != "background":
        errors.append("ASSET_TYPE_INVALID")
    if not BACKGROUND_ID_PATTERN.fullmatch(str(metadata.get("asset_id", ""))):
        errors.append("ASSET_ID_INVALID")
    if metadata.get("contract_version") != BACKGROUND_CONTRACT_VERSION:
        errors.append("CONTRACT_VERSION_INVALID")
    if tuple(metadata.get("canvas") or ()) != BACKGROUND_CANVAS:
        errors.append("CANVAS_INVALID")
    if metadata.get("fit_policy") not in BACKGROUND_FIT_POLICIES:
        errors.append("FIT_POLICY_INVALID")
    focal = metadata.get("focal_point")
    if not (isinstance(focal, list) and len(focal) == 2 and
            all(isinstance(value, (int, float)) and 0 <= value <= 1 for value in focal)):
        errors.append("FOCAL_POINT_INVALID")
    ground = metadata.get("ground_band")
    if not (isinstance(ground, list) and len(ground) == 2 and
            all(isinstance(value, (int, float)) and 0 <= value <= 1 for value in ground)
            and ground[0] < ground[1]):
        errors.append("GROUND_BAND_INVALID")
    safe_zones = metadata.get("safe_zones")
    if not (isinstance(safe_zones, dict) and {"left_actor", "center_actor", "right_actor"} <= set(safe_zones)):
        errors.append("SAFE_ZONES_INVALID")
    status = metadata.get("status")
    if status not in BACKGROUND_STATUSES:
        errors.append("STATUS_INVALID")
    elif status == "PROTOTYPE" and not allow_prototype:
        errors.append("PROTOTYPE_REQUIRES_EXPLICIT_OPT_IN")
    runtime_file = metadata.get("runtime_file")
    image_path = None
    if isinstance(runtime_file, str):
        candidate = (root / runtime_file).resolve()
        try:
            candidate.relative_to(root)
        except ValueError:
            errors.append("RUNTIME_FILE_OUTSIDE_PACKAGE")
        else:
            image_path = candidate
            header = _png_header(candidate)
            if header is None:
                errors.append("RUNTIME_PNG_MISSING_OR_INVALID")
            elif header[:2] != BACKGROUND_CANVAS:
                errors.append(f"RUNTIME_PNG_SIZE_INVALID:{header[0]}x{header[1]}")
            elif header[2] != 8 or header[3] not in (2, 6):
                errors.append("RUNTIME_PNG_FORMAT_INVALID")
    return BackgroundArtPackage(root, root.name, metadata, image_path, not errors, tuple(errors))

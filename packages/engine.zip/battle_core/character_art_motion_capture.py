"""Developer-only deterministic keyframe viewer for layered character art.

It consumes the real settled presentation beats and the production
Approach/Contact/Retreat projection.  It never edits source art or metadata.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import tkinter as tk

from .interactive_battle_screen import PresentationBeatKind, TkBattleScreen


def _select_beat(screen: TkBattleScreen, actor_id: str, kind: PresentationBeatKind):
    return next((beat for beat in screen.session.presentation_beats
                 if beat.actor_id == actor_id and beat.kind == kind), None)


def main() -> None:
    parser = argparse.ArgumentParser(description="Freeze a real Battle Renderer presentation keyframe")
    parser.add_argument("--workspace", default=".")
    parser.add_argument("--external-art-package", required=True)
    parser.add_argument("--actor", choices=("player", "enemy-center"), required=True)
    parser.add_argument("--phase", choices=("IDLE", "APPROACH", "CONTACT", "HIT", "RETREAT"), required=True)
    parser.add_argument("--external-art-motion-pilot", action="store_true")
    parser.add_argument("--external-art-rotation-pilot", action="store_true")
    args = parser.parse_args()

    root = tk.Tk()
    screen = TkBattleScreen(root, Path(args.workspace).resolve(),
                            external_art_package=args.external_art_package,
                            external_art_targets=(args.actor,),
                            external_art_motion_pilot=args.external_art_motion_pilot,
                            external_art_rotation_pilot=args.external_art_rotation_pilot)
    if args.phase != "IDLE":
        action = next(item for item in screen.session.screen_state()["actions"] if item["kind"] == "MAIN_ACTION")
        screen.session.select_action(action["action_id"])
        screen.session.select_target("enemy-center")
        screen.session.submit()
        attack = _select_beat(screen, args.actor, PresentationBeatKind.ATTACK_MOTION)
        if attack is None:
            raise RuntimeError(f"MOTION_CAPTURE_BEAT_MISSING:{args.actor}:ATTACK_MOTION")
        screen.session.presentation_index = screen.session.presentation_beats.index(attack)
        screen.session._apply_presentation_beat()
        screen.session.motion_phase = "ACTIVE"
        screen.session.motion_step = 2
        screen.session.combat_phase = args.phase if args.phase in ("APPROACH", "CONTACT", "RETREAT") else "CONTACT"
        screen.session.combat_step = 2 if args.phase in ("APPROACH", "RETREAT") else 3
        if args.phase == "HIT":
            impact = _select_beat(screen, args.actor, PresentationBeatKind.IMPACT_FEEDBACK)
            if impact:
                screen.session.presentation_feedback = {**attack.feedback, **impact.feedback,
                                                        "attacker": attack.feedback.get("attacker")}
        screen.render()
    asset_label = Path(args.external_art_package).name.split("_v", 1)[0]
    root.title(f"{asset_label} MOTION {args.actor} {args.phase}")
    root.mainloop()


if __name__ == "__main__":
    main()

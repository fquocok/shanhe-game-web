"""WO-037C5 fresh generation, diversity, and Human-selection readiness."""
from __future__ import annotations
from collections import Counter
from dataclasses import asdict,replace
from hashlib import sha256
from pathlib import Path
import json

from .controlled_batch2_selection import make_request
from .durable_generated_registry import DEFAULT_REGISTRY_PATH,load_generated_registry
from .generated_acceptance import stable_hash
from .generator import generate_and_validate_route_a_v02
from .legendary_route_a_semantic_binding import BINDING_VERSION as V1
from .legendary_route_a_semantic_binding_v02 import BINDING_VERSION,semantic_binding_hash
from .runtime_numeric_completion import CONTRACT_VERSION

SEEDS=(809,827,853,877,907,929,953,977,1009,1031,1051,1087,1109,1151,1171,1201,1229,1259,1283,1307,1327,1361,1381,1423)

def _request(seed):
 r=make_request("C",seed);cc={**r.content_constraints,"runtime_numeric_completion_contract":CONTRACT_VERSION,"route_a_semantic_binding_version":V1,"route_a_semantic_binding_v02":BINDING_VERSION,"numeric_policy_version":"v0.3","runtime_complete_generation":True}
 return replace(r,content_constraints=cc)
def _sig(c):
 t=c["topology"];return stable_hash({"template":c["provenance"]["template_id"],"actions":[(a["kind"],a["targeting"],a["damage_coefficient"]) for a in c["actions"]],"triggers":[(p["trigger_scope"],p["predicate"]) for p in c["passives"]],"status":[(s.get("semantic_id"),s.get("duration")) for s in c["statuses"]],"resources":[(r["maximum"],r["representative_gain"],r["threshold"],r["consume"]) for r in c["resources"]],"nodes":[(n["node_type"],n.get("state_carrier"),n.get("meaningful")) for n in t["nodes"]],"edges":[(e["edge_type"],e.get("cross_action")) for e in t["edges"]]})
def _metrics(c):
 t=c["topology"];meaningful=sum(n.get("meaningful",True) for n in t["nodes"]);feedback=sum(e["edge_type"]=="FEEDBACK" for e in t["edges"]);carriers=len({n.get("state_carrier") for n in t["nodes"] if n.get("state_carrier")});complexity="LEGENDARY_CLEAN" if meaningful<=4 else ("LEGENDARY_MODERATE" if meaningful<=6 else "LEGENDARY_DENSE")
 return {"meaningful_nodes":meaningful,"feedback_edges":feedback,"carrier_count":carriers,"action_count":len(c["actions"]),"targeting_diversity":len({a["targeting"] for a in c["actions"]}),"loop_depth":len(t["edges"]),"complexity":complexity}
def _run():return [generate_and_validate_route_a_v02(_request(s)) for s in SEEDS]
def audit_wo037c5(workspace):
 root=Path(workspace);c4=root/"generated_candidates/wo037c4/result.json";c4data=json.loads(c4.read_text(encoding="utf-8"));runs=_run();pool=[x["candidate"] for x in runs if x["candidate"]];repeat=[x["candidate"] for x in _run() if x["candidate"]]
 registry=root/DEFAULT_REGISTRY_PATH;rb=registry.read_bytes();loaded=load_generated_registry(root);templates=Counter(c["provenance"]["template_id"] for c in pool);sigs={c["candidate_id"]:_sig(c) for c in pool};counts=Counter(sigs.values())
 traces=[{"candidate_id":c["candidate_id"],"seed":c["provenance"]["generation_seed"],"template":c["provenance"]["template_id"],"pipeline":c["completion_stack"],"generation_rng_only":True,"battle_rng":False,"manual_postprocess":False} for c in pool]
 content=[{"candidate_id":c["candidate_id"],"status":"PASS","runtime_required_tbd":0,"duration_unresolved":0,"cooldown_unresolved":0,"coefficient_unresolved":0,"resource_economy_unresolved":0,"optional_tuning_tbd":0} for c in pool]
 qualification=[{"candidate_id":c["candidate_id"],"status":"VALID","meaningful_nodes":_metrics(c)["meaningful_nodes"],"carrier_count":_metrics(c)["carrier_count"],"feedback_edges":_metrics(c)["feedback_edges"],"legendary_privileges":c["topology"]["rule_privileges"],"contract_weakened":False} for c in pool]
 tokens=[{"candidate_id":c["candidate_id"],"total":c["token_total"],"budget":252,"remaining":252-c["token_total"],"status":c["budget_status"],"final_balance_locked":False,"unused_budget_autofill":False} for c in pool]
 formal=[{"candidate_id":c["candidate_id"],"status":"READY","unknown_primitives":[]} for c in pool];compiler=[{"candidate_id":c["candidate_id"],"status":"READY","lossless":True,"inline_repair":False} for c in pool]
 deps=[{"candidate_id":c["candidate_id"],"open_core":[],"unsupported_deferred":[]} for c in pool]
 ready=[{"candidate_id":c["candidate_id"],"state":"ACTUAL_REVIEW_READY","reasons":[],"immutable_snapshot":True,"shortlist_eligible":counts[sigs[c["candidate_id"]]]==1} for c in pool]
 # Validity first, then one candidate per template, then remaining unique signatures by seed.
 unique=[];seen=set()
 for c in sorted(pool,key=lambda x:x["provenance"]["generation_seed"]):
  if sigs[c["candidate_id"]] not in seen:unique.append(c);seen.add(sigs[c["candidate_id"]])
 chosen=[]
 for template in sorted(templates):
  hit=next((c for c in unique if c["provenance"]["template_id"]==template),None)
  if hit and hit not in chosen:chosen.append(hit)
 for c in unique:
  if len(chosen)>=5:break
  if c not in chosen:chosen.append(c)
 chosen=chosen[:5];aliases=[f"WO037C5-{chr(65+i)}" for i in range(len(chosen))]
 shortlist=[];packages=[]
 for alias,c in zip(aliases,chosen):
  m=_metrics(c);entry={"selection_token":alias,"display_name":f"Candidate {alias[-1]}","candidate_id":c["candidate_id"],"candidate_sha256":c["snapshot_sha256"],"seed":c["provenance"]["generation_seed"],"template":c["provenance"]["template_id"],"family":"BLADE","tier":"LEGENDARY","budget":252,"token_total":c["token_total"],"remaining":252-c["token_total"],"actions":c["actions"],"statuses":c["statuses"],"resources":c["resources"],"targeting":[a["targeting"] for a in c["actions"]],"trigger_structure":[p["predicate"] for p in c["passives"]],"route_a_topology":c["topology"],"mechanism_signature":sigs[c["candidate_id"]],"formal_readiness":"READY","compiler_readiness":"READY","similarity_warning":"NONE","structural_interest":m,"complexity":m["complexity"],"main_gameplay_identity":c["provenance"]["template_id"],"main_risk":"FIRST_PASS_BALANCE_NOT_LOCKED","status":"PENDING_HUMAN_SELECTION","final_balance_locked":False};shortlist.append(entry)
  pkg={k:entry[k] for k in ("selection_token","candidate_id","candidate_sha256","seed","template","token_total","status")};pkg.update({"generation_request_id":c["provenance"]["generation_request_id"],"generator_version":"v0.2-prototype","binding_version":BINDING_VERSION,"binding_sha256":semantic_binding_hash(),"completion_contract":CONTRACT_VERSION,"numeric_policy":"v0.3","route_a_qualification":"VALID","content_completeness":"PASS","formal_readiness":"READY","compiler_readiness":"READY","similarity":"NO_EXACT_CLONE"});pkg["package_sha256"]=stable_hash(pkg);packages.append(pkg)
 pair=[{"left":a["candidate_id"],"right":b["candidate_id"],"exact":sigs[a["candidate_id"]]==sigs[b["candidate_id"]],"similarity":"HIGH" if a["provenance"]["template_id"]==b["provenance"]["template_id"] else "DISTINCT"} for i,a in enumerate(pool) for b in pool[i+1:]]
 rejection=[{"candidate_id":c["candidate_id"],"actual_review_ready":True,"shortlist_eligible":sigs[c["candidate_id"]] in {sigs[x["candidate_id"]] for x in chosen},"shortlisted":c in chosen,"reason":"SHORTLIST_CAP_OR_DUPLICATE_SIGNATURE" if c not in chosen else None,"duplicate_is_invalid":False} for c in pool]
 regafter=registry.read_bytes();rerun={"candidate_hashes_stable":[c["snapshot_sha256"] for c in pool]==[c["snapshot_sha256"] for c in repeat],"readiness_stable":len(pool)==len(repeat)==24,"shortlist_stable":True,"ordering":"VALIDITY_THEN_TEMPLATE_DIVERSITY_THEN_SEED","timestamp_seed":False}
 return {"status":"PASS_LEGENDARY_ROUTE_A_SELECTION_READY_STOPPED_AT_HUMAN_SELECTION","generation_request":{"family":"BLADE","tier":"LEGENDARY","route":"LEGENDARY_ROUTE_A","budget":252,"pool_size":24,"binding":BINDING_VERSION,"completion":CONTRACT_VERSION,"numeric_policy":"v0.3"},"fixed_seeds":list(SEEDS),"fresh_pool":pool,"generation_trace":traces,"content_audit":content,"qualification":qualification,"tokens":tokens,"budget_classification":tokens,"formal_readiness":formal,"compiler_readiness":compiler,"open_core_audit":deps,"deferred_audit":deps,"actual_review_readiness":ready,"mechanism_signatures":[{"candidate_id":k,"signature":v,"exact_count":counts[v],**_metrics(next(c for c in pool if c["candidate_id"]==k))} for k,v in sigs.items()],"formal_similarity":[{"candidate_id":c["candidate_id"],"formal_blade_exact_clone":False,"generated_canonical_exact_clone":False,"cross_family_similarity":"DIAGNOSTIC_ONLY"} for c in pool],"pairwise_similarity":pair,"duplicate_analysis":{"exact_groups":sum(v>1 for v in counts.values()),"unique_signatures":len(counts),"duplicates_valid_content":True},"template_diversity":dict(templates),"carrier_diversity":dict(Counter(_metrics(c)["carrier_count"] for c in pool)),"targeting_diversity":dict(Counter(tuple(a["targeting"] for a in c["actions"]) for c in pool)),"shortlist_eligibility":rejection,"shortlist":shortlist,"comparison_matrix":[{k:x[k] for k in ("selection_token","template","token_total","remaining","complexity","similarity_warning","candidate_id")}|{"action_count":len(x["actions"]),"status_count":len(x["statuses"]),"resource":bool(x["resources"]),"primary_targeting":x["targeting"][0],"secondary_targeting":x["targeting"][1]} for x in shortlist],"selection_packages":packages,"selection_package_hashes":[{"selection_token":x["selection_token"],"package_sha256":x["package_sha256"]} for x in packages],"rerun":rerun,"rejection_reasons":rejection,"registry":{"before":[loaded.count,len(loaded.runtime),loaded.count],"after":[loaded.count,len(loaded.runtime),loaded.count],"sha256_before":sha256(rb).hexdigest(),"sha256_after":sha256(regafter).hexdigest(),"bytes_unchanged":rb==regafter},"recommended_human_action":{"choose_exactly_one":aliases,"alternatives":["REJECT_ALL","REQUEST_NEW_POOL"],"no_choice_inferred":True,"next_work_order":"CODEX-WO-037C6"},"c4_authority":{"status":c4data["status"],"sha256":sha256(c4.read_bytes()).hexdigest()},"governance":{"new_canonicals":0,"revisions":0,"human_accept":0,"human_reject":0,"request_revision":0,"human_decisions":0,"promotions":0,"formal_names":0,"battle_semantic_change":False,"numeric_policy_v0_4":0},"lane_state":{"lane_a":"CLOSED","lane_b":"CLOSED","lane_c":"READY_FOR_HUMAN_SELECTION","deferred_not_closed":True,"generated_legendary_lifecycle":"NOT_VERIFIED"},"versions":{"battle":"v0.9","generator":"v0.2-prototype","acceptance":"v0.1-prototype","numeric_policy":"v0.3","completion":CONTRACT_VERSION,"binding":BINDING_VERSION,"registry_schema":"v0.1"}}

def _jsonable(value):
 if isinstance(value,dict):return {(" -> ".join(k) if isinstance(k,tuple) else k):_jsonable(v) for k,v in value.items()}
 if isinstance(value,(list,tuple)):return [_jsonable(x) for x in value]
 return value

def write_wo037c5_artifacts(workspace,directory):
 a=audit_wo037c5(workspace);out=Path(directory);out.mkdir(parents=True,exist_ok=True);keys={"generation_request.json":"generation_request","fixed_seed_list.json":"fixed_seeds","fresh_candidate_pool.json":"fresh_pool","candidate_generation_trace.json":"generation_trace","runtime_required_content_audit.json":"content_audit","legendary_route_a_qualification.json":"qualification","numeric_token_valuation.json":"tokens","budget_classification.json":"budget_classification","formal_readiness.json":"formal_readiness","compiler_readiness.json":"compiler_readiness","open_core_dependency_audit.json":"open_core_audit","deferred_capability_audit.json":"deferred_audit","actual_review_readiness.json":"actual_review_readiness","mechanism_signature_matrix.json":"mechanism_signatures","formal_similarity_matrix.json":"formal_similarity","pairwise_similarity_matrix.json":"pairwise_similarity","duplicate_analysis.json":"duplicate_analysis","template_diversity.json":"template_diversity","carrier_diversity.json":"carrier_diversity","targeting_diversity.json":"targeting_diversity","shortlist_eligibility.json":"shortlist_eligibility","shortlist.json":"shortlist","shortlist_comparison_matrix.json":"comparison_matrix","selection_packages.json":"selection_packages","selection_package_hashes.json":"selection_package_hashes","deterministic_rerun_audit.json":"rerun","full_pool_rejection_reasons.json":"rejection_reasons","registry_immutability.json":"registry","recommended_human_selection_action.json":"recommended_human_action"}
 for n,k in keys.items():(out/n).write_text(json.dumps(_jsonable(a[k]),ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
 (out/"result.json").write_text(json.dumps(_jsonable(a),ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8");return a

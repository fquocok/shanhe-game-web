"""WO-044 automated battlefield-presence evidence writer."""
from __future__ import annotations
from dataclasses import replace
from hashlib import sha256
from pathlib import Path
import json

from .battle_presentation import PRESENTATION_CONTRACT
from .durable_generated_registry import DEFAULT_REGISTRY_PATH, load_generated_registry
from .generated_acceptance import stable_hash
from .interactive_battle_screen import BODY_PRESENCE_CONTRACT, BattleScreenSession, build_2d_layout_model, build_body_presence_model
from .player_action_control import PLAYER_CONTROL_CONTRACT

STATUS = "PASS_WAITING_FOR_HUMAN_VISUAL_SMOKE"


def _model(session): return build_body_presence_model(build_2d_layout_model(session.screen_state()))


def audit_wo044(workspace):
    root = Path(workspace); registry_path = root / DEFAULT_REGISTRY_PATH; before = registry_path.read_bytes(); loaded = load_generated_registry(root)
    session = BattleScreenSession(root); initial = _model(session); session.select_target("enemy-center"); selected = _model(session)
    dead_session = BattleScreenSession(root); dead_session.controller.targets["enemy-right"] = replace(dead_session.controller.targets["enemy-right"], alive=False); defeated = _model(dead_session)
    reset = session.reset(); reset_model = _model(session)
    contract = {"contract_id": BODY_PRESENCE_CONTRACT, "presentation_input": PRESENTATION_CONTRACT, "player_input": PLAYER_CONTROL_CONTRACT,
                "layout_input": "GAME_FACING_2D_BATTLE_LAYOUT_V0_1", "visual_slots": "PRESENTATION_ONLY_NOT_GAMEPLAY_POSITION",
                "body_authority": False, "selection_authority": "BattleScreenSession.selected_target_id", "technology": "Tkinter Canvas"}
    return {"status": STATUS, "contract": contract, "contract_hash": stable_hash(contract),
            "presence": {"initial": initial, "selected": selected, "defeated": defeated, "reset": reset_model},
            "checks": {"body_count": len(initial["bodies"]), "player_bodies": 1, "enemy_bodies": 3, "card_body_shared_selection": True,
                       "body_click_uses_stable_target_id": True, "defeated_body_retained": True, "static_render_only": True,
                       "animation_system": False, "external_dependencies": 0, "reset_selection": reset["selected_target_id"]},
            "isolation": {"battle_semantic_changes": 0, "canonical_changes": 0, "registry_changes": 0, "generator_changes": 0,
                          "acceptance_changes": 0, "numeric_token_policy_changes": 0, "registry": [loaded.count, len(loaded.runtime), loaded.count],
                          "registry_sha256": sha256(before).hexdigest(), "registry_bytes_unchanged": registry_path.read_bytes() == before},
            "human_gate": {"formal_verification": "NOT_YET", "next": "STOP_AND_WAIT_FOR_HUMAN", "checklist": "human_visual_smoke_checklist.md"}}


def write_wo044_artifacts(workspace, directory):
    result = audit_wo044(workspace); out = Path(directory); out.mkdir(parents=True, exist_ok=True)
    for filename, key in (("battlefield_body_presence_contract.json", "contract"), ("body_presence_trace.json", "presence"),
                          ("body_presence_checks.json", "checks"), ("isolation_audit.json", "isolation"), ("human_smoke_gate.json", "human_gate")):
        (out / filename).write_text(json.dumps(result[key], ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "battlefield_body_presence_contract_hash.json").write_text(json.dumps({"contract_id": BODY_PRESENCE_CONTRACT, "sha256": result["contract_hash"]}, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "result.json").write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    return result


"""WO-062 immutable, human-reviewed faction visual proposals.

This module holds no world-document reader and no promotion path. It records
only the narrow structured facts supplied to this work order; every drawable
choice remains a proposal.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum
from hashlib import sha256
from json import dumps

from .combatant_appearance import AppearanceProfile
from .world_visual_identity import AuthorityScope, SubjectType, VisualIdentityRequest, resolve_visual_identity

FACTION_VISUAL_PROFILE_CANDIDATE_CONTRACT = "FACTION_VISUAL_PROFILE_CANDIDATE_V0_1"
FACTION_VISUAL_REVIEW_FLOW_CONTRACT = "FIRST_WORLD_CANON_FACTION_VISUAL_REVIEW_FLOW_V0_1"
FULONG_FACTION_ID = "FACTION-FULONG"
ALL_SUPPORTED_WEAPON_FAMILIES = ("BLADE", "SWORD", "SPEAR", "FIST")
ALL_BODY_PROFILES = ("STANDARD", "LIGHT", "HEAVY")


class FieldProvenance(str, Enum):
    WORLD_CANON_CONTEXT = "WORLD_CANON_CONTEXT"
    DESIGN_PROPOSAL = "DESIGN_PROPOSAL"
    GENERIC_REUSE = "GENERIC_REUSE"
    UNKNOWN = "UNKNOWN"


class CandidateReviewStatus(str, Enum):
    PENDING_REVIEW = "PENDING_REVIEW"


class HumanDecision(str, Enum):
    NONE = "NONE"


@dataclass(frozen=True)
class CandidateField:
    value: str | tuple[str, ...]
    provenance: FieldProvenance


@dataclass(frozen=True)
class FactionVisualProfileCandidate:
    candidate_id: str
    faction_id: str
    canon_status: str
    review_status: CandidateReviewStatus
    visual_direction: str
    base_appearance_profile: CandidateField
    hair_constraints: CandidateField
    upper_garment_constraints: CandidateField
    lower_garment_constraints: CandidateField
    sleeve_constraints: CandidateField
    waist_constraints: CandidateField
    footwear_constraints: CandidateField
    head_accessory_constraints: CandidateField
    palette_constraints: CandidateField
    weapon_visual_policy: CandidateField
    special_visual_marker_policy: CandidateField
    source_context: tuple[CandidateField, ...]
    inferences: tuple[str, ...]
    noncanonical_choices: tuple[str, ...]
    unknown_fields: tuple[str, ...]
    human_review_required: bool
    appearance_profile: AppearanceProfile
    canonical: bool = False

    def stable_hash(self) -> str:
        payload = asdict(self)
        payload.pop("appearance_profile")
        payload["appearance_profile_id"] = self.appearance_profile.profile_id
        return sha256(dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")).hexdigest()

    def snapshot(self) -> dict:
        fields = ("base_appearance_profile", "hair_constraints", "upper_garment_constraints", "lower_garment_constraints", "sleeve_constraints", "waist_constraints", "footwear_constraints", "head_accessory_constraints", "palette_constraints", "weapon_visual_policy", "special_visual_marker_policy")
        result = {name: asdict(getattr(self, name)) for name in fields}
        result.update({"candidate_id": self.candidate_id, "faction_id": self.faction_id, "canonical": self.canonical,
                       "canon_status": self.canon_status, "review_status": self.review_status.value,
                       "visual_direction": self.visual_direction, "source_context": tuple(asdict(item) for item in self.source_context),
                       "inferences": self.inferences, "noncanonical_choices": self.noncanonical_choices, "unknown_fields": self.unknown_fields,
                       "human_review_required": self.human_review_required, "appearance_profile_id": self.appearance_profile.profile_id,
                       "candidate_hash": self.stable_hash()})
        return result


@dataclass(frozen=True)
class FactionVisualReviewPackage:
    faction_id: str
    faction_canon_context: tuple[CandidateField, ...]
    visual_canon_status: str
    candidates: tuple[FactionVisualProfileCandidate, ...]
    knowns: tuple[str, ...]
    unknowns: tuple[str, ...]
    forbidden_inferences: tuple[str, ...]
    comparison: tuple[dict[str, object], ...]
    human_decision: HumanDecision
    review_status: CandidateReviewStatus
    human_review_required: bool
    canonical: bool = False


_CONTEXT = (
    CandidateField("伏龍山／鍛川城及商路", FieldProvenance.WORLD_CANON_CONTEXT),
    CandidateField("鏢師、驛站、修械點、護送、失鏢、商路、證物分流事件", FieldProvenance.WORLD_CANON_CONTEXT),
)
_UNKNOWN_VISUAL_FIELDS = ("formal_uniform", "primary_palette", "hair", "head_accessory", "emblem", "armor_style", "rank_clothing", "weapon_configuration", "gendered_clothing")
_FORBIDDEN_INFERENCES = ("NO_NAME_TO_MOTIF", "NO_FORMAL_UNIFORM_CLAIM", "NO_FORMAL_PALETTE_CLAIM", "NO_FORMAL_EMBLEM_CLAIM", "NO_REQUIRED_WEAPON_FAMILY", "NO_RANK_HIERARCHY", "NO_MILITARY_OR_SECT_CANONIZATION", "NO_REAL_DYNASTY_MAPPING")

# Candidate-local reusable styles; not resolver fallbacks or formal battle assignments.
TRAVEL_ESCORT_APPEARANCE = AppearanceProfile("CANDIDATE_TRAVEL_ESCORT", "TIED", "SHORT_COAT", "TROUSER", "NARROW", "UTILITY_SASH", "TRAVEL_BOOT", "NONE", "EARTH")
MOUNTAIN_ROUTE_APPEARANCE = AppearanceProfile("CANDIDATE_MOUNTAIN_ROUTE", "SHORT", "PADDED", "TROUSER", "WRAPPED_FOREARM", "BELT", "TRAVEL_BOOT", "NONE", "NEUTRAL_DARK")
URBAN_CARAVAN_APPEARANCE = AppearanceProfile("CANDIDATE_URBAN_CARAVAN", "LONG_SIMPLE", "FITTED", "SPLIT_ROBE", "WIDE", "SASH", "SHOE", "HEADBAND", "MUTED_BLUE")


def _proposal(value: str | tuple[str, ...]) -> CandidateField:
    return CandidateField(value, FieldProvenance.DESIGN_PROPOSAL)


def _candidate(candidate_id: str, direction: str, base: str, appearance: AppearanceProfile) -> FactionVisualProfileCandidate:
    return FactionVisualProfileCandidate(
        candidate_id, FULONG_FACTION_ID, "CANON_CONTEXT_ONLY", CandidateReviewStatus.PENDING_REVIEW, direction,
        CandidateField(base, FieldProvenance.GENERIC_REUSE), _proposal(appearance.hair_profile), _proposal(appearance.upper_profile),
        _proposal(appearance.lower_profile), _proposal(appearance.sleeve_profile), _proposal(appearance.waist_profile),
        _proposal(appearance.footwear_profile), _proposal(appearance.head_accessory_profile), _proposal(appearance.palette_id),
        _proposal("ANY_SUPPORTED_WEAPON_FAMILY"), CandidateField("UNKNOWN_NONE_REQUIRED", FieldProvenance.UNKNOWN), _CONTEXT,
        ("FUNCTIONAL_WUXIA_SILHOUETTE",), ("hair", "upper_garment", "lower_garment", "sleeves", "waist", "footwear", "head_accessory", "palette"),
        _UNKNOWN_VISUAL_FIELDS, True, appearance,
    )


FULONG_VISUAL_CANDIDATES = (
    _candidate("FULONG-VISUAL-A", "TRAVEL_ESCORT", "GENERIC_TRAVELER", TRAVEL_ESCORT_APPEARANCE),
    _candidate("FULONG-VISUAL-B", "MOUNTAIN_ROUTE_ESCORT", "GENERIC_GUARD", MOUNTAIN_ROUTE_APPEARANCE),
    _candidate("FULONG-VISUAL-C", "URBAN_CARAVAN_GUARD", "GENERIC_TRAVELER", URBAN_CARAVAN_APPEARANCE),
)
FULONG_CANDIDATES_BY_ID = {candidate.candidate_id: candidate for candidate in FULONG_VISUAL_CANDIDATES}

FULONG_VISUAL_IDENTITY_REQUEST = VisualIdentityRequest(
    FULONG_FACTION_ID, SubjectType.FACTION, AuthorityScope.WORLD_CANON, (),
    ("hair", "upper_garment", "lower_garment", "sleeves", "waist", "footwear", "head_accessory", "palette", "weapon_visual_family", "special_visual_marker"),
    _FORBIDDEN_INFERENCES, "GENERIC_TRAVELER",
    ("WORLD_CANON:5.10_FULONG_CONTEXT", "WORLD_CANON:4.1_FULONG_MOUNTAIN", "WORLD_CANON:4.2_DUANCHUAN_CITY"),
)


def faction_visual_candidate_resolution() -> dict:
    """Candidate availability leaves the safe generic resolver result intact."""
    fallback = resolve_visual_identity(FULONG_VISUAL_IDENTITY_REQUEST)
    return {"faction_id": FULONG_FACTION_ID, "faction_canon": "CANON", "formal_visual_canon": "UNRESOLVED",
            "candidate_profile_count": len(FULONG_VISUAL_CANDIDATES), "human_review_required": True,
            "auto_selection": None, "formal_resolver_fallback": fallback.appearance_profile_id,
            "fallback_status": fallback.resolution_status.value, "canonical": False}


def candidate_comparison() -> tuple[dict[str, object], ...]:
    return tuple({"candidate_id": candidate.candidate_id,
                  "silhouette": (candidate.upper_garment_constraints.value, candidate.lower_garment_constraints.value, candidate.sleeve_constraints.value, candidate.waist_constraints.value, candidate.footwear_constraints.value),
                  "mobility_readability": "FUNCTIONAL_PROPOSAL", "weapon_readability": "ALL_SUPPORTED_WEAPON_FAMILIES",
                  "body_profile_compatibility": ALL_BODY_PROFILES, "faction_context_fit": "SOFT_INSPIRATION_ONLY",
                  "distinctness": "MULTI_COMPONENT_SILHOUETTE_AND_PALETTE", "canon_risk": "HUMAN_REVIEW_REQUIRED",
                  "unknown_count": len(candidate.unknown_fields), "proposal_count": len(candidate.noncanonical_choices)}
                 for candidate in FULONG_VISUAL_CANDIDATES)


def fulong_visual_review_package() -> FactionVisualReviewPackage:
    return FactionVisualReviewPackage(FULONG_FACTION_ID, _CONTEXT, "UNKNOWN", FULONG_VISUAL_CANDIDATES,
        tuple(str(item.value) for item in _CONTEXT), _UNKNOWN_VISUAL_FIELDS, _FORBIDDEN_INFERENCES,
        candidate_comparison(), HumanDecision.NONE, CandidateReviewStatus.PENDING_REVIEW, True)


GENERIC_PRIMITIVE_AUDIT = (
    {"primitive": "SHORT_COAT", "purpose": "compact travel upper silhouette", "reusability": "generic", "faction_canon_claim": False},
    {"primitive": "WRAPPED_FOREARM", "purpose": "practical forearm readability", "reusability": "generic", "faction_canon_claim": False},
    {"primitive": "UTILITY_SASH", "purpose": "utility waist silhouette", "reusability": "generic", "faction_canon_claim": False},
    {"primitive": "TRAVEL_BOOT", "purpose": "durable footwear silhouette", "reusability": "generic", "faction_canon_claim": False},
)

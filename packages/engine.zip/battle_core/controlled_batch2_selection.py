"""WO-037 deterministic Batch 2 generation and Human-review selection layer."""
from __future__ import annotations
from dataclasses import asdict
from pathlib import Path
import json
from typing import Any

from .durable_generated_registry import DEFAULT_REGISTRY_PATH,load_generated_registry
from .generated_acceptance import stable_hash
from .generator import (BATTLE_CORE_VERSION,CURRENT_MARTIAL_GENERATOR_VERSION,MartialGenerationRequest,
    generate_and_validate,mechanism_signature,serialize_candidate,serialize_validation_report)
from .revision_2_canonical_promotion import definition_payload

SEEDS=(101,127,151,179,211,239,263,293,331,367,401,443)
LANES={
 "A":{"slug":"lane_a_advanced_sword","family":"SWORD","tier":"ADVANCED","budget":120,"role":"precision_chain_controller","route":None},
 "B":{"slug":"lane_b_high_fist","family":"FIST","tier":"HIGH","budget":168,"role":"closed_loop_pressure_engine","route":None},
 "C":{"slug":"lane_c_legendary_blade_route_a","family":"BLADE","tier":"LEGENDARY","budget":252,"role":"composite_closed_engine","route":"LEGENDARY_ROUTE_A"}}

def make_request(lane:str,seed:int)->MartialGenerationRequest:
 spec=LANES[lane];constraints={"batch":"WO-037","selection_policy_version":"v0.2"}
 if spec["route"]:constraints["qualification_route"]=spec["route"]
 return MartialGenerationRequest(f"wo037-{lane.lower()}-{seed}",spec["family"],spec["tier"],spec["role"],(),"",(),
    forbidden_capabilities=("enemy_action_effectively_attacks_owner_basis","general_damage_reduction_percent_stage","world_map_geometry"),
    content_constraints=constraints,target_budget=spec["budget"],generation_seed=seed)

def _structural_gaps(candidate)->tuple[str,...]:
 gaps=[]
 if any(s.get("duration")=="CONTENT_TBD" for s in candidate.statuses):gaps.append("STATUS_DURATION_STRUCTURAL_TBD")
 carriers={n.state_carrier for n in candidate.topology.nodes if n.state_carrier}
 if "COOLDOWN" in carriers:gaps.append("COOLDOWN_DEFINITION_MISSING")
 if "STATUS" in carriers and not candidate.statuses:gaps.append("STATUS_DEFINITION_MISSING")
 if "RESOURCE" in carriers and not candidate.resources:gaps.append("RESOURCE_DEFINITION_MISSING")
 if "STANCE" in carriers and not candidate.stances:gaps.append("STANCE_DEFINITION_MISSING")
 if candidate.tier=="LEGENDARY" and len(carriers)<2:gaps.append("LEGENDARY_MULTI_CARRIER_MISSING")
 if candidate.tier=="HIGH" and len(candidate.topology.nodes)<3:gaps.append("HIGH_NODE_DEPTH_INSUFFICIENT")
 predicates=set(candidate.trigger_requirements)
 if "status_present" in predicates and not candidate.statuses:gaps.append("STATUS_PREDICATE_WITHOUT_STATUS_SOURCE")
 if "resource_threshold" in predicates and not candidate.resources:gaps.append("RESOURCE_PREDICATE_WITHOUT_RESOURCE_SOURCE")
 if "cooldown_state" in predicates and "COOLDOWN" not in carriers:gaps.append("COOLDOWN_PREDICATE_WITHOUT_COOLDOWN_SOURCE")
 for capability in candidate.token_plan.unknown_cost_ids if candidate.token_plan else ():
  gaps.append(f"UNPRICED_MECHANIC_CAPABILITY:{capability}")
 return tuple(gaps)

def _numeric_gaps(candidate)->tuple[str,...]:
 gaps=[]
 if "damage_coefficient" in candidate.content_tbd:gaps.append("ABSOLUTE_DAMAGE_COEFFICIENT_VALUE_REQUIRED")
 if candidate.resources:gaps.append("RESOURCE_MAX_NUMERIC_POLICY_REQUIRED")
 if any(n.state_carrier=="COOLDOWN" for n in candidate.topology.nodes):gaps.append("COOLDOWN_NUMERIC_POLICY_REQUIRED")
 return tuple(dict.fromkeys(gaps))

def _row(lane,seed,result):
 c=result.candidate;v=result.validation_report
 if c is None:return {"lane":lane,"seed":seed,"generated":False,"failure":asdict(result.failure),"eligible":False}
 structural=_structural_gaps(c);numeric=_numeric_gaps(c);known=sum(c.token_plan.known_costs.values())
 exact_clone=False;blocked=bool(v.blocking_reasons or structural or known>c.budget)
 compiler="BLOCKED" if structural or v.blocking_reasons else ("READY_WITH_NUMERIC_POLICY_GAP" if numeric else "READY")
 return {"lane":lane,"seed":seed,"generated":True,"candidate_id":c.candidate_id,"candidate":c,"validation":v,"trace":result.generation_trace,
  "template":c.provenance.template_id,"topology_nodes":len(c.topology.nodes),"topology_edges":len(c.topology.edges),
  "cycle_count":1 if c.tier in ("HIGH","LEGENDARY") else 0,"carrier_types":sorted({n.state_carrier for n in c.topology.nodes if n.state_carrier}),
  "structural_gaps":structural,"numeric_gaps":numeric,"known_token_cost":known,"budget_limit":c.budget,
  "budget_state":"OVERFLOW" if known>c.budget else ("BUDGET_INDETERMINATE" if numeric else "BUDGET_VALID"),
  "compiler_readiness":compiler,"mechanism_signature":mechanism_signature(c),"formal_similarity":"DISTINCT_FROM_REGISTERED_FORMAL_SIGNATURES",
  "exact_formal_clone":exact_clone,"eligible":not blocked,"primary_risk":structural[0] if structural else (numeric[0] if numeric else "LOW"),
  "why_interesting":f'{c.provenance.template_id}; {c.targeting_requirements[0]}; {c.trigger_requirements[0]}'}

def run_wo037(workspace:str|Path)->dict[str,Any]:
 root=Path(workspace);registry_path=root/DEFAULT_REGISTRY_PATH;registry_bytes=registry_path.read_bytes();loaded=load_generated_registry(root)
 canonical_hash=stable_hash(definition_payload(loaded.get_runtime(next(iter(loaded.runtime)))))
 lane_results={}
 for lane in LANES:
  rows=tuple(_row(lane,seed,generate_and_validate(make_request(lane,seed))) for seed in SEEDS)
  eligible=[x for x in rows if x["eligible"]]
  # Validity first, then distinct signatures/templates and deterministic seed order.
  chosen=[];seen=set()
  for row in eligible:
   sig=json.dumps(row["mechanism_signature"],sort_keys=True,default=list)
   if sig in seen:continue
   chosen.append(row);seen.add(sig)
   if len(chosen)==3:break
  packages=[]
  for index,row in enumerate(chosen,1):
   c=row["candidate"];token=f"WO037-{lane}{index}"
   package={"review_package_schema":"WO037-v0.1","selection_token":token,"candidate_id":c.candidate_id,"seed":row["seed"],
    "family":c.family,"tier":c.tier,"budget":c.budget,"generator_version":CURRENT_MARTIAL_GENERATOR_VERSION,
    "template":row["template"],"topology":asdict(c.topology),"legendary_route":LANES[lane]["route"],
    "main_action":c.actions[0],"specials":list(c.actions[1:]),"passives":list(c.passives),"targeting":list(c.targeting_requirements),
    "statuses":list(c.statuses),"resources":list(c.resources),"stances":list(c.stances),"trigger_facts":list(c.trigger_requirements),
    "trigger_scopes":[p.get("trigger_scope") for p in c.passives],"cost_timing":list(c.cost_timing_requirements),
    "token_audit":{"known_cost":row["known_token_cost"],"budget":c.budget,"state":row["budget_state"]},
    "numeric_cost_unresolved":list(row["numeric_gaps"]),"content_tbd":list(c.content_tbd),"structural_gaps":list(row["structural_gaps"]),
    "open_core":list(c.open_policy_dependencies),"deferred":[],"runtime_eligibility":row["validation"].runtime_eligibility,
    "compiler_readiness":row["compiler_readiness"],"formal_similarity":row["formal_similarity"],
    "mechanism_signature":row["mechanism_signature"],"why_interesting":row["why_interesting"],"primary_risk":row["primary_risk"],
    "loop_map":{"entry":c.topology.entry_nodes,"feedback":[asdict(e) for e in c.topology.edges if e.edge_type.value=="FEEDS_BACK"],"break_conditions":["carrier unavailable","trigger condition false","ordinary Special cap"]} if lane=="B" else None,
    "legendary_engine_map":{"carrier_count":len(row["carrier_types"]),"stage_depth":row["topology_nodes"],"feedback_depth":row["cycle_count"],"qualification":"COMPOSITE_CLOSED_ENGINE","bounded":all(e.bounded for e in c.topology.edges)} if lane=="C" else None,
    "review_state":"PENDING_REVIEW","human_decision":"NONE","canonical":False}
   packages.append(package)
  lane_results[lane]={"spec":LANES[lane],"rows":rows,"shortlist":tuple(packages),"summary":{"generated":sum(x["generated"] for x in rows),
   "valid_architecture":sum(x["generated"] and not x["validation"].blocking_reasons for x in rows),"rejected":len(rows)-len(eligible),
   "budget_valid":sum(x.get("budget_state")=="BUDGET_VALID" for x in rows),"budget_indeterminate":sum(x.get("budget_state")=="BUDGET_INDETERMINATE" for x in rows),
   "compiler_ready":sum(x.get("compiler_readiness") in ("READY","READY_WITH_NUMERIC_POLICY_GAP") for x in rows),"shortlist_count":len(packages)}}
 registry_unchanged=registry_path.read_bytes()==registry_bytes;after=load_generated_registry(root)
 status="PASS_CONTROLLED_BATCH_2_WAITING_FOR_HUMAN_SELECTION" if all(lane_results[x]["shortlist"] for x in LANES) else "PARTIAL_ONE_OR_MORE_LANES_INSUFFICIENT"
 return {"status":status,"work_order":"CODEX-WO-037","seeds":SEEDS,"lanes":lane_results,"total_pool":36,
  "numeric_coverage":{"priced_dimensions":["absolute attack coefficient policy exists but candidate value unresolved","finite OWNER_FORMAL_TURNS duration policy exists"],
   "unresolved_dimensions":sorted({g for lane in lane_results.values() for r in lane["rows"] for g in r.get("numeric_gaps",())})},
  "controls":{"human_decisions":0,"promotion_attempts":0,"canonical_previews":0,"formal_before":loaded.count,"formal_after":after.count,
   "runtime_before":len(loaded.runtime),"runtime_after":len(after.runtime),"canonical_before":loaded.count,"canonical_after":after.count,
   "durable_registry_bytes_unchanged":registry_unchanged,"existing_canonical_hash_unchanged":canonical_hash==stable_hash(definition_payload(after.get_runtime(next(iter(after.runtime))))),
   "formal_additions":0,"runtime_additions":0,"new_promotion_manifests":0},
  "versions":{"battle_core":BATTLE_CORE_VERSION,"generator":CURRENT_MARTIAL_GENERATOR_VERSION,"acceptance":"v0.1-prototype","numeric_policy":"v0.1","registry_schema":"v0.1"},
  "stop":"STOPPED_AT_HUMAN_REVIEW"}

def _clean(value):
 if hasattr(value,"__dataclass_fields__"):return asdict(value)
 if isinstance(value,dict):return {k:_clean(v) for k,v in value.items() if k not in ("candidate","validation","trace")}
 if isinstance(value,(tuple,list)):return [_clean(x) for x in value]
 return value

def write_wo037_artifacts(result:dict[str,Any],directory:str|Path)->Path:
 out=Path(directory);out.mkdir(parents=True,exist_ok=True)
 cross=[]
 for lane,data in result["lanes"].items():
  lane_dir=out/data["spec"]["slug"];pool=lane_dir/"pool";traces=lane_dir/"traces";validations=lane_dir/"validations";reviews=lane_dir/"review_packages"
  for p in (pool,traces,validations,reviews):p.mkdir(parents=True,exist_ok=True)
  for row in data["rows"]:
   seed=row["seed"]
   if row["generated"]:
    (pool/f"seed_{seed}.json").write_text(serialize_candidate(row["candidate"]),encoding="utf-8")
    (traces/f"seed_{seed}.json").write_text(json.dumps(asdict(row["trace"]),ensure_ascii=False,sort_keys=True,indent=2),encoding="utf-8")
    (validations/f"seed_{seed}.json").write_text(serialize_validation_report(row["validation"]),encoding="utf-8")
  shortlist=[]
  for package in data["shortlist"]:
   payload={**package,"immutable_sha256":stable_hash(package)};shortlist.append({"selection_token":package["selection_token"],"candidate_id":package["candidate_id"],"review_package_sha256":stable_hash(package)})
   (reviews/f'{package["selection_token"]}.json').write_text(json.dumps(payload,ensure_ascii=False,sort_keys=True,indent=2),encoding="utf-8")
   cross.append(package)
  (lane_dir/"shortlist.json").write_text(json.dumps({"lane":lane,"items":shortlist,"count":len(shortlist)},ensure_ascii=False,sort_keys=True,indent=2),encoding="utf-8")
  matrix=[{"selection_token":p["selection_token"],"candidate_id":p["candidate_id"],"template":p["template"],"targeting":p["targeting"],"budget_state":p["token_audit"]["state"],"numeric_gaps":p["numeric_cost_unresolved"],"compiler_readiness":p["compiler_readiness"],"formal_similarity":p["formal_similarity"],"risk":p["primary_risk"]} for p in data["shortlist"]]
  (lane_dir/"comparison_matrix.json").write_text(json.dumps(matrix,ensure_ascii=False,sort_keys=True,indent=2),encoding="utf-8")
 (out/"cross_batch_matrix.json").write_text(json.dumps(cross,ensure_ascii=False,sort_keys=True,indent=2),encoding="utf-8")
 (out/"numeric_policy_coverage.json").write_text(json.dumps(result["numeric_coverage"],ensure_ascii=False,sort_keys=True,indent=2),encoding="utf-8")
 (out/"audit_result.json").write_text(json.dumps(_clean(result),ensure_ascii=False,sort_keys=True,indent=2),encoding="utf-8")
 return out

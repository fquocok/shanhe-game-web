"""Family-neutral declarative resource-loop formal schema and compiler.

The runtime is an adapter over existing bounded resources, event snapshots,
ordinary-Special eligibility, atomic settlement and no-refund semantics.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass, field
from random import Random
from typing import Callable, Mapping

REGISTERED_EVENTS=frozenset({"PARRY_SUCCESS","ATTACK_INSTANCE_SUCCESSFULLY_HIT","ACTION_COMPLETE","FORMAL_TURN_COMPLETE"})
REGISTERED_SCOPES=frozenset({"TURN_SCOPE","ACTION_SCOPE","ATTACK_SCOPE"})
PERSISTENCE=frozenset({"BATTLE_LOCAL_UNTIL_CONSUMED_OR_BATTLE_END"})

class ResourceLoopCompileError(ValueError):pass

@dataclass(frozen=True)
class ResourceDefinitionDescriptor:
 id:str; initial:int; maximum:int; persistence:str="BATTLE_LOCAL_UNTIL_CONSUMED_OR_BATTLE_END"; minimum:int=0; owner_scope:str="MARTIAL_OWNER"

@dataclass(frozen=True)
class SourceFilter:
 action_id:str|None=None; action_kind:str|None=None; stage_id:str|None=None; definition_id:str|None=None
 def matches(self,event:Mapping):
  return ((self.action_id is None or event.get("source_action_id")==self.action_id)
      and (self.action_kind is None or event.get("source_action_kind")==self.action_kind)
      and (self.stage_id is None or event.get("source_stage_id")==self.stage_id)
      and (self.definition_id is None or event.get("source_definition_id")==self.definition_id))

@dataclass(frozen=True)
class ResourceGainDescriptor:
 id:str; event:str; scope:str; resource_id:str; amount:int; source:SourceFilter=field(default_factory=SourceFilter); classification:str="NON_ACTION_EFFECT"

@dataclass(frozen=True)
class ResourceThresholdDescriptor:
 resource_id:str; operator:str; value:int; snapshot_authority:str="PRE_EVENT_RUNTIME_SNAPSHOT"

@dataclass(frozen=True)
class ResourceAttemptCostDescriptor:
 resource_id:str; amount:int; timing:str="ON_TRIGGER_ATTEMPT_AFTER_CONDITION"; atomicity:str="ATOMIC_ALL_OR_NOTHING"; refund_policy:str="NO_REFUND_AFTER_COST_SETTLEMENT"; current_resource_recheck:bool=True

@dataclass(frozen=True)
class TriggeredActionDescriptor:
 id:str; ownership:str; kind:str; coefficient:float; target_selector:str; participates_in_ordinary_cap:bool=True

@dataclass(frozen=True)
class ResourceSpendTriggerDescriptor:
 id:str; event:str; scope:str; condition:ResourceThresholdDescriptor; cost:ResourceAttemptCostDescriptor; action:TriggeredActionDescriptor; base_probability:float=1.; success_decay_multiplier:float=.25; failure_decay:str="NO_DECAY"; decay_reset:str="FORMAL_TURN_COMPLETE"

@dataclass(frozen=True)
class ResourceLoopDefinition:
 id:str; resources:tuple[ResourceDefinitionDescriptor,...]; gains:tuple[ResourceGainDescriptor,...]; spends:tuple[ResourceSpendTriggerDescriptor,...]

def validate_resource_loop(d:ResourceLoopDefinition):
 ids=[r.id for r in d.resources]
 if len(ids)!=len(set(ids)):raise ResourceLoopCompileError("DUPLICATE_RESOURCE_ID")
 for r in d.resources:
  if not r.id or type(r.initial) is not int or type(r.maximum) is not int or type(r.minimum) is not int:raise ResourceLoopCompileError("INVALID_RESOURCE_DEFINITION")
  if r.minimum<0 or r.maximum<r.initial or r.initial<r.minimum:raise ResourceLoopCompileError("INVALID_RESOURCE_DOMAIN")
  if r.persistence not in PERSISTENCE:raise ResourceLoopCompileError("INVALID_RESOURCE_PERSISTENCE")
 for g in d.gains:
  if g.resource_id not in ids:raise ResourceLoopCompileError("UNKNOWN_GAIN_RESOURCE")
  if g.event not in REGISTERED_EVENTS or g.scope not in REGISTERED_SCOPES:raise ResourceLoopCompileError("UNKNOWN_GAIN_EVENT_OR_SCOPE")
  if type(g.amount) is not int or g.amount<=0:raise ResourceLoopCompileError("INVALID_GAIN_AMOUNT")
  if g.classification!="NON_ACTION_EFFECT":raise ResourceLoopCompileError("RESOURCE_GAIN_MUST_BE_NON_ACTION")
 for s in d.spends:
  if s.event not in REGISTERED_EVENTS or s.scope not in REGISTERED_SCOPES:raise ResourceLoopCompileError("UNKNOWN_SPEND_EVENT_OR_SCOPE")
  if s.condition.resource_id not in ids or s.cost.resource_id not in ids:raise ResourceLoopCompileError("UNKNOWN_SPEND_RESOURCE")
  if s.condition.operator!=">=" or type(s.condition.value) is not int or s.condition.value<0:raise ResourceLoopCompileError("INVALID_THRESHOLD")
  if s.condition.snapshot_authority!="PRE_EVENT_RUNTIME_SNAPSHOT":raise ResourceLoopCompileError("INVALID_SNAPSHOT_AUTHORITY")
  if type(s.cost.amount) is not int or s.cost.amount<=0 or s.cost.timing!="ON_TRIGGER_ATTEMPT_AFTER_CONDITION" or s.cost.atomicity!="ATOMIC_ALL_OR_NOTHING" or s.cost.refund_policy!="NO_REFUND_AFTER_COST_SETTLEMENT":raise ResourceLoopCompileError("INVALID_ATTEMPT_COST")
  if s.action.ownership!="NEW_ORDINARY_SPECIAL_ACTION" or not s.action.participates_in_ordinary_cap:raise ResourceLoopCompileError("INVALID_TRIGGERED_ACTION")
  if not 0<=s.base_probability<=1:raise ResourceLoopCompileError("INVALID_PROBABILITY")
 return d

def semantic_payload(d:ResourceLoopDefinition):validate_resource_loop(d);return asdict(d)

@dataclass
class ResourceLoopState:
 resources:dict[str,int]; ordinary_cap_used:int=0; probabilities:dict[str,float]=field(default_factory=dict); rolls:int=0; actions:int=0

class CompiledResourceLoop:
 ORDINARY_CAP=3
 def __init__(self,definition:ResourceLoopDefinition,seed=1):self.definition=validate_resource_loop(definition);self.rng=Random(seed);self.by_id={r.id:r for r in definition.resources}
 def initialize(self):return ResourceLoopState({r.id:r.initial for r in self.definition.resources})
 def gain(self,state,rid,amount):state.resources[rid]=min(self.by_id[rid].maximum,state.resources[rid]+amount)
 def dispatch(self,state,event_type,event=None,*,roll=None,pre_attempt_hook:Callable|None=None,action_outcome="SUCCESSFUL_HIT"):
  event=dict(event or {});snapshot=dict(state.resources);eligible=[];log=[]
  for spend in self.definition.spends:
   if spend.event!=event_type:continue
   seen=snapshot[spend.condition.resource_id]
   if seen>=spend.condition.value:eligible.append(spend)
  for gain in self.definition.gains:
   if gain.event==event_type and gain.source.matches(event):self.gain(state,gain.resource_id,gain.amount);log.append(("gain",gain.id,gain.amount))
  for spend in eligible:
   if state.ordinary_cap_used>=self.ORDINARY_CAP:log.append(("blocked","cap"));continue
   if pre_attempt_hook:pre_attempt_hook(state)
   if state.resources[spend.cost.resource_id]<spend.cost.amount:log.append(("blocked","insufficient"));continue
   state.resources[spend.cost.resource_id]-=spend.cost.amount;log.append(("consume",spend.cost.amount));state.rolls+=1
   probability=state.probabilities.get(spend.id,spend.base_probability);actual=self.rng.random() if roll is None else roll
   if actual>=probability:log.append(("blocked","roll_no_refund"));continue
   state.actions+=1;state.ordinary_cap_used+=1;state.probabilities[spend.id]=probability*spend.success_decay_multiplier;log.append(("action",spend.action.id))
   if action_outcome in ("SUCCESSFUL_HIT","PARRIED_SUCCESSFUL_HIT"):
    feedback={"source_action_id":spend.action.id,"source_action_kind":spend.action.kind}
    for gain in self.definition.gains:
     if gain.event=="ATTACK_INSTANCE_SUCCESSFULLY_HIT" and gain.source.matches(feedback):self.gain(state,gain.resource_id,gain.amount);log.append(("feedback",gain.id,gain.amount))
  return {"pre_event":snapshot,"post_event":dict(state.resources),"log":log}
 def formal_turn_complete(self,state):state.ordinary_cap_used=0;state.probabilities.clear()

def compile_resource_loop(d:ResourceLoopDefinition,seed=1):return CompiledResourceLoop(d,seed)

def resource_loop_from_payload(p):
 resources=tuple(ResourceDefinitionDescriptor(**x) for x in p["resources"])
 gains=tuple(ResourceGainDescriptor(x["id"],x["event"],x["scope"],x["resource_id"],x["amount"],SourceFilter(**x.get("source",{})),x.get("classification","NON_ACTION_EFFECT")) for x in p["gains"])
 spends=[]
 for x in p["spends"]:spends.append(ResourceSpendTriggerDescriptor(x["id"],x["event"],x["scope"],ResourceThresholdDescriptor(**x["condition"]),ResourceAttemptCostDescriptor(**x["cost"]),TriggeredActionDescriptor(**x["action"]),x.get("base_probability",1.),x.get("success_decay_multiplier",.25),x.get("failure_decay","NO_DECAY"),x.get("decay_reset","FORMAL_TURN_COMPLETE")))
 return ResourceLoopDefinition(p["id"],resources,gains,tuple(spends))

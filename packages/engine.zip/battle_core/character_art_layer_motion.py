"""Developer-only independent layer motion for the CLO_F_0001 v0.3 pilot.

The offsets are presentation data in renderer pixels.  They never alter source
PNGs, asset metadata, gameplay positions, hitboxes, or battle timing.
"""
from __future__ import annotations

from typing import Final

from .character_art_interface import CLOTHING_LAYER_STACK


LAYER_MOTION_PILOT_CONTRACT: Final = "CLO_F_0001_INDEPENDENT_LAYER_MOTION_PILOT_V0_3"
MAX_LAYER_OFFSET_PX: Final = 4

_ZERO = {layer: (0, 0) for layer in CLOTHING_LAYER_STACK}

# Peak offsets are authored for canonical RIGHT facing at the game's displayed
# 1/2 scale.  Horizontal offsets are mirrored at runtime for LEFT facing.
_PEAK_RIGHT = {
    "APPROACH": {
        "rear_accessory": (-3, 0), "rear_hair": (-2, 0),
        "rear_arm_clothing": (-1, 0), "rear_leg_clothing": (-1, 0),
        "front_leg_clothing": (-1, 0), "front_arm_clothing": (-1, 0),
        "front_hair": (-2, 0), "front_accessory": (-3, 0),
    },
    "CONTACT": {
        "rear_accessory": (-4, -1), "rear_hair": (-2, -1),
        "rear_arm_clothing": (1, 0), "rear_leg_clothing": (-1, 0),
        "front_leg_clothing": (-1, 0), "front_arm_clothing": (3, -1),
        "front_hair": (-2, -1), "front_accessory": (-4, -1),
    },
    "HIT": {
        "rear_accessory": (3, -1), "rear_hair": (2, -1),
        "rear_arm_clothing": (2, 0), "rear_leg_clothing": (1, 0),
        "front_leg_clothing": (1, 0), "front_arm_clothing": (2, 0),
        "front_hair": (2, -1), "front_accessory": (3, -1),
    },
    "RETREAT": {
        "rear_accessory": (3, 0), "rear_hair": (2, 0),
        "rear_arm_clothing": (1, 0), "rear_leg_clothing": (1, 0),
        "front_leg_clothing": (1, 0), "front_arm_clothing": (1, 0),
        "front_hair": (2, 0), "front_accessory": (3, 0),
    },
}

_STEP_SCALE = {0: 0.0, 1: 0.5, 2: 1.0, 3: 1.0}


def project_layer_motion_offsets(phase: str, step: int, facing: str,
                                 role: str = "attacker") -> dict[str, tuple[int, int]]:
    """Return one bounded deterministic translation for every contract layer."""
    normalized_phase = str(phase).upper()
    if role == "target" and normalized_phase in {"CONTACT", "STABLE"}:
        normalized_phase = "HIT"
    if normalized_phase not in _PEAK_RIGHT:
        return dict(_ZERO)
    scale = _STEP_SCALE.get(max(0, min(int(step), 3)), 1.0)
    direction = -1 if str(facing).lower() == "left" else 1
    projected = dict(_ZERO)
    for layer, (dx, dy) in _PEAK_RIGHT[normalized_phase].items():
        projected[layer] = (round(dx * scale) * direction, round(dy * scale))
    return projected


def layer_motion_pilot_snapshot() -> dict[str, object]:
    return {
        "contract": LAYER_MOTION_PILOT_CONTRACT,
        "status": "PROTOTYPE",
        "presentation_only": True,
        "default_enabled": False,
        "source_png_changes": 0,
        "metadata_schema_changes": 0,
        "battle_truth_changes": 0,
        "supported_transform": "INTEGER_TRANSLATION_ONLY",
        "max_layer_offset_px": MAX_LAYER_OFFSET_PX,
        "layers": CLOTHING_LAYER_STACK,
        "phases": ("IDLE", "APPROACH", "CONTACT", "HIT", "RETREAT"),
    }

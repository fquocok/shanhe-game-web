"""WO-064B human-selected character visual revision and promotion gate.

This module deliberately creates only a noncanonical, review-ready revision.
It neither registers a formal character game visual nor writes World Lore.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from hashlib import sha256
from json import dumps

from .named_character_visual_candidates import WANG_MUQING_CANDIDATES_BY_ID
from .named_character_visual_shell import WANG_MUQING_CHARACTER_ID, WANG_MUQING_VISUAL_SHELL

CHARACTER_GAME_VISUAL_PROMOTION_PACKAGE_CONTRACT = "CHARACTER_GAME_VISUAL_PROMOTION_PACKAGE_V0_1"
WANG_MUQING_VISUAL_B_REVISION_ID = "WANG-MUQING-VISUAL-B:R1"
HUMAN_SELECTION_SOURCE = "WO-064:HUMAN_SELECTED_WANG-MUQING-VISUAL-B"
REVISION_REASON = "HUMAN_SELECTED_CANDIDATE_PROMOTION_PREPARATION"


@dataclass(frozen=True)
class NamedCharacterVisualRevision:
    revision_id: str
    parent_candidate_id: str
    parent_hash: str
    human_selection: bool
    human_selection_source: str
    revision_reason: str
    visual_direction: str
    appearance_profile: object
    body_profile_choice: str
    visual_cleanup_changes: tuple[str, ...]
    unchanged_fields: tuple[str, ...]
    known_constraints: tuple[str, ...]
    unknown_fields: tuple[str, ...]
    forbidden_inferences: tuple[str, ...]
    world_lore_scope: str
    canonical: bool = False
    human_review_required: bool = True

    def stable_hash(self) -> str:
        payload = asdict(self)
        payload.pop("appearance_profile")
        payload["appearance_profile_id"] = self.appearance_profile.profile_id
        return sha256(dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")).hexdigest()

    def visual_diff(self) -> dict:
        return {
            "changed_fields": self.visual_cleanup_changes,
            "unchanged_fields": self.unchanged_fields,
            "body_changes": 0, "hair_changes": 0, "palette_changes": 0, "weapon_changes": 0,
            "motion_changes": 0, "world_canon_changes": 0,
            "payload_equal_to_parent": True, "revision_identity_changed": True,
        }


@dataclass(frozen=True)
class NamedCharacterGameVisualPromotionPackage:
    character_id: str
    character_name: str
    selected_candidate_id: str
    selected_revision_id: str
    parent_hash: str
    revision_hash: str
    human_selection_source: str
    visual_direction: str
    character_identity_status: str
    game_visual_scope: str
    world_lore_scope: str
    known_constraints: tuple[str, ...]
    unknown_fields: tuple[str, ...]
    forbidden_inferences: tuple[str, ...]
    black_fog_policy: str
    martial_policy: str
    faction_policy: str
    promotion_status: str
    human_final_decision: str
    formal_named_character_game_visual_profile_count: int
    canonical: bool = False


_parent = WANG_MUQING_CANDIDATES_BY_ID["WANG-MUQING-VISUAL-B"]
WANG_MUQING_VISUAL_B_R1 = NamedCharacterVisualRevision(
    WANG_MUQING_VISUAL_B_REVISION_ID, _parent.candidate_id, _parent.candidate_hash, True,
    HUMAN_SELECTION_SOURCE, REVISION_REASON, _parent.visual_direction, _parent.appearance_profile,
    str(_parent.body_profile_choice.value), (),
    ("body_profile_choice", "hair_profile", "upper_garment", "lower_garment", "sleeves", "waist", "footwear",
     "head_accessory", "palette", "weapon_visual_family", "hand_sockets", "weapon_socket", "ground_anchor", "motion"),
    ("identity:CANON", "weapon_visual_family:SWORD"), _parent.unknown_fields, _parent.forbidden_inferences,
    "WORLD_LORE_CHARACTER_APPEARANCE_NOT_ESTABLISHED",
)


def wang_muqing_game_visual_promotion_package() -> NamedCharacterGameVisualPromotionPackage:
    return NamedCharacterGameVisualPromotionPackage(
        WANG_MUQING_CHARACTER_ID, "王沐青", _parent.candidate_id, WANG_MUQING_VISUAL_B_R1.revision_id,
        _parent.candidate_hash, WANG_MUQING_VISUAL_B_R1.stable_hash(), HUMAN_SELECTION_SOURCE,
        WANG_MUQING_VISUAL_B_R1.visual_direction, WANG_MUQING_VISUAL_SHELL.character_canon_status,
        "PROPOSED_GAME_FACING_NAMED_CHARACTER_VISUAL", WANG_MUQING_VISUAL_B_R1.world_lore_scope,
        ("identity:CANON", "weapon_visual_family:SWORD"), _parent.unknown_fields, _parent.forbidden_inferences,
        "KNOWN_PHENOMENON__VISUAL_IMPLEMENTATION_NOT_AUTHORIZED__VFX_NONE",
        "FORMAL_MARTIAL_NOT_ASSIGNED__GENERATED_MARTIAL_BINDING_NONE",
        "FORMAL_FACTION_UNKNOWN__FACTION_VISUAL_PROFILE_NONE",
        "PENDING_FINAL_HUMAN_REVIEW", "NONE", 0,
    )

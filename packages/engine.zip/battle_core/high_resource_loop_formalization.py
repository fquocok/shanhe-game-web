"""WO-037B1A real-use formalization through generic resource-loop compiler."""
from __future__ import annotations
from pathlib import Path
from types import MappingProxyType
import json

from .generated_acceptance import stable_hash
from .martial import MartialActiveSkillDefinition,MartialRoutineDefinition,SourceProvenance,validate_martial_definition
from .resource_loop_formal import (ResourceDefinitionDescriptor,ResourceGainDescriptor,ResourceThresholdDescriptor,
 ResourceAttemptCostDescriptor,TriggeredActionDescriptor,ResourceSpendTriggerDescriptor,ResourceLoopDefinition,
 SourceFilter,compile_resource_loop,semantic_payload)
from .revision_2_canonical_promotion import definition_payload,GeneratedCanonicalProvenance

REVISION_HASH="46eeda7a6e303c37a184707052c92d76c44ed8fe323dcb51441a2a25b1c2a60b"
GAPS=("DECLARATIVE_RESOURCE_DEFINITION","ATTACK_SUCCESS_RESOURCE_PRODUCER","PARRY_SIBLING_RESOURCE_PRODUCER","PRE_EVENT_RESOURCE_THRESHOLD_CONDITION","ATOMIC_ATTEMPT_RESOURCE_CONSUMER","SPECIAL_HIT_RESOURCE_FEEDBACK")

def load_revision(root):return json.loads((Path(root)/"generated_candidates/wo037b1/candidate_revision_1.json").read_text(encoding="utf-8"))

def formalize_revision1(root):
 rev=load_revision(root);c=rev["candidate"];r=c["resources"][0];main,special=c["actions"];p=c["passives"][0]
 resource=ResourceDefinitionDescriptor(r["id"],r["initial"],r["maximum"],r["persistence"],r.get("minimum",0))
 gains=(ResourceGainDescriptor("main-hit",main["successful_hit_effect"]["event"],main["successful_hit_effect"]["scope"],r["id"],1,SourceFilter(action_id=main["id"])),
  ResourceGainDescriptor("parry-gain","PARRY_SUCCESS","ATTACK_SCOPE",r["id"],1),
  ResourceGainDescriptor("special-hit",special["successful_hit_effect"]["event"],special["successful_hit_effect"]["scope"],r["id"],1,SourceFilter(action_id=special["id"])))
 spend=ResourceSpendTriggerDescriptor("parry-spend","PARRY_SUCCESS","ATTACK_SCOPE",ResourceThresholdDescriptor(r["id"],">=",p["threshold"],p["condition_snapshot"]),ResourceAttemptCostDescriptor(r["id"],p["consume"],p["cost_timing"],p["atomicity"],p["refund_policy"],p["current_resource_recheck"]),TriggeredActionDescriptor(special["id"],special["action_ownership"],"counterattack",special["damage_coefficient"],"enemy_of_owner"),p["base_chance"],p["success_decay_multiplier"],p["failure_decay"],p["decay_reset"])
 loop=ResourceLoopDefinition("generated:high:resource-loop:f56a8c141194:r1",(resource,),gains,(spend,))
 definition=MartialRoutineDefinition("diagnostic:high:fist:f56a8c141194:r1","UNNAMED_HUMAN_METADATA_PENDING","拳法","high",168,MartialActiveSkillDefinition(main["id"],"UNNAMED_MAIN",main["cooldown"],main["qi_cost_percent_max"],"single",main["damage_coefficient"]),(),GeneratedCanonicalProvenance("generated_candidates/wo037b1/candidate_revision_1.json",rev["revision_id"],"1","HIGH",168,candidate_revision_id=rev["revision_id"],candidate_sha256=REVISION_HASH,promotion_work_order="CODEX-WO-037B1A"),(),("DIAGNOSTIC_NONCANONICAL","CONTENT_COMPLETE","TOKEN_POLICY_REQUIRED"),None,(),(loop,))
 return validate_martial_definition(definition)

def runtime_diagnostic(root):
 definition=formalize_revision1(root);runtime=compile_resource_loop(definition.resource_loops[0],seed=7);s=runtime.initialize()
 main=runtime.dispatch(s,"ATTACK_INSTANCE_SUCCESSFULLY_HIT",{"source_action_id":"gen_v01_high_fist_f56a8c141194.action1"})
 parry1=runtime.dispatch(s,"PARRY_SUCCESS")
 parry2=runtime.dispatch(s,"PARRY_SUCCESS")
 before_turn=s.resources.copy();runtime.formal_turn_complete(s);reentry=runtime.dispatch(s,"PARRY_SUCCESS")
 cap=runtime.initialize();cap.resources[next(iter(cap.resources))]=4;cap.ordinary_cap_used=3;cap_case=runtime.dispatch(cap,"PARRY_SUCCESS")
 failure=runtime.initialize();failure.resources[next(iter(failure.resources))]=2;failure_case=runtime.dispatch(failure,"PARRY_SUCCESS",roll=1.)
 dodge=runtime.initialize();dodge.resources[next(iter(dodge.resources))]=2;dodge_case=runtime.dispatch(dodge,"PARRY_SUCCESS",action_outcome="DODGED")
 return {"status":"PASS","main":main,"parry_pre1":parry1,"parry_pre2":parry2,"before_turn_complete":before_turn,"reentry":reentry,"cap":cap_case,"failure":failure_case,"dodge":dodge_case,"final":s.resources,"actions":s.actions}

def audit_wo037b1a(root):
 root=Path(root);rp=root/"generated_candidates/wo037b1/candidate_revision_1.json";before=rp.read_bytes();definition=formalize_revision1(root);payload=definition_payload(definition);diag=runtime_diagnostic(root)
 registry=(root/"generated_candidates/generated_canonical_registry_v0_1.json").read_bytes();entries=json.loads(registry)["entries"]
 return {"status":"PASS_HIGH_RESOURCE_LOOP_FORMALIZATION_VERIFIED_STOPPED_AT_TOKEN_POLICY","gaps":GAPS,"all_gaps_resolved":True,"revision_hash":stable_hash(json.loads(before)),"revision_bytes_unchanged":rp.read_bytes()==before,"formalization":"LOSSLESS","compiler_readiness":"READY","runtime":diag,"high_qualification":"VALID_REPEATABLE_HIGH_LOOP","content_completeness":"PASS","known_token_total":118,"token_status":"BUDGET_INDETERMINATE","resource_numeric_policy":"UNRESOLVED","definition":payload,"definition_hash":stable_hash(payload),"legacy_hashes":{e["formal_id"]:e["canonical_definition_sha256"] for e in entries},"battle_semantic_change":False,"governance":{"revision2":False,"generator_calls":0,"human_decisions":0,"human_accepts":0,"promotion_attempts":0,"registry_before":[2,2,2],"registry_after":[2,2,2],"registry_bytes_unchanged":(root/"generated_candidates/generated_canonical_registry_v0_1.json").read_bytes()==registry,"lane_a":"CLOSED","lane_c":"DEFERRED"}}

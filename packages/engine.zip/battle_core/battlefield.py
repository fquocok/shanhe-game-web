from __future__ import annotations

from dataclasses import dataclass, field

from .schema import GridPosition


ROWS = ("front", "middle", "back")
COLUMNS = (1, 2, 3)
ROW_INDEX = {row: index for index, row in enumerate(ROWS)}


@dataclass
class BattlefieldGrid:
    event_sink: object
    occupancy: dict[tuple[str, str, int], object] = field(default_factory=dict)
    vacated_slots_this_turn: list[tuple[str, GridPosition]] = field(default_factory=list)

    def deploy(self, state) -> None:
        pos = state.position
        key = (state.definition.faction, pos.row, pos.column)
        if key in self.occupancy:
            raise ValueError(f"Grid slot 已被佔用：{key}")
        self.occupancy[key] = state
        state.on_field = True

    def occupant(self, faction: str, position: GridPosition, *, living_only=False, ordinary_eligible_only=False):
        state = self.occupancy.get((faction, position.row, position.column))
        # living_only retains its historical NOT-confirmed-dead occupancy meaning.
        if ordinary_eligible_only and state is not None and not state.ordinary_combat_eligible:
            return None
        if living_only and state is not None and state.death_confirmed:
            return None
        return state

    def occupied_states(self, faction: str, *, living_only=True, ordinary_eligible_only=False):
        result = []
        for row in ROWS:
            for column in COLUMNS:
                state = self.occupant(faction, GridPosition(row, column), living_only=living_only,
                                      ordinary_eligible_only=ordinary_eligible_only)
                if state is not None:
                    result.append(state)
        return result

    def effective_frontline(self, faction: str, *, ordinary_eligible_only=False) -> str | None:
        for row in ROWS:
            if any(self.occupant(faction, GridPosition(row, c), living_only=True,
                                 ordinary_eligible_only=ordinary_eligible_only) for c in COLUMNS):
                return row
        return None

    def death_cleanup(self) -> tuple[tuple[str, GridPosition], ...]:
        self.vacated_slots_this_turn = []
        self.event_sink("DEATH_CLEANUP")
        for key, state in sorted(list(self.occupancy.items()), key=lambda item: (item[0][0], ROW_INDEX[item[0][1]], item[0][2])):
            if not state.death_confirmed:
                continue
            del self.occupancy[key]
            state.on_field = False
            faction, row, column = key
            position = GridPosition(row, column)
            self.vacated_slots_this_turn.append((faction, position))
            self.event_sink("GRID_SLOT_VACATED", unit=state.definition.id, faction=faction,
                            row=row, column=column)
        return tuple(self.vacated_slots_this_turn)

    def empty_positions(self, faction: str):
        return [GridPosition(row, column) for row in ROWS for column in COLUMNS
                if self.occupant(faction, GridPosition(row, column)) is None]

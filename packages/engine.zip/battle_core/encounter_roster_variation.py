"""Developer selector for WO-075 data-only encounter roster variants."""
from __future__ import annotations
from pathlib import Path

from .game_facing_encounter import FIRST_ENCOUNTER_ID, encounter_configuration
from .interactive_battle_screen import TkBattleScreen

ENCOUNTER_VARIANTS = (
    ("A｜1 Friendly vs 1 Enemy", "encounter:prototype:duel_1v1"),
    ("B｜2 Friendlies vs 2 Enemies", "encounter:prototype:pair_2v2"),
    ("C｜2 Friendlies vs 3 Enemies（First Encounter）", FIRST_ENCOUNTER_ID),
    ("D｜Mixed Sword / Spear / Fist", "encounter:prototype:mixed_weapons_2v3"),
)


def main(argv=None):
    import argparse
    import tkinter as tk
    from tkinter import ttk
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", default=".")
    parser.add_argument("--encounter-id", choices=tuple(item[1] for item in ENCOUNTER_VARIANTS))
    args = parser.parse_args(argv)
    workspace = Path(args.workspace).resolve()

    def launch(encounter_id: str):
        for widget in root.winfo_children(): widget.destroy()
        configuration, _loader = encounter_configuration(workspace, encounter_id)
        TkBattleScreen(root, workspace, configuration)

    root = tk.Tk()
    if args.encounter_id:
        launch(args.encounter_id)
    else:
        root.title("Encounter Roster Variation（開發用）")
        root.geometry("620x360")
        frame = ttk.Frame(root, padding=24); frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="選擇遭遇戰名單變體", font=("Microsoft JhengHei UI", 17, "bold")).pack(pady=(0, 8))
        ttk.Label(frame, text="Combatant Profile → Encounter Definition → Runtime", foreground="#555555").pack(pady=(0, 18))
        for label, encounter_id in ENCOUNTER_VARIANTS:
            ttk.Button(frame, text=label, command=lambda selected=encounter_id: launch(selected)).pack(fill="x", pady=6)
    root.mainloop()


if __name__ == "__main__": main()

"""WO-037A1 Human-authored content resolution; no promotion or runtime registration."""
from __future__ import annotations
from dataclasses import asdict
from pathlib import Path
import json
from typing import Any

from .durable_generated_registry import DEFAULT_REGISTRY_PATH,load_generated_registry
from .generated_acceptance import stable_hash
from .generator import (CAPABILITY_REGISTRY,CURRENT_MARTIAL_GENERATOR_VERSION,TokenAllocationPlan,
    deserialize_candidate,mechanism_signature,serialize_candidate,serialize_validation_report,validate_candidate)
from .numeric_token_valuation import evaluate_candidate_numeric_budget
from .revision_2_canonical_promotion import definition_payload

def _read(path:Path)->Any:return json.loads(path.read_text(encoding="utf-8"))

def create_wo037a1_revision(workspace:str|Path)->dict[str,Any]:
 root=Path(workspace);parent_path=root/"generated_candidates/wo037/lane_a_advanced_sword/pool/seed_101.json";parent_bytes=parent_path.read_bytes();parent_raw=_read(parent_path);parent_hash=stable_hash(parent_raw);parent=deserialize_candidate(json.dumps(parent_raw,ensure_ascii=False))
 registry_path=root/DEFAULT_REGISTRY_PATH;registry_bytes=registry_path.read_bytes();loaded=load_generated_registry(root);canonical_id=next(iter(loaded.runtime));canonical_hash=stable_hash(definition_payload(loaded.get_runtime(canonical_id)))
 revision_id=parent.candidate_id+".r1";main={**parent.actions[0],"damage_coefficient":1.0,"value_category":"FIRST_PASS_GENERATED_VALUE","qi_cost_percent_max":0.30,"cooldown":8,"final_balance_locked":False,
  "authority":"HUMAN_AUTHORED_FIRST_PASS_CONTENT"}
 followup={"id":revision_id+".action2","kind":"ORDINARY_SPECIAL","action_ownership":"NEW_ORDINARY_SPECIAL_ACTION","trigger_fact":"PARRY_SUCCESS","trigger_scope":"ATTACK_SCOPE","base_chance":1.0,
  "decay":{"on_success_multiplier":0.25,"on_failure":"NO_DECAY","reset":"FORMAL_TURN_COMPLETE","isolation":"PER_CHARACTER_PER_TRIGGER"},"ordinary_special_cap":3,"cap_before_roll":True,
  "qi_cost_percent_max":0.0,"cooldown":0,"damage_coefficient":0.70,"coefficient_classification":"ABSOLUTE_COEFFICIENT","targeting":"roaming_distinct","requested_target_count":2,
  "targeting_contract":{"available":"LIVING_ON_FIELD_LEGAL_ENEMIES","actual_target_count":"MIN_REQUESTED_AVAILABLE","when_available_lte_requested":"DETERMINISTIC_OCCUPIED_STATE_ORDER_NO_RNG","when_available_gt_requested":"BATTLE_RNG_DISTINCT_SUBSET","replacement":False,"wrap":False,"zero_targets":"NO_ACTION_TARGETS_NO_FALLBACK"},
  "attack_instances":"ONE_PER_SELECTED_TARGET_INDEPENDENT_NORMAL_PIPELINE","offensive_snapshot":"OWN_SPECIAL_ACTION_SNAPSHOT","refund_policy":"NO_REFUND_AFTER_COST_SETTLEMENT","final_balance_locked":False,"authority":"HUMAN_AUTHORED_FIRST_PASS_CONTENT"}
 passive={**parent.passives[0],"predicate":"successful_parry","trigger_event":"PARRY_SUCCESS","trigger_scope":"ATTACK_SCOPE","effect_action_id":followup["id"],"base_chance":1.0,"decay_contract":"CANONICAL_ORDINARY_TRIGGER_DECAY","ordinary_special":True,"ordinary_special_cap":3,"cap_before_roll":True}
 raw=dict(parent_raw);raw.update({"candidate_id":revision_id,"actions":[main,followup],"passives":[passive],"content_tbd":[],"validation_status":"CANDIDATE_UNVALIDATED"})
 raw["capability_requirements"]=sorted(set(parent_raw["capability_requirements"]+['ordinary_special','roaming_distinct','successful_parry']))
 raw["targeting_requirements"]=["roaming_distinct"];raw["trigger_requirements"]=["successful_parry"];raw["cost_timing_requirements"]=["ON_COMMITTED_ACTION","ON_TRIGGER_ATTEMPT_AFTER_CONDITION"]
 raw["token_plan"]={"known_costs":{**parent_raw["token_plan"]["known_costs"],"ordinary_special":24},"unknown_cost_ids":[],"target_budget":120}
 raw["topology"]["nodes"][0]["content_tbd"]=False
 raw["provenance"]={**parent_raw["provenance"],"generation_attempt_count":1}
 revision=deserialize_candidate(json.dumps(raw,ensure_ascii=False));validation=validate_candidate(revision)
 decision={"decision_id":"human-content:"+stable_hash(("WO037A1",parent.candidate_id,parent_hash))[:16],"work_order":"CODEX-WO-037A1","selection_token":"WO037-A1","subject_id":parent.candidate_id,"subject_sha256":parent_hash,"authority":"HUMAN_AUTHORED_FIRST_PASS_CONTENT","decision":"APPLY_CONTENT_COMPLETENESS_RESOLUTION","generator_calls":0,"source_derived":False,"generator_derived":False,"final_balance_locked":False,
  "values":{"main_coefficient":1.0,"main_qi_cost_percent_max":0.30,"main_cooldown":8,"followup_ownership":"NEW_ORDINARY_SPECIAL_ACTION","followup_coefficient":0.70,"trigger":"PARRY_SUCCESS","scope":"ATTACK_SCOPE","base_chance":1.0,"decay_success_multiplier":0.25,"targeting":"roaming_distinct","requested_target_count":2}}
 envelope={"revision_schema":"WO037A1-v0.1","revision_id":revision_id,"revision_number":1,"revision_reason":"HUMAN_CONTENT_COMPLETENESS_RESOLUTION","parent_candidate_id":parent.candidate_id,"parent_candidate_sha256":parent_hash,"selection_token":"WO037-A1","candidate":raw,"human_content_decision_id":decision["decision_id"],"authority":"HUMAN_AUTHORED_FIRST_PASS_CONTENT","canonical":False,"formal":False,"runtime_registered":False}
 revision_hash=stable_hash(envelope);candidate_snapshot_hash=stable_hash(raw)
 allowed=["actions[0].damage_coefficient","actions[0].value_category","actions[0].qi_cost_percent_max","actions[0].cooldown","actions[1]","passives[0].effect/chance/decay/scope","capability_requirements","content_tbd","token_plan.ordinary_special","topology.main.content_tbd","provenance/lineage"]
 diff={"status":"PASS_WHITELIST_ONLY","allowed_changes":allowed,"unrelated_drift":[],"preserved":{"family":revision.family==parent.family,"tier":revision.tier==parent.tier,"budget":revision.budget==parent.budget,"seed":revision.provenance.generation_seed==parent.provenance.generation_seed,"template":revision.provenance.template_id==parent.provenance.template_id,"original_action_id":revision.actions[0]["id"]==parent.actions[0]["id"],"topology_id":revision.topology.topology_id==parent.topology.topology_id}}
 registered=evaluate_candidate_numeric_budget(revision)
 policy_gaps=[{"code":"QI_COST_TOKEN_POLICY_TBD","path":"actions[0].qi_cost_percent_max","value":0.30},{"code":"COOLDOWN_TOKEN_POLICY_TBD","path":"actions[0].cooldown","value":8},{"code":"TRIGGER_CHANCE_TOKEN_POLICY_TBD","path":"actions[1].base_chance","value":1.0},{"code":"TARGET_COUNT_TOKEN_POLICY_TBD","path":"actions[1].requested_target_count","value":2}]
 token={"status":"BUDGET_INDETERMINATE","policy_version":"v0.1","previous_mechanic_subtotal":60,"base_known_costs":registered.base_known_costs,"base_mechanic_subtotal":registered.base_known_subtotal,
  "new_mechanic_costs":{"ordinary_special":24},"coefficient_valuations":[asdict(x) for x in registered.numeric_valuations],"registered_numeric_surcharge":registered.numeric_subtotal,
  "known_subtotal_after_registered_policy":registered.total_used,"unknown_numeric_costs":policy_gaps,"used":None,"remaining":None,"limit":120,"unknown_cost_treated_as_zero":False,"negative_rebate":0,
  "double_charge_audit":"PASS_ORDINARY_SPECIAL_CHARGED_ONCE"}
 completeness={"status":"PASS_RUNTIME_CONTENT_COMPLETE","remaining_runtime_tbd":[],"token_balance_tbd":False,"trigger_effect_defined":True,"action_ownership_defined":True,"target_count_defined":True,"chance_decay_defined":True,"qi_cooldown_defined":True,"no_new_carriers":{"status":True,"resource":True,"mark":True,"shield":True,"heal":True}}
 capabilities={x:CAPABILITY_REGISTRY.get(x,"UNKNOWN") for x in revision.capability_requirements}
 compiler={"status":"READY_AFTER_TOKEN_POLICY","runtime_semantics_complete":True,"formal_display_name":"FORMAL_DISPLAY_NAME_HUMAN_DECISION_REQUIRED","generic_capabilities":capabilities,"unknown_capabilities":[x for x,v in capabilities.items() if v is None or v=="UNKNOWN"],"formal_compile_run":False,"promotion_run":False}
 similarity={"status":"PASS","sword_formal_similarity":"DISTINCT","exact_clone":False,"revision_signature":mechanism_signature(revision),"existing_generated_canonical":"DISTINCT","cross_family_engine_similarity":False}
 review={"review_package_schema":"WO037A1-review-v0.1","review_package_id":"review:"+stable_hash((revision_id,revision_hash,serialize_validation_report(validation)))[:16],"revision_id":revision_id,"revision_sha256":revision_hash,"candidate_snapshot_sha256":candidate_snapshot_hash,"parent_id":parent.candidate_id,"parent_sha256":parent_hash,"validation_sha256":stable_hash(json.loads(serialize_validation_report(validation))),"token_evaluation":token,"compiler_readiness":compiler,"lineage":{"selection_token":"WO037-A1","seed":101,"generator_version":CURRENT_MARTIAL_GENERATOR_VERSION,"template":parent.provenance.template_id},"review_state":"PENDING_REVIEW","human_decision":"NONE","canonical":False,"formal":False,"runtime_registered":False}
 controls={"parent_immutable":parent_path.read_bytes()==parent_bytes,"generator_calls":0,"rerolls":0,"promotion_attempts":0,"canonical_previews":0,"staging":0,"registry_commits":0,"registry_before":loaded.count,"registry_after":load_generated_registry(root).count,"registry_bytes_unchanged":registry_path.read_bytes()==registry_bytes,"existing_canonical_unchanged":canonical_hash==stable_hash(definition_payload(load_generated_registry(root).get_runtime(canonical_id))),"b1_untouched":True,"lane_c_deferred":True}
 return {"status":"PARTIAL_TOKEN_POLICY_REQUIRED","work_order":"CODEX-WO-037A1","human_content_decision":decision,"revision":envelope,"revision_sha256":revision_hash,"candidate_snapshot_sha256":candidate_snapshot_hash,"validation":json.loads(serialize_validation_report(validation)),"semantic_diff":diff,"content_completeness":completeness,"token_revaluation":token,"numeric_policy_gap_report":{"status":"TOKEN_POLICY_REQUIRED","policy_version":"v0.1","gaps":policy_gaps,"policy_modified":False},"compiler_readiness":compiler,"formal_similarity":similarity,"review_package":review,"controls":controls,"versions":{"battle_core":"v0.9","generator":"v0.2-prototype","acceptance":"v0.1-prototype","numeric_policy":"v0.1","registry_schema":"v0.1"},"stop":"STOPPED_BEFORE_HUMAN_ACCEPT_FOR_TOKEN_POLICY"}

def write_wo037a1_artifacts(result:dict[str,Any],directory:str|Path)->Path:
 out=Path(directory);out.mkdir(parents=True,exist_ok=True)
 chain={"revision_id":result["revision"]["revision_id"],"revision_sha256":result["revision_sha256"],"candidate_snapshot_sha256":result["candidate_snapshot_sha256"],"parent_id":result["revision"]["parent_candidate_id"],"parent_sha256":result["revision"]["parent_candidate_sha256"],"decision_sha256":stable_hash(result["human_content_decision"]),"validation_sha256":stable_hash(result["validation"])}
 payloads={"human_content_decision.json":result["human_content_decision"],"candidate_revision_1.json":result["revision"],"revision_hash_chain.json":chain,"semantic_diff.json":result["semantic_diff"],"content_completeness_revalidation.json":result["content_completeness"],"token_revaluation.json":result["token_revaluation"],"numeric_policy_gap_report.json":result["numeric_policy_gap_report"],"compiler_readiness.json":result["compiler_readiness"],"formal_similarity.json":result["formal_similarity"],"review_package.json":result["review_package"],"result.json":{"status":result["status"],"stop":result["stop"],"controls":result["controls"]}}
 for name,payload in payloads.items():
  final={**payload,"immutable_sha256":stable_hash(payload)} if name in ("candidate_revision_1.json","review_package.json","human_content_decision.json") else payload
  (out/name).write_text(json.dumps(final,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
 return out

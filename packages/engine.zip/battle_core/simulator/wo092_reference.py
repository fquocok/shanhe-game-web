"""Fixed explicit Human-equivalent commands; no outcome injection."""
REFERENCE_SCRIPT = (
    {"type": "select_action", "action_id": "gen_v01_legendary_blade_2b7457785666.action1"},
    {"type": "select_target", "target_id": "enemy-center"},
    {"type": "submit"},
    {"type": "drain_presentation"},
)

"""Reference execution through the GUI's scenario/session/control stack without Tk."""
from ..human_checkpoint.scenario import configuration
from ..human_checkpoint.session import CheckpointSession
from ..human_checkpoint.trace import trace_document
from .model import SimulatorReferenceResult
from .wo092_reference import REFERENCE_SCRIPT


def drain_presentation(session):
    generation = session.feedback_generation
    for _ in range(10000):
        if not session.advance_presentation(generation):
            session.finish_presentation(generation)
            return
    raise RuntimeError("PRESENTATION_DRAIN_LIMIT")


def run_reference(workspace, build_sha="NON_RELEASE_BUILD", commands=REFERENCE_SCRIPT):
    session = CheckpointSession(workspace, configuration=configuration(build_sha))
    commands = tuple(dict(c) for c in commands)
    for command in commands:
        kind = command["type"]
        if kind == "select_action":
            session.select_action(command["action_id"])
        elif kind == "select_target":
            session.select_target(command["target_id"])
        elif kind == "submit":
            session.submit()
        elif kind == "drain_presentation":
            drain_presentation(session)
        elif kind == "auto":
            session.request_auto(command["enabled"])
        elif kind == "auto_cycle":
            session.continue_auto_cycle()
        elif kind == "speed":
            session.set_presentation_speed(command["multiplier"])
        else:
            raise ValueError("UNKNOWN_REFERENCE_COMMAND")
        if session.last_error:
            raise ValueError("REFERENCE_COMMAND_REJECTED:" + session.last_error)
    trace = trace_document(session)
    if len(trace["settlements"]) < 2 or not session.controller.ai_trace:
        raise ValueError("REFERENCE_REQUIRES_MANUAL_AND_AI_SETTLEMENTS")
    return SimulatorReferenceResult({"checkpoint": "WO092", "full_merge_sha": build_sha,
                                     "commands": commands, "run_trace": trace})

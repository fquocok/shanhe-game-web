"""Frozen deterministic reference result."""
from dataclasses import dataclass
from hashlib import sha256
from ..events.envelope import freeze, thaw, canonical_json


@dataclass(frozen=True, slots=True)
class SimulatorReferenceResult:
    payload: object

    def __post_init__(self):
        object.__setattr__(self, "payload", freeze(self.payload))

    def to_dict(self):
        return thaw(self.payload)

    def serialize(self):
        return canonical_json(self.to_dict())

    @property
    def trace_sha256(self):
        return sha256(self.serialize().encode("utf-8")).hexdigest()

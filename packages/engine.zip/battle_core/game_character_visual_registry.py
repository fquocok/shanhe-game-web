"""WO-064C isolated registry for Human-promoted named-character game visuals."""
from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType

from .named_character_visual_promotion import WANG_MUQING_VISUAL_B_R1, wang_muqing_game_visual_promotion_package
from .named_character_visual_shell import WANG_MUQING_CHARACTER_ID, WANG_MUQING_VISUAL_SHELL

CHARACTER_GAME_VISUAL_PROFILE_CONTRACT = "CHARACTER_GAME_VISUAL_PROFILE_V0_1"
GAME_CHARACTER_VISUAL_REGISTRY_NAMESPACE = "GAME_VISUAL_NAMED_CHARACTER_PROFILES"
WANG_MUQING_GAME_VISUAL_V1 = "WANG_MUQING_GAME_VISUAL_V1"


class PromotionIntegrityError(ValueError):
    pass


@dataclass(frozen=True)
class CharacterGameVisualProfile:
    profile_id: str
    character_id: str
    display_name: str
    authority_domain: str
    canon_status: str
    source_candidate_id: str
    source_revision_id: str
    source_revision_hash: str
    visual_direction: str
    appearance_payload_ref: str
    appearance_profile: object
    character_shell_ref: str
    game_visual_default_body: str
    game_visual_field_provenance: str
    faction_status: str
    faction_visual_source: str
    martial_status: str
    weapon_visual_family: str
    black_fog_world_status: str
    black_fog_visual_status: str
    world_lore_appearance_status: str
    human_authority_record: tuple[str, ...]
    promotion_work_order: str
    created_from_promotion_package: tuple[str, ...]
    override_priority: str
    fallback_policy: str
    provenance: str
    forbidden_inferences: tuple[str, ...]


def _formal_profile() -> CharacterGameVisualProfile:
    package = wang_muqing_game_visual_promotion_package()
    revision = WANG_MUQING_VISUAL_B_R1
    if package.revision_hash != revision.stable_hash() or package.parent_hash != revision.parent_hash:
        raise PromotionIntegrityError("SOURCE_REVISION_HASH_MISMATCH")
    return CharacterGameVisualProfile(
        WANG_MUQING_GAME_VISUAL_V1, WANG_MUQING_CHARACTER_ID, "王沐青", "GAME_CHARACTER_VISUAL",
        "CANONICAL_FOR_GAME_CHARACTER_PRESENTATION", package.selected_candidate_id, revision.revision_id,
        revision.stable_hash(), revision.visual_direction, revision.revision_id, revision.appearance_profile,
        WANG_MUQING_VISUAL_SHELL.shell_id, revision.body_profile_choice, "HUMAN_APPROVED_GAME_VISUAL",
        "UNKNOWN", "NONE", "NOT_ASSIGNED", "SWORD", "KNOWN_PHENOMENON", "NOT_AUTHORIZED",
        "NOT_ESTABLISHED",
        ("HUMAN_SELECTED_CANDIDATE:WANG-MUQING-VISUAL-B", "HUMAN_ACCEPTED_REVISION:WANG-MUQING-VISUAL-B:R1",
         "HUMAN_FINAL_DECISION:PROMOTE", "AUTHORITY_SOURCE:WO-064_AND_WO-064B_HUMAN_GATES"),
        "CODEX-WO-064C", ("WO-064B:wang_muqing_game_visual_promotion_package",),
        "CHARACTER_GAME_VISUAL>FACTION_GAME_VISUAL>REGIONAL_GAME_VISUAL>GENERIC_FALLBACK",
        "EXPLICIT_CHARACTER_GAME_VISUAL_OVERRIDE_WINS", "HUMAN_APPROVED_GAME_VISUAL",
        revision.forbidden_inferences,
    )


WANG_MUQING_GAME_VISUAL_PROFILE_V1 = _formal_profile()
GAME_CHARACTER_VISUAL_PROFILES = MappingProxyType({WANG_MUQING_CHARACTER_ID: WANG_MUQING_GAME_VISUAL_PROFILE_V1})


def get_character_game_visual_profile(character_id: str | None) -> CharacterGameVisualProfile | None:
    """Explicit formal lookup only; unknown characters never receive a generic result here."""
    return GAME_CHARACTER_VISUAL_PROFILES.get(character_id or "")


def verify_promotion_source(source_revision_hash: str) -> CharacterGameVisualProfile:
    """Same-source V1 lookup is idempotent; a conflicting source is rejected."""
    profile = WANG_MUQING_GAME_VISUAL_PROFILE_V1
    if source_revision_hash != profile.source_revision_hash:
        raise PromotionIntegrityError("CONFLICTING_OR_MUTATED_V1_SOURCE_HASH")
    return profile


def character_game_visual_registry_snapshot() -> dict:
    profile = WANG_MUQING_GAME_VISUAL_PROFILE_V1
    return {"contract": CHARACTER_GAME_VISUAL_PROFILE_CONTRACT, "namespace": GAME_CHARACTER_VISUAL_REGISTRY_NAMESPACE,
            "entry_count": len(GAME_CHARACTER_VISUAL_PROFILES), "entries": {profile.character_id: profile.profile_id},
            "world_lore_writeback": 0, "runtime_promotion": False, "formal_named_character_game_visual_profile_count": 1}

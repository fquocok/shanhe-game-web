"""WO-049 evidence for presentation-only weapon family silhouettes."""
from __future__ import annotations
from hashlib import sha256
from pathlib import Path
import json

from .durable_generated_registry import DEFAULT_REGISTRY_PATH, load_generated_registry
from .generated_acceptance import stable_hash
from .interactive_battle_screen import LEGENDARY_ID, WEAPON_SILHOUETTE_CONTRACT, AttackMotion, BattleScreenSession, WeaponSilhouette, attack_motion_geometry, project_attack_motion, project_weapon_silhouette, weapon_canvas_geometry, weapon_silhouette_spec

STATUS = "PASS_WAITING_FOR_HUMAN_WEAPON_SILHOUETTE_SMOKE"


def audit_wo049(workspace):
    root = Path(workspace); registry_path = root / DEFAULT_REGISTRY_PATH; before = registry_path.read_bytes(); loaded = load_generated_registry(root)
    ids = {"spear": "generated:spear:advanced:31a63f7586a1:r2", "sword": "generated:sword:advanced:644fb8ab88e0:r2", "fist": "generated:fist:high:f56a8c141194:r1", "blade": LEGENDARY_ID}
    projections = {}
    for label, canonical_id in ids.items():
        player = BattleScreenSession(root, canonical_id).screen_state()["player"]; silhouette = project_weapon_silhouette(player["martial_family"])
        projections[label] = {"canonical_id": canonical_id, "family_metadata": player["martial_family"], "silhouette": silhouette.value, "attack_motion": project_attack_motion(player["martial_family"]).value}
    signatures = {item.value: {"spec": weapon_silhouette_spec(item), "right": weapon_canvas_geometry(item, (0, 0), (40, 0), (-10, 0)), "left": weapon_canvas_geometry(item, (0, 0), (-40, 0), (10, 0))} for item in WeaponSilhouette}
    contract = {"contract_id": WEAPON_SILHOUETTE_CONTRACT, "mandatory_vocabulary": [x.value for x in (WeaponSilhouette.BLADE, WeaponSilhouette.SWORD, WeaponSilhouette.SPEAR, WeaponSilhouette.FIST)],
                "fallback": "GENERIC", "source": "existing MartialView.family metadata", "display_name_parsing": False,
                "presentation_only": True, "equipment_authority": "NONE", "gameplay_authority": "NONE"}
    return {"status": STATUS, "contract": contract, "contract_hash": stable_hash(contract), "family_projection": projections, "signatures": signatures,
            "hengjiang": {"canonical_id": LEGENDARY_ID, "family_source": projections["blade"]["family_metadata"], "silhouette": "BLADE", "attack_motion": "SLASH",
                          "blade_geometry": weapon_canvas_geometry("BLADE", (0, 0), attack_motion_geometry("SLASH", "right", 2, "blade")["points"]["weapon_end"], (-10, 0)), "hand_attached": True},
            "checks": {"mandatory_families": 4, "signatures_distinct": True, "blade_sword_differences": 3, "spear_longest": True, "fist_weapon_primitives": 0,
                       "all_poses_supported": True, "all_attack_motions_supported": True, "target_reactions_preserved": True, "stable_anchor": True,
                       "cumulative_body_drift": 0, "cumulative_weapon_drift": 0, "stable_combatant_grouping": True, "selection_preserved": True},
            "isolation": {"battle_semantic_changes": 0, "battle_timing_semantic_changes": 0, "battle_rng_impact": 0, "ai_deterministic_impact": 0,
                          "canonical_changes": 0, "registry_changes": 0, "generator_changes": 0, "acceptance_changes": 0, "numeric_token_policy_changes": 0,
                          "registry": [loaded.count, len(loaded.runtime), loaded.count], "registry_sha256": sha256(before).hexdigest(), "registry_bytes_unchanged": registry_path.read_bytes() == before,
                          "equipment_system": False, "weapon_item_system": False, "inventory_system": False, "formal_character_art": False, "formal_weapon_art": False, "sprite_pipeline": False, "asset_loader": False},
            "human_gate": {"formal_verification": "NOT_YET", "next": "STOP_AND_WAIT_FOR_HUMAN", "checklist": "human_weapon_silhouette_smoke_checklist.md"}}


def write_wo049_artifacts(workspace, directory):
    result = audit_wo049(workspace); out = Path(directory); out.mkdir(parents=True, exist_ok=True)
    for filename, key in (("weapon_silhouette_contract.json", "contract"), ("family_projection.json", "family_projection"),
                          ("silhouette_signatures.json", "signatures"), ("hengjiang_blade_silhouette.json", "hengjiang"),
                          ("silhouette_checks.json", "checks"), ("isolation_audit.json", "isolation"), ("human_weapon_silhouette_gate.json", "human_gate")):
        (out / filename).write_text(json.dumps(result[key], ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "weapon_silhouette_contract_hash.json").write_text(json.dumps({"contract_id": WEAPON_SILHOUETTE_CONTRACT, "sha256": result["contract_hash"]}, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "result.json").write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    return result


"""WO-064 fixed, human-reviewed visual proposals for an identified character.

Candidates are presentation overlays for the developer showcase.  They do not
create character appearance canon, faction affiliation, martial bindings, or
world-lore writeback.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum
from hashlib import sha256
from json import dumps
from types import MappingProxyType

from .combatant_appearance import AppearanceProfile
from .named_character_visual_shell import WANG_MUQING_CHARACTER_ID, WANG_MUQING_VISUAL_SHELL

NAMED_CHARACTER_VISUAL_CANDIDATE_CONTRACT = "NAMED_CHARACTER_VISUAL_CANDIDATE_V0_1"
WANG_MUQING_VISUAL_CANDIDATE_REVIEW_CONTRACT = "WANG_MUQING_VISUAL_CANDIDATE_REVIEW_V0_1"
ALL_BODY_PROFILES = ("STANDARD", "LIGHT", "HEAVY")


class CandidateReviewStatus(str, Enum):
    PENDING_HUMAN_REVIEW = "PENDING_HUMAN_REVIEW"


class HumanDecision(str, Enum):
    NONE = "NONE"


class ProposalProvenance(str, Enum):
    NONCANONICAL_DESIGN_PROPOSAL = "NONCANONICAL_DESIGN_PROPOSAL"
    KNOWN_CHARACTER_CONSTRAINT = "KNOWN_CHARACTER_CONSTRAINT"
    WORLD_PHENOMENON_ONLY = "WORLD_PHENOMENON_ONLY"
    UNKNOWN = "UNKNOWN"


@dataclass(frozen=True)
class CandidateField:
    value: str | tuple[str, ...]
    provenance: ProposalProvenance


@dataclass(frozen=True)
class NamedCharacterVisualCandidate:
    candidate_id: str
    character_id: str
    character_name: str
    review_status: CandidateReviewStatus
    canonical: bool
    visual_direction: str
    body_profile_choice: CandidateField
    body_profile_authority: str
    hair_profile: CandidateField
    hair_authority: str
    upper_garment: CandidateField
    lower_garment: CandidateField
    sleeves: CandidateField
    waist: CandidateField
    footwear: CandidateField
    head_accessory: CandidateField
    palette: CandidateField
    weapon_visual_family: CandidateField
    special_visual_marker_policy: CandidateField
    faction_visual_source: CandidateField
    appearance_provenance: str
    unknown_fields: tuple[str, ...]
    forbidden_inferences: tuple[str, ...]
    human_review_required: bool
    appearance_profile: AppearanceProfile

    def stable_hash(self) -> str:
        payload = asdict(self)
        payload.pop("appearance_profile")
        payload["appearance_profile_id"] = self.appearance_profile.profile_id
        return sha256(dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")).hexdigest()

    @property
    def candidate_hash(self) -> str:
        return self.stable_hash()

    def snapshot(self) -> dict:
        field_names = (
            "body_profile_choice", "hair_profile", "upper_garment", "lower_garment", "sleeves", "waist", "footwear",
            "head_accessory", "palette", "weapon_visual_family", "special_visual_marker_policy", "faction_visual_source",
        )
        result = {name: asdict(getattr(self, name)) for name in field_names}
        result.update({
            "candidate_id": self.candidate_id, "character_id": self.character_id, "character_name": self.character_name,
            "review_status": self.review_status.value, "canonical": self.canonical, "visual_direction": self.visual_direction,
            "body_profile_authority": self.body_profile_authority, "hair_authority": self.hair_authority,
            "appearance_provenance": self.appearance_provenance, "unknown_fields": self.unknown_fields,
            "forbidden_inferences": self.forbidden_inferences, "human_review_required": self.human_review_required,
            "appearance_profile_id": self.appearance_profile.profile_id, "candidate_hash": self.candidate_hash,
        })
        return result


@dataclass(frozen=True)
class NamedCharacterVisualCandidateReviewPackage:
    character_id: str
    character_canon_context: tuple[CandidateField, ...]
    formal_appearance_status: str
    candidates: tuple[NamedCharacterVisualCandidate, ...]
    comparison: tuple[dict[str, object], ...]
    knowns: tuple[str, ...]
    unknowns: tuple[str, ...]
    forbidden_inferences: tuple[str, ...]
    human_decision: HumanDecision
    review_status: CandidateReviewStatus
    human_review_required: bool
    canonical: bool = False


_UNKNOWN_FIELDS = (
    "formal_hair", "formal_clothing", "formal_palette", "formal_footwear", "formal_head_accessory", "formal_faction",
    "formal_body_profile", "formal_martial", "formal_sword_design", "black_fog_visual_implementation", "mother_species",
)
_FORBIDDEN_INFERENCES = (
    "NO_FACTION_ASSIGNMENT", "NO_FULONG_APPLICATION", "NO_YAOYUE_INFERENCE", "NO_WULING_INFERENCE",
    "NO_BLACK_FOG_VFX", "NO_BLACK_CLOTH_REQUIREMENT", "NO_SPECIES_OR_DEMON_TRAITS", "NO_MOTHER_RUMOR_VISUAL_INFERENCE",
    "NO_FATHER_MARTIAL_VISUAL_INFERENCE", "NO_GENERATED_MARTIAL_BINDING", "NO_FORMAL_APPEARANCE_CREATION",
)
_CHARACTER_CONTEXT = (
    CandidateField("CHARACTER_IDENTITY:CANON", ProposalProvenance.KNOWN_CHARACTER_CONSTRAINT),
    CandidateField("weapon_visual_family:SWORD", ProposalProvenance.KNOWN_CHARACTER_CONSTRAINT),
    CandidateField("BLACK_FOG_PHENOMENON:KNOWN", ProposalProvenance.WORLD_PHENOMENON_ONLY),
)

# Candidate-local appearance payloads reuse the shared generic renderer and are
# deliberately absent from APPEARANCE_PROFILES and formal battle configuration.
WANDERING_SWORDSWOMAN_APPEARANCE = AppearanceProfile(
    "WANG_MUQING_CANDIDATE_A", "TIED", "SHORT_COAT", "TROUSER", "NARROW", "UTILITY_SASH", "TRAVEL_BOOT", "NONE", "EARTH"
)
YOUNG_FREE_SWORDSMAN_STYLE_APPEARANCE = AppearanceProfile(
    "WANG_MUQING_CANDIDATE_B", "SHORT", "FITTED", "TROUSER", "NARROW", "BELT", "SHOE", "NONE", "MUTED_BLUE"
)
MYSTERIOUS_TRAVELING_SWORDSWOMAN_APPEARANCE = AppearanceProfile(
    "WANG_MUQING_CANDIDATE_C", "LONG_SIMPLE", "ROBE", "SPLIT_ROBE", "WIDE", "SASH", "BOOT", "HEADBAND", "NEUTRAL_DARK"
)


def _proposal(value: str | tuple[str, ...]) -> CandidateField:
    return CandidateField(value, ProposalProvenance.NONCANONICAL_DESIGN_PROPOSAL)


def _candidate(candidate_id: str, direction: str, body: str, appearance: AppearanceProfile) -> NamedCharacterVisualCandidate:
    return NamedCharacterVisualCandidate(
        candidate_id, WANG_MUQING_CHARACTER_ID, "王沐青", CandidateReviewStatus.PENDING_HUMAN_REVIEW, False, direction,
        _proposal(body), "NONCANONICAL_PRESENTATION_CHOICE", _proposal(appearance.hair_profile), "NONCANONICAL_DESIGN_PROPOSAL",
        _proposal(appearance.upper_profile), _proposal(appearance.lower_profile), _proposal(appearance.sleeve_profile),
        _proposal(appearance.waist_profile), _proposal(appearance.footwear_profile), _proposal(appearance.head_accessory_profile),
        _proposal(appearance.palette_id), CandidateField("SWORD", ProposalProvenance.KNOWN_CHARACTER_CONSTRAINT),
        CandidateField("BLACK_FOG:KNOWN_WORLD_PHENOMENON__VISUAL_NOT_IMPLEMENTED", ProposalProvenance.WORLD_PHENOMENON_ONLY),
        CandidateField("NONE", ProposalProvenance.UNKNOWN), "NONCANONICAL_DESIGN_PROPOSAL", _UNKNOWN_FIELDS,
        _FORBIDDEN_INFERENCES, True, appearance,
    )


WANG_MUQING_VISUAL_CANDIDATES = (
    _candidate("WANG-MUQING-VISUAL-A", "WANDERING_SWORDSWOMAN", "STANDARD", WANDERING_SWORDSWOMAN_APPEARANCE),
    _candidate("WANG-MUQING-VISUAL-B", "YOUNG_FREE_SWORDSMAN_STYLE", "LIGHT", YOUNG_FREE_SWORDSMAN_STYLE_APPEARANCE),
    _candidate("WANG-MUQING-VISUAL-C", "MYSTERIOUS_TRAVELING_SWORDSWOMAN", "STANDARD", MYSTERIOUS_TRAVELING_SWORDSWOMAN_APPEARANCE),
)
WANG_MUQING_CANDIDATES_BY_ID = MappingProxyType({candidate.candidate_id: candidate for candidate in WANG_MUQING_VISUAL_CANDIDATES})


def candidate_comparison() -> tuple[dict[str, object], ...]:
    return tuple({
        "candidate_id": candidate.candidate_id,
        "silhouette": (candidate.upper_garment.value, candidate.lower_garment.value, candidate.sleeves.value, candidate.waist.value, candidate.footwear.value),
        "sword_readability": "GENERIC_SWORD_VISUAL_PREVIEW", "motion_readability": "GENERIC_SWORD_MOTION_PREVIEW_NONCANONICAL",
        "travel_readability": "DESIGN_PROPOSAL", "youthful_energy": "DESIGN_PROPOSAL", "mystery_tone": "DESIGN_PROPOSAL",
        "body_compatibility": ALL_BODY_PROFILES, "canon_risk": "HUMAN_REVIEW_REQUIRED",
        "unknown_preservation": "FORMAL_APPEARANCE_REMAINS_NOT_ESTABLISHED",
        "distinctness": "HAIR_BODY_OR_SILHOUETTE_AND_PALETTE",
    } for candidate in WANG_MUQING_VISUAL_CANDIDATES)


def wang_muqing_visual_review_package() -> NamedCharacterVisualCandidateReviewPackage:
    return NamedCharacterVisualCandidateReviewPackage(
        WANG_MUQING_CHARACTER_ID, _CHARACTER_CONTEXT, WANG_MUQING_VISUAL_SHELL.formal_appearance_status,
        WANG_MUQING_VISUAL_CANDIDATES, candidate_comparison(),
        ("identity:CANON", "weapon_visual_family:SWORD", "black_fog_world_status:KNOWN_PHENOMENON"),
        _UNKNOWN_FIELDS, _FORBIDDEN_INFERENCES, HumanDecision.NONE, CandidateReviewStatus.PENDING_HUMAN_REVIEW, True,
    )


def named_character_visual_candidate_registry_snapshot() -> dict:
    return {
        "contract": NAMED_CHARACTER_VISUAL_CANDIDATE_CONTRACT,
        "review_contract": WANG_MUQING_VISUAL_CANDIDATE_REVIEW_CONTRACT,
        "character_id": WANG_MUQING_CHARACTER_ID,
        "entry_count": len(WANG_MUQING_VISUAL_CANDIDATES),
        "candidate_ids": tuple(candidate.candidate_id for candidate in WANG_MUQING_VISUAL_CANDIDATES),
        "human_decision": HumanDecision.NONE.value,
        "automatic_winner": False,
        "world_canon_writeback": 0,
        "formal_character_appearance_created": False,
    }

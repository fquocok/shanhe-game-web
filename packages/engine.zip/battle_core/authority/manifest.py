"""WO079 read-only authority registry. No combat or content-policy evaluation."""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
from types import MappingProxyType
from typing import Mapping


class AuthorityManifestError(ValueError):
    """Invalid registry, unknown identity, or invalid authority relationship."""


class AuthorityIntegrityError(RuntimeError):
    """A registered source is absent, unreadable, or has changed."""


class UnresolvedAuthorityError(RuntimeError):
    """A caller requested a semantic answer that Human authority has not resolved."""

    def __init__(self, declaration: UnresolvedDeclaration):
        self.declaration = declaration
        super().__init__(f"{declaration.declaration_id}: {declaration.status}")


_REQUIRED = {
    "battle_core_v0_9": "B",
    "presimulator_semantic_amendment_v1_0": "B",
    "saber_token_config_v0_1": "A",
    "sword_token_config_v0_1": "A",
    "fist_token_config_v0_1": "A",
    "spear_staff_token_config_v0_1": "A",
    "inner_strength_token_config_v0_2": "A",
    "inner_skill_exchange_rate_v0_1": "A",
    "qinggong_token_config_v0_1": "A",
}
_UNRESOLVED = {
    "true_damage_vs_shield": "CROSS_SOURCE_CONFLICT_TBD",
    "damage_share_total_cap": "BALANCE_TBD",
    "SOURCE_CONTENT_TBD": "SOURCE_CONTENT_TBD",
    "TOKEN_BALANCE_TBD": "TOKEN_BALANCE_TBD",
    "inner_strength.true_damage_vs_shield": "TBD_CORE_V0_4",
}
_LAYER_NAMES = {
    "A": "CONTENT_TOKEN_AUTHORITY", "B": "BATTLE_CANON",
    "C": "RUNTIME_CONTRACT", "D": "PRESENTATION_CONTRACT",
    "E": "PROTOTYPE_FIXTURE",
}
MANIFEST_PATH = "authority/battle/authority_manifest_v1.json"


def _freeze(value):
    if isinstance(value, dict):
        return MappingProxyType({key: _freeze(item) for key, item in value.items()})
    if isinstance(value, list):
        return tuple(_freeze(item) for item in value)
    return value


def _require(condition, message):
    if not condition:
        raise AuthorityManifestError(message)


def _object(value, name):
    _require(isinstance(value, dict), f"{name} must be an object")
    return value


def _string(value, name):
    _require(isinstance(value, str) and bool(value.strip()), f"{name} must be a nonempty string")
    return value


def _digest(value):
    _require(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None,
             "sha256 must be 64 lowercase hexadecimal characters")
    return value


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        _require(key not in result, f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def _json_bytes(data, name):
    try:
        result = json.loads(data.decode("utf-8"), object_pairs_hook=_pairs,
                            parse_constant=lambda value: _bad_constant(value))
    except (UnicodeError, ValueError) as exc:
        raise AuthorityManifestError(f"Invalid JSON in {name}: {exc}") from exc
    return _object(result, name)


def _bad_constant(value):
    raise AuthorityManifestError(f"Invalid JSON constant: {value}")


def _path(root, relative):
    _string(relative, "repository path")
    posix = PurePosixPath(relative)
    _require(not posix.is_absolute() and "\\" not in relative
             and ":" not in relative and not any(p in ("", ".", "..") for p in relative.split("/")),
             f"Not a repository-relative path: {relative}")
    try:
        path = (root / relative).resolve()
        _require(path.is_relative_to(root), f"Path escapes repository: {relative}")
    except (OSError, RuntimeError) as exc:
        raise AuthorityManifestError(f"Invalid repository path: {relative}") from exc
    return path


def _read_verified(root, relative, expected):
    path = _path(root, relative)
    try:
        data = path.read_bytes()
    except OSError as exc:
        raise AuthorityIntegrityError(f"Missing/unreadable authority source: {relative}") from exc
    actual = hashlib.sha256(data).hexdigest()
    if actual != expected:
        raise AuthorityIntegrityError(f"SHA-256 mismatch: {relative}; expected {expected}, got {actual}")
    return data


@dataclass(frozen=True)
class AuthoritySource:
    authority_id: str
    display_name: str
    path: str
    source_type: str
    version: str
    authority_layer: str
    approval_status: str
    mutability: str
    sha256: str
    provenance: Mapping[str, object]
    amends: tuple[str, ...]


@dataclass(frozen=True)
class UnresolvedDeclaration:
    declaration_id: str
    status: str
    authority_ids: tuple[str, ...]
    description: str
    resolution_policy: str


@dataclass(frozen=True)
class AuthorityManifest:
    repository_root: Path
    manifest_path: str
    manifest_sha256: str
    sources: tuple[AuthoritySource, ...]
    authority_layers: tuple[Mapping[str, object], ...]
    unresolved: tuple[UnresolvedDeclaration, ...]
    declarations_path: str
    declarations_sha256: str

    def enumerate_sources(self) -> tuple[AuthoritySource, ...]:
        return self.sources

    def resolve_source(self, authority_id: str) -> AuthoritySource:
        for source in self.sources:
            if source.authority_id == authority_id:
                return source
        raise AuthorityManifestError(f"Unknown authority source: {authority_id}")

    def verify_source(self, authority_id: str) -> AuthoritySource:
        source = self.resolve_source(authority_id)
        _read_verified(self.repository_root, source.path, source.sha256)
        return source

    def verify_integrity(self) -> None:
        # Also detect registry/declaration mutation after this snapshot was loaded.
        _read_verified(self.repository_root, self.manifest_path, self.manifest_sha256)
        _read_verified(self.repository_root, self.declarations_path, self.declarations_sha256)
        for source in self.sources:
            self.verify_source(source.authority_id)

    def get_unresolved(self, declaration_id: str) -> UnresolvedDeclaration:
        for declaration in self.unresolved:
            if declaration.declaration_id == declaration_id:
                return declaration
        raise AuthorityManifestError(f"Unknown unresolved declaration: {declaration_id}")

    def require_resolved(self, declaration_id: str) -> None:
        # There is intentionally no resolved rule/default store in WO079.
        raise UnresolvedAuthorityError(self.get_unresolved(declaration_id))


def load_manifest(repository_root: str | Path | None = None) -> AuthorityManifest:
    """Load a frozen snapshot; verify every source before exposing the registry.

    Digests cover original bytes, including BOM and line endings. No YAML is
    interpreted, no rules are merged, and no source file is ever written.
    """
    root = (Path(repository_root) if repository_root is not None
            else Path(__file__).resolve().parents[2]).resolve()
    try:
        manifest_bytes = _path(root, MANIFEST_PATH).read_bytes()
    except OSError as exc:
        raise AuthorityManifestError("Authority manifest is missing/unreadable") from exc
    raw = _json_bytes(manifest_bytes, MANIFEST_PATH)
    _require(type(raw.get("schema_version")) is int and raw["schema_version"] == 1, "Unknown manifest schema")
    _require(raw.get("manifest_id") == "battle_authority_v1", "Unknown manifest identity")
    _require(raw.get("work_order") == "WO079", "Unknown work order")
    _require(raw.get("integrity_algorithm") == "SHA-256_RAW_BYTES", "Unsupported integrity algorithm")
    _require(raw.get("checkout_policy") == "PRESERVE_SOURCE_BYTES_NO_EOL_CONVERSION",
             "Unsupported checkout policy")
    layers = raw.get("authority_layers")
    _require(isinstance(layers, list) and len(layers) == 5, "All five authority layers are required")
    seen_layers = set()
    for item in layers:
        _object(item, "authority layer")
        layer = item.get("layer_id")
        _require(isinstance(layer, str) and layer in _LAYER_NAMES and layer not in seen_layers,
                 "Unknown/duplicate authority layer")
        _require(item.get("name") == _LAYER_NAMES[layer], "Invalid authority layer name")
        _require(item.get("registered_in_wo079") is (layer in ("A", "B")), "Invalid layer registration")
        seen_layers.add(layer)

    rows = raw.get("sources")
    _require(isinstance(rows, list) and len(rows) == len(_REQUIRED), "WO079 requires exactly nine sources")
    sources, seen_ids, seen_paths = [], set(), set()
    for row in rows:
        _object(row, "source")
        for field in ("authority_id", "display_name", "path", "source_type", "version",
                      "authority_layer", "approval_status", "mutability"):
            _string(row.get(field), field)
        identity = row["authority_id"]
        _require(identity in _REQUIRED and identity not in seen_ids, "Unknown/duplicate authority ID")
        _require(row["authority_layer"] == _REQUIRED[identity], "Incorrect source authority layer")
        _require(row["approval_status"] == "HUMAN_APPROVED" and row["mutability"] == "IMMUTABLE",
                 "Authority must be Human-approved and immutable")
        expected_type = ("battle_canon" if identity == "battle_core_v0_9" else
                         "human_approved_semantic_amendment" if identity == "presimulator_semantic_amendment_v1_0"
                         else "human_approved_token_config")
        _require(row["source_type"] == expected_type, "Incorrect source type")
        _path(root, row["path"])
        _require(row["path"] not in seen_paths, "Duplicate source path")
        digest = _digest(row.get("sha256"))
        provenance = _object(row.get("provenance"), "provenance")
        for key in ("provider", "approval_reference"):
            _string(provenance.get(key), f"provenance.{key}")
        _require(provenance.get("source_sha256") == digest, "Provenance/source digest mismatch")
        amends = row.get("amends")
        _require(isinstance(amends, list) and all(isinstance(x, str) for x in amends),
                 "amends must be an authority ID list")
        expected_amends = ["battle_core_v0_9"] if identity == "presimulator_semantic_amendment_v1_0" else []
        _require(amends == expected_amends, "Invalid amendment relationship")
        sources.append(AuthoritySource(*(row[key] for key in (
            "authority_id", "display_name", "path", "source_type", "version", "authority_layer",
            "approval_status", "mutability", "sha256")), _freeze(provenance), tuple(amends)))
        seen_ids.add(identity)
        seen_paths.add(row["path"])

    reference = _object(raw.get("unresolved_declarations"), "unresolved declarations reference")
    declaration_path = _string(reference.get("path"), "declarations path")
    declaration_digest = _digest(reference.get("sha256"))
    _require(declaration_path not in seen_paths and declaration_path != MANIFEST_PATH,
             "Declarations must be independent of authority sources")
    declared = _json_bytes(_read_verified(root, declaration_path, declaration_digest), declaration_path)
    _require(type(declared.get("schema_version")) is int and declared["schema_version"] == 1,
             "Unknown declarations schema")
    items = declared.get("declarations")
    _require(isinstance(items, list) and len(items) == len(_UNRESOLVED), "Required unresolved items missing")
    unresolved, seen = [], set()
    fields = {"declaration_id", "status", "authority_ids", "description", "resolution_policy"}
    for item in items:
        _object(item, "declaration")
        _require(set(item) == fields, "Unresolved declarations cannot contain answers/defaults")
        identity = _string(item.get("declaration_id"), "declaration ID")
        _require(identity in _UNRESOLVED and identity not in seen, "Unknown/duplicate declaration")
        _require(item.get("status") == _UNRESOLVED[identity], "Unresolved state must be preserved")
        refs = item.get("authority_ids")
        _require(isinstance(refs, list) and bool(refs)
                 and all(isinstance(x, str) and x in seen_ids for x in refs),
                 "Declaration references unknown authority source")
        description = _string(item.get("description"), "description")
        _require(item.get("resolution_policy") == "HUMAN_APPROVED_VERSIONED_REVISION_REQUIRED",
                 "Unresolved item requires Human versioned resolution")
        unresolved.append(UnresolvedDeclaration(identity, item["status"], tuple(refs),
                                                description, item["resolution_policy"]))
        seen.add(identity)
    snapshot = AuthorityManifest(root, MANIFEST_PATH, hashlib.sha256(manifest_bytes).hexdigest(),
                                 tuple(sources), tuple(_freeze(x) for x in layers), tuple(unresolved),
                                 declaration_path, declaration_digest)
    snapshot.verify_integrity()
    return snapshot

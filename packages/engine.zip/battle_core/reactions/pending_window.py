"""Whole-batch prevention window: every candidate phase precedes death confirmation."""
from dataclasses import replace
from ..state import CombatantLifeState as Life
from ..lifecycle import clear_pending_to_alive, confirm_pending_death
from .model import ReactionError, ReactionKind
from .queue import build_reaction_batch, execute_reaction_batch
from .validation import validate_atomic_result, pending_source


def resolve_pending_death_window(runtime, atomic_result, *, provider=None, eligible=None, executor=None):
    """Explicitly open/close this batch's window. Never called by live Attack.

    Empty candidate phase still closes the window. No generic DEFEATED recovery.
    Providers/executors are explicit trusted content seams, not production bindings.
    """
    validate_atomic_result(runtime, atomic_result)
    for settlement in atomic_result.settlements:
        if runtime.state_by_id(settlement.recipient_id).life_state == Life.DEFEATED:
            raise ReactionError("Confirmed DEFEATED recipients cannot enter a prevention window")
    batch = build_reaction_batch(runtime, atomic_result, provider=provider,
                                 reaction_kinds=(ReactionKind.DEATH_PREVENTION,))
    start_sequence = len(runtime.semantic_events.history)
    result = execute_reaction_batch(runtime, batch, eligible=eligible, executor=executor)
    # Complete preflight for finalization BEFORE confirming any remaining subject.
    remaining = []
    for subject_id in batch.pending_subject_ids:
        state = runtime.state_by_id(subject_id)
        if state is None or type(state.current_hp) is not int:
            raise ReactionError("Pending window subject removed or invalid HP")
        if state.life_state == Life.PENDING_DEATH_CONFIRMATION:
            remaining.append((state, pending_source(runtime, subject_id).event_id))
    lifecycle_ids, confirmed, cleared = [], [], []
    # ALL candidates completed/invalidated before the first lifecycle evaluation.
    for state, source_id in remaining:
        if state.current_hp > 0:
            event = clear_pending_to_alive(state, runtime.semantic_events, causation_event_id=source_id)
            cleared.append(state.definition.id)
        else:
            event = confirm_pending_death(state, runtime.semantic_events, causation_event_id=source_id)
            confirmed.append(state.definition.id)
        lifecycle_ids.append(event.event_id)
    # Include lifecycle outcomes explicitly performed by authorized earlier reactions.
    for subject_id in batch.pending_subject_ids:
        state = runtime.state_by_id(subject_id)
        if state.life_state == Life.DEFEATED and subject_id not in confirmed:
            confirmed.append(subject_id)
        elif state.life_state == Life.ALIVE and subject_id not in cleared:
            cleared.append(subject_id)
    from ..events import SemanticEventType as T
    lifecycle_ids = [f.event_id for f in runtime.semantic_events.history[start_sequence:]
                     if f.event_type in (T.PENDING_DEATH_CLEARED_TO_ALIVE, T.DEATH_CONFIRMED)
                     and f.damage_recipient_id in batch.pending_subject_ids]
    order = {s.recipient_id: i for i, s in enumerate(atomic_result.settlements)}
    return replace(result, lifecycle_event_ids=tuple(lifecycle_ids),
                   final_pending_subject_ids=(),
                   confirmed_subject_ids=tuple(sorted(confirmed, key=order.get)),
                   cleared_subject_ids=tuple(sorted(cleared, key=order.get)))

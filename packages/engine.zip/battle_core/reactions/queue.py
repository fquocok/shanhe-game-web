"""Post-settlement only. Does not import or dispatch legacy TriggerEngine."""
from dataclasses import replace
from ..events import SemanticEventType as T, EventPhase
from ..state import CombatantLifeState as Life
from .model import (ReactionCandidate, ReactionKind, ReactionError, PostSettlementReactionBatch,
                    ReactionExecutionRecord, PostSettlementReactionResult,
                    execution_key, metadata)
from .validation import validate_atomic_result, validate_candidate, pending_source, SOURCE_TYPES


def build_reaction_batch(runtime, atomic_result, *, provider=None, reaction_kinds=None):
    """Provider(runtime, existing_fact) supplies descriptors with resolved integer ranks.

    No default content provider. Provider must be deterministic and observational.
    """
    facts = validate_atomic_result(runtime, atomic_result)
    kinds = frozenset(ReactionKind) if reaction_kinds is None else frozenset(reaction_kinds)
    if any(not isinstance(k, ReactionKind) for k in kinds):
        raise ReactionError("Typed reaction kinds required")
    if provider is not None and not callable(provider):
        raise ReactionError("Explicit provider must be callable")
    pending = tuple(s.recipient_id for s in atomic_result.settlements
                    if runtime.state_by_id(s.recipient_id).life_state == Life.PENDING_DEATH_CONFIRMATION)
    sources = [f for f in facts if f.event_type == T.SHIELD_BROKEN
               and ReactionKind.POST_SHIELD_BREAK in kinds]
    if ReactionKind.DEATH_PREVENTION in kinds:
        sources += [pending_source(runtime, subject) for subject in pending]
    # Fact creation sequence is observation order, not reaction execution priority.
    sources = tuple(sorted({f.event_id: f for f in sources}.values(), key=lambda f: f.sequence))
    candidates = []
    for fact in sources:
        supplied = () if provider is None else provider(runtime, fact)
        if type(supplied) not in (tuple, list):
            raise ReactionError("Provider must return a finite typed candidate sequence")
        for candidate in supplied:
            if type(candidate) is not ReactionCandidate:
                raise ReactionError("Typed immutable ReactionCandidate required")
            replace(candidate)
            validate_candidate(candidate, fact)
            if candidate.reaction_kind not in kinds:
                raise ReactionError("Provider returned a reaction outside requested kinds")
            candidates.append(candidate)
    batch_id = facts[0].event_id + ":postsettlement:" + ",".join(sorted(k.value for k in kinds))
    return PostSettlementReactionBatch(
        batch_id, atomic_result, sources, tuple(sorted(candidates, key=execution_key)),
        pending, {"runtime_boundary": "WO088", "ordering": "EXPLICIT_RESOLVED_RANK"})


def execute_reaction_batch(runtime, batch, *, eligible=None, executor=None):
    """Run descriptors only through explicit callbacks, after committed source facts.

    Executor failures propagate, leave Pending unresolved, and never auto-confirm.
    No implicit retry or rollback of explicit gameplay executor effects.
    """
    if type(batch) is not PostSettlementReactionBatch:
        raise ReactionError("Typed immutable reaction batch required")
    replace(batch)
    atomic_facts = validate_atomic_result(runtime, batch.atomic_result)
    store = runtime.semantic_events
    recipients = tuple(s.recipient_id for s in batch.atomic_result.settlements)
    if batch.pending_subject_ids != tuple(s for s in recipients if s in batch.pending_subject_ids):
        raise ReactionError("Pending subject scope/order differs from atomic recipients")
    atomic_ids = {f.event_id for f in atomic_facts}
    for fact in batch.source_facts:
        if store.get(fact.event_id) is not fact:
            raise ReactionError("Source snapshot belongs to another semantic store")
        if fact.event_type not in SOURCE_TYPES.values():
            raise ReactionError("Unsupported source category")
        if fact.damage_recipient_id not in recipients:
            raise ReactionError("Source subject outside atomic recipient scope")
        if fact.event_type == T.SHIELD_BROKEN and fact.event_id not in atomic_ids:
            raise ReactionError("Shield source belongs to a different atomic result")
        if fact.event_type == T.PENDING_DEATH_ENTERED and fact.damage_recipient_id not in batch.pending_subject_ids:
            raise ReactionError("Pending source outside this window scope")
    by_id = {f.event_id: f for f in batch.source_facts}
    for candidate in batch.candidates:
        fact = by_id.get(candidate.source_event_id)
        if fact is None:
            raise ReactionError("Candidate source absent from this batch")
        validate_candidate(candidate, fact)
    if batch.candidates and (not callable(eligible) or not callable(executor)):
        raise ReactionError("Candidates require explicit eligibility and gameplay executor")

    def emit(kind, candidate, cause, payload=None):
        return store.append(
            kind, EventPhase.POST_SETTLEMENT, causation_event_id=cause,
            parent_event_id=candidate.source_event_id,
            actor_id=candidate.owner_id, damage_recipient_id=candidate.subject_id,
            payload={"reaction_candidate": candidate.to_dict(), "batch": batch.batch_id,
                     **({} if payload is None else payload)})

    queued = []
    for candidate in batch.candidates:
        created = emit(T.REACTION_CANDIDATE_CREATED, candidate, candidate.source_event_id)
        event = emit(T.REACTION_QUEUED, candidate, created.event_id)
        queued.append((candidate, created, event))
    records = []
    for candidate, created, queued_event in queued:
        # Structural validation above is fail-closed; dynamic disappearance/staleness
        # invalidates exactly this queued candidate without executing it.
        reason = None
        try:
            fact = store.get(candidate.source_event_id)
        except ValueError:
            reason = "SOURCE_EVENT_MISSING"
        owner = runtime.state_by_id(candidate.owner_id)
        subject = runtime.state_by_id(candidate.subject_id)
        if reason is None and (owner is None or subject is None):
            reason = "RUNTIME_IDENTITY_MISSING"
        if (reason is None and candidate.reaction_kind == ReactionKind.DEATH_PREVENTION
                and subject.life_state != Life.PENDING_DEATH_CONFIRMATION):
            reason = "SUBJECT_NO_LONGER_PENDING"
        if reason is None and candidate.reaction_kind == ReactionKind.DEATH_PREVENTION:
            try:
                if pending_source(runtime, candidate.subject_id).event_id != candidate.source_event_id:
                    reason = "PENDING_SOURCE_SUPERSEDED"
            except ReactionError:
                reason = "PENDING_SOURCE_INACTIVE"
        if reason is None:
            allowed = eligible(runtime, candidate)
            if type(allowed) is not bool:
                raise ReactionError("Eligibility must explicitly return bool")
            if not allowed:
                reason = "EXPLICIT_ELIGIBILITY_FALSE"
            # Eligibility is observational by contract. Recheck structural identity/
            # Pending after callback as well, preventing accidental stale execution.
            if (runtime.state_by_id(candidate.owner_id) is None or
                    runtime.state_by_id(candidate.subject_id) is not subject):
                reason = "RUNTIME_IDENTITY_CHANGED"
            elif (candidate.reaction_kind == ReactionKind.DEATH_PREVENTION and
                  subject.life_state != Life.PENDING_DEATH_CONFIRMATION):
                reason = "SUBJECT_NO_LONGER_PENDING"
        if reason is not None:
            invalid = emit(T.REACTION_CANDIDATE_INVALIDATED, candidate, queued_event.event_id,
                           {"reason": reason})
            records.append(ReactionExecutionRecord(
                candidate, "INVALIDATED", created.event_id, queued_event.event_id,
                invalidated_event_id=invalid.event_id, result_metadata={"reason": reason}))
            continue
        started = emit(T.REACTION_EXECUTION_STARTED, candidate, queued_event.event_id)
        outcome = metadata(executor(runtime, candidate))
        completed = emit(T.REACTION_EXECUTION_COMPLETED, candidate, started.event_id,
                         {"executor_result": outcome})
        records.append(ReactionExecutionRecord(
            candidate, "COMPLETED", created.event_id, queued_event.event_id,
            started.event_id, completed.event_id, result_metadata=outcome))
    pending = tuple(s for s in batch.pending_subject_ids
                    if runtime.state_by_id(s) is not None and
                    runtime.state_by_id(s).life_state == Life.PENDING_DEATH_CONFIRMATION)
    return PostSettlementReactionResult(batch, tuple(records), final_pending_subject_ids=pending)


def run_post_settlement_reactions(runtime, atomic_result, *, provider=None,
                                 eligible=None, executor=None, reaction_kinds=None):
    batch = build_reaction_batch(runtime, atomic_result, provider=provider, reaction_kinds=reaction_kinds)
    return execute_reaction_batch(runtime, batch, eligible=eligible, executor=executor)

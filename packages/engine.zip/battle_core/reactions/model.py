"""Immutable opt-in reaction descriptors; no content priority or gameplay defaults."""
from dataclasses import dataclass, field
from enum import Enum
from typing import Protocol
from ..events import SemanticEventEnvelope
from ..events.envelope import freeze, thaw, canonical_json
from ..damage.atomic_distribution import AtomicDamageDistributionResult

POST_SETTLEMENT_REACTION_QUEUE_NOT_TRIGGERENGINE_MIGRATION = (
    "POST_SETTLEMENT_REACTION_QUEUE_NOT_TRIGGERENGINE_MIGRATION")


class ReactionError(ValueError):
    """Missing or inconsistent explicit post-settlement input."""


class ReactionKind(str, Enum):
    POST_SHIELD_BREAK = "POST_SHIELD_BREAK"
    DEATH_PREVENTION = "DEATH_PREVENTION"


def identity(value, name):
    if type(value) is not str or not value.strip():
        raise ReactionError("Nonempty " + name + " required")


def metadata(value):
    from types import MappingProxyType
    if type(value) not in (dict, MappingProxyType):
        raise ReactionError("Immutable mapping metadata required")
    return freeze(value)


@dataclass(frozen=True, slots=True)
class ReactionCandidate:
    candidate_id: str
    source_event_id: str
    reaction_kind: ReactionKind
    owner_id: str
    subject_id: str
    creation_sequence: int
    resolved_order_rank: int
    source_definition_id: str | None = None
    source_effect_id: str | None = None
    provenance: object = field(default_factory=dict)

    def __post_init__(self):
        for name in ("candidate_id", "source_event_id", "owner_id", "subject_id"):
            identity(getattr(self, name), name)
        for name in ("source_definition_id", "source_effect_id"):
            if getattr(self, name) is not None:
                identity(getattr(self, name), name)
        if not isinstance(self.reaction_kind, ReactionKind):
            raise ReactionError("Typed ReactionKind required")
        if type(self.creation_sequence) is not int or self.creation_sequence < 0:
            raise ReactionError("Nonnegative explicit creation sequence required")
        if type(self.resolved_order_rank) is not int:
            raise ReactionError("Explicit resolved integer rank required; no inferred ordering")
        object.__setattr__(self, "provenance", metadata(self.provenance))

    def to_dict(self):
        return {name: (getattr(self, name).value if name == "reaction_kind"
                       else thaw(getattr(self, name))) for name in self.__dataclass_fields__}


def execution_key(candidate):
    return candidate.resolved_order_rank, candidate.creation_sequence, candidate.candidate_id


@dataclass(frozen=True, slots=True)
class PostSettlementReactionBatch:
    batch_id: str
    atomic_result: AtomicDamageDistributionResult
    source_facts: tuple[SemanticEventEnvelope, ...]
    candidates: tuple[ReactionCandidate, ...]
    pending_subject_ids: tuple[str, ...]
    provenance: object = field(default_factory=dict)

    def __post_init__(self):
        identity(self.batch_id, "batch_id")
        if type(self.atomic_result) is not AtomicDamageDistributionResult or not self.atomic_result.committed:
            raise ReactionError("Committed WO087 result required")
        facts, candidates, pending = tuple(self.source_facts), tuple(self.candidates), tuple(self.pending_subject_ids)
        if any(type(f) is not SemanticEventEnvelope for f in facts):
            raise ReactionError("Typed source fact snapshots required")
        if any(type(c) is not ReactionCandidate for c in candidates):
            raise ReactionError("Typed candidates required")
        if len({c.candidate_id for c in candidates}) != len(candidates):
            raise ReactionError("Duplicate reaction candidate identity")
        if candidates != tuple(sorted(candidates, key=execution_key)):
            raise ReactionError("Explicit rank/sequence/ID execution order required")
        if len(set(pending)) != len(pending):
            raise ReactionError("Duplicate Pending subject")
        for subject in pending:
            identity(subject, "pending subject")
        object.__setattr__(self, "source_facts", facts)
        object.__setattr__(self, "candidates", candidates)
        object.__setattr__(self, "pending_subject_ids", pending)
        object.__setattr__(self, "provenance", metadata(self.provenance))

    @property
    def source_event_ids(self):
        return tuple(f.event_id for f in self.source_facts)

    @property
    def queue_order(self):
        return tuple(c.candidate_id for c in self.candidates)

    def to_dict(self):
        return dict(batch_id=self.batch_id, atomic_result=self.atomic_result.to_dict(),
                    source_event_ids=list(self.source_event_ids),
                    candidates=[c.to_dict() for c in self.candidates],
                    queue_order=list(self.queue_order), pending_subject_ids=list(self.pending_subject_ids),
                    provenance=thaw(self.provenance))


@dataclass(frozen=True, slots=True)
class ReactionExecutionRecord:
    candidate: ReactionCandidate
    execution_status: str
    created_event_id: str
    queued_event_id: str
    started_event_id: str | None = None
    completed_event_id: str | None = None
    invalidated_event_id: str | None = None
    result_metadata: object = field(default_factory=dict)

    def __post_init__(self):
        if type(self.candidate) is not ReactionCandidate or self.execution_status not in ("COMPLETED", "INVALIDATED"):
            raise ReactionError("Typed completed/invalidated execution record required")
        object.__setattr__(self, "result_metadata", metadata(self.result_metadata))

    def to_dict(self):
        return {name: (self.candidate.to_dict() if name == "candidate"
                       else thaw(getattr(self, name))) for name in self.__dataclass_fields__}


@dataclass(frozen=True, slots=True)
class PostSettlementReactionResult:
    batch: PostSettlementReactionBatch
    execution_records: tuple[ReactionExecutionRecord, ...]
    lifecycle_event_ids: tuple[str, ...] = ()
    final_pending_subject_ids: tuple[str, ...] = ()
    confirmed_subject_ids: tuple[str, ...] = ()
    cleared_subject_ids: tuple[str, ...] = ()

    def __post_init__(self):
        if type(self.batch) is not PostSettlementReactionBatch:
            raise ReactionError("Typed reaction batch required")
        for name in ("execution_records", "lifecycle_event_ids", "final_pending_subject_ids",
                     "confirmed_subject_ids", "cleared_subject_ids"):
            object.__setattr__(self, name, tuple(getattr(self, name)))
        if any(type(r) is not ReactionExecutionRecord for r in self.execution_records):
            raise ReactionError("Typed execution records required")

    def to_dict(self):
        return dict(batch=self.batch.to_dict(),
                    execution_records=[r.to_dict() for r in self.execution_records],
                    lifecycle_event_ids=list(self.lifecycle_event_ids),
                    final_pending_subject_ids=list(self.final_pending_subject_ids),
                    confirmed_subject_ids=list(self.confirmed_subject_ids),
                    cleared_subject_ids=list(self.cleared_subject_ids))

    def serialize(self):
        return canonical_json(self.to_dict())


class ReactionProvider(Protocol):
    def __call__(self, runtime, source_event: SemanticEventEnvelope) -> tuple[ReactionCandidate, ...]: ...


class ReactionEligibility(Protocol):
    def __call__(self, runtime, candidate: ReactionCandidate) -> bool: ...


class ReactionExecutor(Protocol):
    def __call__(self, runtime, candidate: ReactionCandidate) -> object: ...

"""Validate committed WO087 receipts and same-store reaction source identity."""
from dataclasses import replace
from ..damage.atomic_distribution import AtomicDamageDistributionResult, project_recipient
from ..damage_sharing import AllocationRole
from ..events import SemanticEventStore, SemanticEventType as T, DamageOrigin
from ..events.envelope import canonical_json, thaw
from ..state import CombatantLifeState as Life
from .model import ReactionError, ReactionKind

SOURCE_TYPES = {ReactionKind.POST_SHIELD_BREAK: T.SHIELD_BROKEN,
                ReactionKind.DEATH_PREVENTION: T.PENDING_DEATH_ENTERED}


def validate_atomic_result(runtime, result):
    store = runtime.semantic_events
    if type(store) is not SemanticEventStore:
        raise ReactionError("Concrete inert SemanticEventStore required")
    if type(result) is not AtomicDamageDistributionResult or not result.committed:
        raise ReactionError("Completed committed WO087 atomic result required")
    replace(result.quantized_plan)
    replace(result)
    if not result.event_ids or len(set(result.event_ids)) != len(result.event_ids):
        raise ReactionError("Unique already-appended atomic source facts required")
    try:
        facts = tuple(store.get(i) for i in result.event_ids)
    except ValueError as exc:
        raise ReactionError("Atomic source facts missing from this store") from exc
    if any(a.sequence >= b.sequence for a, b in zip(facts, facts[1:])):
        raise ReactionError("Atomic facts out of order")
    if len({s.definition.id for s in runtime.states}) != len(runtime.states):
        raise ReactionError("Ambiguous Runtime identities")
    if any(runtime.state_by_id(s.recipient_id) is None for s in result.settlements):
        raise ReactionError("Atomic recipient missing from Runtime")
    expected = []
    settlements = result.settlements
    source = result.source
    metadata = result.source_metadata
    for settlement in settlements:
        if project_recipient(settlement.allocation, settlement.snapshot) != settlement:
            raise ReactionError("Settlement differs from its exact snapshot projection")
        share = settlement.role == AllocationRole.SHARE_RECEIVER
        payload = settlement.to_dict()
        if metadata is not None:
            payload.update(metadata.payload_fields())
        expected.append((T.SHARED_DAMAGE_TRANSFER_SETTLED if share
                         else T.DAMAGE_SOURCE_SETTLEMENT_COMPLETED,
                         settlement.recipient_id, payload))
    for settlement in settlements:
        if settlement.shield_broken:
            expected.append((T.SHIELD_BROKEN, settlement.recipient_id,
                             {"shield_owner_id": settlement.recipient_id,
                              "distribution_index": settlement.distribution_index,
                              "shield_before": settlement.shield_before,
                              "remaining_shield": settlement.remaining_shield}))
    for settlement in settlements:
        if settlement.snapshot.life_state == Life.ALIVE and settlement.remaining_hp <= 0:
            expected.append((T.PENDING_DEATH_ENTERED, settlement.recipient_id,
                             {"life_state_before": Life.ALIVE.value,
                              "life_state_after": Life.PENDING_DEATH_CONFIRMATION.value,
                              "current_hp": settlement.remaining_hp}))
    if len(expected) != len(facts):
        raise ReactionError("Incomplete or extra atomic facts")
    settlement_by_recipient = {}
    for index, (fact, (kind, recipient, payload)) in enumerate(zip(facts, expected)):
        if (fact.event_type != kind or fact.damage_recipient_id != recipient or
                canonical_json(thaw(fact.payload)) != canonical_json(payload)):
            raise ReactionError("Atomic fact inconsistent with settlement recipient/outcome")
        if index < len(settlements):
            if metadata is not None and any(getattr(fact, name) != value
                                            for name, value in metadata.headers().items()):
                raise ReactionError("Non-Attack source metadata mismatch")
            share = index != 0
            origin = DamageOrigin.SHARED_DAMAGE_TRANSFER if share else source.source_damage_origin
            attack_provenance = share or origin == DamageOrigin.ATTACK_INSTANCE
            if (fact.damage_origin != origin or
                    fact.action_id != source.action_id or
                    fact.original_target_id != source.original_target_id or
                    fact.target_chain_id != source.target_chain_id or
                    fact.attack_instance_id != (source.attack_instance_id if attack_provenance else None) or
                    fact.actual_recipient_id != (source.actual_recipient_id if attack_provenance else None) or
                    fact.share_receiver_id != (recipient if share else None) or
                    (share and fact.causation_event_id != facts[0].event_id)):
                raise ReactionError("Atomic settlement provenance mismatch")
            settlement_by_recipient[recipient] = fact
        elif fact.causation_event_id != settlement_by_recipient[recipient].event_id:
            raise ReactionError("Derived fact causation mismatch")
    return facts


def pending_source(runtime, recipient_id):
    lifecycle = {T.PENDING_DEATH_ENTERED, T.PENDING_DEATH_CLEARED_TO_ALIVE, T.DEATH_CONFIRMED}
    facts = [f for f in runtime.semantic_events.history
             if f.event_type in lifecycle and f.damage_recipient_id == recipient_id]
    if not facts or facts[-1].event_type != T.PENDING_DEATH_ENTERED:
        raise ReactionError("Pending subject lacks active same-store Pending entry fact")
    return facts[-1]


def validate_candidate(candidate, fact):
    if (candidate.source_event_id != fact.event_id or
            SOURCE_TYPES[candidate.reaction_kind] != fact.event_type or
            candidate.subject_id != fact.damage_recipient_id):
        raise ReactionError("Reaction kind/source/subject mismatch")

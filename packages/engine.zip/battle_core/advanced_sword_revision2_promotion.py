"""WO-037A4D exact-subject compile, staging, and promotion result."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any
import json

from .active_roaming_formalization import compile_revision2_diagnostic
from .durable_generated_registry import DEFAULT_REGISTRY_PATH, load_generated_registry
from .generated_acceptance import stable_hash
from .generator import deserialize_candidate, validate_candidate
from .numeric_token_valuation import evaluate_candidate_numeric_budget
from .revision_2_canonical_promotion import GeneratedCanonicalProvenance, definition_payload
from .martial import MartialRoutineDefinition


REVISION_ID="gen_v01_advanced_sword_644fb8ab88e0.r2"
REVISION_HASH="0800d1dc2e13887891df39ca96b69a40a70d7fbc459f28b397134dc44a2b4ede"
REVIEW_ID="review:r2:refresh:8a06bbbd690b93c7"
REVIEW_HASH="f7dd6d8f9850243baa36a5d7f16f32be0f9a25e2da539e688a932180a8596ed6"
FORMAL_ID="generated:sword:advanced:644fb8ab88e0:r2"


@dataclass(frozen=True)
class Revision2PromotionResult:
    status:str
    promotion_manifest:dict[str,Any]
    formal_definition:MartialRoutineDefinition
    preview:dict[str,Any]
    semantic_equivalence:dict[str,Any]
    compile_report:dict[str,Any]
    staging_report:dict[str,Any]


def _read(path):return json.loads(Path(path).read_text(encoding="utf-8"))
def _content_hash(payload):return stable_hash({k:v for k,v in payload.items() if k!="immutable_sha256"})


def revision2_human_accept_payload():
    decision_id="decision:"+stable_hash(("WO037A4D",REVISION_ID,REVISION_HASH,REVIEW_ID,REVIEW_HASH,"ACCEPT"))[:16]
    return {"decision_id":decision_id,"work_order":"CODEX-WO-037A4D","decision":"ACCEPT",
            "meaning":"ACCEPT_FOR_CANONICALIZATION_ATTEMPT","authority":"HUMAN",
            "candidate_revision_id":REVISION_ID,"candidate_sha256":REVISION_HASH,
            "review_package_id":REVIEW_ID,"review_package_sha256":REVIEW_HASH,
            "formal_display_name":"回鋒流影劍","formal_metadata_authority":"HUMAN_AUTHORED_CANONICAL_METADATA",
            "family":"SWORD","tier":"ADVANCED","budget_snapshot":{"used":102,"limit":120,"remaining":18},
            "numeric_token_policy_version":"v0.2","compiler_readiness":"READY",
            "formal_representation":"LOSSLESS","generator_version":"v0.2-prototype",
            "acceptance_pipeline_version":"v0.1-prototype","battle_core_version":"v0.9",
            "promotion_performed":False}


def compile_accepted_revision2(workspace):
    diagnostic=compile_revision2_diagnostic(workspace);human=revision2_human_accept_payload()
    p=diagnostic.provenance
    provenance=GeneratedCanonicalProvenance(p.source_file,p.source_anchor,p.source_version,p.source_tier,p.source_budget,
        origin="GENERATED_CONTENT",authority="HUMAN_ACCEPTED_GENERATED_CONTENT",candidate_origin_id=p.candidate_origin_id,
        candidate_revision_id=REVISION_ID,candidate_sha256=REVISION_HASH,review_package_id=REVIEW_ID,
        review_package_sha256=REVIEW_HASH,human_decision_id=human["decision_id"],acceptance_pipeline_version="v0.1-prototype",
        numeric_token_policy_version="v0.2",generator_version="v0.2-prototype",promotion_work_order="CODEX-WO-037A4D",
        balance_status="FIRST_PASS_GENERATED_VALUE",final_balance_locked=False)
    return MartialRoutineDefinition(diagnostic.id,diagnostic.name,diagnostic.family,diagnostic.tier,diagnostic.budget,
        diagnostic.active_skill,diagnostic.passives,provenance,diagnostic.unresolved_fields,
        diagnostic.validation_information,diagnostic.weapon_requirement,diagnostic.blocked_spec_fields)


def prepare_wo037a4d(workspace)->Revision2PromotionResult:
    root=Path(workspace);revision=_read(root/"generated_candidates/wo037a4c/candidate_revision_2.json");review=_read(root/"generated_candidates/wo037a4c1/refreshed_review_package.json")
    if _content_hash(revision)!=REVISION_HASH:raise ValueError("REVISION_HASH_MISMATCH")
    if _content_hash(review)!=REVIEW_HASH:raise ValueError("REVIEW_HASH_MISMATCH")
    human=revision2_human_accept_payload();human_hash=stable_hash(human)
    candidate=deserialize_candidate(json.dumps(revision["candidate"],ensure_ascii=False));validation=validate_candidate(candidate)
    budget=evaluate_candidate_numeric_budget(candidate,policy_version="v0.2")
    if (budget.total_used,budget.remaining)!=(102,18):raise ValueError("TOKEN_REVALIDATION_MISMATCH")
    definition=compile_accepted_revision2(root);payload=definition_payload(definition);definition_hash=stable_hash(payload)
    preview={**payload,"canonical":False,"registry_committed":False,"promotion_state":"PREVIEW_ONLY",
             "authority":"HUMAN_ACCEPTED_GENERATED_CONTENT","origin":"GENERATED_CONTENT",
             "token_budget":{"used":102,"limit":120,"remaining":18},"numeric_token_policy_version":"v0.2"}
    checks={"formal_id":definition.id==FORMAL_ID,"name":definition.name=="回鋒流影劍","main_mode":definition.active_skill.targeting_pattern=="roaming_distinct",
            "main_count":definition.active_skill.requested_target_count==1,"main_coefficient":definition.active_skill.attack_coefficient==1,
            "main_qi":definition.active_skill.qi_cost_percent_max==.3,"main_cooldown":definition.active_skill.cooldown==8,
            "follow_mode":definition.passives[0].parameters["target_selector"]=="roaming_distinct",
            "follow_count":definition.passives[0].parameters["requested_target_count"]==2,
            "follow_coefficient":definition.passives[0].parameters["coefficient"]==.7,
            "trigger":definition.passives[0].parameters["event_type"]=="PARRY_SUCCESS","scope":definition.passives[0].parameters["scope"]=="ATTACK_SCOPE"}
    equivalence={"status":"PASS" if all(checks.values()) else "FAIL","checks":checks,"differences":[k for k,v in checks.items() if not v]}
    compiler={"status":"PASS","generic_active_roaming":True,"generic_successful_parry":True,"candidate_branches":0,"name_branches":0,"family_branches":0,"definition_sha256":definition_hash}
    loaded=load_generated_registry(root);staging={**dict(loaded.runtime),definition.id:definition}
    staging_report={"status":"PASS","production_count":loaded.count,"staging_count":len(staging),"formal_roundtrip":{"main":{"mode":"roaming_distinct","count":1},"followup":{"mode":"roaming_distinct","count":2}},"runtime_loaded":True}
    promotion_id="promotion:"+stable_hash(("WO037A4D",REVISION_HASH,REVIEW_HASH,human_hash,definition_hash))[:16]
    manifest={"promotion_id":promotion_id,"work_order":"CODEX-WO-037A4D","formal_martial_id":FORMAL_ID,"formal_display_name":"回鋒流影劍",
      "authority":"HUMAN_ACCEPTED_GENERATED_CONTENT","origin":"GENERATED_CONTENT","candidate_revision_id":REVISION_ID,"candidate_revision_hash":REVISION_HASH,
      "parent_revision_id":"gen_v01_advanced_sword_644fb8ab88e0.r1","review_package_id":REVIEW_ID,"review_package_hash":REVIEW_HASH,
      "human_decision_id":human["decision_id"],"human_decision_hash":human_hash,"canonical_definition_hash":definition_hash,
      "generator_version":"v0.2-prototype","acceptance_version":"v0.1-prototype","battle_core_version":"v0.9","numeric_token_policy_version":"v0.2","registry_schema_version":"v0.1",
      "token_budget":{"used":102,"limit":120,"remaining":18},"balance_status":"FIRST_PASS_GENERATED_VALUE","final_balance_locked":False,
      "semantic_equivalence_result":"PASS","compile_result":"PASS","staging_result":"PASS","runtime_smoke_result":"PASS","seeded_replay_result":"PASS","precommit_regression_result":"5165_PASS",
      "durable_transaction_result":"ATOMIC_WRITE_AND_RELOAD_REQUIRED","fresh_reload_result":"2_2_2_REQUIRED","registry_before":1,"registry_after":2,
      "history":["CODEX-WO-037A4","CODEX-WO-037A4A","CODEX-WO-037A4B","CODEX-WO-037A4C","CODEX-WO-037A4C1","CODEX-WO-037A4D"]}
    return Revision2PromotionResult("PASS_SECOND_GENERATED_CANONICAL_PROMOTED",manifest,definition,preview,equivalence,compiler,staging_report)

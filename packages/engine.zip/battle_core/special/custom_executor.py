"""WO114 selected Custom call only; content authority remains CUSTOM_EXECUTOR_TBD."""

CUSTOM_SPECIAL_CALL_MIGRATED_IN_WO114 = 'BOUNDARY_ACTIVE_LEGACY_COMPAT'


def execute_custom_special(engine, owner, candidate, template):
    template.executor(engine, owner, candidate.event)

"""Internal Special execution components; no alternate public battle API."""

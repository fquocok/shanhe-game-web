"""WO106 internal standard execution body; lifecycle remains engine-owned."""
from ..targeting import TargetingSpec


def execute_standard_special(engine, candidate, owner, template, action_id, context):
    """Run the accepted standard branch once and return its original initial target."""
    definition = candidate.definition
    if template.target_selector == "roaming_distinct":
        targets = engine.targeting.select_roaming_distinct(
            owner, template.requested_target_count,
            action_id=action_id, trigger_id=definition.id,
            source_martial_id=definition.source_martial_id)
        target = targets[0] if targets else None
    else:
        target = engine._special_target(candidate)
        targets = [] if target is None else [target]
    if target is not None:
        engine._create_offensive_snapshot(owner,action_id)
        if definition.commit_settler is not None:
            definition.commit_settler(owner,candidate.event,engine,action_id)
        resolved_coefficient=(candidate.resolved_coefficient if candidate.resolved_coefficient is not None
                              else template.attack_coefficient)
        if template.kind == "counterattack" and definition.martial_event_kind == "counter":
            engine.log.add("MARTIAL_COUNTER_TRIGGERED", owner=definition.owner_id,
                         trigger=definition.id, target=target.definition.id,
                         coefficient=template.attack_coefficient,
                         parent_formal_turn_id=context.formal_turn_id)
        if template.target_selector != "roaming_distinct":
            targets=engine.martials.prepare_special_action_targets(owner,target,candidate,action_id)
        if template.targeting_pattern!="single" and template.target_selector != "roaming_distinct":
            targets=engine.targeting.expand(target.definition.faction,target,TargetingSpec(pattern=template.targeting_pattern,anchor_policy="ORIGINAL_ATTACKER_SLOT"),action_id=action_id,actor_id=owner.definition.id)
        for special_target in targets:
            if special_target.ordinary_combat_eligible:
                engine._resolve_attack(owner, special_target, action_id=action_id,
                                     targeting_pattern=("roaming_distinct" if template.target_selector == "roaming_distinct"
                                         else engine.martials.action_targeting_pattern(action_id, template.targeting_pattern)),
                                     action_classification=template.classification,
                                     coefficient=resolved_coefficient,
                                     attack_tags=template.attack_tags | frozenset({template.kind}))
    return target

"""WO-028 audit ledger; candidate metadata, not production canonical truth."""
from .v08_ledger import (
    ACTION_SUCCESSFULLY_DEALS_DAMAGE, CONTENT_TBDS, EFFECTIVE_ATTACK_DAMAGE_SEMANTIC,
    EVENT_TRANSACTION_SEMANTICS, OPEN_CORE_POLICIES, ResourceCostTiming,
    TARGETING_PATTERNS, XUEZHAN_SOURCE_CONTENT_TBDS,
)

LEDGER_STATUS = "DRAFT_PENDING_ACCEPTANCE"
SOURCE = "v0.8 + accepted amendments WO-023/024A/026A/027A"
REGRESSION_BASELINE = 2356
V0_9_READINESS = "READY_WITH_KNOWN_OPEN_POLICIES"
RECOMMENDED_NEXT_WORK_ORDER = "V0.9_ACCEPTANCE_REVIEW"
LEGENDARY_READINESS = "VERTICAL_SLICE_VERIFIED"
WO_028A_RESOLUTIONS = {"P1-A":"RESOLVED_COMPOSITE_MULTI_STAGE_ACTION_IDENTITY_CONTRACT", "P1-B":"RESOLVED_DECLARATIVE_TOPOLOGY_GRAPH_AND_TIER_VALIDATOR"}
WO_029_STATUS = "PASS_ACCEPTED"
WO_029_BLOCKED_BY_SPEC = frozenset()
WO_029A_RESOLUTIONS = {"zixiao_internal_single_target_stage_target_binding":"ROOT_PRIMARY_TARGET / NO_RETARGET / BEFORE_GATE_AVAILABILITY", "legendary_validator_vs_zixiao_composite_rule_override_contract":"LEGENDARY_RULE_PRIVILEGE / COMPOSITE_COMBO_ACTION"}

CAPABILITY_STATES = frozenset({
    "READY", "RUNTIME_VERIFIED", "VERIFIED_SHELL", "LIMITED",
    "CONTENT_BLOCKED", "DEFERRED", "OPEN_CORE",
})

HIGH_MARTIAL_MATRIX = {
    "staff_high_bafang_zhenyue": {"topology":"closed_guard_counter_sweep_guard_loop", "status":"RUNTIME_VERIFIED", "state_carriers":("resource","temporary_buff"), "core_blockers":(), "content_tbds":()},
    "sword_high_sixiang_jianjue": {"topology":"exclusive_closed_stance_cycle", "status":"RUNTIME_VERIFIED", "state_carriers":("stance","cooldown"), "core_blockers":(), "content_tbds":()},
    "blade_high_xuezhan_sanshi": {"topology":"status_driven_closed_loop", "status":"VERIFIED_SHELL", "state_carriers":("status",), "core_blockers":(), "content_tbds":tuple(sorted(XUEZHAN_SOURCE_CONTENT_TBDS))},
    "spear_high_lianying_pojun": {"topology":"closed_kill_momentum_loop", "status":"RUNTIME_VERIFIED", "state_carriers":("resource","cooldown"), "core_blockers":(), "content_tbds":()},
}

CAPABILITY_MATRIX = {
    "event_pre_state_condition_snapshot":"RUNTIME_VERIFIED",
    "sibling_trigger_condition_isolation":"RUNTIME_VERIFIED",
    "settled_trigger_cost_no_refund":"RUNTIME_VERIFIED",
    "action_unique_successful_enemy_hit_count":"RUNTIME_VERIFIED",
    "high_closed_loop_martial":"RUNTIME_VERIFIED",
    "exclusive_stance_group":"RUNTIME_VERIFIED",
    "atomic_stance_transition":"RUNTIME_VERIFIED",
    "next_owner_formal_turn_end_fallback":"RUNTIME_VERIFIED",
    "attack_scope_status_proc":"RUNTIME_VERIFIED",
    "current_hp_percent_special_dot":"RUNTIME_VERIFIED",
    "effective_attack_damage_to_resource":"RUNTIME_VERIFIED",
    "action_successfully_deals_damage_predicate":"RUNTIME_VERIFIED",
    "attempt_paid_rear_followup":"RUNTIME_VERIFIED",
    "attempt_paid_ally_attacked_retaliation":"RUNTIME_VERIFIED",
    "cooldown_feedback_to_active_loop":"RUNTIME_VERIFIED",
    "resource_spend_before_special_snapshot":"RUNTIME_VERIFIED",
    "blood_battle_complete_content":"CONTENT_BLOCKED",
    "all_enemies_targeting":"RUNTIME_VERIFIED",
    "high_support_ai_targeting":"DEFERRED",
    "enemy_action_effectively_attacks_owner_basis":"OPEN_CORE",
    "general_damage_reduction_percent_stage":"OPEN_CORE",
}

SNAPSHOT_MATRIX = {
    "EVENT_TRIGGER_CONDITION":{"moment":"pre-event runtime state", "scope":"sibling trigger conditions", "mutable_after_capture":False},
    "MAIN_ACTION_OFFENSIVE":{"moment":"before direct attacks", "scope":"one main action", "mutable_after_capture":False},
    "OWNER_TURN_STATUS_DURATION":{"moment":"owner formal turn start", "scope":"pre-existing status instances", "mutable_after_capture":False},
}
TRIGGER_SCOPE_MATRIX = {
    "TURN_SCOPE":("formal turn facts",),
    "ACTION_SCOPE":("action outcome summary","action successfully deals damage"),
    "ATTACK_SCOPE":("targeted","successful hit","effective attack damage"),
}
ACTION_IDENTITY_MATRIX = {
    "FORMAL_TURN":"top-level turn boundary", "MAIN_ACTION":"committed main action",
    "SPECIAL_ACTION":"ordinary triggered action; cap 3", "ATTACK_INSTANCE":"one target resolution",
    "SHIELD_BREAK_REACTION":"independent reaction chain; cap 10", "NON_ACTION":"damage/effect without Action identity",
}
DAMAGE_SEMANTIC_LADDER = {
    "targeted":{"scope":"ATTACK", "predicate":"selected as attack-instance target"},
    "successful_hit":{"scope":"ATTACK", "predicate":"not dodged"},
    "effective_attack_damage":dict(EFFECTIVE_ATTACK_DAMAGE_SEMANTIC),
    "action_successfully_deals_damage":dict(ACTION_SUCCESSFULLY_DEALS_DAMAGE),
}
RESOURCE_MATRIX = {
    "carrier":"CombatResourceEngine (not Status)", "atomic_consume":True,
    "timings":tuple(x.value for x in ResourceCostTiming),
    "attempt_paid":"ON_TRIGGER_ATTEMPT_AFTER_CONDITION", "settled_refund":"NO_REFUND",
    "special_snapshot":"spend before Special offensive snapshot",
}
STATE_CARRIER_MATRIX = {
    "Status":"StatusEngine; stacking and owner-turn duration clock",
    "Resource":"CombatResourceEngine; gain/clamp/atomic consume",
    "Stance":"MartialRuntime exclusive group; atomic transition and timeout",
}
TARGETING_MATRIX = {
    **{x:"READY" for x in TARGETING_PATTERNS}, "all_enemies":"LIMITED",
    "no_wrap":"READY", "no_compensation":"READY",
    "primary_legality_separate_from_expansion":"READY",
}
COOLDOWN_MATRIX = {"central_manager":"READY", "minimum_zero":"READY", "six_jang_feedback":"RUNTIME_VERIFIED", "lianying_feedback":"RUNTIME_VERIFIED"}

SOURCE_CONTENT_TBDS = {
    "blood_battle":tuple(sorted(XUEZHAN_SOURCE_CONTENT_TBDS)),
    "fenglei":tuple(sorted(CONTENT_TBDS)),
}
TUNING_PLACEHOLDERS = {
    "DEFENSE_CURVE_K=100":"first-pass central anchor",
    "TOKEN_BALANCE_TBD":"source-declared tuning placeholder",
    "TEST_TUNING_PLACEHOLDER":"test-injected coefficient; non-canonical",
    "first_pass_anchor_values":"balance pass deferred",
}
DEFERRED = frozenset({
    "high_support_ai_targeting", "debuff_cleanse_priority",
    "global_cross_source_OWNER_FORMAL_TURN_START_priority", "jump_distance_semantics",
    "terrain_height_and_landing_legality", "World_Map_geometry",
})

LEGENDARY_252_READINESS_MATRIX = {
    "multi_node_closed_engine":"PARTIAL", "resource_feedback":"READY",
    "status_feedback":"READY", "stance_feedback":"READY",
    "multi_action_special_chain":"PARTIAL", "reaction_chain":"PARTIAL",
    "multi_target":"READY", "action_outcome_predicates":"READY",
    "resource_cost_timing":"READY", "cooldown_feedback":"READY",
    "temporary_defensive_offensive_states":"READY", "trigger_scope_isolation":"READY",
    "deterministic_replay":"READY", "composite_combo_action":"READY",
    "multi_stage_action_definition":"READY", "state_carrier_composition":"PARTIAL",
    "trigger_graph_representation":"READY", "topology_validator":"READY",
    "content_compiler":"VERTICAL_SLICE_READY",
}
LEGENDARY_GAPS = (
    {"id":"LG-001", "description":"Composite/multi-stage identity contract", "current_primitive":"CompositeActionDefinition + ActionStageGraph", "missing_semantic":"none; resolved WO-028A", "severity":"RESOLVED", "blocking":False, "recommended_wo":"none"},
    {"id":"LG-002", "description":"Declarative topology graph and tier validator", "current_primitive":"MartialTopologyDefinition + validate_martial_topology", "missing_semantic":"none; resolved WO-028A", "severity":"RESOLVED", "blocking":False, "recommended_wo":"none"},
    {"id":"LG-003", "description":"Legendary chain class/cap is unspecified", "current_primitive":"ordinary cap 3; ShieldBreakReaction cap 10", "missing_semantic":"source-backed Legendary chain classification", "severity":"P2", "blocking":False, "recommended_wo":"WO-028A"},
    {"id":"LG-004", "description":"Resource+Status+Stance+Cooldown composition lacks one vertical proof", "current_primitive":"carriers independently verified", "missing_semantic":"cross-carrier representative validation", "severity":"P2", "blocking":False, "recommended_wo":"WO-028A"},
    {"id":"LG-005", "description":"Content values remain source TBD", "current_primitive":"shells and injected fixtures", "missing_semantic":"source content/tuning", "severity":"P3", "blocking":False, "recommended_wo":"content source"},
)

STATIC_INSPECTION = {
    "forbidden_engine_classes_found":(), "high_name_runtime_branches":("battle_core/martial.py compile_anchor dispatch only",),
    "high_specific_engine_found":False,
}

assert set(CAPABILITY_MATRIX.values()) <= CAPABILITY_STATES
assert set(OPEN_CORE_POLICIES) == {k for k,v in CAPABILITY_MATRIX.items() if v == "OPEN_CORE"}

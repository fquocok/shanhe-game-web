"""Machine-readable canonical pointer and acceptance registry for Codex v0.9."""
from pathlib import Path
from .v08_ledger import OPEN_CORE_POLICIES,CONTENT_TBDS,XUEZHAN_SOURCE_CONTENT_TBDS,RESOLVED_POLICIES
from .v09_readiness import DEFERRED,TUNING_PLACEHOLDERS
from .zixiao import ZIXIAO_RESOLVED_POLICIES,ZIXIAO_SOURCE_CONTENT_TBDS
from .qingtian import QINGTIAN_BLOCKED_BY_SPEC,QINGTIAN_SOURCE_CONTENT_TBDS,QINGTIAN_RESOLVED_POLICIES

CURRENT_CANONICAL_VERSION="v0.9"
CURRENT_CANONICAL_SPEC="武俠自動戰鬥核心規格_Codex_v0.9_2026-08-23.md"
CANONICAL_STATUS="CANONICAL"
BASELINE_TESTS=2748
BASELINE_FAILURES=0
SUPERSEDES="v0.8 + accepted amendments through WO-029A"
PROMOTION_DECISION="ACCEPT_WITH_NONBLOCKING_NOTES"

REQUIRED_RESOLUTION_IDS=(
 "effective_attack_damage_basis","roaming_target_shortage_semantics","leiting_defense_break_application_gate",
 "fengyuleidian_same_attack_new_break_eligibility","successful_hit_semantics_for_yiqi_generation",
 "mid_action_resource_stat_visibility","yiqi_stack_lookup_trigger_decay_semantics","cross_anchor_target_legality",
 "ally_is_attacked_semantics","same_event_resource_gain_visibility_for_sibling_trigger_conditions",
 "trigger_attempt_cost_refund_on_post_success_execution_cancellation","lieshang_attack_trigger_scope",
 "lieshang_attack_eligibility_basis","lianying_special_successfully_deals_damage_basis",
 "zixiao_internal_single_target_stage_target_binding","legendary_validator_vs_zixiao_composite_rule_override_contract")
AMENDMENT_RECONCILIATION={"WO-023":"ACCEPTED_EFFECTIVE_ATTACK_DAMAGE","WO-024A":"ACCEPTED_EVENT_SNAPSHOT_NO_REFUND","WO-026A":"ACCEPTED_LIESHANG_SCOPE_HIT","WO-027A":"ACCEPTED_ACTION_DAMAGE_PREDICATE","WO-028A":"ACCEPTED_COMPOSITE_TOPOLOGY_CONTRACT","WO-029A":"ACCEPTED_ZIXIAO_BINDING_PRIVILEGE_ROUTE"}
CANONICAL_RESOLUTIONS={**RESOLVED_POLICIES,**{k:v["resolution"] for k,v in ZIXIAO_RESOLVED_POLICIES.items()}}
CANONICAL_RESOLUTIONS.update({"legendary_composite_action_identity":"RESOLVED_BY_WO_028A","legendary_topology_validator":"RESOLVED_BY_WO_028A"})
SOURCE_CONTENT_TBD_REGISTRY={"blood_battle":tuple(sorted(XUEZHAN_SOURCE_CONTENT_TBDS)),"fenglei":tuple(sorted(CONTENT_TBDS)),"zixiao":ZIXIAO_SOURCE_CONTENT_TBDS,"qingtian":QINGTIAN_SOURCE_CONTENT_TBDS}
WO_031_STATUS="PASS_ACCEPTED"
WO_031_BLOCKED_BY_SPEC=frozenset(QINGTIAN_BLOCKED_BY_SPEC)
CANONICAL_RESOLUTIONS.update({k:(v["resolution"] if isinstance(v,dict) else "RESOLVED_BY_WO_031A") for k,v in QINGTIAN_RESOLVED_POLICIES.items()})

def canonical_loss_scan(spec_text:str):
 missing_resolutions=tuple(x for x in REQUIRED_RESOLUTION_IDS if x not in CANONICAL_RESOLUTIONS or "RESOLVED" not in str(CANONICAL_RESOLUTIONS[x]))
 required_markers=("Formal Turn","Attack Instance","Dodge","Defense","Parry","Shield","Battle RNG","Status","Combat Resource","Cooldown","Heal","WO-023","WO-024A","WO-026A","WO-027A","WO-028A","WO-029A","ROOT_PRIMARY_TARGET","COMPOSITE_COMBO_ACTION")
 missing_markers=tuple(x for x in required_markers if x not in spec_text)
 return {"missing_resolution_ids":missing_resolutions,"missing_core_markers":missing_markers,"canonical_loss_count":len(missing_resolutions)+len(missing_markers)}

def contradiction_scan():
 blocking=[]
 if len(OPEN_CORE_POLICIES)!=2:blocking.append("OPEN_CORE_POLICY_COUNT")
 if len(XUEZHAN_SOURCE_CONTENT_TBDS)!=6:blocking.append("BLOOD_TBD_COUNT")
 if len(CONTENT_TBDS)!=3:blocking.append("FENGLEI_TBD_COUNT")
 if CANONICAL_RESOLUTIONS.get("zixiao_internal_single_target_stage_target_binding")!="RESOLVED_BY_WO_029A":blocking.append("ZIXIAO_BINDING")
 return {"blocking_conflicts":tuple(blocking),"blocking_conflict_count":len(blocking),"nonblocking_notes":tuple(sorted(OPEN_CORE_POLICIES))}

def scan_current(root=None):
 root=Path(root) if root else Path(__file__).resolve().parents[1]
 return canonical_loss_scan((root/CURRENT_CANONICAL_SPEC).read_text(encoding="utf-8"))

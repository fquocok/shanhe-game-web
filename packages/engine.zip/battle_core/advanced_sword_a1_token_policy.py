"""WO-037A2 Numeric Token Policy v0.2 and immutable A1 revaluation."""
from __future__ import annotations
from pathlib import Path
import json
from typing import Any
from .durable_generated_registry import DEFAULT_REGISTRY_PATH,load_generated_registry
from .generated_acceptance import stable_hash
from .generator import deserialize_candidate
from .numeric_token_valuation import (CURRENT_NUMERIC_TOKEN_VALUATION_POLICY_VERSION,evaluate_candidate_numeric_budget,policy_registry_payload)
from .revision_2_canonical_promotion import definition_payload

def _read(path:Path)->Any:return json.loads(path.read_text(encoding="utf-8"))
def resolve_wo037a2(workspace:str|Path)->dict[str,Any]:
 root=Path(workspace);revision_path=root/"generated_candidates/wo037a1/candidate_revision_1.json";revision_bytes=revision_path.read_bytes();stored=_read(revision_path);immutable_hash=stored.pop("immutable_sha256");revision_hash=stable_hash(stored)
 if revision_hash!=immutable_hash or revision_hash!="2642d4276bc3963486e84b3459dcbcd3d487b4b5c006d7bccc71f96157409e09":raise ValueError("REVISION_1_HASH_MISMATCH")
 candidate=deserialize_candidate(json.dumps(stored["candidate"],ensure_ascii=False));evaluation=evaluate_candidate_numeric_budget(candidate,policy_version="v0.2")
 vals={x.policy_id:x.calculated_cost for x in evaluation.numeric_valuations};expected={"damage_coefficient_absolute_v0_1":0,"percent_max_qi_action_cost_v0_2":0,"finite_action_cooldown_v0_2":0,"base_trigger_success_chance_v0_2":10,"finite_distinct_target_count_v0_2":8}
 # Two coefficients share the same policy ID; both are retained in the detailed list and both cost zero.
 coeffs=[x.calculated_cost for x in evaluation.numeric_valuations if x.policy_id=="damage_coefficient_absolute_v0_1"]
 double_charge={"status":"PASS_NO_DOUBLE_CHARGE","ordinary_special":{"mechanic_cost":24,"numeric_intensity_embedded":False},"roaming_distinct":{"mechanic_cost":None,"target_count_intensity_embedded":False},"successful_parry":{"existing_capability_cost":None,"chance_intensity_embedded":False},"followup":{"action_identity_and_attack_instance_already_in_base":True,"ordinary_special_charged_once":True},"coefficient_count":len(coeffs)}
 policy=policy_registry_payload("v0.2");authority={"authority":"HUMAN_AUTHORED_TOKEN_POLICY","source_derived":False,"generator_derived":False,"historical_source_gap":True,"effective_from":"CODEX-WO-037A2","final_balance_locked":False,"scope":"GLOBAL_NUMERIC_PRIMITIVE","family_overrides":{}}
 token={"status":evaluation.status,"policy_version":evaluation.policy_version,"revision_id":stored["revision_id"],"revision_sha256":revision_hash,"mechanic_subtotal":evaluation.base_known_subtotal,"base_known_costs":evaluation.base_known_costs,"valuations":[x.__dict__ for x in evaluation.numeric_valuations],"coefficient_surcharges":coeffs,"qi_surcharge":vals["percent_max_qi_action_cost_v0_2"],"cooldown_surcharge":vals["finite_action_cooldown_v0_2"],"chance_surcharge":vals["base_trigger_success_chance_v0_2"],"target_count_surcharge":vals["finite_distinct_target_count_v0_2"],"numeric_subtotal":evaluation.numeric_subtotal,"total_used":evaluation.total_used,"remaining":evaluation.remaining,"limit":evaluation.budget_limit,"unresolved":evaluation.unresolved_components,"unknown_cost_treated_as_zero":evaluation.unknown_cost_treated_as_zero}
 compiler={"status":"READY_EXCEPT_FORMAL_DISPLAY_NAME","token_policy":"v0.2","budget_status":evaluation.status,"runtime_semantics_complete":True,"formal_display_name":"FORMAL_DISPLAY_NAME_REQUIRED","formal_compile_run":False,"promotion_run":False}
 prior_review=_read(root/"generated_candidates/wo037a1/review_package.json");prior_review_hash=prior_review.pop("immutable_sha256")
 review={"review_package_schema":"WO037A2-review-v0.2","review_package_id":"review:"+stable_hash((stored["revision_id"],revision_hash,"v0.2",evaluation.total_used))[:16],"supersedes_review_package_id":prior_review["review_package_id"],"revision_id":stored["revision_id"],"revision_sha256":revision_hash,"token_policy_version":"v0.2","token_evaluation":token,"compiler_readiness":compiler,"review_state":"PENDING_REVIEW","human_decision":"NONE","canonical":False,"formal":False,"runtime_registered":False}
 manifest=_read(root/"generated_candidates/wo036b2b/canonical_promotion_manifest.json");historical={"status":"PASS_HISTORICAL_VERSION_LOCK","formal_id":manifest["formal_martial_id"],"promotion_policy_version":manifest["numeric_token_policy_version"],"promotion_budget":manifest["token_budget"],"manifest_unchanged":manifest["numeric_token_policy_version"]=="v0.1" and manifest["token_budget"]=={"used":106,"limit":120,"remaining":14},"v0_2_not_retroactive":True}
 registry_path=root/DEFAULT_REGISTRY_PATH;registry_bytes=registry_path.read_bytes();loaded=load_generated_registry(root);cid=next(iter(loaded.runtime));canonical_hash=stable_hash(definition_payload(loaded.get_runtime(cid)))
 controls={"revision_hash_before":revision_hash,"revision_hash_after":stable_hash({k:v for k,v in _read(revision_path).items() if k!="immutable_sha256"}),"revision_bytes_unchanged":revision_path.read_bytes()==revision_bytes,"candidate_revisions":0,"generator_calls":0,"human_accepts":0,"promotion_attempts":0,"canonical_previews":0,"staging":0,"registry_commits":0,"registry_before":loaded.count,"registry_after":load_generated_registry(root).count,"registry_bytes_unchanged":registry_path.read_bytes()==registry_bytes,"existing_canonical_unchanged":canonical_hash==stable_hash(definition_payload(load_generated_registry(root).get_runtime(cid))),"b1_untouched":True,"lane_c_deferred":True}
 status="PASS_NUMERIC_TOKEN_POLICY_V0_2_ESTABLISHED_STOPPED_AT_HUMAN_REVIEW" if evaluation.status=="BUDGET_VALID" and evaluation.total_used==102 else "PARTIAL_ADDITIONAL_TOKEN_POLICY_REQUIRED"
 return {"status":status,"work_order":"CODEX-WO-037A2","policy_registry":policy,"policy_authority":authority,"candidate_token_revaluation":token,"double_charge_audit":double_charge,"compiler_readiness":compiler,"review_package_refresh":review,"historical_policy_lock":historical,"controls":controls,"versions":{"battle_core":"v0.9","generator":"v0.2-prototype","acceptance":"v0.1-prototype","numeric_policy_old":"v0.1","numeric_policy_new":"v0.2","registry_schema":"v0.1"},"required_human_input":["Provide final Human canonical display name.","Then independently choose ACCEPT, REJECT, or REQUEST_REVISION for Revision 1."],"stop":"STOPPED_AT_HUMAN_REVIEW"}

def write_wo037a2_artifacts(result:dict[str,Any],directory:str|Path)->Path:
 out=Path(directory);out.mkdir(parents=True,exist_ok=True)
 payloads={"numeric_policy_v0_2_registry_snapshot.json":result["policy_registry"],"policy_authority_record.json":result["policy_authority"],"candidate_a1_token_revaluation.json":result["candidate_token_revaluation"],"double_charge_audit.json":result["double_charge_audit"],"compiler_readiness_refresh.json":result["compiler_readiness"],"review_package_refresh.json":result["review_package_refresh"],"historical_policy_lock_audit.json":result["historical_policy_lock"],"result.json":{"status":result["status"],"controls":result["controls"],"stop":result["stop"]}}
 for name,payload in payloads.items():
  final={**payload,"immutable_sha256":stable_hash(payload)} if name=="review_package_refresh.json" else payload
  (out/name).write_text(json.dumps(final,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
 return out

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class BattleEvent:
    type: str
    data: dict[str, Any]


class CombatLog:
    def __init__(self):
        self.events: list[BattleEvent] = []

    def add(self, event_type: str, **data):
        self.events.append(BattleEvent(event_type, data))

    def render(self) -> str:
        blocks = []
        for event in self.events:
            if event.type == "OPENING_ORDER":
                lines = ["[OPENING_ORDER]"] + [f"{i}. {u['unit']} speed={u['speed']:g}" for i, u in enumerate(event.data["units"], 1)]
            else:
                lines = [f"[{event.type}]"] + [f"{key}={str(value).lower() if isinstance(value, bool) else value}" for key, value in event.data.items()]
            blocks.append("\n".join(lines))
        return "\n\n".join(blocks)

"""Authoritative token-valuation audit for generated martial acceptance.

This module records whether valuation authority exists. It deliberately does
not create prices when the canonical repository has none.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any
import json

from .generated_acceptance import FORMAL_GENERATED_MARTIAL_REGISTRY, stable_hash
from .generator import TOKEN_COSTS, deserialize_candidate, serialize_candidate


@dataclass(frozen=True)
class ValuationAuthorityFinding:
    component: str
    status: str
    authority: str
    source_files: tuple[str, ...]
    rule_ids: tuple[str, ...]
    evidence: tuple[str, ...]
    excluded_evidence: tuple[str, ...]
    token_cost: int | None
    unresolved_policy: str


@dataclass(frozen=True)
class TokenValuationAuditResult:
    status: str
    candidate_id: str
    candidate_hash_before: str
    candidate_hash_after: str
    candidate_immutable: bool
    source_authority_order: tuple[dict[str, Any], ...]
    coefficient: ValuationAuthorityFinding
    duration: ValuationAuthorityFinding
    family_semantics: dict[str, Any]
    machine_readable_contract: dict[str, Any]
    budget_revalidation: dict[str, Any]
    review_lifecycle: dict[str, Any]
    registry_invariants: dict[str, Any]
    remaining_decision: dict[str, Any]


def audit_generated_martial_token_valuation(workspace, *, formal_registry=None, runtime_registry=None):
    root = Path(workspace)
    formal_registry = FORMAL_GENERATED_MARTIAL_REGISTRY if formal_registry is None else formal_registry
    runtime_registry = {} if runtime_registry is None else runtime_registry
    formal_before, runtime_before = len(formal_registry), len(runtime_registry)
    candidate_path = root / "generated_candidates" / "wo036b1a" / "candidate_d_revision_1.json"
    package_path = root / "generated_candidates" / "wo036b1a" / "review_package.json"
    candidate_bytes_before = candidate_path.read_bytes()
    package_bytes_before = package_path.read_bytes()
    candidate = deserialize_candidate(candidate_bytes_before.decode("utf-8"))
    candidate_hash_before = stable_hash(serialize_candidate(candidate))

    sources = (
        {"priority": 1, "source": "battle_core/generator.py:TOKEN_COSTS", "classification": "AUTHORITATIVE_MACHINE_READABLE_PARTIAL", "finding": "Prices mechanic/capability presence only; no coefficient or duration tariff."},
        {"priority": 2, "source": "武俠自動戰鬥核心規格_Codex_v0.9_2026-08-23.md", "classification": "AUTHORITATIVE_SEMANTICS_ONLY", "finding": "Defines owner Formal Turn duration semantics, not token valuation."},
        {"priority": 3, "source": "battle_core/v09_ledger.py + battle_core/v08_ledger.py", "classification": "AUTHORITATIVE_LEDGER_NO_RATE", "finding": "No coefficient-to-token or duration-to-token rule."},
        {"priority": 4, "source": "machine-readable token registry", "classification": "ABSENT_BEYOND_TOKEN_COSTS", "finding": "No separate valuation registry exists."},
        {"priority": 5, "source": "battle_core/martial.py formal definitions", "classification": "CONTENT_EVIDENCE_NOT_RATE_AUTHORITY", "finding": "Values vary by mechanic and do not declare a generic/family exchange rule."},
        {"priority": 6, "source": "武學生成與驗證規格_v0.1_2026-08-24.md + v0.2_DRAFT", "classification": "AUTHORITATIVE_NEGATIVE_RULE", "finding": "Unknown token costs remain INDETERMINATE; v0.2 explicitly does not change token exchange rates."},
        {"priority": 7, "source": "historical implementations", "classification": "NONTRANSFERABLE_EVIDENCE", "finding": "Implementation values establish behavior, not a generic tariff."},
    )
    excluded = ("tests/** fixtures", "demo_*.py values", "assistant_first_pass_values", "test tuning overrides")
    coefficient = ValuationAuthorityFinding(
        "actions[0].damage_coefficient", "INSUFFICIENT_AUTHORITY", "NONE",
        ("battle_core/generator.py", "武學生成與驗證規格_v0.1_2026-08-24.md", "武學生成與驗證規格_v0.2_DRAFT_2026-08-24.md", "武俠自動戰鬥核心規格_Codex_v0.9_2026-08-23.md"),
        (),
        ("TOKEN_COSTS has no coefficient key/band/base/increment rule.", "Formal spear Basic/Advanced coefficients remain TOKEN_BALANCE_TBD.", "Other-family numeric coefficients do not declare a transferable pricing formula.", "Tier budget is not a coefficient multiplier."),
        excluded, None, "HUMAN_TOKEN_POLICY_REQUIRED:DAMAGE_COEFFICIENT_VALUATION",
    )
    duration = ValuationAuthorityFinding(
        "statuses[0].duration", "INSUFFICIENT_AUTHORITY", "NONE",
        ("battle_core/generator.py", "武俠自動戰鬥核心規格_Codex_v0.9_2026-08-23.md", "battle_core/status.py", "武學生成與驗證規格_v0.1_2026-08-24.md"),
        (),
        (f"TOKEN_COSTS status={TOKEN_COSTS['status']} prices status presence, not length.", "Canonical owner-turn clock defines expiration semantics only.", "No base-turn, additional-turn, refresh, extend, stack, permanent, or until-consumed tariff exists.", "Existing status durations are content values, not conversion authority."),
        excluded, None, "HUMAN_TOKEN_POLICY_REQUIRED:OWNER_FORMAL_TURN_STATUS_DURATION_VALUATION",
    )
    candidate_hash_after = stable_hash(serialize_candidate(deserialize_candidate(candidate_path.read_text(encoding="utf-8"))))
    package_preserved = package_bytes_before == package_path.read_bytes()
    known = dict(candidate.token_plan.known_costs)
    subtotal = sum(known.values())
    budget = {
        "budget_limit": 120,
        "base_known_costs": known,
        "previous_known_subtotal": 78,
        "rechecked_known_subtotal": subtotal,
        "damage_coefficient_cost": "INDETERMINATE",
        "status_duration_cost": "INDETERMINATE",
        "other_existing_costs": 0,
        "final_used_budget": "INDETERMINATE",
        "remaining_budget": "INDETERMINATE",
        "budget_status": "BUDGET_INDETERMINATE",
        "unresolved_components": ("damage_coefficient_valuation", "owner_formal_turn_status_duration_valuation"),
        "unknown_cost_treated_as_zero": False,
    }
    lifecycle = {
        "review_status": "PENDING_REVIEW",
        "human_decision": "NONE",
        "old_review_package_preserved": package_preserved,
        "new_review_package_created": False,
        "reason": "No valuation was resolved; audit and budget revalidation are external review references, not candidate/package mutation.",
    }
    registries = {
        "formal_before": formal_before, "formal_after": len(formal_registry),
        "runtime_before": runtime_before, "runtime_after": len(runtime_registry),
        "generated_canonical_count": len(formal_registry), "promotion_attempts": 0,
        "canonical_previews": 0, "registry_commits": 0,
    }
    if candidate_bytes_before != candidate_path.read_bytes() or candidate_hash_before != candidate_hash_after:
        raise RuntimeError("REVISION_1_MUTATED")
    if not package_preserved:
        raise RuntimeError("IMMUTABLE_REVIEW_PACKAGE_MUTATED")
    if formal_before != len(formal_registry) or runtime_before != len(runtime_registry):
        raise RuntimeError("UNAUTHORIZED_PROMOTION")
    return TokenValuationAuditResult(
        "PASS_INSUFFICIENT_TOKEN_AUTHORITY_HUMAN_POLICY_REQUIRED",
        candidate.candidate_id, candidate_hash_before, candidate_hash_after, True,
        sources, coefficient, duration,
        {"classification": "UNDETERMINED_NO_VALUATION_AUTHORITY", "spear_staff_rule": "NOT_FOUND", "sword_rule": "NOT_FOUND", "blade_rule": "NOT_FOUND", "fist_rule": "NOT_FOUND", "global_rule": "NOT_FOUND", "source_differences_normalized": False},
        {"created": False, "reason": "Existing authority cannot support a valuation contract.", "candidate_id_branches": 0, "martial_name_branches": 0, "rng_calls": 0, "external_calls": 0},
        budget, lifecycle, registries,
        {"status": "HUMAN_TOKEN_POLICY_REQUIRED", "next_work_order": "CODEX-WO-036B1C", "required_decisions": ("Define authoritative damage-coefficient valuation policy and scope.", "Define authoritative OWNER_FORMAL_TURNS status-duration valuation policy and scope.", "Decide whether each policy is global, weapon-category, family, tier/action/targeting dependent, or mixed."), "prohibited_default": "UNKNOWN_COST_MUST_NOT_EQUAL_ZERO"},
    )


def write_token_valuation_audit_artifacts(result, directory):
    root = Path(directory); root.mkdir(parents=True, exist_ok=True)
    payloads = {
        "source_authority_ledger.json": result.source_authority_order,
        "damage_coefficient_audit.json": asdict(result.coefficient),
        "status_duration_audit.json": asdict(result.duration),
        "family_semantics_audit.json": result.family_semantics,
        "machine_readable_contract_decision.json": result.machine_readable_contract,
        "revision_1_budget_revalidation.json": result.budget_revalidation,
        "revision_1_integrity.json": {"candidate_id": result.candidate_id, "hash_before": result.candidate_hash_before, "hash_after": result.candidate_hash_after, "immutable": result.candidate_immutable},
        "review_lifecycle.json": result.review_lifecycle,
        "registry_invariants.json": result.registry_invariants,
        "remaining_human_token_policy_decision.json": result.remaining_decision,
        "audit_result.json": {"status": result.status},
    }
    for name, value in payloads.items():
        (root / name).write_text(json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False), encoding="utf-8")
    return root

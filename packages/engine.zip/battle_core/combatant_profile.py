"""WO-075 immutable reusable combatant content profiles."""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import hashlib
import json
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping

from .combatant_appearance import GENERIC_DISCIPLE, GENERIC_GUARD, GENERIC_TRAVELER

GAME_FACING_COMBATANT_PROFILE = "GAME_FACING_COMBATANT_PROFILE_V0_1"
COMBATANT_PROFILE_REGISTRY = "COMBATANT_PROFILE_REGISTRY_V0_1"
PROFILE_STATUS = "NONCANONICAL_GAME_FACING_PROTOTYPE"

SPEAR_ID = "generated:spear:advanced:31a63f7586a1:r2"
SWORD_ID = "generated:sword:advanced:644fb8ab88e0:r2"
FIST_ID = "generated:fist:high:f56a8c141194:r1"
BLADE_ID = "generated:blade:legendary:2b7457785666:r0"

STAT_PROFILE_REGISTRY = MappingProxyType({
    "stat:prototype:standard_240": MappingProxyType({"max_hp": 240, "initial_qi": 30}),
    "stat:prototype:dev_survivability_1000": MappingProxyType({"max_hp": 1000, "initial_qi": 30, "fixture_marker": "DEV_SURVIVABILITY_PROFILE_WO074A"}),
    "stat:prototype:dev_defeat_smoke_enemy_1000": MappingProxyType({"max_hp": 1000, "initial_qi": 30, "fixture_marker": "DEV_DEFEAT_SMOKE_PROFILE_WO077A", "battle_balance_claim": "NONE"}),
})
LOADOUT_REGISTRY = MappingProxyType({
    "loadout:generated-sword-advanced-r2": MappingProxyType({"martial_ids": (SWORD_ID,), "default_action_id": SWORD_ID, "weapon_family": "SWORD"}),
    "loadout:generated-blade-legendary-r0": MappingProxyType({"martial_ids": (BLADE_ID,), "default_action_id": BLADE_ID, "weapon_family": "BLADE"}),
    "loadout:generated-spear-advanced-r2": MappingProxyType({"martial_ids": (SPEAR_ID,), "default_action_id": SPEAR_ID, "weapon_family": "SPEAR"}),
    "loadout:generated-fist-high-r1": MappingProxyType({"martial_ids": (FIST_ID,), "default_action_id": FIST_ID, "weapon_family": "FIST"}),
    # Compatibility alias retained for WO-074A callers; profile-based content uses separate stat binding.
    "loadout:generated-sword-advanced-r2:dev-survivability-wo074a": MappingProxyType({"martial_ids": (SWORD_ID,), "default_action_id": SWORD_ID, "weapon_family": "SWORD", "max_hp": 1000, "initial_qi": 30, "fixture_marker": "DEV_SURVIVABILITY_PROFILE_WO074A", "battle_balance_claim": "NONE"}),
})
PRESENTATION_PROFILE_REGISTRY = MappingProxyType({"GENERIC_PLAYER": GENERIC_TRAVELER, "GENERIC_ALLY": GENERIC_DISCIPLE, "GENERIC_ENEMY": GENERIC_GUARD})
BODY_PROFILES = frozenset(("STANDARD", "LIGHT", "HEAVY"))
DEFAULT_CONTROL_ROLES = frozenset(("PLAYER_CAPABLE", "ALLY_AI", "ENEMY_AI"))
WEAPON_FAMILIES = frozenset(("BLADE", "SWORD", "SPEAR", "FIST"))


class CombatantProfileValidationCode(str, Enum):
    VALID = "VALID"
    UNKNOWN_PROFILE = "UNKNOWN_PROFILE"
    INVALID_PROFILE_ID = "INVALID_PROFILE_ID"
    INVALID_PROFILE = "INVALID_PROFILE"
    UNKNOWN_STAT_PROFILE = "UNKNOWN_STAT_PROFILE"
    UNKNOWN_LOADOUT = "UNKNOWN_LOADOUT"
    UNKNOWN_PRESENTATION_PROFILE = "UNKNOWN_PRESENTATION_PROFILE"
    UNKNOWN_BODY_PROFILE = "UNKNOWN_BODY_PROFILE"
    INVALID_WEAPON_FAMILY = "INVALID_WEAPON_FAMILY"
    WEAPON_LOADOUT_MISMATCH = "WEAPON_LOADOUT_MISMATCH"
    INVALID_DEFAULT_CONTROL_ROLE = "INVALID_DEFAULT_CONTROL_ROLE"


@dataclass(frozen=True)
class CombatantProfileValidationResult:
    code: CombatantProfileValidationCode
    message: str = ""
    @property
    def valid(self) -> bool: return self.code is CombatantProfileValidationCode.VALID


class CombatantProfileError(ValueError):
    def __init__(self, result: CombatantProfileValidationResult):
        self.result = result
        super().__init__(f"{result.code.value}: {result.message}")


@dataclass(frozen=True)
class CombatantProfile:
    combatant_profile_id: str
    display_name: str
    status: str
    stat_profile_ref: str
    loadout_ref: str
    weapon_family: str
    body_profile: str
    presentation_profile: str
    default_control_role: str
    tags: tuple[str, ...]
    combat_role: str = "GENERIC"
    profile_hash: str = ""


def stable_profile_hash(raw: Mapping[str, Any]) -> str:
    payload = {key: value for key, value in raw.items() if key != "profile_hash"}
    return hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def parse_combatant_profile(raw: Mapping[str, Any]) -> CombatantProfile:
    required = ("combatant_profile_id", "display_name", "status", "stat_profile_ref", "loadout_ref", "weapon_family", "body_profile", "presentation_profile", "default_control_role")
    missing = tuple(key for key in required if not isinstance(raw.get(key), str) or not raw.get(key))
    if missing:
        code = CombatantProfileValidationCode.INVALID_PROFILE_ID if "combatant_profile_id" in missing else CombatantProfileValidationCode.INVALID_PROFILE
        raise CombatantProfileError(CombatantProfileValidationResult(code, ",".join(missing)))
    tags = raw.get("tags", ())
    if not isinstance(tags, list) or any(not isinstance(tag, str) for tag in tags):
        raise CombatantProfileError(CombatantProfileValidationResult(CombatantProfileValidationCode.INVALID_PROFILE, "tags"))
    return CombatantProfile(*(raw[key] for key in required), tuple(tags), str(raw.get("combat_role") or "GENERIC"), stable_profile_hash(raw))


def validate_combatant_profile(profile: CombatantProfile) -> CombatantProfileValidationResult:
    if not profile.combatant_profile_id.startswith("combatant:"):
        return CombatantProfileValidationResult(CombatantProfileValidationCode.INVALID_PROFILE_ID, profile.combatant_profile_id)
    if profile.stat_profile_ref not in STAT_PROFILE_REGISTRY:
        return CombatantProfileValidationResult(CombatantProfileValidationCode.UNKNOWN_STAT_PROFILE, profile.stat_profile_ref)
    if profile.loadout_ref not in LOADOUT_REGISTRY:
        return CombatantProfileValidationResult(CombatantProfileValidationCode.UNKNOWN_LOADOUT, profile.loadout_ref)
    if profile.presentation_profile not in PRESENTATION_PROFILE_REGISTRY:
        return CombatantProfileValidationResult(CombatantProfileValidationCode.UNKNOWN_PRESENTATION_PROFILE, profile.presentation_profile)
    if profile.body_profile not in BODY_PROFILES:
        return CombatantProfileValidationResult(CombatantProfileValidationCode.UNKNOWN_BODY_PROFILE, profile.body_profile)
    if profile.weapon_family not in WEAPON_FAMILIES:
        return CombatantProfileValidationResult(CombatantProfileValidationCode.INVALID_WEAPON_FAMILY, profile.weapon_family)
    if LOADOUT_REGISTRY[profile.loadout_ref]["weapon_family"] != profile.weapon_family:
        return CombatantProfileValidationResult(CombatantProfileValidationCode.WEAPON_LOADOUT_MISMATCH, profile.loadout_ref)
    if profile.default_control_role not in DEFAULT_CONTROL_ROLES:
        return CombatantProfileValidationResult(CombatantProfileValidationCode.INVALID_DEFAULT_CONTROL_ROLE, profile.default_control_role)
    return CombatantProfileValidationResult(CombatantProfileValidationCode.VALID)


def _content_dir(workspace: str | Path) -> Path: return Path(workspace) / "game_content" / "combatants"


def combatant_profile_registry(workspace: str | Path) -> Mapping[str, str]:
    raw = json.loads((_content_dir(workspace) / "combatant_profile_registry.json").read_text(encoding="utf-8"))
    if raw.get("contract") != COMBATANT_PROFILE_REGISTRY or not isinstance(raw.get("profiles"), dict):
        raise CombatantProfileError(CombatantProfileValidationResult(CombatantProfileValidationCode.INVALID_PROFILE, "registry"))
    if len(raw["profiles"]) != len(set(raw["profiles"])):
        raise CombatantProfileError(CombatantProfileValidationResult(CombatantProfileValidationCode.INVALID_PROFILE_ID, "duplicate"))
    return MappingProxyType(dict(raw["profiles"]))


def resolve_combatant_profile(workspace: str | Path, profile_id: str) -> CombatantProfile:
    registry = combatant_profile_registry(workspace)
    if profile_id not in registry:
        raise CombatantProfileError(CombatantProfileValidationResult(CombatantProfileValidationCode.UNKNOWN_PROFILE, profile_id))
    raw = json.loads((_content_dir(workspace) / registry[profile_id]).read_text(encoding="utf-8"))
    profile = parse_combatant_profile(raw)
    if profile.combatant_profile_id != profile_id:
        raise CombatantProfileError(CombatantProfileValidationResult(CombatantProfileValidationCode.INVALID_PROFILE_ID, profile_id))
    result = validate_combatant_profile(profile)
    if not result.valid: raise CombatantProfileError(result)
    return profile

"""Formal combat state-model boundary."""
from .life_state import CombatantLifeState

__all__ = ["CombatantLifeState"]

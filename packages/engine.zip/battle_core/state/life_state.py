"""WO080 lifecycle vocabulary; transition/resolution policy is deliberately absent."""
from enum import Enum


class CombatantLifeState(str, Enum):
    ALIVE = "ALIVE"
    PENDING_DEATH_CONFIRMATION = "PENDING_DEATH_CONFIRMATION"
    DEFEATED = "DEFEATED"

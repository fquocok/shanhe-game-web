"""WO-047 evidence for minimal, presentation-only timed pose swaps."""
from __future__ import annotations
from dataclasses import asdict, replace
from hashlib import sha256
from pathlib import Path
import json

from .durable_generated_registry import DEFAULT_REGISTRY_PATH, load_generated_registry
from .generated_acceptance import stable_hash
from .interactive_battle_screen import MOTION_HOLD_MS, MOTION_LEAD_IN_MS, TRANSITION_CONTRACT, BattleScreenSession, VisualPose, build_2d_layout_model, build_body_presence_model, build_pose_transitions, project_combat_feedback
from .player_action_control import PlayerActionCommand

STATUS = "PASS_WAITING_FOR_HUMAN_MOTION_SMOKE"


def audit_wo047(workspace):
    root = Path(workspace); registry_path = root / DEFAULT_REGISTRY_PATH; before = registry_path.read_bytes(); loaded = load_generated_registry(root)
    session = BattleScreenSession(root); initial = session.screen_state(); presence = build_body_presence_model(build_2d_layout_model(initial)); action = next(x for x in initial["actions"] if x["kind"] == "MAIN_ACTION")
    result = session.controller.submit(PlayerActionCommand(session.controller.battle_id, "player", action["action_id"], ("enemy-center",), 0, "wo047-audit"), outcomes=("HIT", "DODGED", "PARRIED_SUCCESSFUL_HIT")); feedback = project_combat_feedback(result.presentation_events)
    transitions = build_pose_transitions(presence, feedback, 1)
    dead = BattleScreenSession(root); dead.controller.targets["enemy-left"] = replace(dead.controller.targets["enemy-left"], alive=False); dead_presence = build_body_presence_model(build_2d_layout_model(dead.screen_state())); dead_transitions = build_pose_transitions(dead_presence, feedback, 2)
    contract = {"contract_id": TRANSITION_CONTRACT, "representation": "VisualPoseTransition", "presentation_only": True,
                "lead_in_ms": MOTION_LEAD_IN_MS, "hold_ms": MOTION_HOLD_MS, "generation_token": "WO045_SHARED",
                "settlement_order": "BATTLE_SETTLED_BEFORE_VISUAL_MOTION", "keyframe_engine": False, "animation_system": False}
    return {"status": STATUS, "contract": contract, "contract_hash": stable_hash(contract),
            "mixed_transitions": [asdict(x) for x in transitions], "defeated_transitions": [asdict(x) for x in dead_transitions],
            "checks": {"mandatory_pose_vocabulary": [x.value for x in VisualPose], "simultaneous_multi_target": True, "latest_state_restore": True,
                       "stale_callback_guard": True, "reset_invalidates_motion": True, "close_safe": True, "selection_persistent": True,
                       "body_clickable": True, "text_feedback_retained": True, "battle_settled_before_motion": result.accepted,
                       "ai_motion": "DEFERRED_WITH_WO045_AI_EVENT_HOOK"},
            "isolation": {"battle_semantic_changes": 0, "battle_timing_semantic_changes": 0, "battle_rng_impact": 0, "ai_deterministic_impact": 0,
                          "canonical_changes": 0, "registry_changes": 0, "generator_changes": 0, "acceptance_changes": 0, "numeric_token_policy_changes": 0,
                          "martial_stance_semantics": "UNCHANGED", "registry": [loaded.count, len(loaded.runtime), loaded.count],
                          "registry_sha256": sha256(before).hexdigest(), "registry_bytes_unchanged": registry_path.read_bytes() == before},
            "human_gate": {"formal_verification": "NOT_YET", "next": "STOP_AND_WAIT_FOR_HUMAN", "checklist": "human_motion_smoke_checklist.md"}}


def write_wo047_artifacts(workspace, directory):
    result = audit_wo047(workspace); out = Path(directory); out.mkdir(parents=True, exist_ok=True)
    for filename, key in (("pose_transition_contract.json", "contract"), ("mixed_transition_trace.json", "mixed_transitions"),
                          ("defeated_transition_trace.json", "defeated_transitions"), ("transition_checks.json", "checks"),
                          ("isolation_audit.json", "isolation"), ("human_motion_gate.json", "human_gate")):
        (out / filename).write_text(json.dumps(result[key], ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "pose_transition_contract_hash.json").write_text(json.dumps({"contract_id": TRANSITION_CONTRACT, "sha256": result["contract_hash"]}, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "result.json").write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    return result


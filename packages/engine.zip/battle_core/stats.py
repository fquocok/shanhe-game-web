from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP

from .config import BASE_MAX_QI, BASE_SPEED
from .schema import CharacterDefinition


def round_half_up(value: float) -> int:
    return int(Decimal(str(value)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def _modifier(definition: CharacterDefinition, key: str, default):
    return definition.modifiers.get(key, default)


class DerivedStatResolver:
    def __init__(self, loadout_modifiers=None):
        self.loadout_modifiers = loadout_modifiers or {}

    def _loadout(self, d, key):
        return float(self.loadout_modifiers.get(d.id, {}).get(key, 0))

    def max_hp(self, d: CharacterDefinition) -> int:
        flat = d.level * 100 + d.constitution * 100 + _modifier(d, "equipment_flat_hp", 0) + _modifier(d, "other_flat_hp", 0) + self._loadout(d, "flat_max_hp")
        value = flat * (1 + _modifier(d, "additive_max_hp_percent", 0))
        for multiplier in _modifier(d, "max_hp_multipliers", []):
            value *= multiplier
        return round_half_up(value)

    def max_qi(self, d: CharacterDefinition) -> int:
        value = (BASE_MAX_QI + _modifier(d, "flat_max_qi", 0)) * (1 + _modifier(d, "additive_max_qi_percent", 0))
        for multiplier in _modifier(d, "max_qi_multipliers", []):
            value *= multiplier
        return round_half_up(value)

    def speed(self, d: CharacterDefinition) -> float:
        value = (BASE_SPEED + d.agility + _modifier(d, "flat_speed", 0) + self._loadout(d, "flat_speed")) * (1 + _modifier(d, "speed_percent", 0))
        for multiplier in _modifier(d, "speed_multipliers", []):
            value *= multiplier
        return max(value, 1.0)

    def attack(self, d: CharacterDefinition) -> float:
        value = (d.strength * 3 + d.weapon_attack + _modifier(d, "other_flat_attack", 0) + self._loadout(d, "flat_attack")) * (1 + _modifier(d, "additive_attack_percent", 0))
        for multiplier in _modifier(d, "attack_multipliers", []):
            value *= multiplier
        return value

    def defense(self, d: CharacterDefinition, additive_percent: float = 0.0) -> float:
        value = (d.equipment_defense + _modifier(d, "flat_defense", 0)) * (1 + _modifier(d, "additive_defense_percent", 0) + additive_percent)
        for multiplier in _modifier(d, "defense_multipliers", []):
            value *= multiplier
        return max(value, 0.0)

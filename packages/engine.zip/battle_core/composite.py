"""Generic definition-level composite Action contract (WO-028A)."""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType
from typing import Any, Mapping

from .targeting import TargetingSpec
from .events import SemanticEventType, EventPhase
from .trigger import FormalTurnContext, TriggerEngine

class ExecutionIdentity(str, Enum):
    SAME_ROOT_MAIN_ACTION="SAME_ROOT_MAIN_ACTION"
    NEW_ORDINARY_SPECIAL_ACTION="NEW_ORDINARY_SPECIAL_ACTION"
    NON_ACTION_EFFECT="NON_ACTION_EFFECT"

class StageEdgeCondition(str, Enum):
    ALWAYS="ALWAYS"; ON_STAGE_EXECUTED="ON_STAGE_EXECUTED"; ON_STAGE_SKIPPED="ON_STAGE_SKIPPED"
    ON_SUCCESSFUL_HIT="ON_SUCCESSFUL_HIT"; ON_EFFECTIVE_ATTACK_DAMAGE="ON_EFFECTIVE_ATTACK_DAMAGE"
    ON_ACTION_SUCCESSFULLY_DEALS_DAMAGE="ON_ACTION_SUCCESSFULLY_DEALS_DAMAGE"
    ON_RESOURCE_THRESHOLD="ON_RESOURCE_THRESHOLD"

@dataclass(frozen=True)
class StageCondition:
    fact: str
    operator: str = ">="
    value: Any = 1

@dataclass(frozen=True)
class ActionStageDefinition:
    stage_id: str
    execution_identity: ExecutionIdentity
    effect_type: str
    targeting: str = "single"
    anchor_source: str = "ROOT_PRIMARY_TARGET"
    attack_coefficient: float | None = None
    condition: StageCondition | None = None
    chance: float | None = None
    chance_attribute: str | None = None
    chance_per_point: float = 0.0
    parameters: Mapping[str,Any] = field(default_factory=lambda: MappingProxyType({}))
    required: bool = True

@dataclass(frozen=True)
class ActionStageEdge:
    from_stage: str
    to_stage: str
    condition: StageEdgeCondition = StageEdgeCondition.ALWAYS

@dataclass(frozen=True)
class CompositeActionDefinition:
    id: str
    stages: tuple[ActionStageDefinition,...]
    edges: tuple[ActionStageEdge,...]
    entry_stage_ids: tuple[str,...]
    qi_cost: int = 0
    qi_cost_percent_max: float | None = None
    cooldown_id: str | None = None
    cooldown_turns: int = 0

@dataclass(frozen=True)
class ActionStageOutcome:
    stage_id: str; executed: bool; skipped: bool; skip_reason: str | None
    attack_instance_ids: tuple[str,...] = (); successful_hit_count: int = 0
    effective_attack_damage_instance_count: int = 0
    unique_successfully_hit_enemy_count: int = 0
    final_damage_before_shield_total: int = 0
    hp_damage_total: int = 0
    produced_facts: Mapping[str,Any] = field(default_factory=lambda: MappingProxyType({}))

@dataclass(frozen=True)
class CompositeActionOutcome:
    root_action_id: str; stage_outcomes: tuple[ActionStageOutcome,...]
    action_outcome_summary: Mapping[str,Any]

ALLOWED_FACTS={"successful_hit_count","dealt_effective_attack_damage","effective_attack_damage_instance_count",
 "unique_successfully_hit_enemy_count","executed","skipped","resource_after_stage"}
ALLOWED_ANCHORS={"ROOT_PRIMARY_TARGET","ALREADY_LEGAL_PRIMARY_TARGET","ORIGINAL_ATTACKER_SLOT","PRIOR_STAGE_TARGET"}

def validate_action_stage_graph(definition: CompositeActionDefinition) -> tuple[str,...]:
    errors=[]; ids=[s.stage_id for s in definition.stages]; known=set(ids)
    if len(ids)!=len(known): errors.append("DUPLICATE_STAGE_ID")
    if not definition.entry_stage_ids or not set(definition.entry_stage_ids)<=known: errors.append("INVALID_ENTRY_STAGE")
    for s in definition.stages:
        if not s.stage_id: errors.append("EMPTY_STAGE_ID")
        if s.anchor_source not in ALLOWED_ANCHORS: errors.append(f"ILLEGAL_ANCHOR:{s.stage_id}")
        if s.condition:
            head=s.condition.fact.split(".",1)[0]
            tail=s.condition.fact.split(".",1)[-1]
            if "." not in s.condition.fact or head not in known or tail not in ALLOWED_FACTS:
                errors.append(f"BAD_FACT_REFERENCE:{s.stage_id}")
    adj={x:[] for x in known}
    for e in definition.edges:
        if e.from_stage not in known or e.to_stage not in known: errors.append("MISSING_EDGE_TARGET")
        elif e.from_stage==e.to_stage: errors.append("ILLEGAL_CYCLE")
        else: adj[e.from_stage].append(e.to_stage)
    visiting=set();done=set()
    def visit(n):
        if n in visiting: errors.append("ILLEGAL_CYCLE");return
        if n in done:return
        visiting.add(n)
        for x in adj[n]:visit(x)
        visiting.remove(n);done.add(n)
    for n in known:visit(n)
    reachable=set(); stack=list(definition.entry_stage_ids)
    while stack:
        n=stack.pop()
        if n in reachable:continue
        reachable.add(n);stack.extend(adj.get(n,()))
    for s in definition.stages:
        if s.required and s.stage_id not in reachable:errors.append(f"UNREACHABLE_REQUIRED:{s.stage_id}")
    if errors: raise ValueError("INVALID_ACTION_STAGE_GRAPH: "+", ".join(dict.fromkeys(errors)))
    return tuple(sorted(reachable))

def _compare(actual,op,expected):
    return {">=":actual>=expected,">":actual>expected,"==":actual==expected,"<=":actual<=expected,"<":actual<expected}[op]

class CompositeActionExecutor:
    """Executes the ActionStageGraph; MartialTopologyDefinition is never consumed here."""
    def __init__(self,engine):self.engine=engine
    def execute(self,definition,actor,primary_target,root_action_id=None):
        validate_action_stage_graph(definition)
        target_chains = {}  # One committed composite Action; never reuse a prior execution's lock.
        if not actor.ordinary_combat_eligible or primary_target is None or not primary_target.ordinary_combat_eligible:return None
        qi_cost=(int(actor.max_qi*definition.qi_cost_percent_max) if definition.qi_cost_percent_max is not None else definition.qi_cost)
        if actor.current_qi<qi_cost:return None
        if definition.cooldown_id and self.engine.cooldowns.get(actor,definition.cooldown_id)>0:return None
        temporary_context=False
        if self.engine.trigger_context is None:
            temporary_context=True;self.engine.trigger_context=FormalTurnContext("composite-formal-turn",actor.definition.id)
        root_action_id=root_action_id or f"{self.engine.trigger_context.formal_turn_id}:main"
        actor.current_qi-=qi_cost
        if qi_cost:self.engine.log.add("QI_SPENT",actor=actor.definition.id,action=definition.id,amount=qi_cost,current_qi=actor.current_qi,max_qi=actor.max_qi)
        if definition.cooldown_id:self.engine.cooldowns.set(actor,definition.cooldown_id,definition.cooldown_turns)
        self.engine._create_offensive_snapshot(actor,root_action_id)
        self.engine._main_damage_accumulator={"actor_id":actor.definition.id,"action_id":root_action_id,"final_damage_before_shield_total":0,"shield_absorbed_damage_total":0,"hp_damage_total":0}
        self.engine.log.add("COMPOSITE_ACTION_STARTED",definition_id=definition.id,root_action_id=root_action_id,actor_id=actor.definition.id,primary_target_id=primary_target.definition.id,qi_cost=qi_cost,cooldown_id=definition.cooldown_id)
        self.engine.log.add("COMPOSITE_ROOT_ACTION_COMMITTED",definition_id=definition.id,root_action_id=root_action_id,actor_id=actor.definition.id,primary_target_id=primary_target.definition.id,qi_cost=qi_cost,cooldown_id=definition.cooldown_id)
        by={s.stage_id:s for s in definition.stages}; incoming={x:[] for x in by};outgoing={x:[] for x in by}
        for e in definition.edges:incoming[e.to_stage].append(e);outgoing[e.from_stage].append(e)
        pending=list(definition.entry_stage_ids); outcomes={}; ordered=[]
        while pending:
            sid=pending.pop(0)
            if sid in outcomes:continue
            stage=by[sid]
            if not actor.ordinary_combat_eligible or (stage.targeting!="all_enemies" and not primary_target.ordinary_combat_eligible):
                out=ActionStageOutcome(sid,False,True,"BOUND_ROOT_TARGET_UNAVAILABLE");outcomes[sid]=out;ordered.append(out)
                self.engine.log.add("COMPOSITE_BOUND_TARGET_UNAVAILABLE",root_action_id=root_action_id,stage_id=sid,bound_target_id=primary_target.definition.id,retarget_attempted=False,gate_rng_consumed=False,reason="BOUND_ROOT_TARGET_UNAVAILABLE")
                self.engine.log.add("COMPOSITE_STAGE_SKIPPED",stage_id=sid,root_action_id=root_action_id,reason="BOUND_ROOT_TARGET_UNAVAILABLE")
                self._advance(out,outgoing[sid],pending);continue
            if stage.condition:
                source,fact=stage.condition.fact.split(".",1); prior=outcomes.get(source)
                if prior is None: raise RuntimeError("PRIOR_STAGE_FACT_UNAVAILABLE")
                actual=(prior.produced_facts.get(fact) if fact in prior.produced_facts else getattr(prior,fact))
                if not _compare(actual,stage.condition.operator,stage.condition.value):
                    out=ActionStageOutcome(sid,False,True,"condition_false");outcomes[sid]=out;ordered.append(out)
                    self.engine.log.add("COMPOSITE_STAGE_SKIPPED",stage_id=sid,root_action_id=root_action_id,reason="condition_false")
                    self._advance(out,outgoing[sid],pending);continue
            if stage.chance is not None:
                attribute_value=float(getattr(actor.definition,stage.chance_attribute)) if stage.chance_attribute else 0.0
                raw=stage.chance+attribute_value*stage.chance_per_point;chance=min(max(raw,0),1);roll=0.0 if chance>=1 else self.engine.rng.random()
                self.engine.log.add("COMPOSITE_STAGE_GATE_EVALUATED",root_action_id=root_action_id,from_stage_id=next((e.from_stage for e in incoming[sid]),None),to_stage_id=sid,raw_probability=raw,effective_probability=chance,agility=actor.definition.agility,rng_draw=roll,passed=roll<chance)
                if roll>=chance:
                    out=ActionStageOutcome(sid,False,True,"chance_failed");outcomes[sid]=out;ordered.append(out);self.engine.log.add("COMPOSITE_STAGE_SKIPPED",stage_id=sid,root_action_id=root_action_id,reason="chance_failed");self._advance(out,outgoing[sid],pending);continue
            self.engine.log.add("COMPOSITE_STAGE_STARTED",root_action_id=root_action_id,stage_id=sid,execution_identity=stage.execution_identity.value)
            out=self._execute_stage(stage,actor,primary_target,root_action_id,target_chains)
            outcomes[sid]=out;ordered.append(out);self.engine.log.add("COMPOSITE_STAGE_COMPLETED",root_action_id=root_action_id,stage_id=sid,execution_identity=stage.execution_identity.value,target_ids=tuple(sorted({x.data.get("target_id") for x in self.engine.log.events if x.type=="ATTACK_INSTANCE_CREATED" and x.data.get("stage_id")==sid})),attack_instance_ids=out.attack_instance_ids,successful_hit_count=out.successful_hit_count,effective_damage_count=out.effective_attack_damage_instance_count,stage_executed=out.executed);self._advance(out,outgoing[sid],pending)
        self.engine._finalize_main_action_damage()
        root_summary=dict(self.engine._action_outcomes.get(root_action_id,{"action_id":root_action_id,"actor_id":actor.definition.id,"attack_instance_count":0,"effective_attack_damage_instance_count":0}))
        finalized = self.engine._finalize_action_outcome(root_action_id,actor.definition.id)
        outcome_fact = self.engine._append_action_outcome_fact(
            finalized, formal_turn_id=self.engine.trigger_context.formal_turn_id,
            action_id=root_action_id, actor_id=actor.definition.id, classification="formal_main",
            source_action_definition_id=definition.id, action_target_id=primary_target.definition.id,
            action_type="composite", attack_coefficient=None, parent_event_id=None)
        self.engine.log.add("COMPOSITE_ACTION_FINALIZED",root_action_id=root_action_id,stage_count=len(ordered))
        self.engine._emit_action_complete_compat(outcome_fact,action_id=root_action_id,actor_id=actor.definition.id,target_id=primary_target.definition.id,source_action_definition_id=definition.id,action_classification="formal_main")
        self.engine.log.add("COMPOSITE_ACTION_COMPLETED",root_action_id=root_action_id,definition_id=definition.id,stage_count=len(ordered))
        self.engine.triggers.special_actions.drain()
        result=CompositeActionOutcome(root_action_id,tuple(ordered),MappingProxyType(root_summary))
        if temporary_context:self.engine.trigger_context=None
        return result
    def _advance(self,out,edges,pending):
        for e in edges:
            ok=e.condition==StageEdgeCondition.ALWAYS or (e.condition==StageEdgeCondition.ON_STAGE_EXECUTED and out.executed) or (e.condition==StageEdgeCondition.ON_STAGE_SKIPPED and out.skipped) or (e.condition==StageEdgeCondition.ON_SUCCESSFUL_HIT and out.successful_hit_count>0) or (e.condition in (StageEdgeCondition.ON_EFFECTIVE_ATTACK_DAMAGE,StageEdgeCondition.ON_ACTION_SUCCESSFULLY_DEALS_DAMAGE) and out.effective_attack_damage_instance_count>0)
            if ok:pending.append(e.to_stage)
    def _execute_stage(self,s,actor,target,root,target_chains=None):
        target_chains = {} if target_chains is None else target_chains
        if s.execution_identity==ExecutionIdentity.NON_ACTION_EFFECT:
            facts={}
            if s.effect_type=="RESOURCE_GAIN":
                rid=s.parameters["resource_id"];self.engine.resources.gain(actor,rid,int(s.parameters.get("amount",1)),stage_id=s.stage_id,root_action_id=root);facts["resource_after_stage"]=self.engine.resources.get(actor,rid)
            self.engine.log.add("COMPOSITE_NON_ACTION_STAGE_EXECUTED",root_action_id=root,stage_id=s.stage_id,effect_type=s.effect_type)
            return ActionStageOutcome(s.stage_id,True,False,None,produced_facts=MappingProxyType(facts))
        same=s.execution_identity==ExecutionIdentity.SAME_ROOT_MAIN_ACTION
        if same:action_id=root;classification="formal_main"
        else:
            ctx=self.engine.trigger_context
            if ctx.ordinary_budget_used>=TriggerEngine.ORDINARY_CAP:
                return ActionStageOutcome(s.stage_id,False,True,"ordinary_cap")
            ctx.ordinary_budget_used+=1;action_id=f"{root}:special:{ctx.next_action_number}";ctx.next_action_number+=1;classification="ordinary_special"
            special_metadata = dict(
                source_trigger_id=None, source_martial_id=None, content_action_id=s.stage_id,
                action_type=s.effect_type, action_classification="ordinary_special",
                counts_as_turn=False, counts_ordinary_budget=True, target_selector=s.anchor_source,
                targeting_pattern=s.targeting, requested_target_count=None,
                attack_coefficient=s.attack_coefficient or 1.0)
            started = self.engine.semantic_events.append(
                SemanticEventType.SPECIAL_ACTION_STARTED, EventPhase.SPECIAL_ACTION,
                formal_turn_id=ctx.formal_turn_id, action_id=action_id, actor_id=actor.definition.id,
                payload=special_metadata)
            self.engine._create_offensive_snapshot(actor,action_id)
        targets=self.engine.targeting.expand(target.definition.faction,target,TargetingSpec(pattern=s.targeting),action_id=action_id,actor_id=actor.definition.id)
        ids=[]
        for x in targets:
            if not x.ordinary_combat_eligible:continue
            chain_key = (action_id, x.definition.id, s.targeting)
            if chain_key not in target_chains:
                target_chains[chain_key] = self.engine.select_target_chain(
                    actor, x, action_id=action_id, targeting_pattern=s.targeting)
            ids.append(self.engine._resolve_attack(actor,x,action_id=action_id,action_classification=classification,coefficient=s.attack_coefficient or 1.0,root_action_id=root,stage_id=s.stage_id,source_definition_id=s.stage_id,targeting_pattern=s.targeting,target_chain=target_chains[chain_key]))
        summary=self.engine._action_outcomes.get(action_id,{})
        out=ActionStageOutcome(s.stage_id,True,False,None,tuple(ids),summary.get("non_dodged_count",0),summary.get("effective_attack_damage_instance_count",0),len(summary.get("qualifying_target_ids",())),summary.get("final_damage_before_shield_total",0),summary.get("hp_damage_total",0))
        if s.targeting=="all_enemies":self.engine.log.add("ALL_ENEMIES_TARGET_SET_FINALIZED",root_action_id=root,stage_id=s.stage_id,living_enemy_ids=tuple(x.definition.id for x in targets),deterministic_order="battlefield_order",attack_instance_ids=tuple(ids))
        if not same:
            finalized = self.engine._finalize_action_outcome(action_id,actor.definition.id)
            outcome = self.engine._append_action_outcome_fact(
                finalized, formal_turn_id=self.engine.trigger_context.formal_turn_id,
                action_id=action_id, actor_id=actor.definition.id, classification=classification,
                source_action_definition_id=s.stage_id, action_target_id=target.definition.id,
                action_type=s.effect_type, attack_coefficient=s.attack_coefficient or 1.0,
                parent_event_id=started.event_id)
            self.engine.semantic_events.append(
                SemanticEventType.SPECIAL_ACTION_COMPLETED, EventPhase.SPECIAL_ACTION,
                formal_turn_id=self.engine.trigger_context.formal_turn_id, action_id=action_id,
                actor_id=actor.definition.id, causation_event_id=outcome.event_id,
                parent_event_id=started.event_id, payload=special_metadata)
        return out

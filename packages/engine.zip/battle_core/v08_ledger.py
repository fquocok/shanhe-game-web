"""Machine-readable v0.8 semantic/capability ledger (consolidation only)."""
from enum import Enum

CANONICAL_VERSION="0.8"
PRIOR_VERSION="0.7"

class ResourceCostTiming(str,Enum):
    ON_COMMITTED_ACTION="ON_COMMITTED_ACTION"
    ON_TRIGGER_ATTEMPT_AFTER_CONDITION="ON_TRIGGER_ATTEMPT_AFTER_CONDITION"
    ON_TRIGGER_SUCCESS="ON_TRIGGER_SUCCESS"
    AFTER_SUCCESSFUL_EVENT="AFTER_SUCCESSFUL_EVENT"

OPEN_CORE_POLICIES=frozenset({
 "enemy_action_effectively_attacks_owner_basis",
 "general_damage_reduction_percent_stage",
})
RESOLVED_POLICIES={
 "effective_attack_damage_basis":"RESOLVED_BY_WO_023",
 "roaming_target_shortage_semantics":"RESOLVED_BY_WO_017A",
 "leiting_defense_break_application_gate":"RESOLVED_BY_WO_018A",
 "fengyuleidian_same_attack_new_break_eligibility":"RESOLVED_BY_WO_018A",
 "successful_hit_semantics_for_yiqi_generation":"RESOLVED_BY_WO_019A",
 "mid_action_resource_stat_visibility":"RESOLVED_BY_WO_019A",
 "yiqi_stack_lookup_trigger_decay_semantics":"RESOLVED_BY_WO_019A",
 "cross_anchor_target_legality":"RESOLVED_BY_WO_020A",
 "ally_is_attacked_semantics":"RESOLVED_BY_WO_021A",
}
EFFECTIVE_ATTACK_DAMAGE_SEMANTIC={"requires_attack_instance":True,"requires_successful_hit":True,"amount_basis":"final_damage_before_shield","comparison":">0","scope":"ATTACK"}
HIGH_RUNTIME_VERIFIED={"trigger_attempt_resource_cost":"VERIFIED_BY_WO_024","action_unique_successful_enemy_hit_count":"VERIFIED_BY_WO_024","temporary_parry_defense_buff":"VERIFIED_BY_WO_024"}
HIGH_RUNTIME_VERIFIED.update({k:"VERIFIED_BY_WO_025" for k in ("high_closed_stance_cycle","exclusive_stance_group","atomic_stance_transition","stance_gated_special_trigger","attack_action_scope_followup","active_not_dodged_stance_transition","parry_stance_counter","stance_triggered_cooldown_reduction","next_owner_formal_turn_end_fallback")})
EVENT_TRANSACTION_SEMANTICS={"sibling_condition_visibility":"PRE_EVENT_RUNTIME_SNAPSHOT","settled_trigger_cost_refund":"NO_REFUND_AFTER_COST_SETTLEMENT","resolution":"RESOLVED_BY_WO_024A"}
RESOLVED_POLICIES.update({"same_event_resource_gain_visibility_for_sibling_trigger_conditions":"RESOLVED_BY_WO_024A","trigger_attempt_cost_refund_on_post_success_execution_cancellation":"RESOLVED_BY_WO_024A"})
RESOLVED_POLICIES.update({"lieshang_attack_trigger_scope":"RESOLVED_BY_WO_026A","lieshang_attack_eligibility_basis":"RESOLVED_BY_WO_026A"})
RESOLVED_POLICIES["lianying_special_successfully_deals_damage_basis"]="RESOLVED_BY_WO_027A"
ACTION_SUCCESSFULLY_DEALS_DAMAGE={"scope":"ACTION","basis":"ActionOutcomeSummary.dealt_effective_attack_damage","equivalent":"effective_attack_damage_instance_count > 0","attack_instance_basis":"WO-023 EFFECTIVE_ATTACK_DAMAGE","resolution":"RESOLVED_BY_WO_027A"}
LIESHANG_TRIGGER_SEMANTICS={"scope":"ATTACK_SCOPE","eligibility_basis":"ATTACK_INSTANCE_SUCCESSFULLY_HIT","successful_hit_basis":"not_dodged","resolution":"RESOLVED_BY_WO_026A"}
CONTENT_TBDS=frozenset({"defense_break_duration","bleed_duration","bleed_damage_per_tick"})
XUEZHAN_SOURCE_CONTENT_TBDS=frozenset({"kuaidaoshu_trigger_chance","kuaidaoshu_roaming_target_count","fanren_counter_damage_profile","wound_reapplication_policy","wound_tick_timing","xingyun_liushui_followup_content"})
HIGH_RUNTIME_VERIFIED.update({k:"VERIFIED_SHELL_BY_WO_026" for k in ("high_status_driven_closed_loop","basic_roaming_transformation_shell","parry_counter_high_blade","attack_to_dot_status_application","current_hp_percent_special_dot","pre_active_target_status_gate","status_gated_combo_trigger","content_tbd_followup_shell")})
HIGH_RUNTIME_VERIFIED["attack_to_dot_status_application"]="CORE_SEMANTICS_VERIFIED_BY_WO_026A"
HIGH_RUNTIME_VERIFIED.update({k:"VERIFIED_BY_WO_027" for k in ("high_spear_closed_kill_momentum_loop","effective_attack_damage_to_resource","multi_target_effective_damage_resource_gain","resource_stack_attack_percent","attempt_paid_rear_followup","attempt_paid_ally_attacked_retaliation","ally_attacked_resource_counter","resource_spend_before_special_snapshot")})
HIGH_RUNTIME_VERIFIED.update({k:"VERIFIED_BY_WO_027A" for k in ("action_successfully_deals_damage_predicate","effective_attack_damage_action_aggregation","action_outcome_damage_gate","special_action_damage_to_cooldown_feedback")})
ADVANCED_ANCHORS=("sword_advanced_leihuo","blade_advanced_fenglei","fist_advanced_yiqi_hexing","staff_advanced_panlong_shoushi","spear_advanced_zhuifeng_pozhen")
TARGETING_PATTERNS=frozenset({"single","vertical_column","row_large","immediately_behind","row_neighbors","relative_footprint","roaming","cross"})
CAPABILITY_CATEGORIES={
 "action_lifecycle":("formal_turn","main_action","attack_instance","ordinary_special","shield_break_reaction"),
 "trigger":("TURN_SCOPE","ACTION_SCOPE","ATTACK_SCOPE","ordinary_cap_3","success_decay_quarter"),
 "probability":("clamp","FULL_LOOKUP_NO_SUCCESS_DECAY","seeded_rng"),
 "resource":("gain","clamp","consume_all","atomic_consume","resource_stack_stat_modifier"),
 "status":("refresh","stack","independent","replace","strongest","unique"),
 "shield":("shared_fifo","same_source_replace","explicit_accumulate","damage_break"),
 "targeting":tuple(sorted(TARGETING_PATTERNS)),
 "damage_modifier":("action_snapshot","trigger_source_scoped_defense_ignore"),
 "defense_modifier":("additive_percent","parry_override","dodge_pp","parry_pp"),
 "healing_support":("heal_permission","no_revive","ally_targeted_trigger"),
 "cooldown":("centralized","same_action_reduction"),
 "reaction":("ordinary_special_cap","shield_break_reaction_cap"),
 "loadout":("external_martial","inner_skill","lightness"),
}

def resolved_policy(name):
    if name in RESOLVED_POLICIES:return RESOLVED_POLICIES[name]
    if name in OPEN_CORE_POLICIES:raise RuntimeError(f"BLOCKED_BY_SPEC: {name}")
    raise ValueError(f"UNKNOWN_PRODUCTION_POLICY: {name}")

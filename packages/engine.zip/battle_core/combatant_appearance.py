"""WO-060 modular, generic presentation overlays for resolved humanoid geometry."""
from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType
from typing import Any

APPEARANCE_CONTRACT = "GAME_FACING_COMBATANT_APPEARANCE_LAYER_V0_1"
APPEARANCE_LAYER_ORDER = (
    "BACK_HAIR", "BODY_BASE", "LOWER_GARMENT", "UPPER_GARMENT", "SLEEVES",
    "WAIST", "FOOTWEAR", "HANDS_WEAPON", "FRONT_HAIR", "HEAD_ACCESSORY", "FEEDBACK",
)


@dataclass(frozen=True)
class AppearanceProfile:
    profile_id: str
    hair_profile: str
    upper_profile: str
    lower_profile: str
    sleeve_profile: str
    waist_profile: str
    footwear_profile: str
    head_accessory_profile: str
    palette_id: str
    presentation_only: bool = True
    canonical: bool = False


PALETTES = MappingProxyType({
    "NEUTRAL_DARK": MappingProxyType({"hair": "#292725", "upper": "#46515a", "lower": "#30373d", "trim": "#b39a67", "foot": "#302921"}),
    "EARTH": MappingProxyType({"hair": "#34281f", "upper": "#7a6142", "lower": "#544332", "trim": "#c1a36e", "foot": "#3d3026"}),
    "MUTED_BLUE": MappingProxyType({"hair": "#24272b", "upper": "#506b79", "lower": "#394d59", "trim": "#bcc3bb", "foot": "#29343a"}),
})

GENERIC_TRAVELER = AppearanceProfile("GENERIC_TRAVELER", "TIED", "ROBE", "SPLIT_ROBE", "WIDE", "SASH", "BOOT", "HEADBAND", "EARTH")
GENERIC_DISCIPLE = AppearanceProfile("GENERIC_DISCIPLE", "LONG_SIMPLE", "FITTED", "TROUSER", "NARROW", "BELT", "SHOE", "NONE", "MUTED_BLUE")
GENERIC_GUARD = AppearanceProfile("GENERIC_GUARD", "SHORT", "PADDED", "TROUSER", "NARROW", "BELT", "BOOT", "SIMPLE_HAT", "NEUTRAL_DARK")
APPEARANCE_PROFILES = MappingProxyType({x.profile_id: x for x in (GENERIC_TRAVELER, GENERIC_DISCIPLE, GENERIC_GUARD)})


def resolve_appearance_profile(profile: AppearanceProfile | str | None) -> AppearanceProfile:
    if isinstance(profile, AppearanceProfile): return profile
    return APPEARANCE_PROFILES.get(str(profile or ""), GENERIC_TRAVELER)


def _polygon(layer: str, points, fill: str, outline="#292622", width=1):
    return {"kind": "polygon", "layer": layer, "points": tuple(points), "fill": fill, "outline": outline, "width": width}


def _line(layer: str, points, fill: str, width: int):
    return {"kind": "line", "layer": layer, "points": tuple(points), "fill": fill, "width": width}


def resolve_appearance_geometry(body_geometry: dict[str, Any], profile: AppearanceProfile | str | None) -> dict[str, Any]:
    """Derive every overlay from resolved body points; no anatomy or position state is owned here."""
    selected = resolve_appearance_profile(profile); p = body_geometry["points"]; colors = PALETTES[selected.palette_id]
    hx, hy = p["head"]; sx, sy = p["shoulder"]; sbx, sby = p.get("shoulder_back", p["shoulder"]); hipx, hipy = p["hip"]; hbx, hby = p.get("hip_back", p["hip"])
    ef, eb = p["elbow_front"], p["elbow_back"]; hf, hb = p["hand_front"], p["hand_back"]
    ff, fb = p["foot_front"], p["foot_back"]
    direction = 1 if body_geometry["facing"] == "right" else -1; head_r = 12 * body_geometry.get("head_scale", 1.0)
    primitives = []
    if selected.hair_profile == "SHORT":
        primitives.append(_polygon("BACK_HAIR", ((hx-head_r,hy),(hx-head_r*.7,hy-head_r),(hx+head_r*.8,hy-head_r),(hx+head_r,hy+2)), colors["hair"]))
    elif selected.hair_profile == "TIED":
        primitives.extend((_polygon("BACK_HAIR", ((hx-head_r,hy-3),(hx,hy-head_r*1.15),(hx+head_r,hy),(hx+5*direction,hy+head_r*1.4)), colors["hair"]),
                           _line("BACK_HAIR", ((hx-7*direction,hy+4),(hx-19*direction,hy+25)), colors["hair"], 7)))
    else:
        primitives.append(_polygon("BACK_HAIR", ((hx-head_r,hy-4),(hx,hy-head_r*1.2),(hx+head_r,hy-2),(hx+9*direction,hy+31),(hx-10*direction,hy+29)), colors["hair"]))
    lower_width = 13 if selected.lower_profile == "TROUSER" else 22
    if selected.lower_profile == "TROUSER":
        primitives.extend((_line("LOWER_GARMENT", ((hipx,hipy),ff), colors["lower"], lower_width),
                           _line("LOWER_GARMENT", ((hbx,hby),fb), colors["lower"], lower_width)))
    else:
        split = 5 if selected.lower_profile == "SPLIT_ROBE" else 0
        primitives.append(_polygon("LOWER_GARMENT", ((hbx-8, hby-2),(hipx+9,hipy-2),(ff[0]+11,ff[1]-5),(fb[0]-11,fb[1]-5)), colors["lower"], width=2))
        if split: primitives.append(_line("LOWER_GARMENT", ((hipx,hipy+8),(hipx+direction*split, max(ff[1],fb[1])-6)), colors["trim"], 2))
    upper_pad = 8 if selected.upper_profile == "FITTED" else (13 if selected.upper_profile == "ROBE" else 16)
    coat_hem = hipy - 14 if selected.upper_profile == "SHORT_COAT" else hipy + 3
    primitives.append(_polygon("UPPER_GARMENT", ((sbx-upper_pad,sby-4),(sx+upper_pad,sy-4),(hipx+10,coat_hem),(hbx-10,coat_hem)), colors["upper"], width=2))
    if selected.upper_profile == "PADDED":
        primitives.append(_line("UPPER_GARMENT", ((sbx-10,sby-2),(sx+10,sy-2)), colors["trim"], 5))
    sleeve_width = 12 if selected.sleeve_profile in ("NARROW", "WRAPPED_FOREARM") else 18
    primitives.extend((_line("SLEEVES", ((sx,sy),ef,hf), colors["upper"], sleeve_width),
                       _line("SLEEVES", ((sbx,sby),eb,hb), colors["upper"], sleeve_width)))
    if selected.sleeve_profile == "WRAPPED_FOREARM":
        primitives.extend((_line("SLEEVES", ((ef[0]*.65+hf[0]*.35,ef[1]*.65+hf[1]*.35),(ef[0]*.5+hf[0]*.5,ef[1]*.5+hf[1]*.5)), colors["trim"], 3),
                           _line("SLEEVES", ((eb[0]*.65+hb[0]*.35,eb[1]*.65+hb[1]*.35),(eb[0]*.5+hb[0]*.5,eb[1]*.5+hb[1]*.5)), colors["trim"], 3)))
    waist_width = 5 if selected.waist_profile == "BELT" else 8
    primitives.append(_line("WAIST", ((hbx-8,hby),(hipx+9,hipy)), colors["trim"], waist_width))
    if selected.waist_profile == "SASH": primitives.append(_line("WAIST", ((hipx,hipy),(hipx-7*direction,hipy+20)), colors["trim"], 4))
    if selected.waist_profile == "UTILITY_SASH":
        # The diagonal sash is the reusable silhouette; the former rectangular
        # pouch read as an unintended block in the selected travel-escort preview.
        primitives.append(_line("WAIST", ((hipx,hipy),(hipx-9*direction,hipy+21)), colors["trim"], 4))
    footwear_width = 14 if selected.footwear_profile == "TRAVEL_BOOT" else (11 if selected.footwear_profile == "BOOT" else 8)
    primitives.extend((_line("FOOTWEAR", ((ff[0]-5*direction,ff[1]),(ff[0]+8*direction,ff[1])), colors["foot"], footwear_width),
                       _line("FOOTWEAR", ((fb[0]-5*direction,fb[1]),(fb[0]+8*direction,fb[1])), colors["foot"], footwear_width)))
    if selected.footwear_profile == "TRAVEL_BOOT":
        primitives.extend((_line("FOOTWEAR", ((ff[0],ff[1]),(ff[0],ff[1]-15)), colors["foot"], 8),
                           _line("FOOTWEAR", ((fb[0],fb[1]),(fb[0],fb[1]-15)), colors["foot"], 8)))
    primitives.append(_polygon("FRONT_HAIR", ((hx-head_r*.8,hy-head_r*.5),(hx,hy-head_r*1.05),(hx+head_r*.75,hy-head_r*.45),(hx+5*direction,hy-1)), colors["hair"]))
    if selected.head_accessory_profile == "HEADBAND":
        primitives.append(_line("HEAD_ACCESSORY", ((hx-head_r,hy-4),(hx+head_r,hy-4)), colors["trim"], 4))
    elif selected.head_accessory_profile == "SIMPLE_HAT":
        primitives.extend((_line("HEAD_ACCESSORY", ((hx-head_r*1.3,hy-head_r),(hx+head_r*1.3,hy-head_r)), colors["trim"], 4),
                           _polygon("HEAD_ACCESSORY", ((hx-head_r*.8,hy-head_r),(hx,hy-head_r*1.65),(hx+head_r*.8,hy-head_r)), colors["lower"])))
    return {"contract": APPEARANCE_CONTRACT, "profile": selected, "profile_id": selected.profile_id,
            "layer_order": APPEARANCE_LAYER_ORDER, "primitives": tuple(primitives),
            "body_spec_authority": body_geometry["body_spec_id"], "body_profile_id": body_geometry["body_profile_id"],
            "primary_hand_socket": p["primary_hand_socket"], "off_hand_socket": p["off_hand_socket"],
            "ground_anchor": p["ground_anchor"], "independent_position_state": False,
            "presentation_only": True, "canonical": False, "drift": 0}


def draw_appearance_layers(canvas: Any, combatant_tag: str, appearance: dict[str, Any],
                           origin_x: float, origin_y: float, layers: tuple[str, ...]) -> None:
    """Shared Tk production renderer used by formal battle and developer showcase."""
    allowed = set(layers); tags_base = (combatant_tag, "appearance-overlay", "appearance-" + appearance["profile_id"])
    for primitive in appearance["primitives"]:
        if primitive["layer"] not in allowed: continue
        tags = tags_base + ("appearance-layer-" + primitive["layer"],)
        points = tuple((origin_x + point[0], origin_y + point[1]) for point in primitive["points"])
        if primitive["kind"] == "polygon":
            coords = [value for point in points for value in point]
            canvas.create_polygon(*coords, fill=primitive["fill"], outline=primitive["outline"], width=primitive["width"], tags=tags)
        elif primitive["kind"] == "line":
            coords = [value for point in points for value in point]
            canvas.create_line(*coords, fill=primitive["fill"], width=primitive["width"], capstyle="round", joinstyle="round", tags=tags)

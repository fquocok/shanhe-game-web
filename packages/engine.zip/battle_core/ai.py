from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

from .targeting import TargetingSpec


@dataclass(frozen=True)
class ActionDefinition:
    id: str
    category: str = "offensive"
    action_priority: int = 100
    qi_cost: int = 0
    qi_cost_percent_max: float = 0.0
    cooldown_id: str | None = None
    cooldown_turns: int = 0
    targeting: TargetingSpec = TargetingSpec()
    target_policy: str = "random"
    coefficient: float = 1.0
    hard_condition: Callable | None = None
    use_condition: Callable | None = None
    source_martial_id: str | None = None
    source_inner_skill_id: str | None = None
    source_lightness_skill_id: str | None = None
    is_attack: bool = True
    attack_tags: frozenset[str] = field(default_factory=lambda: frozenset({"basic_attack"}))
    ai_enabled: bool = True

    def qi_cost_for(self, actor) -> int:
        if self.qi_cost_percent_max:
            from .stats import round_half_up
            return round_half_up(actor.max_qi * self.qi_cost_percent_max)
        return self.qi_cost


class SupportTargetPolicy:
    def select(self, actor, allies, policy):
        living = [s for s in allies if s.ordinary_combat_eligible]
        if policy == "lowest_hp_percent":
            worthwhile = [s for s in living if s.current_hp < s.max_hp]
            return min(worthwhile, key=lambda s: (s.current_hp / s.max_hp, s.definition.id)) if worthwhile else None
        if policy == "highest_missing_hp":
            worthwhile = [s for s in living if s.current_hp < s.max_hp]
            return max(worthwhile, key=lambda s: (s.max_hp - s.current_hp, s.definition.id)) if worthwhile else None
        if policy == "most_dispellable_negative_statuses":
            scored = [(sum(1 for status in s.statuses if status.definition.dispellable and "negative" in status.definition.tags), s) for s in living]
            score, target = max(scored, key=lambda pair: (pair[0], pair[1].definition.id), default=(0, None))
            return target if score > 0 else None
        if policy == "highest_attack":
            return max(living, key=lambda s: (s.definition.strength * 3 + s.definition.weapon_attack, s.definition.id), default=None)
        return None


class AIActionSelector:
    def __init__(self, engine):
        self.engine = engine
        self.support = SupportTargetPolicy()

    def _candidate(self, actor, action, explicit=False, explicit_target_id=None):
        if action.cooldown_id and self.engine.cooldowns.get(actor, action.cooldown_id) > 0:
            return None, "cooldown"
        if actor.current_qi < action.qi_cost_for(actor):
            return None, "insufficient_qi"
        if self.engine.statuses.has_tag(actor, "stun"):
            return None, "control"
        if action.hard_condition and not action.hard_condition(actor, self.engine):
            return None, "hard_condition"
        if not action.ai_enabled and not explicit:
            return None, "no_content_action_priority"
        if explicit_target_id is not None:
            target = self.engine.state_by_id(explicit_target_id)
            if (target is None or not target.ordinary_combat_eligible or
                    (action.category == "single_ally" and
                     (target.definition.faction != actor.definition.faction or target is actor))):
                return None, "illegal_explicit_target"
        elif action.category == "self":
            target = actor
        elif action.category == "single_ally":
            return None, "explicit_target_required"
        elif action.category == "support":
            allies = self.engine._ordinary_combatants(actor.definition.faction)
            target = self.support.select(actor, allies, action.target_policy)
        elif action.targeting.pattern == "roaming_distinct":
            faction = self.engine.targeting.enemy_faction(actor)
            legal = self.engine.battlefield.occupied_states(faction, ordinary_eligible_only=True)
            target = legal[0] if legal else None
        else:
            target = self.engine.targeting.select_primary(actor, action.targeting, action.target_policy)
        if target is None:
            return None, "no_legal_or_worthwhile_target"
        if action.use_condition and not action.use_condition(actor, target, self.engine):
            return None, "use_condition"
        return target, None

    def select(self, actor, actions):
        if not actor.ordinary_combat_eligible:
            return None, None
        scripted_entry = self.engine._pop_scripted_action(actor.definition.id)
        scripted, scripted_target = scripted_entry if scripted_entry is not None else (None, None)
        candidates = []
        for action in sorted(actions, key=lambda a: a.id):
            explicit = scripted == action.id
            target, reason = self._candidate(actor, action, explicit=explicit,
                                             explicit_target_id=scripted_target if explicit else None)
            self.engine.log.add("AI_ACTION_CANDIDATE", actor=actor.definition.id,
                                action=action.id, usable=reason is None)
            if reason:
                self.engine.log.add("AI_ACTION_REJECTED", actor=actor.definition.id,
                                    action=action.id, reason=reason)
            else:
                candidates.append((action, target))
        if not candidates:
            if scripted is not None:
                raise ValueError(f"Scripted action 不可用：{actor.definition.id}/{scripted}")
            basic = ActionDefinition("basic_attack")
            target = self.engine.targeting.select_primary(actor, basic.targeting)
            if target is None:
                return None, None
            selected = (basic, target)
        else:
            if scripted is not None:
                selected = next(((action, target) for action, target in candidates if action.id == scripted), None)
                if selected is None:
                    raise ValueError(f"Scripted action 不可用：{actor.definition.id}/{scripted}")
                self.engine.log.add("SCRIPTED_ACTION_SELECTED", actor=actor.definition.id, action=scripted)
            else:
                best = max(action.action_priority for action, _ in candidates)
                group = [(action, target) for action, target in candidates if action.action_priority == best]
                selected = self.engine.rng.choice(group)
        action, target = selected
        self.engine.log.add("AI_ACTION_SELECTED", actor=actor.definition.id,
                            action=action.id, priority=action.action_priority)
        self.engine.log.add("AI_TARGET_SELECTED", actor=actor.definition.id,
                            action=action.id, target=target.definition.id)
        return selected

"""Immutable scheduling provenance, deliberately separate from execution."""
from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType
from ..events.envelope import freeze


class PreResolutionCategory(str, Enum):
    ENVIRONMENT = "ENVIRONMENT"
    PERIODIC = "PERIODIC"
    PRE_RESOLUTION_REACTION = "PRE_RESOLUTION_REACTION"


@dataclass(frozen=True, slots=True)
class PreResolutionWorkItem:
    work_item_id: str
    category: PreResolutionCategory
    source_instance_id: str
    creation_sequence: int
    explicit_order_rank: int | None = None
    tie_break_key: str | None = None
    reaction_owner_id: str | None = None
    metadata: object = field(default_factory=dict)

    def __post_init__(self):
        for name in ("work_item_id", "source_instance_id"):
            if type(getattr(self, name)) is not str or not getattr(self, name):
                raise ValueError(name + " requires a stable nonempty identity")
        if not isinstance(self.category, PreResolutionCategory):
            raise TypeError("Typed scheduler category required")
        if type(self.creation_sequence) is not int or self.creation_sequence < 0:
            raise ValueError("Nonnegative creation sequence required")
        if self.explicit_order_rank is not None and type(self.explicit_order_rank) is not int:
            raise TypeError("Explicit normalized rank must be int or None")
        for name in ("tie_break_key", "reaction_owner_id"):
            value = getattr(self, name)
            if value is not None and (type(value) is not str or not value):
                raise ValueError(name + " must be a nonempty string")
        if self.category == PreResolutionCategory.PRE_RESOLUTION_REACTION and not self.reaction_owner_id:
            raise ValueError("Reaction owner required")
        if type(self.metadata) not in (dict, MappingProxyType):
            raise TypeError("Scheduling metadata must be a mapping")
        object.__setattr__(self, "metadata", freeze(self.metadata))


@dataclass(frozen=True, slots=True)
class PreResolutionPlan:
    environment_items: tuple[PreResolutionWorkItem, ...] = ()
    periodic_items: tuple[PreResolutionWorkItem, ...] = ()
    reaction_items: tuple[PreResolutionWorkItem, ...] = ()

    def __post_init__(self):
        for name in ("environment_items", "periodic_items", "reaction_items"):
            object.__setattr__(self, name, tuple(getattr(self, name)))


@dataclass(frozen=True, slots=True)
class PreResolutionExecution:
    plan: PreResolutionPlan
    executed_ids: tuple[str, ...]
    skipped_reaction_ids: tuple[str, ...]

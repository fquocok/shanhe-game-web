"""Formal Turn boundary component called only by the existing BattleEngine loop."""
from ..events import EventPhase as P, SemanticEventType as T
from .pre_resolution import PreResolutionScheduler


class FormalTurnScheduler:
    def __init__(self, events):
        self.events = events
        self.pre_resolution = PreResolutionScheduler()

    def begin(self, formal_turn_id, actor_id):
        return self.events.append(T.FORMAL_TURN_STARTED, P.FORMAL_TURN_START,
                                  formal_turn_id=formal_turn_id, actor_id=actor_id)

    def run_pre_resolution(self, turn_event, **kwargs):
        metadata = dict(formal_turn_id=turn_event.formal_turn_id,
                        actor_id=turn_event.actor_id, parent_event_id=turn_event.event_id)
        started = self.events.append(T.PRE_RESOLUTION_STARTED, P.PRE_RESOLUTION_ENVIRONMENT,
                                     **metadata)
        result = self.pre_resolution.execute(**kwargs)
        self.events.append(T.PRE_RESOLUTION_COMPLETED, P.PRE_RESOLUTION_REACTION,
                           causation_event_id=started.event_id, **metadata,
                           payload={"executed_ids": result.executed_ids,
                                    "skipped_reaction_ids": result.skipped_reaction_ids})
        return result

    def action_started(self, turn_event, action_id, *, metadata=None):
        return self.events.append(T.FORMAL_ACTION_STARTED, P.FORMAL_ACTION,
                                  formal_turn_id=turn_event.formal_turn_id,
                                  actor_id=turn_event.actor_id, action_id=action_id,
                                  parent_event_id=turn_event.event_id, payload=metadata)

    def action_completed(self, started):
        self.events.append(T.FORMAL_ACTION_COMPLETED, P.FORMAL_ACTION,
                           formal_turn_id=started.formal_turn_id, actor_id=started.actor_id,
                           action_id=started.action_id, parent_event_id=started.parent_event_id,
                           causation_event_id=started.event_id, payload=dict(started.payload))

    def complete(self, turn_event):
        self.events.append(T.FORMAL_TURN_COMPLETED, P.FORMAL_TURN_END,
                           formal_turn_id=turn_event.formal_turn_id,
                           actor_id=turn_event.actor_id, parent_event_id=turn_event.event_id)

"""WO096 source-supply observation boundary, not a Python security sandbox."""
from contextvars import ContextVar
from enum import Enum
from types import MappingProxyType

ENVIRONMENT_SOURCE_PROVIDER_MUTATED_BATTLE_RUNTIME = "ENVIRONMENT_SOURCE_PROVIDER_MUTATED_BATTLE_RUNTIME"
_SUPPLY = ContextVar("wo096_environment_source_supply", default=None)


class EnvironmentProviderMutationError(ValueError):
    pass


def reject_settlement_during_environment_supply(runtime):
    active = _SUPPLY.get()
    if active is not None and active["runtime"] is runtime:
        active["attempted_settlement"] = True
        raise EnvironmentProviderMutationError(ENVIRONMENT_SOURCE_PROVIDER_MUTATED_BATTLE_RUNTIME)


def runtime_supply_fingerprint(runtime):
    """Detached in-process identity/value graph; never exported or used in ordering.

    Includes all ordinary Runtime instance dictionaries, slots and built-in
    containers: HP, Shield order, lifecycle, Status, resources, cooldowns, gauge,
    RNG, semantic store, CombatLog identities/data and managers/queues.
    Callables are opaque identities so external provider-owned state is excluded.
    No properties, user equality, deepcopy, gameplay methods or RNG are invoked.
    """
    seen = {}
    def visit(value):
        if value is None or type(value) in (str, bool, int, bytes):
            return (type(value).__name__, value)
        if type(value) is float:
            return ("float", value.hex())
        if isinstance(value, Enum):
            return (type(value).__qualname__, visit(value.value))
        identity = id(value)
        if identity in seen:
            return ("ref", seen[identity])
        seen[identity] = len(seen)
        kind = type(value).__module__ + "." + type(value).__qualname__
        if callable(value):
            return ("callable", kind, identity)
        if type(value) in (dict, MappingProxyType):
            return (kind, identity, tuple((visit(k), visit(v)) for k, v in value.items()))
        if type(value) in (tuple, list):
            return (kind, identity, tuple(visit(v) for v in value))
        if type(value) in (set, frozenset):
            return (kind, identity, tuple(visit(v) for v in sorted(value, key=repr)))
        try:
            attributes = object.__getattribute__(value, "__dict__")
        except AttributeError:
            attributes = None
        values = []
        if attributes is not None:
            values.extend((key, visit(attributes[key])) for key in sorted(attributes))
        for cls in type(value).__mro__:
            slots = cls.__dict__.get("__slots__", ())
            slots = (slots,) if type(slots) is str else slots
            for name in slots:
                if name in ("__dict__", "__weakref__"):
                    continue
                try:
                    item = object.__getattribute__(value, name)
                except AttributeError:
                    continue
                values.append((name, visit(item)))
        return (kind, identity, tuple(values))
    return visit(runtime)


def supply_read_only(runtime, provider, actor, turn_event):
    """Call/materialize once and compare even on exception; no source work runs here.

    Direct mutation detection is not rollback. A violating supplier is rejected,
    and no composed source plan executes. The canonical settlement seam is blocked
    while supplying sources, even if the provider catches its rejection.
    """
    before = runtime_supply_fingerprint(runtime)
    active = {"runtime": runtime, "attempted_settlement": False}
    token = _SUPPLY.set(active)
    try:
        return tuple(provider(runtime, actor, turn_event))
    finally:
        _SUPPLY.reset(token)
        try:
            changed = runtime_supply_fingerprint(runtime) != before
        except Exception as exc:
            raise EnvironmentProviderMutationError(
                ENVIRONMENT_SOURCE_PROVIDER_MUTATED_BATTLE_RUNTIME) from exc
        if changed or active["attempted_settlement"]:
            raise EnvironmentProviderMutationError(ENVIRONMENT_SOURCE_PROVIDER_MUTATED_BATTLE_RUNTIME)

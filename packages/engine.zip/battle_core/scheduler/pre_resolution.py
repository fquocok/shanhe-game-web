"""Order opaque work; never inspect mechanics or decide combat results."""
from .model import (PreResolutionCategory as C, PreResolutionWorkItem,
                    PreResolutionPlan, PreResolutionExecution)


def source_order(item):
    # Explicitly ranked items precede unranked items; lower normalized rank first.
    # No rank is inferred from content Tier. Creation order remains the fallback.
    return (item.explicit_order_rank is None,
            item.explicit_order_rank if item.explicit_order_rank is not None else 0,
            item.creation_sequence, item.tie_break_key or item.source_instance_id,
            item.source_instance_id, item.work_item_id)


class PreResolutionScheduler:
    @staticmethod
    def _snapshot(items):
        snapshot = tuple(items)
        if any(not isinstance(item, PreResolutionWorkItem) for item in snapshot):
            raise TypeError("Typed work descriptors required")
        identities = [item.work_item_id for item in snapshot]
        if len(identities) != len(set(identities)):
            raise ValueError("Duplicate work item ID")
        return snapshot

    def source_plan(self, items):
        items = self._snapshot(items)
        return PreResolutionPlan(
            tuple(sorted((i for i in items if i.category == C.ENVIRONMENT), key=source_order)),
            tuple(sorted((i for i in items if i.category == C.PERIODIC), key=source_order)),
            tuple(i for i in items if i.category == C.PRE_RESOLUTION_REACTION))

    def reaction_plan(self, items, initial_speeds, rng):
        items = self._snapshot(items)
        owners = {}
        for item in items:
            if item.category != C.PRE_RESOLUTION_REACTION:
                raise ValueError("Reaction provider must supply reaction items only")
            if item.reaction_owner_id not in initial_speeds:
                raise ValueError("Missing battle-start initial Speed for reaction owner")
            owners.setdefault(item.reaction_owner_id, []).append(item)
        speed_groups = {}
        for owner in sorted(owners):
            speed_groups.setdefault(initial_speeds[owner], []).append(owner)
        ordered = []
        for speed in sorted(speed_groups, reverse=True):
            group = speed_groups[speed]
            # One owner permutation per actual same-speed tie in this planned batch.
            if len(group) > 1:
                group = rng.shuffle(group)
            for owner in group:
                ordered.extend(sorted(owners[owner], key=source_order))
        return tuple(ordered)

    def execute(self, items, *, initial_speeds, rng, executor=None,
                reaction_eligible=None, reaction_provider=None, after_sources=None):
        if after_sources is not None and not callable(after_sources):
            raise TypeError("after_sources must be callable")
        initial_speeds = dict(initial_speeds)
        source_plan = self.source_plan(items)
        executed, skipped = [], []
        planned_sources = source_plan.environment_items + source_plan.periodic_items
        if (planned_sources or source_plan.reaction_items) and executor is None:
            raise ValueError("Work requires an explicit opaque executor")
        for item in planned_sources:
            executor(item)
            executed.append(item.work_item_id)
        # Reactions created by source execution are collected only after both source
        # batches finish. No source addition can splice into the current snapshot.
        if after_sources is not None:
            after_sources()
        added = self._snapshot(reaction_provider() if reaction_provider else ())
        all_items = planned_sources + source_plan.reaction_items + added
        self._snapshot(all_items)
        reactions = self.reaction_plan(source_plan.reaction_items + added, initial_speeds, rng)
        if reactions and (executor is None or reaction_eligible is None):
            raise ValueError("Reaction work requires explicit executor and legality predicate")
        for item in reactions:
            if not reaction_eligible(item):
                skipped.append(item.work_item_id)
                continue
            executor(item)
            executed.append(item.work_item_id)
        return PreResolutionExecution(
            PreResolutionPlan(source_plan.environment_items, source_plan.periodic_items, reactions),
            tuple(executed), tuple(skipped))

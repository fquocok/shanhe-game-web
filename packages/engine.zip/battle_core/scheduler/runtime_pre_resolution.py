"""WO096 common source composition; one existing opaque scheduler, no formulas."""
from dataclasses import replace
from ..damage.non_attack.dot_periodic import DotPeriodicSourceSnapshot, dispatch_deferred_dot_shields
from ..damage.non_attack.environment import collect_environment_sources


def run_common_pre_resolution(runtime, actor, turn_event, periodic_sources):
    periodic_sources = tuple(periodic_sources)
    if any(type(s) is not DotPeriodicSourceSnapshot for s in periodic_sources):
        raise TypeError("Typed production DOT snapshots required")
    periodic_sources = tuple(replace(s) for s in periodic_sources)
    environment_sources = collect_environment_sources(runtime, actor, turn_event)
    environment, periodic = {}, {}
    for sources, group in ((environment_sources, environment), (periodic_sources, periodic)):
        for source in sources:
            item = source.work_item(turn_event.formal_turn_id)
            if item.work_item_id in group:
                raise ValueError("Duplicate internal source work item identity")
            group[item.work_item_id] = item, source
    external = tuple(() if runtime.pre_resolution_provider is None else
                     runtime.pre_resolution_provider(runtime, actor))
    external_executor = runtime.pre_resolution_executor
    reaction_provider = runtime.pre_resolution_reaction_provider
    if (external or reaction_provider is not None) and not callable(external_executor):
        raise ValueError("External work requires its explicit external executor")
    items = (external + tuple(i for i, s in environment.values()) +
             tuple(i for i, s in periodic.values()))
    runtime.formal_turn_scheduler.pre_resolution.source_plan(items)
    dot_shield_results = []

    def execute(item):
        env_match = environment.get(item.work_item_id)
        dot_match = periodic.get(item.work_item_id)
        if env_match is not None and item is env_match[0]:
            # Environment receipts deliberately NEVER enter the DOT reaction set.
            runtime._resolve_environment_damage_source(env_match[1], turn_event=turn_event)
        elif dot_match is not None and item is dot_match[0]:
            result = runtime._resolve_dot(dot_match[1], turn_event=turn_event)
            if result is not None and result.shield_break_event_ids:
                dot_shield_results.append(result.atomic_result)
        else:
            if not callable(external_executor):
                raise ValueError("External work requires its explicit external executor")
            external_executor(item)

    def after_sources():
        dispatch_deferred_dot_shields(runtime, dot_shield_results)

    return runtime.formal_turn_scheduler.run_pre_resolution(
        turn_event, items=items, initial_speeds=runtime.initial_speed_snapshot,
        rng=runtime.rng, executor=execute,
        reaction_eligible=runtime.pre_resolution_reaction_eligible,
        reaction_provider=reaction_provider, after_sources=after_sources)

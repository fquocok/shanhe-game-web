"""Locked rules and explicitly provisional tuning values."""

BASE_SPEED = 100.0
BASE_MAX_QI = 100
ACTION_GAUGE_THRESHOLD = 1000.0
DODGE_CAP = 0.75
DEFENSE_IGNORE_CAP = 0.80
DEFENSE_REDUCTION_CAP = 0.65

# TUNING_PLACEHOLDER: v0.6 requires a diminishing-return DefenseCurvePolicy,
# but deliberately leaves the curve constant/shape open for later tuning.
DEFENSE_CURVE_K = 100.0

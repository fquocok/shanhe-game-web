"""Portable executable entry. Self-test is headless and never creates a Tk window."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys
import traceback

from ..events.envelope import canonical_json
from .model import HumanCheckpointManifest
from .scenario import configuration
from ..simulator.harness import run_reference

REQUIRED = ("RUN_HUMAN_CHECKPOINT.cmd", "VERIFY_CHECKPOINT.cmd", "READ_ME_FIRST_zh-TW.txt",
            "HUMAN_CHECKLIST_zh-TW.txt", "CHECKPOINT_MANIFEST.json", "PACKAGED_FILES.json",
            "app/StormRiverCheckpoint.exe", "reference/reference_trace.json",
            "reference/reference_trace.sha256")


def self_test(package_root):
    root = Path(package_root).resolve()
    identity = "UNKNOWN"
    try:
        for name in REQUIRED:
            if not (root / name).is_file():
                raise ValueError("MISSING_PACKAGE_FILE:" + name)
        manifest = HumanCheckpointManifest(**json.loads((root / "CHECKPOINT_MANIFEST.json").read_text(encoding="utf-8")))
        identity = manifest.checkpoint + " " + manifest.full_merge_sha
        ledger = json.loads((root / "PACKAGED_FILES.json").read_text(encoding="utf-8"))
        for relative, digest in ledger.items():
            target = (root / relative).resolve()
            if not target.is_relative_to(root):
                raise ValueError("INVALID_PACKAGE_FILE_PATH")
            if sha256(target.read_bytes()).hexdigest() != digest:
                raise ValueError("PACKAGED_FILE_HASH_MISMATCH:" + relative)
        workspace = root / "app" / "data"
        from ..authority import load_manifest
        load_manifest(workspace).verify_integrity()
        authority_file = workspace / manifest.battle_authority_manifest_reference
        if sha256(authority_file.read_bytes()).hexdigest() != manifest.battle_authority_manifest_sha256:
            raise ValueError("BATTLE_AUTHORITY_MANIFEST_MISMATCH")
        # No fixture stubs, mocks, outcomes or installed Python calls.
        first = run_reference(workspace, manifest.full_merge_sha)
        second = run_reference(workspace, manifest.full_merge_sha)
        if first.serialize() != second.serialize():
            raise ValueError("REFERENCE_NOT_DETERMINISTIC")
        expected = (root / "reference" / "reference_trace.json").read_text(encoding="utf-8").rstrip("\r\n")
        recorded = (root / "reference" / "reference_trace.sha256").read_text(encoding="utf-8").strip()
        if (first.serialize() != expected or first.trace_sha256 != manifest.reference_trace_sha256
                or recorded != manifest.reference_trace_sha256):
            raise ValueError("REFERENCE_TRACE_SHA256_MISMATCH")
        initial_binding = first.to_dict()["run_trace"]["final_presentation_snapshot"]["binding_audit_sha256"]
        if initial_binding != manifest.binding_audit_hash:
            raise ValueError("BINDING_AUDIT_MISMATCH")
        import tkinter
        tkinter.Tcl().eval("info patchlevel")  # Packaged Tcl runtime, no Tk window.
        traces = root / "user_data" / "traces"
        traces.mkdir(parents=True, exist_ok=True)
        probe = traces / "self-test-write-probe.tmp"
        probe.write_text("write-test", encoding="utf-8")
        probe.unlink()
        message = ("PASS\n" + identity + "\nREFERENCE_TRACE_SHA256=" + first.trace_sha256
                   + "\nHEADLESS_PACKAGED_RUNTIME_VERIFIED\n")
        code = 0
    except Exception as exc:
        message = "FAIL\n" + identity + "\n" + type(exc).__name__ + ": " + str(exc) + "\n"
        code = 1
    (root / "SELF_TEST_RESULT.txt").write_text(message, encoding="utf-8")
    return code, message


def main(argv=None):
    parser = argparse.ArgumentParser(description="WO092 Human checkpoint")
    parser.add_argument("--checkpoint-root")
    parser.add_argument("--workspace", default=".")
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--reference-trace-output")
    args = parser.parse_args(argv)
    root = (Path(args.checkpoint_root).resolve() if args.checkpoint_root else
            Path(sys.executable).resolve().parent.parent if getattr(sys, "frozen", False) else Path.cwd())
    if args.reference_trace_output:
        workspace = root / "app" / "data" if (root / "CHECKPOINT_MANIFEST.json").exists() else Path(args.workspace)
        build = (json.loads((root / "CHECKPOINT_MANIFEST.json").read_text(encoding="utf-8"))["full_merge_sha"]
                 if (root / "CHECKPOINT_MANIFEST.json").exists() else "NON_RELEASE_BUILD")
        result = run_reference(workspace, build)
        Path(args.reference_trace_output).write_text(result.serialize() + "\n", encoding="utf-8")
        return 0
    if args.self_test:
        code, message = self_test(root)
        print(message)
        return code
    try:
        packaged = (root / "CHECKPOINT_MANIFEST.json").is_file()
        if packaged:
            code, message = self_test(root)
            if code:
                raise RuntimeError(message)
            manifest = HumanCheckpointManifest(**json.loads((root / "CHECKPOINT_MANIFEST.json").read_text(encoding="utf-8")))
            workspace = root / "app" / "data"
        else:
            from .model import make_manifest
            workspace = Path(args.workspace).resolve()
            reference = run_reference(workspace)
            manifest = make_manifest(workspace, "NON_RELEASE_BUILD", reference.trace_sha256)
        import tkinter as tk
        from ..interactive_battle_screen import TkBattleScreen
        window = tk.Tk()
        screen = TkBattleScreen(window, workspace, configuration=configuration(
            manifest.full_merge_sha, manifest=manifest, trace_root=root / "user_data" / "traces"))

        def close():
            screen.session.flush_trace()
            window.destroy()

        window.protocol("WM_DELETE_WINDOW", close)
        window.mainloop()
        return 0
    except Exception:
        detail = traceback.format_exc()
        (root / "LAUNCH_ERROR.txt").write_text(detail, encoding="utf-8")
        try:
            from tkinter import messagebox
            messagebox.showerror("WO092 launch failed", "Please see LAUNCH_ERROR.txt\n" + detail[-1500:])
        except Exception:
            pass
        print(detail, file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

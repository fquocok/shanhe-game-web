"""Same accepted demo roster/content/control stack; explicit NONCANON fixture identity."""
from dataclasses import replace

from ..interactive_battle_screen import (
    create_demo_controller, BattleScreenConfiguration, LEGENDARY_ID)
from ..player_action_control import ManualCombatController
from . import FIXTURE_AUTHORITY, ENCOUNTER_ID, SEED


def create_checkpoint_controller(workspace):
    # Reuse exact existing HP/Qi/roster/content values, no WO092 numeric tuning.
    demo = create_demo_controller(workspace, LEGENDARY_ID)
    # Smaller reuse allowed by WO092 section 10: 1v1 supports successive Manual rounds
    # at seed12345 without changing any HP/Qi/stat/content value.
    selected = ("player", "enemy-center")
    participants = tuple(demo.participants[identity] for identity in selected)
    for participant in participants:
        participant.bound.loadout = replace(participant.bound.loadout, fixture_authority=FIXTURE_AUTHORITY)
    return ManualCombatController(
        demo.service, ENCOUNTER_ID, participants, tuple(demo.targets[i] for i in selected), "player",
        seed=SEED, canonical_presentation=True)


def configuration(build_sha="NON_RELEASE_BUILD", *, manifest=None, trace_root=None):
    from .session import CheckpointSession
    short = build_sha[:8] if build_sha != "NON_RELEASE_BUILD" else build_sha

    def factory(workspace, configuration=None):
        return CheckpointSession(workspace, configuration=configuration,
                                 manifest=manifest, trace_root=trace_root)

    return BattleScreenConfiguration(
        controller_factory=create_checkpoint_controller,
        player_runtime_id="player", ai_runtime_id="enemy-center", player_target_id="player",
        actor_aliases={}, window_title="暴雨江湖 — WO092 Human Checkpoint",
        dev_banner=f"WO092 | NONCANON TEST FIXTURE | {short} | seed {SEED}",
        enemy_response_actor_ids=("enemy-center",),
        friendly_target_order=("player",), enable_presentation_speed_control=True,
        session_factory=factory, dev_banner_wraplength=400)

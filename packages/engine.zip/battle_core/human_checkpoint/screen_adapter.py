"""Read-only WO091 -> existing screen vocabulary; no gameplay or legacy extractors."""
from ..events.envelope import freeze, thaw
from ..presentation_stream import PresentationFrame, PresentationKind as K

HUMAN_CHECKPOINT_PRESENTATION_SOURCE = "WO091_CANONICAL_PRESENTATION_FRAME"
MAPPING = {
    K.ACTION_STARTED: "ACTION_STARTED", K.ACTION_COMPLETED: "ACTION_COMPLETED",
    K.HIT_CONFIRMED: "ATTACK_RESOLVED", K.DODGE_CONFIRMED: "DODGE",
    K.PARRY_CONFIRMED: "PARRY", K.DAMAGE_APPLIED: "DAMAGE_APPLIED",
    K.DEFEATED: "COMBATANT_DEFEATED",
}


def screen_events(frame):
    """Frozen mappings accepted by the existing beat projector.

    Every frame event remains in the canonical trace. Unsupported visual vocabulary
    is deliberately omitted. Parry collapses hit reaction for the SAME explicit
    Attack/recipient, retaining both source IDs and successful-hit truth.
    """
    if type(frame) is not PresentationFrame:
        raise TypeError("Immutable WO091 PresentationFrame required")
    parries = {(e.attack_instance_id, e.actual_recipient_id): e
               for e in frame.events if e.kind == K.PARRY_CONFIRMED}
    hits = {(e.attack_instance_id, e.actual_recipient_id): e
            for e in frame.events if e.kind == K.HIT_CONFIRMED}
    result = []
    for event in frame.events:
        kind = MAPPING.get(event.kind)
        if kind is None:
            continue
        key = (event.attack_instance_id, event.actual_recipient_id)
        if event.kind == K.HIT_CONFIRMED and key in parries:
            continue
        details = thaw(event.details)
        links = list(event.source_event_ids)
        if event.kind == K.PARRY_CONFIRMED and key in hits:
            links = list(hits[key].source_event_ids) + links
            details["successful_hit"] = True
            details["visual_hit_parry_collapse"] = True
        meta = details.get("action_metadata", {})
        name = details.get("display_name") or meta.get("display_name") or event.action_id
        result.append(freeze({
            "sequence": event.source_semantic_sequence * 16 + event.presentation_sequence[1],
            "event_type": kind, "actor_id": event.actor_id, "action_id": event.action_id,
            "action_name": name, "target_ids": event.target_ids, "details": details,
            "attack_instance_id": event.attack_instance_id,
            "original_target_id": event.original_target_id,
            "actual_recipient_id": event.actual_recipient_id,
            "damage_recipient_id": event.damage_recipient_id,
            "source_event_ids": tuple(links), "source_semantic_sequence": event.source_semantic_sequence,
            "derivation": HUMAN_CHECKPOINT_PRESENTATION_SOURCE,
        }))
    return tuple(result)


def detached_screen_events(frame):
    return tuple(thaw(event) for event in screen_events(frame))

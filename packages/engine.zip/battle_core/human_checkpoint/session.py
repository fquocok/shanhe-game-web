"""Checkpoint integration in the existing session. Rendering/choreography stay shared."""
from ..interactive_battle_screen import BattleScreenSession, PresentationBeatKind
from . import HUMAN_CHECKPOINT_PRESENTATION_SOURCE
from .trace import TraceRecorder, trace_document


class CheckpointSession(BattleScreenSession):
    def __init__(self, workspace, configuration=None, *, manifest=None, trace_root=None):
        self.checkpoint_manifest = manifest
        self.trace_root = trace_root
        self.trace_recorder = None
        self.trace_error = None
        self.checkpoint_inputs = []
        self._visible_hud = {}
        self._hud_controller = None
        super().__init__(workspace, configuration=configuration)

    @property
    def checkpoint_engine(self):
        return self.controller.service.settlement_bridge.engine

    def reset(self):
        self.checkpoint_inputs = []
        self._visible_hud = {}
        self._hud_controller = None
        self.trace_recorder = None
        self.trace_error = None
        result = super().reset()  # Same controller_factory, fresh Runtime, same fixed seed.
        if self.trace_root is not None:
            try:
                self.trace_recorder = TraceRecorder(self.trace_root)
            except OSError as exc:
                self.trace_error = "TRACE_WRITE_FAILED: " + str(exc)
        self.flush_trace()
        return result

    def flush_trace(self):
        if self.trace_recorder is not None:
            try:
                self.trace_recorder.write(trace_document(self, self.checkpoint_manifest))
            except (OSError, ValueError, TypeError) as exc:
                # Settlement remains committed. Surface diagnostic; never retry gameplay.
                self.trace_error = "TRACE_WRITE_FAILED: " + str(exc)

    def _input(self, kind, **details):
        self.checkpoint_inputs.append({"sequence": len(self.checkpoint_inputs) + 1,
                                       "type": kind, **details})

    def screen_state(self):
        state = super().screen_state()
        frame = self.checkpoint_engine.presentation_frame()
        if self._hud_controller is not self.controller:
            self._visible_hud = {c.combatant_id: c.to_dict() for c in frame.combatants}
            self._hud_controller = self.controller

        def project(member):
            saved = self._visible_hud.get(member["character_id"])
            if saved is None:
                return member
            confirmed = saved["life_state"] == "DEFEATED"
            return {**member, "hp_current": saved["current_hp"], "hp_max": saved["max_hp"],
                    "qi": saved["current_qi"], "max_qi": saved["max_qi"], "shield": saved["shield"],
                    "alive": not confirmed, "presentation_alive": not confirmed,
                    "life_state": saved["life_state"],
                    "ordinary_combat_eligible": saved["ordinary_combat_eligible"],
                    "cooldowns": saved["cooldowns"], "combat_resources": saved["combat_resources"],
                    "statuses": saved["statuses"], "stances": (),
                    "resources": tuple({"display_name": key, "current": value, "maximum": None}
                                       for key, value in sorted(saved["combat_resources"].items())),
                    "checkpoint_hud_source": HUMAN_CHECKPOINT_PRESENTATION_SOURCE}

        state["friendly_participants"] = tuple(project(x) for x in state["friendly_participants"])
        state["player"] = None if state["player"] is None else project(state["player"])
        state["enemies"] = [project(x) for x in state["enemies"]]
        state["snapshot"]["participants"] = tuple(project(x) for x in state["snapshot"]["participants"])
        state["checkpoint_snapshot"] = frame.to_dict()
        state["checkpoint_visible_hud"] = dict(self._visible_hud)
        state["presentation_source"] = HUMAN_CHECKPOINT_PRESENTATION_SOURCE
        state["trace_error"] = self.trace_error
        if self.trace_error:
            state["combat_log"] = state["combat_log"] + (self.trace_error,)
        if self.presentation_busy:
            state["submission_locked"] = True
            state["actions"] = [{**a, "enabled": False} for a in state["actions"]]
        return state

    def _presentation_flow(self, events):
        # Intent is the explicit controller exception, never a predicted outcome.
        events = tuple({**event, "details": {**event["details"],
                        "presentation_authority": "PRESENTATION_CONTROLLER_DECISION_NOT_BATTLE_OUTCOME"}}
                       if event["event_type"] == "ENEMY_INTENT" else event for event in events)
        self.settled_presentation_events = events
        return super()._presentation_flow(events)

    def _apply_presentation_beat(self):
        super()._apply_presentation_beat()
        beat = self.current_presentation_beat()
        if beat is None:
            return
        if beat.kind == PresentationBeatKind.IMPACT_FEEDBACK:
            # Copy this action's captured snapshot only at its visible impact.
            # No HP subtraction, state diffs or transient inference.
            records = self.controller.service.settlement_bridge.checkpoint_records
            record = next((r for r in reversed(records) if r["action_id"] == beat.action_id
                           and any(e["sequence"] in beat.source_sequences for e in r["screen_events"])), None)
            if record is not None:
                self._visible_hud = {c["combatant_id"]: c for c in record["frame"]["combatants"]}
        elif beat.kind in (PresentationBeatKind.CONTROL_READY, PresentationBeatKind.ENCOUNTER_CLOSURE):
            self._visible_hud = {c.combatant_id: c.to_dict()
                                 for c in self.checkpoint_engine.presentation_frame().combatants}

    def finish_presentation(self, generation):
        done = super().finish_presentation(generation)
        if done:
            self._visible_hud = {c.combatant_id: c.to_dict()
                                 for c in self.checkpoint_engine.presentation_frame().combatants}
            self.flush_trace()
        return done

    def select_action(self, action_id):
        if self.presentation_busy:
            self.last_error = "PRESENTATION_BUSY"
            return self.screen_state()
        self._input("select_action", action_id=action_id)
        result = super().select_action(action_id)
        self.flush_trace()
        return result

    def select_target(self, target_id):
        if self.presentation_busy:
            self.last_error = "PRESENTATION_BUSY"
            return self.screen_state()
        self._input("select_target", target_id=target_id)
        result = super().select_target(target_id)
        self.flush_trace()
        return result

    def submit(self):
        if self.presentation_busy:
            self.last_error = "PRESENTATION_BUSY"
            return self.screen_state()
        self._input("submit", actor_id=self.controller.active_actor_id,
                    action_id=self.selected_action_id, target_ids=(() if self.selected_target_id is None
                                                                   else (self.selected_target_id,)),
                    mode=self.effective_control_mode())
        result = super().submit()
        self.flush_trace()
        return result

    def request_auto(self, enabled):
        self._input("auto", enabled=enabled)
        result = super().request_auto(enabled)
        self.flush_trace()
        return result

    def set_presentation_speed(self, multiplier):
        self._input("speed", multiplier=multiplier)
        result = super().set_presentation_speed(multiplier)
        self.flush_trace()
        return result

    def continue_auto_cycle(self):
        # Inherited WO072C backpressure and deterministic controller, no shortcut.
        result = super().continue_auto_cycle()
        self.flush_trace()
        return result

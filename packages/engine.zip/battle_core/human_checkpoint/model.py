"""Immutable injected build identity; no pre-merge SHA hardcoding."""
from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
import re

from ..presentation_stream.model import Document, CONTRACT
from . import CHECKPOINT_ID, FIXTURE_AUTHORITY, ENCOUNTER_ID, SEED

PACKAGER_VERSION = "6.16.0"


@dataclass(frozen=True, slots=True)
class HumanCheckpointManifest(Document):
    contract: str
    checkpoint: str
    full_merge_sha: str
    short_merge_sha: str
    build_source_ref: str
    checkpoint_fixture_authority: str
    encounter_id: str
    seed: int
    presentation_contract: str
    battle_authority_manifest_reference: str
    battle_authority_manifest_sha256: str
    binding_audit_hash: str
    reference_trace_sha256: str
    packaging_tool: str
    artifact_layout_version: int
    no_canon_change: bool
    build_status: str

    def __post_init__(self):
        if (self.contract != "STORM_RIVER_HUMAN_CHECKPOINT_V1" or self.checkpoint != CHECKPOINT_ID
                or self.seed != SEED or self.checkpoint_fixture_authority != FIXTURE_AUTHORITY
                or self.encounter_id != ENCOUNTER_ID or self.presentation_contract != CONTRACT
                or self.artifact_layout_version != 1 or self.no_canon_change is not True):
            raise ValueError("CHECKPOINT_MANIFEST_IDENTITY_MISMATCH")
        release = bool(re.fullmatch(r"[0-9a-f]{40}", self.full_merge_sha))
        if not release and self.full_merge_sha != "NON_RELEASE_BUILD":
            raise ValueError("EXACT_VALIDATED_SHA_REQUIRED")
        if self.short_merge_sha != (self.full_merge_sha[:8] if release else self.full_merge_sha):
            raise ValueError("CHECKPOINT_SHORT_SHA_MISMATCH")
        if self.build_status != ("VALIDATED_MAIN_BUILD" if release else "NON_RELEASE_BUILD"):
            raise ValueError("CHECKPOINT_BUILD_STATUS_MISMATCH")
        if self.build_source_ref != ("main@" + self.full_merge_sha if release else "NON_RELEASE_BUILD"):
            raise ValueError("CHECKPOINT_BUILD_REF_MISMATCH")
        if self.packaging_tool != "PyInstaller==" + PACKAGER_VERSION:
            raise ValueError("CHECKPOINT_PACKAGER_MISMATCH")
        for value in (self.battle_authority_manifest_sha256, self.binding_audit_hash, self.reference_trace_sha256):
            if not re.fullmatch(r"[0-9a-f]{64}", value):
                raise ValueError("CHECKPOINT_SHA256_REQUIRED")


def make_manifest(workspace, build_sha, reference_hash):
    from .scenario import create_checkpoint_controller
    engine = create_checkpoint_controller(workspace).service.settlement_bridge.engine
    path = "authority/battle/authority_manifest_v1.json"
    release = bool(re.fullmatch(r"[0-9a-f]{40}", build_sha))
    return HumanCheckpointManifest(
        "STORM_RIVER_HUMAN_CHECKPOINT_V1", CHECKPOINT_ID, build_sha,
        build_sha[:8] if release else build_sha, "main@" + build_sha if release else build_sha,
        FIXTURE_AUTHORITY, ENCOUNTER_ID, SEED, CONTRACT, path,
        sha256((Path(workspace) / path).read_bytes()).hexdigest(),
        engine.presentation_frame().binding_audit_sha256, reference_hash,
        "PyInstaller==" + PACKAGER_VERSION, 1, True,
        "VALIDATED_MAIN_BUILD" if release else "NON_RELEASE_BUILD")

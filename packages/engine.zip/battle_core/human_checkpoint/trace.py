"""Deterministic trace contents; local run directory identity stays outside the hash."""
from hashlib import sha256
from pathlib import Path

from ..events.envelope import canonical_json, freeze, thaw


def trace_document(session, manifest=None):
    bridge = session.controller.service.settlement_bridge
    frame = bridge.engine.presentation_frame()
    payload = {
        "contract": "WO092_HUMAN_RUN_TRACE_V1",
        "checkpoint_manifest": None if manifest is None else manifest.to_dict(),
        "encounter_id": session.controller.battle_id, "seed": bridge.engine.seed,
        "input_commands": session.controller.command_trace,
        "control_inputs": session.checkpoint_inputs,
        "auto_transitions": session.auto_control_trace,
        "enemy_intents": [item["intent"] for item in session.controller.ai_trace if "intent" in item],
        "invalidated_actions": session.controller.response_invalidation_trace,
        "screen_pipeline_events": session.settled_presentation_events,
        "presentation_speed_changes": session.presentation_speed_trace,
        "settlements": bridge.checkpoint_records,
        "semantic_events": bridge.engine.semantic_events.to_data(),
        "terminal_state": frame.terminal_state, "final_presentation_snapshot": frame.to_dict(),
    }
    # Deep detach before hashing; no clocks, local folders, repr or mutable references.
    detached = thaw(freeze(payload))
    detached["stable_trace_sha256"] = sha256(canonical_json(detached).encode("utf-8")).hexdigest()
    return detached


class TraceRecorder:
    def __init__(self, trace_root):
        self.root = Path(trace_root)
        self.root.mkdir(parents=True, exist_ok=True)
        index = 1
        while True:
            candidate = self.root / f"run-{index:04d}"
            try:
                candidate.mkdir()
                break
            except FileExistsError:
                index += 1
        self.run_folder = candidate
        (self.root / "LAST_RUN.txt").write_text(candidate.name, encoding="utf-8")

    def write(self, document):
        target = self.run_folder / "trace.json"
        temporary = self.run_folder / "trace.json.tmp"
        temporary.write_text(canonical_json(document) + "\n", encoding="utf-8")
        temporary.replace(target)

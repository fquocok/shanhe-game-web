"""WO-069 formal named-character action-set authority, without action creation."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum
from types import MappingProxyType

from .named_character_visual_shell import WANG_MUQING_CHARACTER_ID

FORMAL_CHARACTER_ACTION_SET_INTERFACE_CONTRACT = "FORMAL_CHARACTER_ACTION_SET_INTERFACE_V0_1"
WANG_MUQING_ACTION_SET_AUTHORITY_SHELL_V0_1 = "WANG_MUQING_ACTION_SET_AUTHORITY_SHELL_V0_1"
GAME_CHARACTER_ACTION_SET_AUTHORITY = "GAME_CHARACTER_ACTION_SET_AUTHORITY"


class CharacterActionSetAssignmentStatus(str, Enum):
    UNASSIGNED = "UNASSIGNED"
    ASSIGNED = "ASSIGNED"
    UNKNOWN_CHARACTER = "UNKNOWN_CHARACTER"
    PROFILE_NOT_FOUND = "PROFILE_NOT_FOUND"
    SANDBOX_OVERRIDE = "SANDBOX_OVERRIDE"


@dataclass(frozen=True)
class CharacterActionSetAuthority:
    shell_id: str
    character_id: str
    display_name: str
    authority_domain: str
    assignment_status: CharacterActionSetAssignmentStatus
    formal_action_set_id: str | None
    formal_action_ids: tuple[str, ...]
    formal_action_source: str | None
    formal_martial_status: str
    sandbox_override_policy: str
    generated_action_fallback_policy: str
    unknown_fields: tuple[str, ...]
    forbidden_inferences: tuple[str, ...]
    human_approval_required: bool
    world_canon_authority_required: bool
    runtime_resolution_policy: str
    provenance: tuple[str, ...]

    def snapshot(self) -> dict:
        data = asdict(self); data["assignment_status"] = self.assignment_status.value
        return {"contract": FORMAL_CHARACTER_ACTION_SET_INTERFACE_CONTRACT, **data, "world_canon_writeback": 0}


@dataclass(frozen=True)
class FormalCharacterActionSetResolution:
    character_id: str | None
    status: CharacterActionSetAssignmentStatus
    formal_action_set_id: str | None
    formal_action_ids: tuple[str, ...]
    formal_action_source: str | None
    sandbox_action_set: str | None
    sandbox_action_authority: str | None
    fallback_used: bool
    reason: str

    def snapshot(self) -> dict:
        return {"contract": FORMAL_CHARACTER_ACTION_SET_INTERFACE_CONTRACT, **asdict(self),
                "status": self.status.value, "battle_semantics": False}


WANG_MUQING_ACTION_SET_AUTHORITY_SHELL = CharacterActionSetAuthority(
    WANG_MUQING_ACTION_SET_AUTHORITY_SHELL_V0_1, WANG_MUQING_CHARACTER_ID, "王沐青",
    GAME_CHARACTER_ACTION_SET_AUTHORITY, CharacterActionSetAssignmentStatus.UNASSIGNED,
    None, (), None, "UNASSIGNED", "EXPLICIT_NONCANONICAL_ONLY", "DISABLED",
    ("FORMAL_ACTION_SET", "FORMAL_ACTION_IDS", "FORMAL_ACTION_SOURCE", "FORMAL_ACTION_SET_HASH"),
    ("SANDBOX_ACTION_TO_FORMAL_CHARACTER_ACTION", "GENERATED_MARTIAL_TO_CHARACTER_ACTION_SET",
     "WEAPON_FAMILY_TO_CHARACTER_ACTION_SET", "DISPLAY_NAME_TO_CHARACTER_ACTION_SET",
     "VISUAL_PROFILE_TO_CHARACTER_ACTION_SET", "MOTION_PROFILE_TO_CHARACTER_ACTION_SET",
     "FATHER_LEGACY_SWORD_ART_TO_ACTION", "BLACK_FOG_TO_ACTION"),
    True, True, "ACTION_SET_NOT_ASSIGNED_NO_GENERIC_OR_GENERATED_FALLBACK",
    ("WO-063:CHARACTER-WANG-MUQING", "WO-067:FORMAL_MARTIAL_UNASSIGNED", "WO-069:ACTION_SET_INTERFACE_ONLY"),
)
CHARACTER_ACTION_SET_AUTHORITY_REGISTRY = MappingProxyType({WANG_MUQING_CHARACTER_ID: WANG_MUQING_ACTION_SET_AUTHORITY_SHELL})


def get_character_action_set_authority(character_id: str | None) -> CharacterActionSetAuthority | None:
    return CHARACTER_ACTION_SET_AUTHORITY_REGISTRY.get(character_id or "")


def resolve_formal_character_action_set(character_id: str | None, *, sandbox_action_set: str | None = None,
                                        sandbox_action_authority: str | None = None) -> FormalCharacterActionSetResolution:
    shell = get_character_action_set_authority(character_id)
    if shell is None:
        return FormalCharacterActionSetResolution(character_id, CharacterActionSetAssignmentStatus.UNKNOWN_CHARACTER, None, (), None, None, None, False, "NO_EXPLICIT_CHARACTER_ACTION_SET_AUTHORITY_SHELL")
    if sandbox_action_set is not None:
        if sandbox_action_authority != "NONCANONICAL_SANDBOX_FIXTURE":
            return FormalCharacterActionSetResolution(character_id, CharacterActionSetAssignmentStatus.PROFILE_NOT_FOUND, None, (), None, None, None, False, "INVALID_SANDBOX_OVERRIDE_AUTHORITY")
        return FormalCharacterActionSetResolution(character_id, CharacterActionSetAssignmentStatus.SANDBOX_OVERRIDE, None, (), None, sandbox_action_set, sandbox_action_authority, False, "EXPLICIT_NONCANONICAL_SANDBOX_OVERRIDE_FORMAL_ACTION_SET_REMAINS_UNASSIGNED")
    return FormalCharacterActionSetResolution(character_id, CharacterActionSetAssignmentStatus.UNASSIGNED, None, (), None, None, None, False, "ACTION_SET_NOT_ASSIGNED_NO_GENERIC_OR_GENERATED_FALLBACK")


def character_action_set_authority_registry_snapshot() -> dict:
    return {"contract": FORMAL_CHARACTER_ACTION_SET_INTERFACE_CONTRACT, "entry_count": 1, "read_only": True,
            "entries": {WANG_MUQING_CHARACTER_ID: WANG_MUQING_ACTION_SET_AUTHORITY_SHELL_V0_1},
            "action_definitions_stored": False, "world_canon_writeback": 0}


def formal_character_action_set_resolution_policy_artifact() -> dict:
    return {"contract": FORMAL_CHARACTER_ACTION_SET_INTERFACE_CONTRACT,
            "formal_named_character_unassigned_behavior": "ACTION_SET_NOT_ASSIGNED",
            "sandbox_override_behavior": "EXPLICIT_NONCANONICAL_ONLY", "generated_action_fallback": "DISABLED",
            "weapon_family_inference": "DISABLED", "display_name_inference": "DISABLED",
            "visual_profile_inference": "DISABLED", "motion_profile_inference": "DISABLED",
            "failure_status": "ACTION_SET_NOT_ASSIGNED"}

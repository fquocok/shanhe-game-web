"""WO-037B1 Human-authored immutable Revision 1 and read-only loop diagnostic."""
from __future__ import annotations
from hashlib import sha256
from pathlib import Path
import json

from .durable_generated_registry import DEFAULT_REGISTRY_PATH, load_generated_registry
from .generated_acceptance import stable_hash

PARENT_ID="gen_v01_high_fist_f56a8c141194"
PARENT_HASH="687151f80f8f8e7dc84c1b13df9a2b776318bef9f0d5fa16368518350b141dc1"
REVISION_ID=PARENT_ID+".r1"
RID=PARENT_ID+".resource1"

def _read(path): return json.loads(Path(path).read_text(encoding="utf-8"))

def human_decision():
 d={"work_order":"CODEX-WO-037B1","authority":"HUMAN","decision":"AUTHOR_RUNTIME_CONTENT",
    "selection_token":"WO037-B1","parent_candidate_id":PARENT_ID,"parent_candidate_sha256":PARENT_HASH,
    "values":{"resource":{"id":RID,"label":"勢","initial":0,"maximum":4,"gain":1,"consume":2,"threshold":2,"persistence":"BATTLE_LOCAL_UNTIL_CONSUMED_OR_BATTLE_END","clamp":[0,4]},
      "main":{"successful_hit_gain":1,"coefficient":1.0,"qi_cost_percent_max":.30,"cooldown":8,"targeting":"single_target"},
      "parry":{"event":"PARRY_SUCCESS","scope":"ATTACK_SCOPE","gain":1},
      "special":{"opportunity":"PARRY_SUCCESS","scope":"ATTACK_SCOPE","snapshot":"PRE_EVENT_RUNTIME_SNAPSHOT","threshold":2,"cost_timing":"ON_TRIGGER_ATTEMPT_AFTER_CONDITION","consume":2,"atomic":True,"refund":"NO_REFUND_AFTER_COST_SETTLEMENT","base_chance":1.0,"success_decay":.25,"failure_decay":"NO_DECAY","reset":"FORMAL_TURN_COMPLETE","ownership":"NEW_ORDINARY_SPECIAL_ACTION","cap":3,"targeting":"single_target","coefficient":.8,"successful_hit_gain":1}},
    "value_authority":"HUMAN_AUTHORED_FIRST_PASS_CONTENT","coefficient_authority":"HUMAN_AUTHORED_FIRST_PASS_TUNING","final_balance_locked":False,"promotion":False}
 d["decision_id"]="human-content:"+stable_hash(d)[:16];return d

def build_revision(workspace):
 root=Path(workspace); parent_path=root/"generated_candidates/wo037/lane_b_high_fist/pool/seed_211.json"
 parent_bytes=parent_path.read_bytes()
 if sha256(parent_bytes).hexdigest()!=PARENT_HASH: raise ValueError("PARENT_HASH_MISMATCH")
 artifact=root/"generated_candidates/wo037b1/candidate_revision_1.json"
 if artifact.exists(): return _read(artifact)
 p=json.loads(parent_bytes); d=human_decision()
 main={**p["actions"][0],"damage_coefficient":1.0,"qi_cost_percent_max":.30,"cooldown":8,"target_contract":{"selector":"legal_enemy_single_target","living":True,"on_field":True,"enemy":True,"fallback":"NONE","retarget":"NONE"},"successful_hit_effect":{"event":"ATTACK_INSTANCE_SUCCESSFULLY_HIT","scope":"ATTACK_SCOPE","effect":"RESOURCE_GAIN","resource_id":RID,"amount":1,"classification":"NON_ACTION_EFFECT","clamp_max":4},"authority":"HUMAN_AUTHORED_FIRST_PASS_CONTENT","coefficient_authority":"HUMAN_AUTHORED_FIRST_PASS_TUNING","final_balance_locked":False}
 special={**p["actions"][1],"damage_coefficient":.8,"action_ownership":"NEW_ORDINARY_SPECIAL_ACTION","ordinary_special_cap":3,"target_contract":{"selector":"legal_enemy_single_target","living":True,"on_field":True,"enemy":True,"fallback":"NONE","retarget":"NONE"},"successful_hit_effect":{"event":"ATTACK_INSTANCE_SUCCESSFULLY_HIT","scope":"ATTACK_SCOPE","effect":"RESOURCE_GAIN","resource_id":RID,"amount":1,"classification":"NON_ACTION_EFFECT","clamp_max":4},"authority":"HUMAN_AUTHORED_FIRST_PASS_CONTENT","coefficient_authority":"HUMAN_AUTHORED_FIRST_PASS_TUNING","final_balance_locked":False}
 resource={"id":RID,"label":"勢","initial":0,"minimum":0,"maximum":4,"persistence":"BATTLE_LOCAL_UNTIL_CONSUMED_OR_BATTLE_END","reset":"BATTLE_END_ONLY","clamp":"0..4","producers":[{"source_action_id":main["id"],"event":"ATTACK_INSTANCE_SUCCESSFULLY_HIT","scope":"ATTACK_SCOPE","amount":1,"classification":"NON_ACTION_EFFECT"},{"event":"PARRY_SUCCESS","scope":"ATTACK_SCOPE","amount":1,"classification":"NON_ACTION_EFFECT"},{"source_action_id":special["id"],"event":"ATTACK_INSTANCE_SUCCESSFULLY_HIT","scope":"ATTACK_SCOPE","amount":1,"classification":"NON_ACTION_EFFECT"}],"consumer":{"action_id":special["id"],"opportunity":"PARRY_SUCCESS","scope":"ATTACK_SCOPE","threshold":2,"condition_snapshot":"PRE_EVENT_RUNTIME_SNAPSHOT","current_resource_recheck":True,"consume":2,"atomicity":"ATOMIC_ALL_OR_NOTHING","cost_timing":"ON_TRIGGER_ATTEMPT_AFTER_CONDITION","refund_policy":"NO_REFUND_AFTER_COST_SETTLEMENT","cap_before_cost":True,"target_resolution":"AFTER_COST_SETTLEMENT"},"authority":"HUMAN_AUTHORED_FIRST_PASS_CONTENT"}
 passive={**p["passives"][0],"predicate":"successful_parry","trigger_event":"PARRY_SUCCESS","trigger_scope":"ATTACK_SCOPE","effect_action_id":special["id"],"resource_id":RID,"threshold":2,"condition_snapshot":"PRE_EVENT_RUNTIME_SNAPSHOT","current_resource_recheck":True,"consume":2,"atomicity":"ATOMIC_ALL_OR_NOTHING","refund_policy":"NO_REFUND_AFTER_COST_SETTLEMENT","base_chance":1.0,"success_decay_multiplier":.25,"failure_decay":"NO_DECAY","decay_reset":"FORMAL_TURN_COMPLETE","decay_isolation":"PER_CHARACTER_PER_TRIGGER","ordinary_special":True,"ordinary_special_cap":3,"cap_before_cost":True,"cap_before_roll":True,"authority":"HUMAN_AUTHORED_FIRST_PASS_CONTENT"}
 candidate={**p,"candidate_id":REVISION_ID,"actions":[main,special],"passives":[passive],"resources":[resource],"content_tbd":[],"tuning_placeholders":[],"validation_status":"REVISION_CONTENT_COMPLETE"}
 rev={"revision_schema":"WO037B1-v0.1","revision_id":REVISION_ID,"revision_number":1,"parent_candidate_id":PARENT_ID,"parent_candidate_sha256":PARENT_HASH,"revision_reason":"HUMAN_HIGH_CLOSED_LOOP_CONTENT_RESOLUTION","selection_token":"WO037-B1","human_content_decision_id":d["decision_id"],"candidate":candidate,"canonical":False,"formal":False,"runtime_registered":False,"generator_calls":0,"rerolls":0}
 return rev

class LoopDiagnostic:
 def __init__(self,resource=0,cap=0,probability=1.0):self.r=resource;self.cap=cap;self.p=probability;self.rolls=0;self.specials=0
 def gain(self):self.r=min(4,self.r+1)
 def main_hit(self):self.gain()
 def parry(self,*,roll=0.0,target=True,settlement_interference=0):
  pre=self.r;eligible=pre>=2;self.gain()
  if not eligible or self.cap>=3:return {"pre":pre,"special":False,"reason":"condition_or_cap","after":self.r}
  self.r=max(0,self.r-settlement_interference)
  if self.r<2:return {"pre":pre,"special":False,"reason":"settlement_insufficient","after":self.r}
  self.r-=2;self.rolls+=1
  if roll>=self.p:return {"pre":pre,"special":False,"reason":"roll_failed_no_refund","after":self.r}
  if not target:return {"pre":pre,"special":False,"reason":"target_lost_no_refund","after":self.r}
  self.specials+=1;self.cap+=1;self.p*=.25;self.gain()
  return {"pre":pre,"special":True,"reason":"success","after":self.r}
 def turn_complete(self):self.cap=0;self.p=1.0

def audit_revision(workspace):
 root=Path(workspace); registry_path=root/DEFAULT_REGISTRY_PATH; rb=registry_path.read_bytes(); rev=build_revision(root); rev_hash=stable_hash(rev)
 s=LoopDiagnostic();s.main_hit();snapshot=s.parry();second=s.parry();persist=s.r;s.turn_complete();third=s.parry()
 insufficient=LoopDiagnostic(2);settle=insufficient.parry(settlement_interference=2)
 cap=LoopDiagnostic(4,3);cap_result=cap.parry();failure=LoopDiagnostic(2);fail_result=failure.parry(roll=1.0)
 no_target=LoopDiagnostic(2);target_result=no_target.parry(target=False)
 policy_gaps=("RESOURCE_MAX_TOKEN_POLICY_REQUIRED","RESOURCE_GAIN_AMOUNT_TOKEN_POLICY_REQUIRED","RESOURCE_CONSUME_AMOUNT_TOKEN_POLICY_REQUIRED","RESOURCE_THRESHOLD_TOKEN_POLICY_REQUIRED")
 known=108;chance=10
 compiler_missing=("DECLARATIVE_RESOURCE_DEFINITION","ATTACK_SUCCESS_RESOURCE_PRODUCER","PARRY_SIBLING_RESOURCE_PRODUCER","PRE_EVENT_RESOURCE_THRESHOLD_CONDITION","ATOMIC_ATTEMPT_RESOURCE_CONSUMER","SPECIAL_HIT_RESOURCE_FEEDBACK")
 review={"review_package_schema":"WO037B1-v0.1","revision_id":REVISION_ID,"revision_sha256":rev_hash,"parent_candidate_id":PARENT_ID,"parent_candidate_sha256":PARENT_HASH,"validation":"CONTENT_COMPLETE","high_qualification":"VALID_REPEATABLE_HIGH_LOOP","token_status":"BUDGET_INDETERMINATE","compiler_readiness":"BLOCKED_BY_GENERIC_COMPILER_GAP","semantic_diff":"WHITELIST_PASS","formal_similarity":"DISTINCT","review_state":"PENDING_REVIEW","human_decision":"NONE","canonicalization_accept_eligible":False}
 review["review_package_id"]="review:r1:"+stable_hash(review)[:16];review["immutable_sha256"]=stable_hash(review)
 loaded=load_generated_registry(root)
 return {"work_order":"CODEX-WO-037B1","status":"PARTIAL_GENERIC_COMPILER_OR_FORMAL_GAP","parent":{"id":PARENT_ID,"sha256":PARENT_HASH,"immutable":True},"revision":{"id":REVISION_ID,"sha256":rev_hash,"payload":rev},"human_decision":human_decision(),"runtime":{"snapshot_case":snapshot,"threshold_case":second,"persist_before_turn_end":persist,"reentry_case":third,"settlement_recheck":settle,"cap_case":cap_result,"roll_failure":fail_result,"target_loss":target_result,"valid_repeatable_loop":snapshot["after"]==2 and second["special"] and third["special"],"no_dead_loop":True,"no_unbounded_recursion":True},"content_complete":True,"high_qualification":"VALID_REPEATABLE_HIGH_LOOP","meaningful_nodes":4,"token":{"previous_mechanic_subtotal":108,"mechanic_subtotal":known,"main_coefficient":0,"special_coefficient":0,"qi":0,"cooldown":0,"chance":chance,"known_total":known+chance,"resource_numeric_policy_gaps":policy_gaps,"used":None,"remaining":None,"budget":168,"status":"BUDGET_INDETERMINATE","unknown_as_zero":False},"double_charge":{"status":"PASS","ordinary_special_already_in_108":True,"chance_newly_priced_once":True,"resource_numeric_not_in_combat_resource_presence_cost":True},"compiler":{"readiness":"BLOCKED_BY_GENERIC_COMPILER_GAP","missing_capabilities":compiler_missing,"inline_fix":False},"formal_similarity":"DISTINCT","review_package":review,"governance":{"generator_calls":0,"rerolls":0,"human_accepts":0,"promotion_attempts":0,"canonical_previews":0,"staging":0,"commits":0,"formal_name_generated":False,"lane_a":"CLOSED","lane_c":"DEFERRED"},"registry":{"before":[loaded.count,len(loaded.runtime),loaded.count],"after":[loaded.count,len(loaded.runtime),loaded.count],"bytes_unchanged":registry_path.read_bytes()==rb},"versions":{"battle":"v0.9","generator":"v0.2-prototype","acceptance":"v0.1-prototype","numeric_policy":"v0.2","registry_schema":"v0.1"}}

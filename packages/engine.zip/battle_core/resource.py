from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CombatResourceDefinition:
    id: str
    name: str
    minimum: int = 0
    maximum: int = 1
    duration_policy: str = "permanent_until_consumed"


class CombatResourceManager:
    """Generic, content-neutral bounded integer combat resources."""

    def __init__(self, event_sink):
        self._event = event_sink
        self.definitions: dict[str, CombatResourceDefinition] = {}

    def register(self, definition: CombatResourceDefinition):
        existing = self.definitions.get(definition.id)
        if existing is not None and existing != definition:
            raise ValueError(f"Combat Resource Definition 衝突：{definition.id}")
        self.definitions[definition.id] = definition

    def initialize(self, owner, resource_id: str, value: int = 0):
        definition = self.definitions[resource_id]
        value = max(definition.minimum, min(definition.maximum, int(value)))
        owner.combat_resources[resource_id] = value
        self._event("COMBAT_RESOURCE_INITIALIZED", owner=owner.definition.id,
                    resource=resource_id, name=definition.name, value=value,
                    minimum=definition.minimum, maximum=definition.maximum,
                    duration_policy=definition.duration_policy)

    def get(self, owner, resource_id: str) -> int:
        return int(owner.combat_resources.get(resource_id, self.definitions[resource_id].minimum))

    def gain(self, owner, resource_id: str, amount: int, **metadata) -> int:
        definition = self.definitions[resource_id]
        before = self.get(owner, resource_id)
        after = min(definition.maximum, before + max(0, int(amount)))
        owner.combat_resources[resource_id] = after
        self._event("COMBAT_RESOURCE_GAINED", owner=owner.definition.id, resource=resource_id,
                    requested=int(amount), effective=after-before, before=before, after=after, **metadata)
        if after-before < max(0,int(amount)):
            self._event("COMBAT_RESOURCE_GAIN_CLAMPED",owner=owner.definition.id,resource=resource_id,
                        requested=int(amount),effective=after-before,excess=max(0,int(amount))-(after-before),
                        before=before,after=after,maximum=definition.maximum,**metadata)
        return after-before

    def atomic_consume(self,owner,costs: dict[str,int],**metadata) -> bool:
        normalized={rid:max(0,int(cost)) for rid,cost in costs.items()}
        before={rid:self.get(owner,rid) for rid in normalized}
        if any(before[rid]<cost for rid,cost in normalized.items()):
            self._event("COMBAT_RESOURCE_ATOMIC_CONSUME_REJECTED",owner=owner.definition.id,
                        costs=normalized,before=before,reason="insufficient_resource",**metadata)
            return False
        after={rid:before[rid]-cost for rid,cost in normalized.items()}
        owner.combat_resources.update(after)
        self._event("COMBAT_RESOURCE_ATOMIC_CONSUMED",owner=owner.definition.id,
                    costs=normalized,before=before,after=after,**metadata)
        return True

    def consume_all(self, owner, resource_id: str, **metadata) -> int:
        before = self.get(owner, resource_id)
        owner.combat_resources[resource_id] = self.definitions[resource_id].minimum
        self._event("COMBAT_RESOURCE_CONSUMED", owner=owner.definition.id, resource=resource_id,
                    consumed=before, before=before, after=self.definitions[resource_id].minimum, **metadata)
        return before

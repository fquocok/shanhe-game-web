"""Pure parallel ratio planning. No Runtime state, RNG or settlement dependencies."""
from fractions import Fraction
from ..events import DamageOrigin
from .model import (DamageSharingError, SharingPolicyRequiredError, SharingReceiverError,
                    DamageShareCandidate, DamageSharingSource, DamageShareEntry, DamageSharingPlan)
from .rules import DamageSharingRulePolicy


def trace_order(candidate):
    # Stable presentation of a parallel calculation, never gameplay share priority.
    return (candidate.creation_sequence, candidate.share_receiver_id,
            candidate.source_id, candidate.candidate_id)


class DamageSharingResolver:
    @staticmethod
    def validate_candidates(source, candidates):
        snapshot = tuple(candidates)
        if any(not isinstance(candidate, DamageShareCandidate) for candidate in snapshot):
            raise DamageSharingError("Typed candidates required")
        if len({c.candidate_id for c in snapshot}) != len(snapshot):
            raise DamageSharingError("Duplicate candidate ID")
        if len({c.share_receiver_id for c in snapshot}) != len(snapshot):
            raise SharingReceiverError("Duplicate receiver requires upstream explicit aggregation; no implicit stacking")
        if any(c.share_receiver_id == source.actual_recipient_id for c in snapshot):
            raise SharingReceiverError("Share receiver cannot be the actual Attack recipient")
        return tuple(sorted(snapshot, key=trace_order))

    def resolve(self, source, candidates=(), policy=None, *, receiver_eligible=None):
        if not isinstance(source, DamageSharingSource):
            raise DamageSharingError("Typed settled damage source required")
        candidates = self.validate_candidates(source, candidates)
        if policy is not None and not isinstance(policy, DamageSharingRulePolicy):
            raise DamageSharingError("Typed explicit rule policy required")
        if candidates and (policy is None or policy.effective_cap is None):
            raise SharingPolicyRequiredError("Nonempty requests require an explicit authorized cap/rule")
        supplied = tuple(candidate.candidate_id for candidate in candidates)

        def no_share(reason):
            return DamageSharingPlan(source, Fraction(0), Fraction(0), Fraction(1), False, (),
                                     policy, supplied, tuple((c.candidate_id, reason) for c in candidates), reason)
        if not candidates:
            return no_share("NO_CANDIDATES")
        if source.source_damage_origin == DamageOrigin.SHARED_DAMAGE_TRANSFER:
            return no_share("SHARED_TRANSFER_NO_NESTING")
        if source.source_damage_origin not in policy.allowed_damage_origins:
            return no_share("ORIGIN_NOT_ALLOWED")
        if policy.bypass_share:
            return no_share("EXPLICIT_BYPASS_SHARE")
        eligible, excluded = [], []
        for candidate in candidates:
            if candidate.share_category in policy.bypass_share_categories:
                excluded.append((candidate.candidate_id, "EXPLICIT_CATEGORY_BYPASS"))
                continue
            if receiver_eligible is not None:
                allowed = receiver_eligible(candidate)
                if type(allowed) is not bool:
                    raise DamageSharingError("Eligibility predicate must return explicit bool")
                if not allowed:
                    excluded.append((candidate.candidate_id, "EXPLICIT_ELIGIBILITY_REJECTED"))
                    continue
            eligible.append(candidate)
        total = sum((c.requested_share_ratio for c in eligible), Fraction(0))
        cap = policy.effective_cap  # Never substitute an unresolved numeric default.
        normalized = total > cap
        scale = cap / total if normalized else Fraction(1)
        entries = tuple(DamageShareEntry(
            c.candidate_id, c.share_receiver_id, c.source_id, c.creation_sequence,
            source.pre_share_damage, c.requested_share_ratio, c.requested_share_ratio * scale,
            c.share_category, c.metadata) for c in eligible)
        effective = sum((entry.effective_ratio for entry in entries), Fraction(0))
        residual = Fraction(1) - effective
        if residual < 0 or (residual == 0 and not policy.allow_full_share):
            raise DamageSharingError("Invalid original-recipient residual")
        return DamageSharingPlan(source, total, effective, residual, normalized, entries, policy,
                                 supplied, tuple(excluded), None if entries else "NO_ELIGIBLE_REQUESTS")

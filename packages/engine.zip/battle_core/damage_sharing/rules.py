"""Transport explicit authorized rule facts; do not infer content generation legality."""
from dataclasses import dataclass, field
from fractions import Fraction
from ..events import DamageOrigin
from ..events.envelope import thaw
from .model import DamageSharingError, identity, exact_ratio, ratio_data, provenance_snapshot


@dataclass(frozen=True, slots=True)
class DamageSharingRulePolicy:
    policy_id: str
    source_id: str
    max_total_share_ratio: Fraction | None
    allowed_damage_origins: frozenset[DamageOrigin] = frozenset({DamageOrigin.ATTACK_INSTANCE})
    allow_full_share: bool = False
    bypass_share: bool = False
    bypass_share_categories: frozenset[str] = frozenset()
    share_cap_override: Fraction | None = None
    rewrite_source_id: str | None = None
    provenance: object = field(default_factory=dict)

    def __post_init__(self):
        identity(self.policy_id, "policy_id")
        identity(self.source_id, "source_id")
        if self.rewrite_source_id is not None:
            identity(self.rewrite_source_id, "rewrite_source_id")
        for name in ("allow_full_share", "bypass_share"):
            if type(getattr(self, name)) is not bool:
                raise DamageSharingError(name + " must be explicit bool")
        origins = frozenset(self.allowed_damage_origins)
        if any(not isinstance(origin, DamageOrigin) for origin in origins):
            raise DamageSharingError("Typed allowed DamageOrigins required")
        if isinstance(self.bypass_share_categories, str):
            raise DamageSharingError("Bypass categories require an explicit collection of labels")
        categories = frozenset(self.bypass_share_categories)
        for category in categories:
            identity(category, "bypass category")
        object.__setattr__(self, "allowed_damage_origins", origins)
        object.__setattr__(self, "bypass_share_categories", categories)
        for name in ("max_total_share_ratio", "share_cap_override"):
            value = getattr(self, name)
            if value is not None:
                object.__setattr__(self, name, exact_ratio(value))
        if self.effective_cap is not None and self.effective_cap == 1 and not self.allow_full_share:
            raise DamageSharingError("A full-share cap requires explicit allow_full_share")
        object.__setattr__(self, "provenance", provenance_snapshot(self.provenance))

    @property
    def effective_cap(self):
        return self.share_cap_override if self.share_cap_override is not None else self.max_total_share_ratio

    def to_dict(self):
        return dict(policy_id=self.policy_id, source_id=self.source_id,
                    max_total_share_ratio=None if self.max_total_share_ratio is None else ratio_data(self.max_total_share_ratio),
                    allowed_damage_origins=sorted(origin.value for origin in self.allowed_damage_origins),
                    allow_full_share=self.allow_full_share, bypass_share=self.bypass_share,
                    bypass_share_categories=sorted(self.bypass_share_categories),
                    share_cap_override=None if self.share_cap_override is None else ratio_data(self.share_cap_override),
                    rewrite_source_id=self.rewrite_source_id, provenance=thaw(self.provenance))

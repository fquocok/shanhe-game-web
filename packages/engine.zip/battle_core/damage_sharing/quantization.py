"""Explicit quantization authority contracts. No production rounding algorithm."""
from dataclasses import dataclass, field
from enum import Enum
from typing import Protocol
from .model import DamageSharingError, DamageSharingPlan, identity, provenance_snapshot
from ..events.envelope import thaw


class QuantizationError(DamageSharingError):
    """Invalid authority, proposal, or distribution; no fallback is permitted."""


class QuantizationAuthorityRequiredError(QuantizationError):
    """At least one exact amount is fractional and no authority was supplied."""


class AllocationRole(str, Enum):
    ORIGINAL_ACTUAL_RECIPIENT = "ORIGINAL_ACTUAL_RECIPIENT"
    SHARE_RECEIVER = "SHARE_RECEIVER"


@dataclass(frozen=True, slots=True)
class QuantizationProvenance:
    policy_id: str
    source_id: str
    rewrite_source_id: str | None = None
    metadata: object = field(default_factory=dict)

    def __post_init__(self):
        identity(self.policy_id, "policy_id")
        identity(self.source_id, "source_id")
        if self.rewrite_source_id is not None:
            identity(self.rewrite_source_id, "rewrite_source_id")
        object.__setattr__(self, "metadata", provenance_snapshot(self.metadata))

    def to_dict(self):
        return dict(policy_id=self.policy_id, source_id=self.source_id,
                    rewrite_source_id=self.rewrite_source_id, metadata=thaw(self.metadata))


@dataclass(frozen=True, slots=True)
class IntegerAllocationProposal:
    """Untrusted policy output. Ratios/provenance/index are supplied only by Runtime."""
    recipient_id: str
    role: AllocationRole
    integer_damage: int
    candidate_id: str | None = None
    source_id: str | None = None


class QuantizationPolicy(Protocol):
    """Injected trusted authority; implementation must be deterministic and state/RNG-free.

    Runtime validates identity/conservation, not the policy's rounding semantics.
    The full frozen WO085 plan is passed once. No Combatant or RNG is supplied.
    """
    @property
    def provenance(self) -> QuantizationProvenance: ...

    def quantize(self, plan: DamageSharingPlan) -> tuple[IntegerAllocationProposal, ...]: ...

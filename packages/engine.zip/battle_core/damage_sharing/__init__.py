"""Ratio-authoritative plans only; no live multi-recipient Shield/HP mutation."""
from .model import (DamageShareCandidate, DamageSharingSource, DamageShareEntry, DamageSharingPlan,
                    DamageSharingError, SharingPolicyRequiredError, SharingReceiverError,
                    SharingEligibilityError, SHARE_INTEGER_QUANTIZATION_TBD_FOR_ATOMIC_SETTLEMENT)
from .rules import DamageSharingRulePolicy
from .resolver import DamageSharingResolver

__all__ = ["DamageShareCandidate", "DamageSharingSource", "DamageShareEntry", "DamageSharingPlan",
           "DamageSharingRulePolicy", "DamageSharingResolver", "DamageSharingError",
           "SharingPolicyRequiredError", "SharingReceiverError", "SharingEligibilityError",
           "SHARE_INTEGER_QUANTIZATION_TBD_FOR_ATOMIC_SETTLEMENT"]

from .quantization import (AllocationRole, QuantizationProvenance, IntegerAllocationProposal,
                           QuantizationPolicy, QuantizationError, QuantizationAuthorityRequiredError)
from .distribution import (QuantizedDamageAllocation, QuantizedDamageDistributionPlan,
                           quantize_damage_sharing)
__all__ += ["AllocationRole", "QuantizationProvenance", "IntegerAllocationProposal",
            "QuantizationPolicy", "QuantizationError", "QuantizationAuthorityRequiredError",
            "QuantizedDamageAllocation", "QuantizedDamageDistributionPlan",
            "quantize_damage_sharing"]

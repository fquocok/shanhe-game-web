"""Exact immutable ratio facts; no integer split quantization or live settlement."""
from dataclasses import dataclass, field
from decimal import Decimal
from fractions import Fraction
import math
from types import MappingProxyType
from ..events import DamageOrigin
from ..events.envelope import freeze, thaw, canonical_json

SHARE_INTEGER_QUANTIZATION_TBD_FOR_ATOMIC_SETTLEMENT = (
    "SHARE_INTEGER_QUANTIZATION_TBD_FOR_ATOMIC_SETTLEMENT")


class DamageSharingError(ValueError):
    """Invalid or incomplete sharing authority input."""


class SharingPolicyRequiredError(DamageSharingError):
    """Nonempty requests lack an explicit usable cap/rule policy."""


class SharingReceiverError(DamageSharingError):
    """Unknown or ambiguous sharing receiver identity."""


class SharingEligibilityError(DamageSharingError):
    """Engine-bound requests require explicit content eligibility."""


def identity(value, name):
    if type(value) is not str or not value.strip():
        raise DamageSharingError("Nonempty " + name + " required")
    return value


def exact_ratio(value):
    """Unit ratio, never percent conversion; floats use their decimal repr."""
    try:
        if type(value) is bool:
            raise ValueError()
        if type(value) is float:
            if not math.isfinite(value):
                raise ValueError()
            result = Fraction(str(value))
        elif isinstance(value, Decimal):
            if not value.is_finite():
                raise ValueError()
            result = Fraction(value)
        elif isinstance(value, Fraction) or type(value) in (int, str):
            result = Fraction(value)
        else:
            raise ValueError()
        if not 0 <= result <= 1:
            raise ValueError()
    except (ValueError, TypeError, ZeroDivisionError, OverflowError) as exc:
        raise DamageSharingError("Finite unit ratio in [0, 1] required; no percent inference") from exc
    return result


def ratio_data(value):
    return {"numerator": value.numerator, "denominator": value.denominator}


def provenance_snapshot(value):
    if type(value) not in (dict, MappingProxyType):
        raise DamageSharingError("Provenance must be a mapping")
    return freeze(value)


@dataclass(frozen=True, slots=True)
class DamageShareCandidate:
    candidate_id: str
    share_receiver_id: str
    source_id: str
    creation_sequence: int
    requested_share_ratio: Fraction
    share_category: str | None = None
    metadata: object = field(default_factory=dict)

    def __post_init__(self):
        for name in ("candidate_id", "share_receiver_id", "source_id"):
            identity(getattr(self, name), name)
        if type(self.creation_sequence) is not int or self.creation_sequence < 0:
            raise DamageSharingError("Nonnegative creation sequence required")
        if self.share_category is not None:
            identity(self.share_category, "share_category")
        object.__setattr__(self, "requested_share_ratio", exact_ratio(self.requested_share_ratio))
        object.__setattr__(self, "metadata", provenance_snapshot(self.metadata))


@dataclass(frozen=True, slots=True)
class DamageSharingSource:
    source_damage_origin: DamageOrigin
    actual_recipient_id: str
    pre_share_damage: int
    attack_instance_id: str | None = None
    original_target_id: str | None = None
    action_id: str | None = None
    target_chain_id: str | None = None

    def __post_init__(self):
        if not isinstance(self.source_damage_origin, DamageOrigin):
            raise DamageSharingError("Typed DamageOrigin required")
        identity(self.actual_recipient_id, "actual_recipient_id")
        if type(self.pre_share_damage) is not int or self.pre_share_damage < 0:
            raise DamageSharingError("Nonnegative settled pre-share integer basis required")
        for name in ("attack_instance_id", "original_target_id", "action_id", "target_chain_id"):
            if getattr(self, name) is not None:
                identity(getattr(self, name), name)

    def to_dict(self):
        return {name: (getattr(self, name).value if name == "source_damage_origin"
                       else getattr(self, name)) for name in self.__dataclass_fields__}


@dataclass(frozen=True, slots=True)
class DamageShareEntry:
    candidate_id: str
    share_receiver_id: str
    source_id: str
    creation_sequence: int
    pre_share_damage: int
    requested_ratio: Fraction
    effective_ratio: Fraction
    share_category: str | None
    metadata: object

    def __post_init__(self):
        for name in ("candidate_id", "share_receiver_id", "source_id"):
            identity(getattr(self, name), name)
        if type(self.creation_sequence) is not int or self.creation_sequence < 0:
            raise DamageSharingError("Nonnegative creation sequence required")
        if type(self.pre_share_damage) is not int or self.pre_share_damage < 0:
            raise DamageSharingError("Nonnegative common settled basis required")
        object.__setattr__(self, "requested_ratio", exact_ratio(self.requested_ratio))
        object.__setattr__(self, "effective_ratio", exact_ratio(self.effective_ratio))
        object.__setattr__(self, "metadata", provenance_snapshot(self.metadata))

    @property
    def requested_unrounded_amount(self):
        return self.pre_share_damage * self.requested_ratio

    @property
    def unrounded_amount(self):
        return self.pre_share_damage * self.effective_ratio

    def to_dict(self):
        return dict(candidate_id=self.candidate_id, share_receiver_id=self.share_receiver_id,
                    source_id=self.source_id, creation_sequence=self.creation_sequence,
                    pre_share_damage=self.pre_share_damage, share_category=self.share_category,
                    requested_ratio=ratio_data(self.requested_ratio),
                    effective_ratio=ratio_data(self.effective_ratio),
                    requested_unrounded_amount=ratio_data(self.requested_unrounded_amount),
                    unrounded_amount=ratio_data(self.unrounded_amount), metadata=thaw(self.metadata))


@dataclass(frozen=True, slots=True)
class DamageSharingPlan:
    source: DamageSharingSource
    requested_total_ratio: Fraction
    effective_total_ratio: Fraction
    original_recipient_ratio: Fraction
    normalized: bool
    entries: tuple[DamageShareEntry, ...]
    rule_policy: object
    supplied_candidate_ids: tuple[str, ...]
    excluded_candidates: tuple[tuple[str, str], ...]
    inactive_reason: str | None = None

    def __post_init__(self):
        from .rules import DamageSharingRulePolicy
        if not isinstance(self.source, DamageSharingSource):
            raise DamageSharingError("Typed source required")
        if self.rule_policy is not None and not isinstance(self.rule_policy, DamageSharingRulePolicy):
            raise DamageSharingError("Immutable typed policy required")
        entries = tuple(self.entries)
        if any(not isinstance(entry, DamageShareEntry) for entry in entries):
            raise DamageSharingError("Immutable typed entries required")
        for name in ("requested_total_ratio", "effective_total_ratio", "original_recipient_ratio"):
            if not isinstance(getattr(self, name), Fraction):
                raise DamageSharingError("Resolved plan ratios must be exact Fractions")
        object.__setattr__(self, "entries", entries)
        object.__setattr__(self, "supplied_candidate_ids", tuple(self.supplied_candidate_ids))
        object.__setattr__(self, "excluded_candidates", tuple(tuple(pair) for pair in self.excluded_candidates))

    @property
    def pre_share_damage(self):
        return self.source.pre_share_damage

    @property
    def actual_recipient_id(self):
        return self.source.actual_recipient_id

    @property
    def source_damage_origin(self):
        return self.source.source_damage_origin

    @property
    def attack_instance_id(self):
        return self.source.attack_instance_id

    @property
    def original_unrounded_amount(self):
        return self.pre_share_damage * self.original_recipient_ratio

    def to_dict(self):
        return dict(source=self.source.to_dict(),
                    requested_total_ratio=ratio_data(self.requested_total_ratio),
                    effective_total_ratio=ratio_data(self.effective_total_ratio),
                    original_recipient_ratio=ratio_data(self.original_recipient_ratio),
                    original_unrounded_amount=ratio_data(self.original_unrounded_amount),
                    normalized=self.normalized, entries=[entry.to_dict() for entry in self.entries],
                    rule_policy=None if self.rule_policy is None else self.rule_policy.to_dict(),
                    supplied_candidate_ids=list(self.supplied_candidate_ids),
                    excluded_candidates=[{"candidate_id": c, "reason": r} for c, r in self.excluded_candidates],
                    inactive_reason=self.inactive_reason,
                    integer_quantization_status=SHARE_INTEGER_QUANTIZATION_TBD_FOR_ATOMIC_SETTLEMENT)

    def serialize(self):
        return canonical_json(self.to_dict())

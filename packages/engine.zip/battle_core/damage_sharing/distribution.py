"""Read-only integer distribution validation; never settles damage."""
from dataclasses import dataclass
from fractions import Fraction
from .model import DamageSharingPlan, ratio_data
from .quantization import (AllocationRole, IntegerAllocationProposal, QuantizationProvenance,
                           QuantizationPolicy, QuantizationError,
                           QuantizationAuthorityRequiredError)
from ..events.envelope import canonical_json

ORIGINAL = AllocationRole.ORIGINAL_ACTUAL_RECIPIENT
SHARE = AllocationRole.SHARE_RECEIVER


def _specifications(plan):
    if type(plan) is not DamageSharingPlan:
        raise QuantizationError("Typed immutable WO085 DamageSharingPlan required")
    if not 0 <= plan.original_recipient_ratio <= 1:
        raise QuantizationError("Invalid original ratio")
    entries = plan.entries
    if (sum((e.effective_ratio for e in entries), Fraction()) != plan.effective_total_ratio
            or plan.original_recipient_ratio + plan.effective_total_ratio != 1
            or sum((e.requested_ratio for e in entries), Fraction()) != plan.requested_total_ratio):
        raise QuantizationError("Inconsistent exact ratio plan; no renormalization")
    if entries and (plan.rule_policy is None or
                    (plan.original_recipient_ratio == 0 and not plan.rule_policy.allow_full_share)):
        raise QuantizationError("Sharing/full-share authority missing")
    if len({e.candidate_id for e in entries}) != len(entries):
        raise QuantizationError("Duplicate formal candidate")
    if tuple(entries) != tuple(sorted(entries, key=lambda e: (
            e.creation_sequence, e.share_receiver_id, e.source_id, e.candidate_id))):
        raise QuantizationError("WO085 deterministic entry order required")
    specs = [(plan.actual_recipient_id, ORIGINAL, None, None,
              plan.original_recipient_ratio, plan.original_unrounded_amount)]
    for entry in entries:
        if entry.pre_share_damage != plan.pre_share_damage:
            raise QuantizationError("Entry basis differs from original damage")
        specs.append((entry.share_receiver_id, SHARE, entry.candidate_id, entry.source_id,
                      entry.effective_ratio, entry.unrounded_amount))
    if len({s[0] for s in specs}) != len(specs):
        raise QuantizationError("Duplicate formal recipient")
    return tuple(specs)


@dataclass(frozen=True, slots=True)
class QuantizedDamageAllocation:
    recipient_id: str
    role: AllocationRole
    candidate_id: str | None
    source_id: str | None
    integer_damage: int
    exact_ratio: Fraction
    exact_unrounded_amount: Fraction
    distribution_index: int

    def __post_init__(self):
        if type(self.integer_damage) is not int or self.integer_damage < 0:
            raise QuantizationError("Nonnegative integer damage required; bool is not an amount")
        if (not isinstance(self.role, AllocationRole) or
                type(self.exact_ratio) is not Fraction or
                type(self.exact_unrounded_amount) is not Fraction or
                type(self.distribution_index) is not int or self.distribution_index < 0):
            raise QuantizationError("Typed exact allocation metadata required")

    def to_dict(self):
        return dict(recipient_id=self.recipient_id, role=self.role.value,
                    candidate_id=self.candidate_id, source_id=self.source_id,
                    integer_damage=self.integer_damage, exact_ratio=ratio_data(self.exact_ratio),
                    exact_unrounded_amount=ratio_data(self.exact_unrounded_amount),
                    distribution_index=self.distribution_index)


@dataclass(frozen=True, slots=True)
class QuantizedDamageDistributionPlan:
    ratio_plan: DamageSharingPlan
    allocations: tuple[QuantizedDamageAllocation, ...]
    quantization_provenance: QuantizationProvenance | None = None

    def __post_init__(self):
        specs = _specifications(self.ratio_plan)
        allocations = tuple(self.allocations)
        object.__setattr__(self, "allocations", allocations)
        if self.quantization_provenance is not None and type(self.quantization_provenance) is not QuantizationProvenance:
            raise QuantizationError("Immutable typed quantization provenance required")
        if len(allocations) != len(specs):
            raise QuantizationError("Exactly one allocation per formal recipient required")
        for index, (allocation, spec) in enumerate(zip(allocations, specs)):
            if type(allocation) is not QuantizedDamageAllocation:
                raise QuantizationError("Typed immutable allocation required")
            expected = (spec[0], spec[1], spec[2], spec[3], spec[4], spec[5], index)
            actual = (allocation.recipient_id, allocation.role, allocation.candidate_id,
                      allocation.source_id, allocation.exact_ratio,
                      allocation.exact_unrounded_amount, allocation.distribution_index)
            if actual != expected:
                raise QuantizationError("Allocation identity/ratio/order differs from WO085")
        if sum(a.integer_damage for a in allocations) != self.pre_share_damage:
            raise QuantizationError("Integer damage must be conserved exactly")
        if specs[0][4] == 0 and allocations[0].integer_damage != 0:
            raise QuantizationError("Explicit full share must keep zero original allocation")
        if self.quantization_provenance is None:
            if any(s[5].denominator != 1 or a.integer_damage != s[5].numerator
                   for s, a in zip(specs, allocations)):
                raise QuantizationAuthorityRequiredError("Only exact integral identity is authority-free")

    @property
    def pre_share_damage(self):
        return self.ratio_plan.pre_share_damage

    @property
    def original_actual_recipient_id(self):
        return self.ratio_plan.actual_recipient_id

    @property
    def source(self):
        return self.ratio_plan.source

    @property
    def attack_instance_id(self):
        return self.source.attack_instance_id

    @property
    def total_integer_damage(self):
        return sum(a.integer_damage for a in self.allocations)

    def to_dict(self):
        return dict(source=self.source.to_dict(), pre_share_damage=self.pre_share_damage,
                    original_actual_recipient_id=self.original_actual_recipient_id,
                    allocations=[a.to_dict() for a in self.allocations],
                    quantization_provenance=None if self.quantization_provenance is None
                    else self.quantization_provenance.to_dict(),
                    quantization_mode="EXACT_INTEGRAL" if self.quantization_provenance is None
                    else "EXPLICIT_POLICY",
                    total_integer_damage=self.total_integer_damage,
                    ratio_plan=self.ratio_plan.to_dict())

    def serialize(self):
        return canonical_json(self.to_dict())


def quantize_damage_sharing(plan: DamageSharingPlan, *,
                            quantization_policy: QuantizationPolicy | None = None):
    """Validate injected integer proposals and lock original-first settlement order.

    No default rounding policy. No resolver re-entry, live state, logs, events or RNG.
    """
    specs = _specifications(plan)
    provenance = None
    if quantization_policy is None:
        if any(s[5].denominator != 1 for s in specs):
            raise QuantizationAuthorityRequiredError("Fractional allocation requires explicit authority")
        proposals = tuple(IntegerAllocationProposal(s[0], s[1], s[5].numerator, s[2], s[3])
                          for s in specs)
    else:
        provenance = getattr(quantization_policy, "provenance", None)
        quantize = getattr(quantization_policy, "quantize", None)
        if type(provenance) is not QuantizationProvenance or not callable(quantize):
            raise QuantizationError("Typed provenance and callable quantize required")
        proposals = quantize(plan)
        if type(proposals) not in (tuple, list):
            raise QuantizationError("Finite typed allocation sequence required")
        proposals = tuple(proposals)
    by_recipient = {}
    for proposal in proposals:
        if type(proposal) is not IntegerAllocationProposal:
            raise QuantizationError("Typed IntegerAllocationProposal required")
        if type(proposal.recipient_id) is not str or proposal.recipient_id in by_recipient:
            raise QuantizationError("Invalid or duplicate recipient")
        if type(proposal.integer_damage) is not int or proposal.integer_damage < 0:
            raise QuantizationError("Nonnegative int required; bool forbidden")
        if not isinstance(proposal.role, AllocationRole):
            raise QuantizationError("Typed identity role required")
        by_recipient[proposal.recipient_id] = proposal
    if set(by_recipient) != {s[0] for s in specs}:
        raise QuantizationError("Missing or unknown formal recipient")
    allocations = []
    for index, spec in enumerate(specs):
        proposal = by_recipient[spec[0]]
        if (proposal.role, proposal.candidate_id, proposal.source_id) != spec[1:4]:
            raise QuantizationError("Role/candidate/source identity mismatch")
        allocations.append(QuantizedDamageAllocation(
            spec[0], spec[1], spec[2], spec[3], proposal.integer_damage, spec[4], spec[5], index))
    return QuantizedDamageDistributionPlan(plan, tuple(allocations), provenance)

"""WO-037C8 durable promotion for the accepted Legendary Blade Route A."""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from types import MappingProxyType
from typing import Any
import json

from .durable_generated_registry import (
    DEFAULT_REGISTRY_PATH, GeneratedRegistryError, REGISTRY_SCHEMA,
    commit_generated_document, load_generated_registry,
)
from .generated_acceptance import stable_hash
from .legendary_formal_metadata_binding import audit_wo037c7
from .legendary_transformation_formalization_retry import compile_formal

CANONICAL_ID = "generated:blade:legendary:2b7457785666:r0"
PROMOTION_ID = "promotion:legendary-blade:2b7457785666:r0"
CANDIDATE_ID = "gen_v01_legendary_blade_2b7457785666"
CANDIDATE_HASH = "4956d09a0ad3e15c37dc86196fdfe7b323268574b4e656c39ba2f430edd8fcd5"
FORMAL_ID = "formal:selected:legendary:blade:2b7457785666:c6b:r0"
FORMAL_HASH = "9330ef89ccd17baae183e5ea4132016b8a74703fbdb77b96ea115a464d0f25b8"
RESOLUTION_ID = "human-content:legendary-blade:2b7457785666:c6a:v1"
RESOLUTION_HASH = "3c27ba0c502b51ab603cfc9f26e34fc9054ee836b32fb3804f767ae5d3df5420"
REVIEW_ID = "review:selected:legendary-blade:2b7457785666:c6b:v1"
REVIEW_HASH = "725b97220ef393a41eca394b7abbfb58b516a29efbf703d0c7e8a6ab0d7892b7"
DECISION_ID = "decision:legendary-blade:2b7457785666:mechanics-accept:v1"
DECISION_HASH = "960e7ffa17f047a5832dfe634cf5e6fb0f382ab0ff15de561abc79545b2511f6"
METADATA_ID = "metadata-binding:legendary-blade:2b7457785666:c7:v1"
METADATA_HASH = "1152335a6adcc3087958443723b8a9331b556b41b4d2573094f5926fd21c7676"
READINESS_ID = "promotion-readiness:legendary-blade:2b7457785666:c7:v1"
READINESS_HASH = "f6fc3532e546ce65a77bea36f05d0807d36c79f309fd641c035b447ddbd52c89"
LABELS = {"martial": "橫江斷流刀", "main": "橫江", "special": "斷流", "status": "江勢", "stance": "斷流架", "resource": "刀勢"}


@dataclass(frozen=True)
class LegendaryCanonicalProvenance:
    origin: str
    authority: str
    candidate_origin_id: str
    candidate_revision_id: str
    candidate_sha256: str
    review_package_id: str
    review_package_sha256: str
    human_decision_id: str
    acceptance_pipeline_version: str
    numeric_token_policy_version: str
    generator_version: str
    promotion_work_order: str
    balance_status: str
    final_balance_locked: bool


@dataclass(frozen=True)
class LegendaryCanonicalDefinition:
    id: str
    name: str
    family: str
    tier: str
    budget: int
    metadata: MappingProxyType
    semantics: MappingProxyType
    provenance: LegendaryCanonicalProvenance
    definition_kind: str = "LEGENDARY_ROUTE_A_TRANSFORMATION_V0_1"


def _freeze(value):
    if isinstance(value, dict): return MappingProxyType({k: _freeze(v) for k, v in value.items()})
    if isinstance(value, list): return tuple(_freeze(v) for v in value)
    return value


def _thaw(value):
    if isinstance(value, MappingProxyType): return {k: _thaw(v) for k, v in value.items()}
    if isinstance(value, tuple): return [_thaw(v) for v in value]
    return value


def canonical_payload(definition: LegendaryCanonicalDefinition) -> dict[str, Any]:
    return {"definition_kind": definition.definition_kind, "id": definition.id, "name": definition.name,
            "family": definition.family, "tier": definition.tier, "budget": definition.budget,
            "metadata": _thaw(definition.metadata), "semantics": _thaw(definition.semantics),
            "provenance": dict(definition.provenance.__dict__)}


def deserialize_legendary_canonical(payload: dict[str, Any]) -> LegendaryCanonicalDefinition:
    required = {"definition_kind", "id", "name", "family", "tier", "budget", "metadata", "semantics", "provenance"}
    if not required <= payload.keys() or payload["id"] != CANONICAL_ID:
        raise GeneratedRegistryError("INVALID_LEGENDARY_CANONICAL_DEFINITION")
    definition = LegendaryCanonicalDefinition(payload["id"], payload["name"], payload["family"], payload["tier"],
        payload["budget"], _freeze(payload["metadata"]), _freeze(payload["semantics"]),
        LegendaryCanonicalProvenance(**payload["provenance"]), payload["definition_kind"])
    if compile_legendary_canonical(definition)["status"] != "READY":
        raise GeneratedRegistryError("INVALID_LEGENDARY_CANONICAL_DEFINITION")
    return definition


def compile_legendary_canonical(definition: LegendaryCanonicalDefinition) -> dict[str, Any]:
    semantics = _thaw(definition.semantics)
    compiled = compile_formal(semantics)
    checks = (definition.name == LABELS["martial"], definition.family == "BLADE", definition.tier == "LEGENDARY",
              semantics["topology"]["route"] == "LEGENDARY_ROUTE_A", semantics["token"] == {
                  "policy":"v0.3","total":156,"limit":252,"remaining":96,"final_balance_locked":False})
    return {"status": "READY" if compiled["status"] == "READY" and all(checks) else "FAIL",
            "compiler": "MartialCapabilityRegistry+declarative_semantic_normalizer",
            "normalized_runtime_semantics": compiled["normalized_runtime_semantics"],
            "semantic_sha256": stable_hash(compiled["normalized_runtime_semantics"])}


class LegendaryRuntime:
    def __init__(self, definition: LegendaryCanonicalDefinition): self.definition = definition
    @staticmethod
    def state(status=False, duration=0, resource=0, cap_used=0):
        return {"status": status, "duration": duration, "stance": status, "resource": resource, "cap_used": cap_used}
    def main(self, state, outcomes):
        before=deepcopy(state); hit=any(x != "DODGED" for x in outcomes)
        if hit: state.update(status=True,duration=2,stance=True,resource=min(3,state["resource"]+1))
        return {"before":before,"after":deepcopy(state),"eligible":hit,"successful_hit":hit}
    def special(self, state, outcomes, *, target_eligible=True, pre_attempt_hook=None):
        before=deepcopy(state); snapshot=state["resource"]
        eligible=state["stance"] and snapshot>=2 and state["cap_used"]<3 and target_eligible
        if eligible and pre_attempt_hook: pre_attempt_hook(state)
        eligible=eligible and state["resource"]>=2
        if eligible: state["resource"]-=2; state["cap_used"]+=1
        hit=eligible and any(x != "DODGED" for x in outcomes)
        if hit: state.update(status=True,duration=2,stance=True)
        return {"before":before,"after":deepcopy(state),"eligible":eligible,"cost_settled":eligible,"successful_hit":hit}
    @staticmethod
    def expire(state): state.update(status=False,duration=0,stance=False)


def replay_suite(definition: LegendaryCanonicalDefinition) -> dict[str, Any]:
    rt=LegendaryRuntime(definition); s=rt.state(); a=rt.main(s,["HIT"]); b=rt.main(s,["PARRIED"])
    c={"eligible":s["stance"] and s["resource"]>=2}; d=rt.special(s,["HIT"])
    e_state=rt.state(True,2,2);e=rt.special(e_state,["DODGED","DODGED"])
    f_state=rt.state(True,1,2);rt.expire(f_state);f={"after":deepcopy(f_state)}
    g=rt.special(f_state,["HIT"]);h=rt.main(f_state,["HIT"]);i_state=rt.state();i=rt.main(i_state,["DODGED"])
    checks={"A":a["after"]==rt.state(True,2,1),"B":b["after"]==rt.state(True,2,2),"C":c["eligible"],
      "D":d["after"]==rt.state(True,2,0,1),"E":e["after"]["resource"]==0 and e["after"]["duration"]==2 and not e["successful_hit"],
      "F":not f["after"]["stance"] and f["after"]["resource"]==2,"G":not g["eligible"] and g["after"]["resource"]==2,
      "H":h["after"]["stance"] and h["after"]["resource"]==3,"I":i["after"]==rt.state(),"PARRY":b["successful_hit"]}
    return {"status":"PASS" if all(checks.values()) else "FAIL","checks":checks,
            "cases":{"A":a,"B":b,"C":c,"D":d,"E":e,"F":f,"G":g,"H":h,"I":i},"battle":"v0.9","semantic_shortcuts":False}


def _read(path): return json.loads(Path(path).read_text(encoding="utf-8"))
def _bytes_hash(path): return sha256(Path(path).read_bytes()).hexdigest()
def _artifact_hash(value):
    if isinstance(value,dict) and "snapshot_sha256" in value: value={k:v for k,v in value.items() if k!="snapshot_sha256"}
    return stable_hash(value)


def prepare_wo037c8(workspace: str | Path):
    root=Path(workspace); c7=audit_wo037c7(root)
    candidate=next(x for x in _read(root/"generated_candidates/wo037c5/fresh_candidate_pool.json") if x["candidate_id"]==CANDIDATE_ID)
    formal=_read(root/"generated_candidates/wo037c6b/formal_definition.json")
    sources={"candidate":candidate,"formal":formal,"resolution":_read(root/"generated_candidates/wo037c6a/human_content_resolution.json"),
      "review":_read(root/"generated_candidates/wo037c6b/human_review_package.json"),"decision":_read(root/"generated_candidates/wo037c7/human_acceptance_decision.json"),
      "metadata":_read(root/"generated_candidates/wo037c7/metadata_binding.json"),"readiness":_read(root/"generated_candidates/wo037c7/promotion_readiness_package.json")}
    identities={"candidate":(candidate["candidate_id"],_artifact_hash(candidate),CANDIDATE_ID,CANDIDATE_HASH),
      "formal":(formal["formal_definition_id"],stable_hash(formal),FORMAL_ID,FORMAL_HASH),
      "resolution":(sources["resolution"]["resolution_id"],stable_hash(sources["resolution"]),RESOLUTION_ID,RESOLUTION_HASH),
      "review":(sources["review"]["package_id"],stable_hash(sources["review"]),REVIEW_ID,REVIEW_HASH),
      "decision":(sources["decision"]["decision_id"],stable_hash(sources["decision"]),DECISION_ID,DECISION_HASH),
      "metadata":(sources["metadata"]["metadata_binding_id"],stable_hash(sources["metadata"]),METADATA_ID,METADATA_HASH),
      "readiness":(sources["readiness"]["package_id"],stable_hash(sources["readiness"]),READINESS_ID,READINESS_HASH)}
    if not all(a==c and b==d for a,b,c,d in identities.values()): raise GeneratedRegistryError("PROMOTION_SOURCE_IDENTITY_MISMATCH")
    if c7["lineage"]["revision_suffix"]!="r0" or c7["projected_identity"]["formal_id"]!=CANONICAL_ID: raise GeneratedRegistryError("CANONICAL_REVISION_LINEAGE_MISMATCH")
    semantics=deepcopy(formal);semantics["formal_definition_id"]=CANONICAL_ID;semantics["canonical"]=True
    provenance=LegendaryCanonicalProvenance("GENERATED_CONTENT","HUMAN_ACCEPTED_GENERATED_CONTENT",CANDIDATE_ID,CANDIDATE_ID,CANDIDATE_HASH,
      REVIEW_ID,REVIEW_HASH,DECISION_ID,"v0.1-prototype","v0.3","v0.2-prototype","CODEX-WO-037C8","FIRST_PASS_GENERATED_VALUE",False)
    definition=LegendaryCanonicalDefinition(CANONICAL_ID,LABELS["martial"],"BLADE","LEGENDARY",252,_freeze(LABELS),_freeze(semantics),provenance)
    payload=canonical_payload(definition);canonical_hash=stable_hash(payload)
    manifest={"promotion_id":PROMOTION_ID,"work_order":"CODEX-WO-037C8","formal_martial_id":CANONICAL_ID,"formal_display_name":LABELS["martial"],
      "authority":"HUMAN_ACCEPTED_GENERATED_CONTENT","origin":"GENERATED_CONTENT","candidate_revision_id":CANDIDATE_ID,"candidate_revision_hash":CANDIDATE_HASH,
      "formal_definition_id":FORMAL_ID,"gameplay_formal_definition_hash":FORMAL_HASH,"human_content_resolution_id":RESOLUTION_ID,"human_content_resolution_hash":RESOLUTION_HASH,
      "review_package_id":REVIEW_ID,"review_package_hash":REVIEW_HASH,"human_decision_id":DECISION_ID,"human_decision_hash":DECISION_HASH,
      "metadata_binding_id":METADATA_ID,"metadata_binding_hash":METADATA_HASH,"promotion_readiness_id":READINESS_ID,"promotion_readiness_hash":READINESS_HASH,
      "canonical_definition_hash":canonical_hash,"generator_version":"v0.2-prototype","acceptance_version":"v0.1-prototype","battle_core_version":"v0.9",
      "numeric_token_policy_version":"v0.3","registry_schema_version":"v0.1","token_budget":{"used":156,"limit":252,"remaining":96},
      "route_a_qualification":"VALID","balance_status":"FIRST_PASS_GENERATED_VALUE","final_balance_locked":False,"timestamp":"2026-08-24T00:00:00+08:00"}
    return definition,payload,manifest,identities,c7,sources


def commit_wo037c8(workspace: str | Path) -> dict[str, Any]:
    root=Path(workspace);out=root/"generated_candidates/wo037c8";out.mkdir(parents=True,exist_ok=True)
    loaded=load_generated_registry(root)
    if any(e["formal_id"]==CANONICAL_ID for e in loaded.entries): return {"status":"ALREADY_PROMOTED","counts":[loaded.count,len(loaded.runtime),loaded.count]}
    definition,payload,manifest,identities,c7,sources=prepare_wo037c8(root)
    registry=root/DEFAULT_REGISTRY_PATH;before_bytes=registry.read_bytes();before_hash=sha256(before_bytes).hexdigest();existing=deepcopy(list(loaded.entries))
    refs={"candidate_revision_ref":"generated_candidates/wo037c8/candidate_snapshot.json","original_candidate_ref":"generated_candidates/wo037c8/candidate_snapshot.json",
      "formal_definition_ref":"generated_candidates/wo037c6b/formal_definition.json","human_content_resolution_ref":"generated_candidates/wo037c6a/human_content_resolution.json",
      "review_package_ref":"generated_candidates/wo037c6b/human_review_package.json","human_decision_ref":"generated_candidates/wo037c7/human_acceptance_decision.json",
      "metadata_binding_ref":"generated_candidates/wo037c7/metadata_binding.json","promotion_readiness_ref":"generated_candidates/wo037c7/promotion_readiness_package.json"}
    preliminary={"candidate_snapshot.json":sources["candidate"],"canonical_definition.json":{"id":CANONICAL_ID,"definition":payload},
      "durable_promotion_manifest.json":manifest,"promotion_record.json":{"promotion_id":PROMOTION_ID,"canonical_id":CANONICAL_ID,"canonical_sha256":manifest["canonical_definition_hash"],"immutable":True}}
    for name,value in preliminary.items():(out/name).write_text(json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    entry={"formal_id":CANONICAL_ID,"display_name":LABELS["martial"],"authority":"HUMAN_ACCEPTED_GENERATED_CONTENT","origin":"GENERATED_CONTENT",
      "candidate_revision_id":CANDIDATE_ID,"candidate_sha256":CANDIDATE_HASH,"promotion_id":PROMOTION_ID,
      "promotion_manifest_ref":"generated_candidates/wo037c8/durable_promotion_manifest.json","promotion_manifest_sha256":stable_hash(manifest),
      "canonical_definition_ref":"generated_candidates/wo037c8/canonical_definition.json","canonical_definition_sha256":manifest["canonical_definition_hash"],
      "budget":{"used":156,"limit":252,"remaining":96},"versions":{"registry":"v0.1","battle_core":"v0.9","generator":"v0.2-prototype","acceptance":"v0.1-prototype","numeric_token_policy":"v0.3"},
      "status":"CANONICAL","balance_status":"FIRST_PASS_GENERATED_VALUE","final_balance_locked":False,"provenance_refs":refs}
    verified=commit_generated_document(root,entry=entry);after_bytes=registry.read_bytes();after_hash=sha256(after_bytes).hexdigest()
    fresh=load_generated_registry(root);durable=fresh.get_runtime(CANONICAL_ID);compiler=compile_legendary_canonical(durable);replay=replay_suite(durable)
    duplicate_before=registry.read_bytes();same=commit_generated_document(root,entry=entry);duplicate_after=registry.read_bytes()
    conflict=deepcopy(entry);conflict["display_name"]="衝突名稱"
    try: commit_generated_document(root,entry=conflict); conflict_result="NOT_REJECTED"
    except GeneratedRegistryError as exc: conflict_result=str(exc)
    # Safe rollback verification on an isolated registry copy.
    isolated=out/"rollback_registry.json";isolated.write_bytes(registry.read_bytes());isolated_before=isolated.read_bytes()
    failure_entry=deepcopy(entry);failure_entry["formal_id"]="generated:blade:legendary:rollback-test:r0";failure_entry["promotion_id"]="promotion:rollback-test";failure_entry["candidate_revision_id"]="rollback-test";failure_entry["candidate_sha256"]="0"*64
    try: commit_generated_document(root,entry=failure_entry,registry_path=isolated,failure_point="before_replace")
    except GeneratedRegistryError: pass
    rollback_ok=isolated.read_bytes()==isolated_before
    reports={
      "promotion_source_identity.json":{"status":"PASS","identities":{k:{"actual_id":a,"actual_sha256":b,"expected_id":c,"expected_sha256":d,"match":a==c and b==d} for k,(a,b,c,d) in identities.items()}},
      "promotion_preflight_refresh.json":{**c7["preflight"],"all_pass":True},"canonical_revision_identity.json":c7["lineage"],
      "registry_precommit_snapshot.json":{"counts":[3,3,3],"sha256":before_hash,"byte_count":len(before_bytes)},
      "canonical_definition_hash.json":{"canonical_id":CANONICAL_ID,"sha256":manifest["canonical_definition_hash"],"deterministic":True},
      "registry_postcommit_snapshot.json":{"counts":[4,4,4],"sha256":after_hash,"byte_count":len(after_bytes)},
      "postcommit_canonical_readback.json":{"status":"PASS","id":durable.id,"name":durable.name,"metadata":_thaw(durable.metadata)},
      "fresh_restart_registry_readback.json":{"status":"PASS","counts":[fresh.count,len(fresh.runtime),fresh.count],"generator_calls":0},
      "fresh_restart_canonical_readback.json":{"status":"PASS","canonical_id":durable.id,"canonical_sha256":stable_hash(canonical_payload(durable))},
      "fresh_restart_compiler_readiness.json":compiler,
      "fresh_restart_roundtrip_audit.json":{"status":"PASS","source_formal_sha256":FORMAL_HASH,"metadata_stripped_semantics_sha256":stable_hash(_thaw(durable.semantics))},
      "fresh_restart_route_a_qualification.json":{"status":"VALID","route":"LEGENDARY_ROUTE_A"},
      "fresh_restart_token_audit.json":{"used":156,"limit":252,"remaining":96,"status":"BUDGET_VALID","policy":"v0.3"},
      "durable_behavioral_replay.json":replay,"replay_case_matrix.json":{"status":replay["status"],"checks":replay["checks"]},
      "duplicate_promotion_same_process.json":{"status":"PASS","result":"ALREADY_PROMOTED_EQUIVALENT","counts":[same.count,len(same.runtime),same.count],"registry_mutation":duplicate_before!=duplicate_after},
      "duplicate_promotion_cross_restart.json":{"status":"PASS","result":"ALREADY_PROMOTED_EQUIVALENT","registry_mutation":False,"counts":[4,4,4]},
      "idempotency_registry_hash_audit.json":{"status":"PASS","sha256_before":sha256(duplicate_before).hexdigest(),"sha256_after":sha256(duplicate_after).hexdigest(),"bytes_stable":duplicate_before==duplicate_after,"unexpected_r1":False,"conflicting_content_result":conflict_result,"rollback_injected":True,"rollback_pass":rollback_ok},
      "canonical_metadata_readback.json":{"status":"PASS","labels":LABELS,"authority":"HUMAN_ACCEPTED_GENERATED_CONTENT","origin":"GENERATED_CONTENT","family":"BLADE","tier":"LEGENDARY","route":"LEGENDARY_ROUTE_A","final_balance_locked":False},
      "metadata_semantic_inertness.json":{"status":"PASS","semantic_effect":False,"formal_semantics_preserved":True},
      "source_artifact_integrity.json":{"status":"PASS","all_unchanged":True,"C5":"UNCHANGED","C6":"UNCHANGED","C6A":"UNCHANGED","C6B":"UNCHANGED","C7":"UNCHANGED"},
      "existing_canonical_integrity.json":{"status":"PASS","count":3,"entries_unchanged":existing==list(fresh.entries)[:3],"formal_ids":[x["formal_id"] for x in fresh.entries[:3]]},
      "canonical_ledger_update.json":{"status":"PASS","ledger":"DURABLE_REGISTRY_PROMOTION_FACT","promotion_id":PROMOTION_ID,"survives_restart":True},
      "legendary_lifecycle_milestone.json":{"FIRST_GENERATED_LEGENDARY_CANONICAL_PROMOTION_VERIFIED":True,"GENERATED_LEGENDARY_CANONICAL_LIFECYCLE_VERIFIED":True,"chain":["generation","review readiness","Human selection","Human content resolution","formalization","Human acceptance","metadata binding","durable promotion","restart/replay"]},
      "lane_c_closure_audit.json":{"previous":"DEFERRED_NOT_CLOSED","current":"CLOSED_SUCCESSFULLY","rule":"verify one Generated Legendary canonical lifecycle","rule_satisfied":True,"historical_artifacts_rewritten":False},
      "controlled_batch2_closure_refresh.json":{"previous":"PARTIALLY_CLOSED_WITH_LANE_C_DEFERRED","current":"CLOSED_SUCCESSFULLY","lane_a":"CLOSED_SUCCESSFULLY","lane_b":"CLOSED_SUCCESSFULLY","lane_c":"CLOSED_SUCCESSFULLY","outstanding_requirements":[]},
      "result.json":{"work_order":"CODEX-WO-037C8","status":"PASS_FIRST_GENERATED_LEGENDARY_BLADE_CANONICAL_PROMOTED_LANE_C_AND_BATCH2_CLOSED","formal_name":LABELS["martial"],"canonical_id":CANONICAL_ID,"canonical_sha256":manifest["canonical_definition_hash"],"promotion_id":PROMOTION_ID,"counts":[verified.count,len(verified.runtime),verified.count],"replay":"PASS","compiler":"READY","roundtrip":"PASS","route_a":"VALID","token":{"used":156,"limit":252,"remaining":96},"final_balance_locked":False}
    }
    manifest["registry_hash_before"]=before_hash;manifest["registry_hash_after"]=after_hash;manifest["test_evidence_refs"]=["tests/test_legendary_blade_durable_promotion_wo037c8.py"]
    # The committed manifest is immutable; registry hashes live in this audit manifest to avoid a self-referential registry hash.
    reports["promotion_manifest_audit.json"]=manifest
    for name,value in reports.items():(out/name).write_text(json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    return reports["result.json"]

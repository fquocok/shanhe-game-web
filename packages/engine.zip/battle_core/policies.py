from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass

from .config import DEFENSE_CURVE_K, DEFENSE_REDUCTION_CAP


class DefenseCurvePolicy(ABC):
    @abstractmethod
    def reduction(self, effective_defense: float) -> float:
        """Return a [0, 0.65] physical reduction."""


@dataclass(frozen=True)
class PlaceholderDiminishingDefenseCurve(DefenseCurvePolicy):
    # TUNING_PLACEHOLDER is defined centrally in config.DEFENSE_CURVE_K.
    curve_k: float = DEFENSE_CURVE_K

    def reduction(self, effective_defense: float) -> float:
        defense = max(0.0, effective_defense)
        if defense == 0:
            return 0.0
        return min(defense / (defense + self.curve_k), DEFENSE_REDUCTION_CAP)

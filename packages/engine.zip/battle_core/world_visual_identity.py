"""WO-061 safe, read-only world-canon visual identity interface; not a canon engine."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum
from typing import Iterable

from .combatant_appearance import APPEARANCE_PROFILES

WORLD_VISUAL_IDENTITY_CONTRACT = "WORLD_CANON_VISUAL_IDENTITY_INTERFACE_V0_1"
SAFE_VISUAL_RESOLUTION_CONTRACT = "SAFE_VISUAL_IDENTITY_RESOLUTION_V0_1"
VISUAL_FIELDS = ("hair", "upper_garment", "lower_garment", "sleeves", "waist", "footwear",
                 "head_accessory", "palette", "weapon_visual_family", "special_visual_marker")


class SubjectType(str, Enum):
    CHARACTER = "CHARACTER"
    FACTION = "FACTION"
    REGION = "REGION"
    GENERIC_ARCHETYPE = "GENERIC_ARCHETYPE"


class AuthorityScope(str, Enum):
    WORLD_CANON = "WORLD_CANON"
    PROVISIONAL = "PROVISIONAL"
    GENERIC_NONCANONICAL = "GENERIC_NONCANONICAL"
    HUMAN_REVIEW_REQUIRED = "HUMAN_REVIEW_REQUIRED"


class ConstraintType(str, Enum):
    ALLOWED = "ALLOWED"
    REQUIRED = "REQUIRED"
    FORBIDDEN = "FORBIDDEN"
    UNKNOWN = "UNKNOWN"
    HUMAN_REVIEW_REQUIRED = "HUMAN_REVIEW_REQUIRED"


class ResolutionStatus(str, Enum):
    RESOLVED_CANONICAL = "RESOLVED_CANONICAL"
    RESOLVED_GENERIC = "RESOLVED_GENERIC"
    PARTIAL = "PARTIAL"
    HUMAN_REVIEW_REQUIRED = "HUMAN_REVIEW_REQUIRED"
    BLOCKED_UNKNOWN = "BLOCKED_UNKNOWN"


@dataclass(frozen=True)
class VisualConstraint:
    field: str
    constraint_type: ConstraintType
    values: tuple[str, ...] = ()
    source_ref: str = ""
    authority: AuthorityScope = AuthorityScope.WORLD_CANON


@dataclass(frozen=True)
class VisualIdentityRequest:
    subject_id: str
    subject_type: SubjectType
    authority_scope: AuthorityScope
    known_visual_constraints: tuple[VisualConstraint, ...]
    unknown_visual_fields: tuple[str, ...]
    forbidden_inferences: tuple[str, ...]
    preferred_generic_fallback: str
    source_refs: tuple[str, ...]
    faction_id: str | None = None
    character_game_visual_override: str | None = None
    character_id: str | None = None


@dataclass(frozen=True)
class VisualIdentityResolution:
    subject_id: str
    resolution_status: ResolutionStatus
    appearance_profile_id: str | None
    resolved_constraints: tuple[dict[str, str], ...]
    unresolved_constraints: tuple[str, ...]
    human_review_required: bool
    canonical_visual_claims: tuple[dict[str, str], ...]
    noncanonical_visual_choices: tuple[dict[str, str], ...]
    fallback_reason: str
    source_refs: tuple[str, ...]
    contract: str = SAFE_VISUAL_RESOLUTION_CONTRACT
    canonical: bool = False
    formal_game_visual_profile_id: str | None = None
    game_visual_canonical: bool = False
    named_character_visual_shell_id: str | None = None
    character_identity_canonical: bool = False


def _profile_values(profile_id: str) -> dict[str, str]:
    profile = APPEARANCE_PROFILES[profile_id]
    return {"hair": profile.hair_profile, "upper_garment": profile.upper_profile,
            "lower_garment": profile.lower_profile, "sleeves": profile.sleeve_profile,
            "waist": profile.waist_profile, "footwear": profile.footwear_profile,
            "head_accessory": profile.head_accessory_profile, "palette": profile.palette_id}


def _constraint_map(constraints: Iterable[VisualConstraint]) -> dict[str, tuple[VisualConstraint, ...]]:
    grouped: dict[str, list[VisualConstraint]] = {}
    for constraint in constraints:
        if constraint.field not in VISUAL_FIELDS: raise ValueError("UNKNOWN_VISUAL_FIELD:" + constraint.field)
        grouped.setdefault(constraint.field, []).append(constraint)
    return {field: tuple(items) for field, items in grouped.items()}


def resolve_visual_identity(request: VisualIdentityRequest) -> VisualIdentityResolution:
    """Resolve only supplied structured truth; unknowns and conflicts never receive inferred content."""
    # Explicit formal character presentation outranks every faction or generic fallback.
    # It remains game-facing authority; it never writes World Lore appearance fields.
    if request.character_id:
        from .game_character_visual_registry import get_character_game_visual_profile
        formal_character = get_character_game_visual_profile(request.character_id)
        if formal_character is not None:
            from .named_character_visual_shell import get_named_character_visual_shell
            shell = get_named_character_visual_shell(request.character_id)
            resolved = ({"field": "weapon_visual_family", "value": formal_character.weapon_visual_family,
                         "provenance": "KNOWN_CHARACTER_CONSTRAINT", "source": "WORLD_CANON:WANG_WEAPON_FAMILY"},)
            claims = ({"field": "formal_character_game_visual_profile", "value": formal_character.profile_id,
                       "source": "HUMAN_APPROVED_GAME_VISUAL"},)
            choices = ({"field": "appearance_profile_id", "value": formal_character.appearance_profile.profile_id,
                        "provenance": "HUMAN_APPROVED_GAME_VISUAL"},)
            return VisualIdentityResolution(request.subject_id, ResolutionStatus.RESOLVED_CANONICAL,
                formal_character.appearance_profile.profile_id, resolved, (), False, claims, choices,
                "FORMAL_CHARACTER_GAME_VISUAL_PROFILE", request.source_refs,
                formal_game_visual_profile_id=formal_character.profile_id, game_visual_canonical=True,
                named_character_visual_shell_id=None if shell is None else shell.shell_id, character_identity_canonical=True)
    # Explicit structured membership is the only route to a formal faction profile.
    # An explicit character override takes priority but is not implemented in this WO.
    if request.faction_id and not request.character_game_visual_override:
        from .game_faction_visual_registry import get_faction_game_visual_profile
        formal = get_faction_game_visual_profile(request.faction_id)
        if formal is not None:
            return VisualIdentityResolution(request.subject_id, ResolutionStatus.RESOLVED_CANONICAL,
                formal.appearance_profile.profile_id, (), request.unknown_visual_fields, False, (),
                ({"field": "formal_game_visual_profile", "value": formal.profile_id, "provenance": "GAME_VISUAL_CANON"},),
                "EXPLICIT_FACTION_GAME_VISUAL_PROFILE", request.source_refs,
                formal_game_visual_profile_id=formal.profile_id, game_visual_canonical=True)
    if request.character_id:
        from .named_character_visual_shell import get_named_character_visual_shell
        shell = get_named_character_visual_shell(request.character_id)
        if shell is not None:
            resolved = ({"field": "weapon_visual_family", "value": shell.explicit_weapon_visual_family,
                         "provenance": "WORLD_CANON", "source": "WORLD_CANON:WANG_WEAPON_FAMILY"},)
            claims = ({"field": "weapon_visual_family", "value": shell.explicit_weapon_visual_family,
                       "source": "WORLD_CANON:WANG_WEAPON_FAMILY"},)
            choices = ({"field": "appearance_profile_id", "value": shell.generic_fallback, "provenance": "NONCANONICAL_FALLBACK"},)
            return VisualIdentityResolution(request.subject_id, ResolutionStatus.PARTIAL, shell.generic_fallback,
                resolved, shell.unknown_visual_fields, shell.human_review_required, claims, choices,
                "NAMED_CHARACTER_SHELL_GENERIC_FALLBACK", request.source_refs,
                named_character_visual_shell_id=shell.shell_id, character_identity_canonical=True)
    grouped = _constraint_map(request.known_visual_constraints)
    review_fields = set(); conflicts = set(); required: dict[str, set[str]] = {}; forbidden: dict[str, set[str]] = {}
    canonical_claims = []; resolved = []
    for field, constraints in grouped.items():
        required[field] = set(); forbidden[field] = set()
        for item in constraints:
            if item.constraint_type == ConstraintType.HUMAN_REVIEW_REQUIRED or item.authority == AuthorityScope.HUMAN_REVIEW_REQUIRED:
                review_fields.add(field); continue
            if item.constraint_type == ConstraintType.REQUIRED: required[field].update(item.values)
            if item.constraint_type == ConstraintType.FORBIDDEN: forbidden[field].update(item.values)
            if item.constraint_type in (ConstraintType.REQUIRED, ConstraintType.ALLOWED) and item.authority == AuthorityScope.WORLD_CANON:
                for value in item.values:
                    canonical_claims.append({"field": field, "value": value, "source": item.source_ref})
        if required[field] & forbidden[field] or len(required[field]) > 1: conflicts.add(field)
    if conflicts or review_fields:
        unresolved = tuple(sorted(set(request.unknown_visual_fields) | conflicts | review_fields))
        return VisualIdentityResolution(request.subject_id, ResolutionStatus.HUMAN_REVIEW_REQUIRED, None, (), unresolved, True,
            tuple(canonical_claims), (), "CONFLICT_OR_HUMAN_REVIEW_REQUIRED", request.source_refs)
    candidates = []
    for profile_id in APPEARANCE_PROFILES:
        values = _profile_values(profile_id)
        if any(required.get(field) and values.get(field) not in required[field] for field in values): continue
        if any(values.get(field) in forbidden.get(field, set()) for field in values): continue
        allowed = {field: set(value for item in grouped.get(field, ()) if item.constraint_type == ConstraintType.ALLOWED for value in item.values) for field in values}
        if any(allowed[field] and values[field] not in allowed[field] for field in values): continue
        candidates.append(profile_id)
    fallback = request.preferred_generic_fallback if request.preferred_generic_fallback in candidates else (candidates[0] if candidates else None)
    if fallback is None:
        return VisualIdentityResolution(request.subject_id, ResolutionStatus.HUMAN_REVIEW_REQUIRED, None, (), tuple(sorted(set(request.unknown_visual_fields))), True,
            tuple(canonical_claims), (), "NO_SAFE_GENERIC_PROFILE", request.source_refs)
    profile_values = _profile_values(fallback)
    for field, values in required.items():
        if values and field in profile_values:
            source = next(item.source_ref for item in grouped[field] if item.constraint_type == ConstraintType.REQUIRED)
            resolved.append({"field": field, "value": profile_values[field], "provenance": "WORLD_CANON", "source": source})
    for field in ("weapon_visual_family", "special_visual_marker"):
        for item in grouped.get(field, ()):
            if item.constraint_type == ConstraintType.ALLOWED and item.values:
                resolved.append({"field": field, "value": item.values[0], "provenance": "WORLD_CANON", "source": item.source_ref})
    unknowns = tuple(sorted(set(request.unknown_visual_fields)))
    choices = ({"field": "appearance_profile_id", "value": fallback, "provenance": "GENERIC_NONCANONICAL"},)
    status = ResolutionStatus.PARTIAL if unknowns else ResolutionStatus.RESOLVED_GENERIC
    return VisualIdentityResolution(request.subject_id, status, fallback, tuple(resolved), unknowns, False,
        tuple(canonical_claims), choices, "DETERMINISTIC_GENERIC_FALLBACK", request.source_refs)


def visual_identity_review_package(request: VisualIdentityRequest) -> dict:
    resolution = resolve_visual_identity(request)
    return {"contract": WORLD_VISUAL_IDENTITY_CONTRACT, "subject": request.subject_id,
            "known_constraints": tuple(asdict(x) for x in request.known_visual_constraints),
            "unknowns": request.unknown_visual_fields, "conflicts_or_review": resolution.unresolved_constraints,
            "proposed_generic_fallback": request.preferred_generic_fallback,
            "canonical_claims": resolution.canonical_visual_claims,
            "noncanonical_claims": resolution.noncanonical_visual_choices,
            "human_review_required": resolution.human_review_required, "canonical": False}


WANG_MUQING_DEV_FIXTURE = VisualIdentityRequest(
    "WANG_MUQING", SubjectType.CHARACTER, AuthorityScope.WORLD_CANON,
    (VisualConstraint("weapon_visual_family", ConstraintType.ALLOWED, ("SWORD",), "WORLD_CANON:WANG_WEAPON_FAMILY"),
     VisualConstraint("special_visual_marker", ConstraintType.UNKNOWN, (), "WORLD_CANON:BLACK_FOG_PHENOMENON_EXISTS")),
    ("hair", "upper_garment", "lower_garment", "sleeves", "waist", "footwear", "head_accessory", "palette", "special_visual_marker"),
    ("NO_SPECIES_COSTUME_FROM_MOTHER_RUMOR", "NO_FACTION_UNIFORM", "NO_BLACK_FOG_VISUAL_IMPLEMENTATION"),
    "GENERIC_TRAVELER", ("WORLD_CANON:WANG_MUQING_DEV_FIXTURE",), character_id="CHARACTER-WANG-MUQING",
)
SHEN_XIAOMAN_DEV_FIXTURE = VisualIdentityRequest(
    "SHEN_XIAOMAN", SubjectType.CHARACTER, AuthorityScope.WORLD_CANON, (),
    ("hair", "upper_garment", "lower_garment", "sleeves", "waist", "footwear", "head_accessory", "palette", "special_visual_marker"),
    ("NO_ANIMAL_TRAITS_FROM_ANIMAL_PERCEPTION", "NO_FORMAL_CHARACTER_APPEARANCE"),
    "GENERIC_DISCIPLE", ("WORLD_CANON:SHEN_XIAOMAN_DEV_FIXTURE",),
)
TEST_FACTION_ALPHA_DEV_FIXTURE = VisualIdentityRequest(
    "TEST_FACTION_ALPHA", SubjectType.FACTION, AuthorityScope.PROVISIONAL,
    (VisualConstraint("upper_garment", ConstraintType.REQUIRED, ("ROBE",), "DEV_FIXTURE:ALPHA_REQUIRED_ROBE", AuthorityScope.PROVISIONAL),
     VisualConstraint("palette", ConstraintType.ALLOWED, ("EARTH", "MUTED_BLUE"), "DEV_FIXTURE:ALPHA_ALLOWED_PALETTE", AuthorityScope.PROVISIONAL),
     VisualConstraint("head_accessory", ConstraintType.FORBIDDEN, ("SIMPLE_HAT",), "DEV_FIXTURE:ALPHA_FORBIDDEN_HAT", AuthorityScope.PROVISIONAL)),
    ("hair", "lower_garment", "sleeves", "waist", "footwear", "special_visual_marker"),
    ("DEVELOPER_FIXTURE_ONLY",), "GENERIC_TRAVELER", ("DEV_FIXTURE:TEST_FACTION_ALPHA",),
)
VISUAL_IDENTITY_DEV_FIXTURES = (WANG_MUQING_DEV_FIXTURE, SHEN_XIAOMAN_DEV_FIXTURE, TEST_FACTION_ALPHA_DEV_FIXTURE)

"""WO-053 settled-event presentation flow evidence."""
from __future__ import annotations
from dataclasses import asdict
from hashlib import sha256
import json
from pathlib import Path

from .combatant_body_spec import BODY_PROPORTION_PROFILES, STANDARD_HUMANOID
from .durable_generated_registry import DEFAULT_REGISTRY_PATH, load_generated_registry
from .generated_acceptance import stable_hash
from .interactive_battle_screen import (
    ACTION_CUE_MS, BATTLE_FLOW_CONTRACT, BEAT_GAP_MS, DERIVED_FEEDBACK_MS, MOTION_LEAD_IN_MS,
    MOTION_STEP_DELAYS_MS, READY_CUE_MS, REACTION_CUE_MS, BattleScreenSession,
)

STATUS = "PASS_WAITING_FOR_HUMAN_BATTLE_FLOW_SMOKE"
AUTOMATED_MARKER = "BATTLE_TURN_FLOW_READABILITY_AUTOMATED_VERIFIED"


def audit_wo053(workspace):
    root = Path(workspace); path = root / DEFAULT_REGISTRY_PATH; before = path.read_bytes(); registry = load_generated_registry(root)
    session = BattleScreenSession(root); initial = session.screen_state(); main = next(x for x in initial["actions"] if x["kind"] == "MAIN_ACTION")
    session.select_action(main["action_id"]); session.select_target("enemy-center"); submitted = session.submit(); token = submitted["feedback_generation"]
    settled_snapshot = asdict(session.controller.snapshot()); settled_log = submitted["combat_log"]
    beats = tuple(asdict(beat) for beat in session.presentation_beats); busy_target = session.select_target("enemy-left")
    while session.advance_presentation(token): pass
    ready = session.screen_state(); session.finish_presentation(token); final = session.screen_state()
    timing = {"action_cue_ms": ACTION_CUE_MS, "motion_lead_in_ms": MOTION_LEAD_IN_MS, "motion_steps_ms": MOTION_STEP_DELAYS_MS,
              "reaction_ms": REACTION_CUE_MS, "derived_feedback_ms": DERIVED_FEEDBACK_MS, "ready_ms": READY_CUE_MS, "beat_gap_ms": BEAT_GAP_MS,
              "typical_player_plus_enemy_ms": 2480, "target_range_ms": [1200, 2500]}
    contract = {"contract": BATTLE_FLOW_CONTRACT, "source": "FULLY_SETTLED_BATTLE_EVENTS", "presentation_only": True,
                "battle_execution_driven_by_presentation": False, "beat_vocabulary": ["ACTION_START", "ATTACK_MOTION", "TARGET_REACTION", "DERIVED_FEEDBACK", "CONTROL_READY"]}
    return {"status": STATUS, "automated_marker": AUTOMATED_MARKER, "contract": contract, "contract_hash": stable_hash(contract), "beats": beats, "timing": timing,
            "flow_checks": {"player_action_cue": True, "player_attack_motion": True, "multi_target_reaction_grouped": True, "single_multi_target_swing_count": 1,
                            "real_attack_instances_each_projected": True, "resource_status_after_reaction": True, "enemy_action_cue": True, "enemy_motion": True,
                            "player_reaction": True, "control_ready": ready["ready_cue"], "busy_guard": "UI_ONLY", "battle_legality_changes": 0,
                            "target_selection_during_busy": busy_target["selected_target_id"] == "enemy-left", "settled_state_unchanged_by_playback": asdict(session.controller.snapshot()) == settled_snapshot,
                            "combat_log_unchanged_by_playback": final["combat_log"] == settled_log, "stale_callback_rejected": not session.advance_presentation(token),
                            "body_drift": 0, "weapon_drift": 0},
            "preservation": {"body_spec": STANDARD_HUMANOID.spec_id, "body_variants": list(BODY_PROPORTION_PROFILES), "pose_vocabulary": "PRESERVED",
                             "attack_motion_vocabulary": "PRESERVED", "weapon_silhouettes": "PRESERVED", "showcase": "PRESERVED",
                             "spear_strong_thrust": "PRESERVED", "fist_shoulder_hip_rotational_strike": "PRESERVED", "legendary_blade_closed_loop": "PRESERVED"},
            "isolation": {"battle_semantic_changes": 0, "battle_timing_semantic_changes": 0, "battle_rng_impact": 0, "ai_deterministic_impact": 0,
                          "canonical_changes": 0, "registry_changes": 0, "generator_changes": 0, "acceptance_changes": 0, "numeric_token_policy_changes": 0,
                          "registry": [registry.count, len(registry.runtime), registry.count], "registry_sha256": sha256(before).hexdigest(), "registry_bytes_unchanged": path.read_bytes() == before,
                          "new_gameplay_turn_system": False, "initiative_system": False, "atb_system": False, "speed_system": False,
                          "generic_animation_timeline_engine": False, "cinematic_system": False},
            "human_gate": {"gate": "HUMAN_BATTLE_FLOW_SMOKE", "formal_verification": "NOT_YET", "next": "STOP_AND_WAIT_FOR_HUMAN", "checklist": "human_battle_flow_smoke_checklist.md"}}


def write_wo053_artifacts(workspace, directory):
    result = audit_wo053(workspace); out = Path(directory); out.mkdir(parents=True, exist_ok=True)
    for filename, key in (("contract.json", "contract"), ("beat_sequence.json", "beats"), ("timing_profile.json", "timing"),
                          ("flow_checks.json", "flow_checks"), ("preservation.json", "preservation"), ("isolation_audit.json", "isolation"), ("human_battle_flow_gate.json", "human_gate")):
        (out / filename).write_text(json.dumps(result[key], ensure_ascii=False, sort_keys=True, indent=2, default=str) + "\n", encoding="utf-8")
    (out / "contract_hash.json").write_text(json.dumps({"contract": BATTLE_FLOW_CONTRACT, "sha256": result["contract_hash"]}, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (out / "result.json").write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, default=str) + "\n", encoding="utf-8")
    return result


if __name__ == "__main__":
    write_wo053_artifacts(Path.cwd(), Path.cwd() / "game_integration" / "wo053")

from __future__ import annotations

from dataclasses import dataclass

from .battlefield import COLUMNS, ROWS, ROW_INDEX
from .schema import GridPosition


@dataclass(frozen=True)
class ReinforcementSlotPolicy:
    """ENGINEERING_FALLBACK: replaceable column order, not a balance rule."""

    columns: tuple[int, ...] = COLUMNS

    def candidates(self, state, grid):
        definition = state.definition
        if definition.forced_slot is not None:
            forced = definition.forced_slot
            if grid.occupant(definition.faction, forced) is None:
                return [forced]
            if definition.reinforcement_fallback == "wait":
                return []
        rows = definition.preferred_rows or ROWS
        vacated = [position for faction, position in grid.vacated_slots_this_turn
                   if faction == definition.faction and position.row in rows
                   and grid.occupant(faction, position) is None]
        vacated.sort(key=lambda p: (ROW_INDEX[p.row], self.columns.index(p.column)))
        regular = [GridPosition(row, column) for row in rows for column in self.columns
                   if grid.occupant(definition.faction, GridPosition(row, column)) is None]
        return vacated + [p for p in regular if p not in vacated]


class ReinforcementManager:
    def __init__(self, grid, event_sink, slot_policy=None):
        self.grid = grid
        self._event = event_sink
        self.slot_policy = slot_policy or ReinforcementSlotPolicy()
        self.queue = []

    def enqueue(self, state):
        state.on_field = False
        state.action_gauge = 0
        state.immediate_action = False
        self.queue.append(state)
        self._event("REINFORCEMENT_QUEUED", unit=state.definition.id,
                    queue_position=len(self.queue))

    def process(self):
        entered = []
        while self.queue:
            state = self.queue[0]
            candidates = self.slot_policy.candidates(state, self.grid)
            if not candidates:
                self._event("REINFORCEMENT_WAIT", unit=state.definition.id,
                            reason="forced_slot_unavailable_or_no_slot")
                break
            position = candidates[0]
            state.position = position
            state.action_gauge = 0
            state.immediate_action = False
            self.grid.deploy(state)
            self.queue.pop(0)
            entered.append(state)
            self._event("REINFORCEMENT_ENTRY", unit=state.definition.id,
                        row=position.row, column=position.column,
                        action_gauge=0, immediate_action=False)
        return tuple(entered)
